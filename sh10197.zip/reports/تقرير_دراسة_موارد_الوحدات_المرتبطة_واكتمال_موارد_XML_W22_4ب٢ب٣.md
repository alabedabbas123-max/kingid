# مواردُ الوحداتِ المرتبطةِ إلى «`R`» واكتمالُ `XML` — دراسةُ 4ب٢‑ب٣ (1.0.166)

**القاعدةُ المنهجيةُ:** ما كانَ من `dex.zip` (خِطافُ `../settings.gradle`، و`project.properties` و`android.library.reference.N=`، و`.classpath`/`classpathentry`، و`/bin` و`/bin/jardex` و`/classes.jar` و`classmap.txt`، و`gen/` و`R.java` مع `aapt`) قُرِئَ **مبدأً** لا شيفرةً؛ لم تُنسَخْ ملفٌّ واحدٌ، ولم يُنقَلْ حرفٌ واحدٌ من المرجعِ إلى `app/src/main/java/abeed/`؛ أما `kay_id.zip` (٤٦٫٦ مليون بايت) فقُورِنَ: هو حمولةُ المرجعِ المفكوكةُ (خصائصُ `javac`، وجداولُ `androidx`، و`api-versions.xml`، و`resource_mapping.txt`، و`busybox`، و`android.jar.jet`) بلا `classes.dex` وبلا مصاردَ مصدّرةٍ؛ وسجلُّ تغييراتِهِ يحملُ سطرًا واحدًا يمسُّ البندَ: «‏`Fixed: Incorrect errors with libraries`» (سطرُ 6) — أي أنَّ المرجعَ عالجَ الخطأَ نفسه بإسكاتِهِ لا بإنتاجِهِ، وهو ما نلتزمُهُ: **علاماتُ حالةٍ لا أخطاءُ بناءٍ**. حُذِفَتِ النسخةُ المؤقتةُ بعدَ القراءةِ.

---

## أولًا: ما الذي كانَ ناقصًا (الفجوةُ `f5`)

- `almlk/XmlResourceIndex.java` (٣٥٨ سطرًا) يبني من **جذرٍ واحدٍ**: `build(File projectRoot)` — لا يرى `src/*/res` في وحدةٍ خارجَ الجذرِ، فيبقى `@drawable/…` و`@layout/…` داخلَ `XML` بلا هدفٍ، والذهابُ إليها يردُّ بـ «لا شيءَ هنا».
- `almlk/LibraryClassIndex.java` (٩٤٧ سطرًا) يصنع `R` التطبيقِ من `projectResources(moduleDir)` وحقولِ `AAR` (`data.rFields`)؛ **ولا يصنعُ `R` لوحدةٍ مرتبطةٍ**، فـ `import com.demo.lib.R;` في `sources` الوحدةِ أو في التطبيقِ لا يُحَلُّ، ولا تُرى أسماءُ مواردِ الوحدةِ في `resourceNames(type)` التي يستدعيها `XmlCompletionEngine:634`.
- `GradleProjectModules.issues()` موجودةٌ (نوعُها `project`/`include` مع `path` و`file` و`line` و`reason`) ولا تُعرَضُ في مكانٍ؛ فالوحدةُ غيرُ القابلةِ للحلِّ تصمتُ صمتًا تامًّا.

## ثانيًا: دلالةُ `R` كما هي في النظامِ (لا كما نشتهي)

من `gradle-wrapper` و`AGP:` منذ **`AGP` 8.0** صارَ `android.nonTransitiveRClass = true` افتراضًا، أي أنَّ `R` كلِّ وحدةٍ يحوي **مواردَها هي** فقط؛ والوحدةُ لا ترى مواردَ وحداتِها الفرعيةِ إلا بأسمائِها الموسّعةِ. في `AGP` 7.1 وأقلَّ كانت المواردُ تُدمَجُ تصاعديًا في `R` التابعِ. مؤسستُنا **تطابقُ هذا الحكمُ فعلًا**: `LibraryClassIndex.transitiveR(model)` تقرأُ `android.nonTransitiveRClass` الصريحَ من `gradle.properties`، وإلا تعتبرُ الدمجَ قائمًا إذا كانَ رقمُ `AGP` الرئيسي `< 8`. وعليه تُبنى الطبقتانِ 2 و3 بلا اختراعٍ: `R` الوحدةِ أساسيٌّ دائمًا، والدمجُ في `R` التطبيقِ مشروطٌ بـ `transitiveR`.

## ثالثًا: مبدأُ المرجعِ كما فُهِمَ، وبناؤُنا عليه

في `AIDE` كانت الوحدةُ المرتبطةُ تدخلُ مسارًا في `.classpath` ومجلدًا في `classpathentry` ومخرجًا في `/bin`، ثمَّ يمرُّ كلُّ ذلكَ إلى `javac -classpath/-sourcepath`، وتُبنى مواردُ المكتبةِ إلى `gen/R.java` بأداةِ المواردِ (`aapt`). أي: **الوحدةُ موردٌ من مواردِ البناءِ، لا مجلدٌ يُعرَضُ في الشجرةِ**. مقابلُنا الصحيحُ لذلكَ ليسَ توليدَ `R.java` (بناءٌ قسريٌّ — ممنوعٌ بندًا)، بل **طبقةُ فهرسٍ**: نصنعُ كتلةَ أصنافِ `R` في الذاكرةِ من المواردِ المقروءةِ على القرصِ، ونمرّرُها في القناةِ نفسِها التي تمرُّ منها أصنافُ `android.jar`. وهذا ما يفعلُهُ `rClassBlock(...)` مع `AAR` اليومَ؛ فالواجبُ هنا توسيعُ مصدرِ البياناتِ لا اختراعُ قناةٍ جديدةٍ.

## رابعًا: الطبقاتُ الستُّ (كلُّها في هذه المرحلةِ)

1. **`GradleProjectModules.resourceDirs()`** — `src/<sourceSet>/res` لكلِّ وحدةٍ **موصولةٍ** (لا `res` الجذرَ القديمَ هنا؛ يُضافُ فقط إن لم توجد حديثةٌ، قياسًا على `projectResources`)؛ القائمةُ من `forAnalysis()` ف `Units` غيرُ الواصلةِ لا تُفحَصُ؛ `dedupe` بـ `getCanonicalPath`، وإسقاطُ ما كانَ تحتَ الجذرِ (مُفهرَسٌ أصلًا)، وسقفُ `MAX_SOURCE_DIRS=36`، وبلا `res` داخلِ `test/androidTest/debug` (نفسُ استبعادِ `projectResources`).
2. **مواردُ الوحدةِ إلى `LibraryClassIndex`**: نوعٌ داخليٌّ `ModuleResources{dir, rPackage, set}` يحمله `Request` (بجانبِ `moduleJars`/`moduleNodes`)؛ حزمةُ `R` تُقرأ من `NAMESPACE` في `build` الوحدةِ، وإلا `package=` في `AndroidManifest.xml` — وهي الدوالُ نفسُها التي يستعملُها `appPackage(model)`؛ عند `install` تُبنى لكلِّ وحدةٍ كتلةُ `rClassBlock(pkg, rFieldsOf(set), false)` وتُضافُ كتلُها إلى `blocks`، وأسماءُها تُدمَجُ في `libraries` (فتراهُ `resourceNames(type)` للإكمالِ في `XML`).
3. **الدمجُ التصاعديُّ مشروطٌ**: إن كانت `request.transitiveR` تُضافُ حقولُ وحداتِ المشروعِ إلى `allRFields` (ومنها إلى كتلةِ `R` التطبيقِ)؛ وإلا يبقى `R` التطبيقِ نقيًّا — كما يفعُلُ البناءُ الحقيقيُّ. يُخزَّنُ `transitiveR` في `Request` (كان محليًّا في `of`).
4. **تحديثُ الخلفيةِ**: `refreshProject` يعيدُ قراءةَ `projectResources(وحدة.dir)` لكلِّ وحدةٍ، ويحفظُ `modulesSignature`؛ تغيّرُ التوقيعِ وحدهُ يستدعي `install(snapshot.request, …)` من جديدٍ (إعادةُ بناءِ طبقةِ المكتباتِ)، محكومًا بسقفِ `PROJECT_REFRESH_MS=3000` نفسِهِ. لا خزانةَ مركزيةَ للمواردِ ولا حلقةَ فهرسةٍ ثانيةَ — البوابةُ «لا خريطةَ مواردَ مجمّعة» تبقى ساريةً.
5. **اكتفاءُ `XML`**: حِملُ `XmlResourceIndex.build(File projectRoot, List<File> extraRoots)` (القديمُ يؤدّي إليه بقائمةٍ فارغةٍ)؛ `findResDirs(extra, 1)` يعيدُ استخدامَ الماشي نفسِهِ بلا حدودٍ جديدةٍ. و`BrowserPager` يتلقّى الجذورَ الزائدةَ بنفسِ خيطِ 1.0.165: `setLinkedResourceRoots(File projectRoot, Supplier<List<File>>)` تُحَلُّ كسولًا على `symbolWorker`، وتُربَطُ بـ `canonicalPath(جذرِ المشروعِ)`، ويستدعيها `resolveXmlResourceAsync` في `build(root, dirs)`. **يُمنَعُ** تمريرُ `GradleBuildModel` أو بناءِ قائمةٍ على خيطِ الواجهةِ (بوّابتانِ تَحَرَّيانِ).
6. **علاماتُ الحالةِ لا الأخطاءُ**: `BuildDiagnosticsParser.moduleIssue(file, line, message, sourceLine)` تصنعُ `BuildError` بـ `warning = true` و`code = "MODULE"`؛ و`MainActivity` تبني `moduleDiagnostics` من `model.projectModules.issues()` بعدَ كلِّ دورةِ حلٍّ، وتدمجُها خامسًا في `publishProjectDiagnostics`. **لمسةُ `isError()` لا تتغيّرُ**: العلامةُ تحذيرٌ، فالبانرُ والشارةُ لا يتحوّلانِ إلى «فشلٍ»، ولا يُفتَحُ حوارٌ ولا يُجبَرُ بناءٌ؛ والنقرُ على مصدرٍ خارجِ الجذرِ يخضعُ لقاعدةِ `W21` (إن لم يوجدْ مُدخَلٌ في المتصفّحِ: تنبيهٌ لا تنقّلٌ أعمى).

## خامسًا: العُقدُ التي قُطِعَت قبلَ الكتابةِ

- لا `listFiles` داخلَ `GradleProjectModules` (بوابةٌ): تُقرأُ المواردُ من `LibraryClassIndex.projectResources` وحدهُ، و`resourceDirs()` تُعيدُ مساراتٍ فقط.
- لا استدعاءُ بناءٍ لأجلِ `R.java` ولا لمسُ `build/intermediates` (بوّابتانِ قائمتانِ).
- لا `*-sources.jar`/`*-javadoc.jar` في أيِّ قناةٍ (بوّابةٌ عامةٌ).
- لا حلقةَ فهرسةٍ ثانيةَ للمواردِ: الدورةُ تمرُّ عبرَ `install` القائمِ، والكتلةُ الواحدةُ تُبنى بالدوالِ القائمةِ.
- خيطُ `installAsync` يبقى وحيدًا في `DependencyCycle` (بوابةٌ قائمةٌ)، والمواردُ تُقرأ داخلَ `Request.of` عليهِ.
- `ProjectLibraries.fingerprint` يتوسّعُ بتوقيعِ مواردِ الوحداتِ، فيُعيدُ الدورةَ الصامتةَ عندَ تعديلِ موردٍ في وحدةٍ (`offline:` لا تنزيلَ ولا إبطاءَ)، مع تمييزِ `#offline@` القائمِ.

## سادسًا: بواباتُ القفلِ (تُضافُ قبلَ التوقيعِ)

`qa.sh`: (1) `resourceDirs`/`MAX_SOURCE_DIRS`/`getCanonicalPath`/استبعادُ `test` في `GradleProjectModules`؛ (2) لا `listFiles` فيه؛ (3) `ModuleResources` + `rClassBlock(` ≥ 3 في `LibraryClassIndex` (تطبيقٌ + `AAR` + وحدةٌ)؛ (4) `transitiveR` مخزونةٌ في `Request` ومستعملةٌ في `install`؛ (5) توقيعُ الوحداتِ في `refreshProject`؛ (6) توقيعاُ `XmlResourceIndex` (1‑`arg` → 2‑`arg`) مع `findResDirs(extra, 1)`؛ (7) خِطمُ `BrowserPager` (`supplier`، ربطٌ بـ `canonicalPath`، مناداةُ `build(root, `)؛ (8) `MainActivity` يمرّرُ مُورّدًا كسولًا من `scanned.projectModules` فقط؛ (9) `moduleIssue` بـ `warning` + دمجٌ خامسٌ في النشرِ؛ (10) `isError()` كما هو بلا «`MODULE`».
`RegressionSuite.stage137()`: `resourceDirs` (خارجُ الجذرِ، `dedupe`، `test` مُستبْعَد، سقفٌ، وحدةٌ غيرُ موصولةٍ لا تظهرُ)، مواردُ الوحدةِ ⇒ كتلةُ `R` بحزمةِ الوحدةِ وأسماءُها في `resourceNames`، الدمجُ تصاعديًّا فقط عندما `transitiveR`، `XmlResourceIndex.build(root, extra)` يرى `@drawable` الوحدةِ، `moduleIssue` تحذيرٌ بـ `line` صحيحٌ، وبوابةُ «لا خِطمَ في `almlk`».
`acceptance.sh` [24]: «موردٌ خارجَ الجذرِ يُرى»، «لا قسْرَ بناءٍ»، «لا خِطمةِ نموذجٍ في الواجهةِ»، «تحذيرٌ لا خطأٌ».

## سابعًا: ما لن نفعلَهُ في هذه المرحلةِ

لا توليدَ `R.java` على القرصِ، ولا قراءةَ `build/intermediates`، ولا فهرسةَ مواردِ وحداتٍ غيرِ موصولةٍ أو `assets/` أو `res` داخلِ `AAR` مرّةً أخرى، ولا شاشةَ إدارةِ وحداتٍ، ولا تبديلَ تصميمِ العرضِ (اللوحةُ والـ `PopupMenu` كما هما)، ولا مستمِعًا لـ `AndroidManifest.xml` (تلكَ 4ب٢‑ب٤).


---

## تتمّةٌ بعدَ التنفيذِ (لا تُمحى القراءةُ السابقةُ — تُصحَّحُ الأسماءُ)

- الاسمُ المُصدَّرُ هو ‏`resourceRoots()` لا ‏`resourceDirs()`: يُعادُ **مجلدُ الوحدةِ** لأنَّ ‏`XmlResourceIndex.collectResDirs` يعرفُ ‏`src/<set>/res` و`res` ويحترمُ استبعادَهُ، فتكرارُ المشيِ هنا ماكينةٌ ثانيةٌ بلا فائدةٍ.
- **لا بصمةَ مواردَ في ‏`ProjectLibraries.fingerprint`**: كانَ في الخطةِ، وتركناهُ — إعادةُ دورةِ الحلِّ (ومعَها جردُ ‏`libs/`) لأجلِ تعديلِ ‏`res` أثقلُ من نفْعِها، و‏`onFileSaved` يستدعي ‏`refreshProjectResources` فعلًا، وسؤالُ ‏`resourceNames` يوقظُ ‏`refreshProject` بعدَ ‏`PROJECT_REFRESH_MS`.
- كتلةُ ‏`R` الوحدةِ تُبنَى بعلامةِ «مؤقَّتٌ» (‏`rClassBlock(..., true)`) لا بعلامةِ ‏`AAR` (‏`false`): مَن بنيأعضاءَهُ من شجرةٍ يقرؤُها لا يدّعي الكمالَ، وإلا عادَ الخطأُ الذي أصلحَهُ المرجعُ بإسكاتِهِ.
- علامةُ الوحدةِ تُصنعُ في ‏`ProjectDiagnostic.fromModuleIssues` لا في ‏`MainActivity`: بوابةُ 4ب٢‑ب١ تمنعُ أن تسمّي الطبقةُ العليا الطبقةَ الصافيةَ، والحارسُ بقيَ صفرًا.
