package com.almlkid.ui.build;

import almlk.ConsoleBuffer;
import android.content.Context;
import android.graphics.Typeface;
import android.text.Editable;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * مخرَجُ البناءِ والعمليّاتِ الطويلةِ — الوصفُ الذي يسمّيهِ تخطيطُ {@code outputconsole.xml}.
 *
 * <p>التخطيطُ يَنبُو (‏InflateException) إن لم يكنِ الصنفُ موجودًا باسمِهِ، فهو إذنْ {@code TextView}
 * كامِلٌ بثلاثةِ بنّائينَ كما يستدعيهِ المِنفَاخُ، لا مُسمًّى بلا مسمًّى. وسِمتُهُ ثلاثٌ: خطٌّ ثابتٌ،
 * بلا التفافٍ (الاتّلافُ الأفقيُّ يَقبَلُهُ {@code HorizontalScrollView} المُصمَّم)، وتحديدٌ للنسخِ.
 *
 * <p>والسياسةُ كلُّها في {@link ConsoleBuffer} الصرفةِ (سقفُ المحارفِ، وحدُّ التخفيفِ، وحدُّ السطرِ،
 * وإعلانُ القطعِ) لا هنا: لا رقمٌ مُضمَّرٌ في واجهةٍ، ولا خيطَ ولا ملفَّ — فالمِحوَرُ أنَّ مخزنَ
 * TextView يَتضخّمُ مع كلِّ سطرِ إخراجٍ حتى تُنفَدَ ذاكرةَ التطبيقِ على الجهازِ. لذا يُفرَضُ
 * {@code BufferType.SPANNABLE} في {@code setText} العامّةِ — والدالّةُ الحاملةُ للنوعِ محجوبةٌ في
 * المنصّةِ فلا تُورَثُ إلى التطبيقاتِ، والاعتمادُ عليها يُعطِّلُ البناءَ؛ وبِذا يبقى المخزنُ
 * {@code Editable} دائمًا فيُلحَقُ فيهِ بلا نُسخةٍ لكلِّ سطرٍ.
 */
public class OutputConsole extends TextView {

  public OutputConsole(Context context) {
    this(context, null);
  }

  public OutputConsole(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public OutputConsole(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    setTypeface(Typeface.MONOSPACE);
    setHorizontallyScrolling(true);
    setTextIsSelectable(true);
  }

  /** النصُّ كاملًا: النوعُ مُفرَضٌ كما في الوثيقةِ، ثمَّ السقفُ ثمَّ تتبّعُ الذيلِ. */
  @Override
  public void setText(CharSequence text, BufferType type) {
    super.setText(text, BufferType.SPANNABLE);
    trimToCap();
    followTail();
  }

  /**
   * الإلحاقُ هو مسارُ البناءِ كلِّهِ سطرًا سطرًا: يَمُرُّ عبرَ {@code TextView.append} ثمَّ يُقلَّمُ
   * ويُتبِعُ ذيلَهُ — فبدونَ التخفيفِ لا يَنفَدُ ذاكرةً فحسب، بل يَبطأُ كلُّ سطرٍ أكثرَ من سابقِهِ.
   */
  @Override
  public void append(CharSequence text, int start, int end) {
    super.append(text, start, end);
    trimToCap();
    followTail();
  }

  /**
   * التخفيفُ عندَ السقفِ بمسارَيْنِ لا مسارٍ واحدٍ: حيثُ كانَ المخزنُ قابلَ التحريرِ قُطِعَت مُقدّمتُهُ
   * في محلَّها (بلا نُسخةِ ميغابايتٍ مع كلِّ سطرٍ)، وحيثُ لم يكنْ أُعيدَ ضبطُهُ بالنافذةِ المحفوظةِ.
   * والقطعُ يبدأُ من حدِّ سطرٍ كاملٍ ({@link ConsoleBuffer#firstLineStart}) لا من ذيولِهِ.
   */
  private void trimToCap() {
    CharSequence current = getText();
    if (current == null || !ConsoleBuffer.needsTrim(current.length())) return;
    if (current instanceof Editable) {
      int from = ConsoleBuffer.firstLineStart(current, ConsoleBuffer.overflow(current.length()));
      if (from > 0 && from < current.length()) {
        ((Editable) current).replace(0, from, ConsoleBuffer.CUT_MARK, 0,
            ConsoleBuffer.CUT_MARK.length());
        return;
      }
      return; // لا سطرٌ كاملٌ في الذيلِ: لا قطعَ هذهِ المرّةَ، لا قطعٌ في الهواءِ
    }
    setText(ConsoleBuffer.trimmed(current.toString()));
  }

  /** آخرُ سطرٍ ظاهرٌ دائمًا: البناءُ يَجري أمامَ عينِ المستخدمِ لا تحتَها. */
  private void followTail() {
    CharSequence current = getText();
    if (current == null || current.length() == 0) return;
    bringPointIntoView(current.length() - 1);
  }
}
