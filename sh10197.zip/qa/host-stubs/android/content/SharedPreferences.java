package android.content;

/**
 * بديل اختياري لواجهة تفضيلات أندرويد — يُصرَّف بدل android.jar في مجموعة الانحدار فقط.
 *
 * <p>لا يمسّ الشيفرة المشحونة: المسار الإنتاجي يستخدم أندرويد الحقيقي. موجود لأن
 * {@code almlk.CodeStyle} يقرأ التفضيلات، والمجموعة تحتاج تخزينًا قابلًا للضبط.
 */
public interface SharedPreferences {
  String getString(String key, String defValue);

  boolean getBoolean(String key, boolean defValue);

  boolean contains(String key);

  Editor edit();

  interface Editor {
    Editor putString(String key, String value);

    Editor putBoolean(String key, boolean value);

    void apply();
  }
}
