package android.preference;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;
import java.util.Map;

/**
 * بديل اختياري يكشف مخزنًا قابلًا للضبط — منفذ الاختبار الوحيد في مجموعة الانحدار.
 *
 * <p>الشيفرة المشحونة تستدعي {@code PreferenceManager.getDefaultSharedPreferences} نفسها؛
 * الفرق هنا أن المخزن خريطة في الذاكرة بدل ملف على القرص.
 */
public class PreferenceManager {

  /** مخزن التفضيلات الاختباري. تُصفِّره المجموعة قبل كل قسم. */
  public static final Map<String, String> store = new HashMap<>();
  public static final Map<String, Boolean> boolStore = new HashMap<>();

  public static void reset() {
    store.clear();
    boolStore.clear();
  }

  public static SharedPreferences getDefaultSharedPreferences(Context context) {
    return new SharedPreferences() {
      @Override
      public String getString(String key, String defValue) {
        return store.containsKey(key) ? store.get(key) : defValue;
      }

      @Override
      public boolean getBoolean(String key, boolean defValue) {
        return boolStore.containsKey(key) ? boolStore.get(key) : defValue;
      }

      @Override
      public boolean contains(String key) {
        return store.containsKey(key);
      }

      @Override
      public Editor edit() {
        return new Editor() {
          @Override
          public Editor putString(String key, String value) {
            store.put(key, value);
            return this;
          }

          @Override
          public Editor putBoolean(String key, boolean value) {
            boolStore.put(key, value);
            return this;
          }

          @Override
          public void apply() {}
        };
      }
    };
  }
}
