package android.view;

/** بديل اختياري بثوابت رموز المفاتيح الحقيقية — لمجموعة الانحدار فقط. */
public class KeyEvent {
  public static final int ACTION_DOWN = 0;
  public static final int KEYCODE_0 = 7;
  public static final int KEYCODE_9 = 16;
  public static final int KEYCODE_A = 29;
  public static final int KEYCODE_K = 39;
  public static final int KEYCODE_S = 47;
  public static final int KEYCODE_Z = 54;
  public static final int KEYCODE_TAB = 61;
  public static final int KEYCODE_SPACE = 62;
  public static final int KEYCODE_ENTER = 66;
  public static final int KEYCODE_F1 = 131;
  public static final int KEYCODE_F5 = 135;
  public static final int KEYCODE_F12 = 142;
  public static final int KEYCODE_DPAD_UP = 19;
  public static final int KEYCODE_DPAD_DOWN = 20;
  public static final int KEYCODE_DPAD_LEFT = 21;
  public static final int KEYCODE_DPAD_RIGHT = 22;
  public static final int KEYCODE_DPAD_CENTER = 23;
  public static final int KEYCODE_DEL = 67;
  public static final int KEYCODE_MOVE_HOME = 122;
  public static final int KEYCODE_MOVE_END = 123;
  public static final int KEYCODE_PAGE_UP = 92;
  public static final int KEYCODE_PAGE_DOWN = 93;
  public static final int KEYCODE_ESCAPE = 111;
  public static final int KEYCODE_FORWARD_DEL = 112;
  public static final int KEYCODE_1 = 8;
  public static final int KEYCODE_5 = 12;
  public static final int KEYCODE_COMMA = 55;
  public static final int KEYCODE_SEMICOLON = 74;
}
