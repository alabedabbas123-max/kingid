package android.os;

/** Executes posted callbacks inline in the source-only regression suite. */
public final class Handler {
  public Handler(Looper looper) {}

  public boolean post(Runnable callback) {
    if (callback == null) return false;
    callback.run();
    return true;
  }
}
