package android.os;

/** Minimal main-loop token for the source-only regression suite. */
public final class Looper {
  private static final Looper MAIN = new Looper();

  private Looper() {}

  public static Looper getMainLooper() {
    return MAIN;
  }
}
