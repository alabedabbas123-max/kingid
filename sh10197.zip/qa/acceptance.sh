#!/usr/bin/env bash
# القبول الشامل للحزمة — المرحلة التاسعة.
#
# يفحص **الناتج النهائي** لا نجاح الترجمة: المانيفست، الموارد، الـdex، التوقيع،
# أرقام النسخة، وسلامة الاستبعادات في zip المصدر.
#
#   ./qa/acceptance.sh <apk> <zip>
#
# يخرج 0 عند اجتياز كل بنود القبول، و1 عند سقوط أي بند.

set -uo pipefail

APK="${1:-}"
ZIP="${2:-}"
# مساران مطلَقان: الفحوص تنفّذ cd مؤقتة (لفكّ الـdex) فلا يجوز الاعتماد على نسبي.
case "$APK" in /*) ;; *) APK="$PWD/$APK" ;; esac
case "$ZIP" in /*) ;; *) ZIP="$PWD/$ZIP" ;; esac
if [ -z "$APK" ] || [ -z "$ZIP" ]; then
  echo "الاستخدام: ./qa/acceptance.sh <apk> <zip>" >&2; exit 2
fi
cd "$(dirname "$0")/.."

# ── إيجاد build-tools ────────────────────────────────────────────────────
BT=""
for cand in "${ANDROID_HOME:-}/build-tools"/* /home/user/.cache/android-sdk/build-tools/*; do
  [ -x "$cand/aapt2" ] && BT="$cand"
done
if [ -z "$BT" ]; then echo "✘ لم يُعثر على aapt2 (ANDROID_HOME؟)" >&2; exit 2; fi

PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✔ $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  ✘ $1 — $2"; }
note() { echo "  · $1"; }

echo
echo "═══ القبول الشامل ═══"
VERSION=$(cat VERSION 2>/dev/null || echo "?")
UNDER=$(echo "$VERSION" | tr '.' '_')

echo
echo "[1] تطابق النسخة والتسمية"
[ "$VERSION" != "?" ] && ok "VERSION = $VERSION" || bad "VERSION" "غير مقروء"
case "$(basename "$APK")" in
  shima_${UNDER}.apk) ok "اسم الـAPK يطابق النسخة" ;;
  *) bad "اسم الـAPK" "$(basename "$APK") ≠ shima_${UNDER}.apk" ;;
esac
case "$(basename "$ZIP")" in
  shima_${UNDER}.zip) ok "اسم الـzip يطابق النسخة" ;;
  *) bad "اسم الـzip" "$(basename "$ZIP") ≠ shima_${UNDER}.zip" ;;
esac
ZIPVER=$(unzip -p "$ZIP" VERSION 2>/dev/null || echo "?")
[ "$ZIPVER" = "$VERSION" ] && ok "VERSION داخل الـzip = $VERSION" \
  || bad "VERSION داخل الـzip" "$ZIPVER ≠ $VERSION"

echo
echo "[2] التوقيع — يجب أن تبقى الشهادة نفسها عبر النسخ (وإلا تعذّر التحديث)"
CERT=$("$BT/apksigner" verify --print-certs "$APK" 2>/dev/null \
       | grep -o 'certificate SHA-256 digest: [0-9a-f]*' | head -1 | awk '{print $NF}')
EXPECTED=40655b0b0a05c83a3ae0322df1a8fd4410fda71480005ebb6032f4c9592dc4a6
[ "$CERT" = "$EXPECTED" ] && ok "شهادة التوقيع مطابقة لـ1.0.60+" \
  || bad "شهادة التوقيع" "${CERT:-لم تُقرأ} ≠ $EXPECTED"
"$BT/apksigner" verify "$APK" >/dev/null 2>&1 && ok "التوقيع صالح" || bad "التوقيع" "غير صالح"

echo
echo "[3] هوية الحزمة"
BADGING=$("$BT/aapt2" dump badging "$APK" 2>/dev/null | head -1)
echo "$BADGING" | grep -q "name='com.shima.demo'" && ok "اسم الحزمة com.shima.demo" \
  || bad "اسم الحزمة" "$BADGING"
note "$BADGING" | sed 's/^  · //'

echo
echo "[4] الأنشطة مُسجَّلة في المانيفست (لا صنف يُستدعى بلا تسجيل)"
TREE=$("$BT/aapt2" dump xmltree --file AndroidManifest.xml "$APK" 2>/dev/null)
# عيبٌ كامِنٌ في البوّابةِ: قسمَا ‏1.0.181 و‏1.0.158 كانا يقرآنِ «MANIFEST» ولا مُعرِّفَ
# له في السطرِ العلويِّ، فكان «set -u» يُسكِتُهما بلا نتيجةٍ (سقطَ الحُكمُ لا الحُجَّةُ). يُثبَّتُ
# هنا من مَسحِ Manifest نفسِهِ، فتُقيَسُ الصفتانِ فعلًا: صِفرُ خدمةِ بقاءٍ، وعَدَدُ الأذوناتِ.
MANIFEST="$TREE"
for act in MainActivity AboutActivity ThemeActivity CodeStyleActivity DesignerActivity; do
  if [[ "$TREE" == *"com.shima.demo.$act"* ]]; then ok "النشاط $act مُسجَّل"
  else bad "النشاط $act" "غير موجود في المانيفست"; fi
done
if [[ "$TREE" == *"com.almlkid.ui.preferences.AlmlkPreferencesActivity"* ]]; then ok "النشاط AlmlkPreferencesActivity مُسجَّل"
else bad "النشاط AlmlkPreferencesActivity" "غير موجود في المانيفست"; fi
EXPORTED=$(echo "$TREE" | grep -c 'android:exported.*=true' || true)
note "أنشطة exported=true: $EXPORTED"

echo
echo "[5] كل صنف com.shima.demo موجود في الـdex فعلًا"
TMP=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP" 2>/dev/null
DEXN=$(ls "$TMP"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
[ "$DEXN" -gt 0 ] && ok "استُخرجت $DEXN ملفات dex" || bad "استخراج الـdex" "صفر ملفات"
MISSING=0
for cls in MainActivity AboutActivity CodeStyleActivity CommandCenter LocaleAwareActivity LocaleAwarePreferenceActivity; do
  # grep -l بلا -q: الأخير يخرج مبكرًا فيقتل grep بـSIGPIPE ومع pipefail يسقط الأنبوب كاذبًا.
  HITS=$(grep -l "Lcom/shima/demo/$cls;" "$TMP"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "الصنف $cls" "غير موجود في أي dex"; MISSING=$((MISSING+1)); fi
done
[ $MISSING -eq 0 ] && ok "أصناف com.shima.demo الأساسية في الـdex"
rm -rf "$TMP"

echo
echo "[6] الموارد: لا مرجع مكسور (الترجمة وحدها لا تكشف هذا)"
RES=$("$BT/aapt2" dump resources "$APK" 2>/dev/null)
for r in layout/activity_code_style layout/activity_settings string/code_style_title id/settingsCodeStyle menu/main_options_menu layout/errorbrowser layout/errorbrowser_entry layout/error_popup layout/error_popup_entry id/errorPopupText string/menu_fix_imports string/menu_add_import string/ui_diagnostic_ambiguous_type; do
  # مطابقة بـ[[ ]] لا بأنبوب: RES ضخم (آلاف الموارد) وgrep -q كان يقتله بـSIGPIPE.
  if [[ "$RES" == *"$r"* ]]; then ok "المورد $r موجود"; else bad "المورد $r" "غير موجود"; fi
done
if [[ "$RES" == *'() "Application"'* && "$RES" == *'(ar) "التطبيق"'* ]]; then
  ok "موارد عنوان الإعدادات موجودة بالإنجليزية والعربية"
else
  bad "موارد عنوان الإعدادات" "الإنجليزية أو العربية غير معبأة في APK"
fi

echo
echo "[7] zip المصدر: لا تسريب"
# -Z1 يُدرج الأسماء وحدها: ترويسة `unzip -l` تحمل المسار المطلق للـzip نفسه،
# ومساره يحوي /deliverables/ فيُطابق نمط الاستبعاد كذبًا.
ZLIST=$(unzip -Z1 "$ZIP" 2>/dev/null)
# البوّابةُ على قائمةِ الـzip من ملفٍّ لا من أنبوبٍ: grep -q تَخرُجُ عندَ أوّلِ مطابقةٍ، فيُقتَلُ printf بـSIGPIPE،
# وset -o pipefail يَنسِبُ فشلَ printf إلى الفحصِ كلِّهِ — بصماتٌ تَسقُطُ ثمَّ تَقيامُ من تلقائِها حسبَ جَدولةِ القراءةِ.
# ملفٌّ واحدٌ بالقراءةِ من stdin يُلغي التَّسابقَ في المواضعِ التسعةِ والستّينَ بلا تغييرِ دلالةِ المطابقةِ.
ZLISTF=$(mktemp)
printf '%s\n' "$ZLIST" > "$ZLISTF"
zq() { grep "$@" < "$ZLISTF"; }
# «build» اسمُ حزمةِ شيفرةٍ (com/almlkid/ui/build) كما اسمُ مجلدِ مخرجاتِ Gradle:
# ما كانَ تحتَ /src/ شيفرةٌ فلا يُحاسَبُ تسريبًا، وما سوى ذلكَ من مخرجٍ فالتسريبُ قائمٌ.
LEAK=$(printf '%s\n' "$ZLIST" | grep -Ev '/src/' \
  | grep -Ec 'local\.properties|/build/|/\.gradle/|/deliverables/|/qa/\.out/' || true)
[ "$LEAK" = "0" ] && ok "لا local.properties ولا build ولا .gradle ولا deliverables" \
  || bad "تسريب في الـzip" "$LEAK مدخلًا مستبعدًا موجودًا"
if [[ "$ZLIST" == *"app/src/main/java/almlk/CodeStyle.java"* ]]; then
  ok "المصادر موجودة في الـzip"
else bad "المصادر" "almlk/CodeStyle.java غائب"; fi
if [[ "$ZLIST" == *"qa.sh"* ]]; then
  ok "مجموعة الانحدار داخل الـzip (تنتقل مع المشروع)"
else bad "qa.sh" "غير موجود في الـzip"; fi
if [[ "$ZLIST" == *"qa/acceptance.sh"* ]]; then
  ok "سكربت القبول داخل الـzip"
else bad "qa/acceptance.sh" "غير موجود في الـzip"; fi
# completeness, not just exclusion: every source file in the tree must be in the zip,
# وإلا صُنعَتِ الحزمةُ بصنفٍ ناقصٍ لا يراه أحدٌ حتى ينهارَ الجهازُ
SRCJAVA=$(find app/src/main/java -name "*.java" | sort)
ZIPJAVA=$(printf '%s\n' "$ZLIST" | grep -E '^app/src/main/java/.*\.java$' | sort)
MISSJAVA=$(comm -23 <(printf '%s\n' "$SRCJAVA") <(printf '%s\n' "$ZIPJAVA") | grep -c . || true)
if [ "$MISSJAVA" = "0" ]; then
  ok "كلُّ ملفِ شيفرةٍ في الشجرةِ داخلُ الحزمةِ ($(printf '%s\n' "$SRCJAVA" | grep -c .) ملفًّا) — لا صنفٌ يُبنى ولا يُصدَّرُ"
else bad "نقصُ الحزمةِ المصدريّةِ" "$MISSJAVA ملفًّا في الشجرةِ لا في الحزمةِ"
fi
if [[ "$ZLIST" == *"app/src/main/java/com/almlkid/ui/build/OutputConsole.java"* ]]; then
  ok "صنفُ المخرَجِ المُؤلَّفُ جديدًا مُصدَّرٌ مع مَن يسمّيهِ من تخطيطٍ"
else bad "OutputConsole.java" "غائبٌ عن الحزمةِ — يبقى العطلُ حيًّا لمن يفتحُ المصدرَ"; fi

echo
echo "[8] بنية صفحة الأخطاء (W1): موارد المرجع مستعمَلة فعلًا، ولا لون مقنَّن"
PANEL=app/src/main/java/com/almlkid/ui/SequentialPanelHost.java
# region الدالة وحدها: الفحص على الملف كاملًا كان يسمح بلون مقنَّن في صفحة أخرى يمرّ كذبًا
PREGION=$(awk '/private View createErrorsPage/,/private View createSearchPage/' "$PANEL" 2>/dev/null || true)
if [ -z "$PREGION" ]; then
  bad "createErrorsPage" "لم تُعثر — تغيّر اسم الدالة؟"
else
  if [[ "$PREGION" == *"R.layout.errorbrowser"* ]]; then
    ok "صفحة الأخطاء تستنسخ errorbrowser.xml (لم يبقَ موردًا ميتًا)"
  else bad "errorbrowser.xml" "غير مستنسخ في createErrorsPage"; fi
  if [[ "$PREGION" == *"errorbrowserErrorList"* ]]; then
    ok "القائمة مأخوذة من @id/errorbrowserErrorList (CustomKeysListView)"
  else bad "القائمة" "لم تُؤخذ من errorbrowserErrorList"; fi
  if [[ "$PREGION" == *"R.layout.browser_header"* && "$PREGION" == *"addHeaderView"* ]]; then
    ok "الرأس داخل القائمة (browser_header + addHeaderView) كما في المرجع"
  else bad "رأس القائمة" "browser_header/addHeaderView مفقود"; fi
  if [[ "$PREGION" == *"browserHeaderMenuButton"* && "$PREGION" == *"View.GONE"* ]]; then
    ok "زر قائمة الرأس محجوب كالمرجع (setVisibility(8) مقابلًا)"
  else bad "زر الرأس" "لم يُحجب في رأس متصفح الأخطاء"; fi
  if [[ "$PREGION" == *"new ListView"* ]]; then
    bad "قائمة يدوية" "createErrorsPage لا يزال يبني ListView برمجيًا"
  else ok "لا ListView برمجيًا في صفحة الأخطاء"; fi
  if [[ "$PREGION" == *"setDivider"* || "$PREGION" == *"setDividerHeight"* ]]; then
    bad "فاصل مقنَّن" "الفاصل يجب أن يأتي من نمط BrowserListView وحده"
  else ok "لا setDivider: الفواصل وتمرير سريع من النمط"; fi
  if [[ "$PREGION" == *"getItemAtPosition"* ]]; then
    ok "النقر والضغط المطوّل يمران بـgetItemAtPosition (إزاحة الرأس محسوبة)"
  else bad "مواضع النقر" "getItemAtPosition غير مستعمل مع رأس القائمة"; fi
fi
ROWS=$(awk '/class ErrorAdapter/,/private String diagnosticMessage/' "$PANEL" 2>/dev/null || true)
if [[ "$ROWS" == *"Color.WHITE"* ]]; then
  bad "لون صفوف الأخطاء" "Color.WHITE مقنَّن بدل ?color_browser_label في النمط"
else ok "نصوص الصفوف من BrowserLabelLarge/Small (?color_browser_label)"; fi

echo
echo "[9] إغلاقُ الجولةِ 20: رموزُ الجولةِ في الدكسِ، وأوراقُها في الحزمةِ"
DTMP=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP" 2>/dev/null
for sym in preserveViewAcrossEdit reinspectFilesAsync backPayloads hasFileEntry; do
  # grep -l بلا -q: -q يقتلُ grep بـSIGPIPE فمع pipefail يسقطُ الأنبوبُ كذبًا (تجربةُ 1.0.14x).
  HITS=$(grep -l "$sym" "$DTMP"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
rm -rf "$DTMP"
if [[ "$ZLIST" == *"reports/تقرير_ختام_الجولة_20_"* ]]; then
  ok "ورقةُ ختامِ الجولةِ داخلُ الحزمةِ المصدريّةِ"
else bad "ورقةُ الختامِ" "لم تُحمَلْ في الـzip"; fi
CLOSURE=$(unzip -p "$ZIP" $(printf '%s\n' "$ZLIST" | grep "reports/تقرير_ختام_الجولة_20_" | head -1) 2>/dev/null || true)
STAGES=$(printf '%s' "$CLOSURE" | grep -c "4/4" || true)
[ "$STAGES" -ge 1 ] && ok "الختامُ المنقولُ في الحزمةِ يعلنُ أربعَ مراحلَ (4/4)" \
  || bad "عدُّ المراحلِ في ورقةِ الختامِ" "لم يُعلَن 4/4"
REPORTS=$(printf '%s\n' "$ZLIST" | grep -cE "reports/تقرير_(تنفيذ_W20_[1-3]|ختام_الجولة_20_)" || true)
[ "$REPORTS" = "4" ] && ok "أوراقُ الجولةِ الأربعُ في الحزمةِ" \
  || bad "أوراقُ الجولةِ في الحزمةِ" "$REPORTS من 4"

echo
echo "[10] الجولةُ 21/1: مواكبةُ المنادِينِ في الدكسِ وأوراقُها في الحزمةِ"
DTMP21=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP21" 2>/dev/null
for sym in findDependentsAsync noteLiveMembers structureEpoch delayForBurst reinspectProbes DependencyWatchDeclaration; do
  if [ "$sym" = "DependencyWatchDeclaration" ]; then
    # اسمُ الصنفِ لا ينجو دائمًا من التصغيرِ: يُختبَرُ بمسارِهِ الداخليِّ في dex
    HITS=$(grep -l "almlk/DeclarationWatch" "$DTMP21"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  else
    HITS=$(grep -l "$sym" "$DTMP21"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  fi
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
rm -rf "$DTMP21"
if [[ "$ZLIST" == *"app/src/main/java/almlk/DeclarationWatch.java"* ]]; then
  ok "منطقُ التجميعِ الصافيُ داخلُ الحزمةِ المصدريّةِ"
else bad "منطقُ التجميعِ" "لم يُحمَلْ almlk/DeclarationWatch.java في الـzip"; fi
if [[ "$ZLIST" == *"reports/تقرير_دراسة_مواكبة_الفحص_وجذور_المصادر_وتثبيت_المكاتب_"* ]]; then
  ok "ورقةُ دراسةِ الجولةِ 21 داخلُ الحزمةِ المصدريّةِ"
else bad "ورقةُ الدراسةِ" "لم تُحمَلْ في الـzip"; fi
if zq -q "reports/تقرير_تنفيذ_W21_1_"; then
  ok "ورقةُ تنفيذِ المرحلةِ الأولى في الحزمةِ"
else bad "ورقةُ المرحلةِ الأولى" "reports/تقرير_تنفيذ_W21_1_* مفقودٌ"; fi

echo "[11] الجولةُ 21/2: ظلٌّ مرفوضٌ ومبلَّغٌ، وصياغةُ القفزةِ، وعُدَّةُ المضيفِ خارجَ المصادرِ"
DTMP22=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP22" 2>/dev/null
for sym in skipIndexingFor platformOrLibraryPackage underSourceRoot shadowedDefinitions shadowedCount; do
  HITS=$(grep -l "$sym" "$DTMP22"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
rm -rf "$DTMP22"
# مطابقةٌ بـ[[ ]] لا بأنبوبِ grep: RES ضخمٌ، وpipefail يجعلُ SIGPIPE من printf فشلًا حتى لو وجدَ grepُ.
for key in string/ui_shadow_file_ignored string/ui_error_definition_not_found; do
  if [[ "$RES" == *"$key"* ]]; then ok "المورد $key في جدولِ مواردِ الحزمةِ"
  else bad "المورد $key" "لم يظهرْ في dump resources"; fi
done
if [[ "$RES" == *'"The selected code can not be identified"'* ]]; then
  ok "صياغةُ الإنجليزيةِ كالمرجعِ داخلَ الحزمةِ المبنيةِ"
else bad "صياغةُ الإنجليزيةِ" "«The selected code can not be identified» غيرُ موجودةٍ في المواردِ"; fi
if [[ "$RES" == *'(ar) "لا يمكن تحديد الكود المحدد"'* ]]; then
  ok "صياغةُ العربيّةِ سالمةُ الترميزِ في الحزمةِ المبنيةِ"
else bad "صياغةُ العربيّةِ" "«لا يمكن تحديد الكود المحدد» لم تُحفَظْ في المواردِ كما كُتِبَتْ"; fi
if [[ "$ZLIST" == *"app/src/main/java/almlk/ProjectSourceRoots.java"* ]]; then
  ok "سياسةُ الجذورِ الصافيّةُ داخلُ الحزمةِ المصدريّةِ"
else bad "سياسةُ الجذورِ" "لم يُحمَلْ almlk/ProjectSourceRoots.java في الـzip"; fi
if zq -q "qa/host-stubs/android/content/Context.java"; then
  ok "عُدَّةُ المضيفِ في الحزمةِ تحتَ اسمِها الجديدِ"
else bad "عُدَّةُ المضيفِ" "qa/host-stubs مفقودةٌ من الـzip"; fi
if zq -q "qa/stubs/"; then
  bad "نقلُ العُدَّةِ" "qa/stubs باقٍ في الحزمةِ رغمَ نقلِها"
else ok "لا qa/stubs في الحزمةِ — خرجتْ من جذورِ المصادرِ"; fi
if zq -q "reports/تقرير_تنفيذ_W21_2_"; then
  ok "ورقةُ تنفيذِ المرحلةِ الثانيةِ في الحزمةِ"
else bad "ورقةُ المرحلةِ الثانيةِ" "reports/تقرير_تنفيذ_W21_2_* مفقودٌ"; fi

echo "[12] الجولةُ 21/3: التثبيتُ بمضمونِ الأرشيفِ في الدكسِ والمواردِ والحزمةِ"
DTMP23=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP23" 2>/dev/null
for sym in readyCount withoutClassesCount withoutClasses usableDownloaded usableForeign unusableReason; do
  HITS=$(grep -l "$sym" "$DTMP23"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
HITS=$(grep -l "almlk/LibraryInstallState" "$DTMP23"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
if [ "$HITS" = "0" ]; then bad "صنفُ حالةِ التثبيتِ" "لم يُصدَّرْ almlk/LibraryInstallState"
else ok "صنفُ حالةِ التثبيتِ في الدكسِ ($HITS ملفًّا)"; fi
HITS=$(grep -l "incomplete download" "$DTMP23"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
if [ "$HITS" = "0" ]; then bad "حارسُ التنزيلِ المقطوعِ" "رسالتُهُ ليست في الدكسِ"
else ok "حارسُ التنزيلِ المقطوعِ في الدكسِ ($HITS ملفًّا)"; fi
rm -rf "$DTMP23"
for key in string/ui_maven_incomplete_install string/ui_maven_without_classes; do
  if [[ "$RES" == *"$key"* ]]; then ok "المورد $key في جدولِ مواردِ الحزمةِ"
  else bad "المورد $key" "لم يظهرْ في dump resources"; fi
done
if [[ "$RES" == *'"%1$d of the installed libraries carry no classes inside: %2$s"'* ]]; then
  ok "صياغةُ «بلا أصنافَ داخلَها» في الحزمةِ المبنيةِ"
else bad "صياغةُ «بلا أصنافَ»" "لم تُحفَظْ في المواردِ كما كُتِبَتْ"; fi
if zq -q "app/src/main/java/almlk/LibraryInstallState.java"; then
  ok "منطقُ حالةِ التثبيتِ الصافيُ داخلُ الحزمةِ المصدريّةِ"
else bad "منطقُ حالةِ التثبيتِ" "almlk/LibraryInstallState.java مفقودٌ من الـzip"; fi
# بلا أنبوبٍ إلى grep: pipefail يقتلُ unzip بـSIGPIPE فيفشلُ الشرطُ ولو وُجِدَ المطلوبُ — استخراجٌ ثمَّ فحصُ ملفٍ
RSTMP=$(mktemp -d); unzip -p "$ZIP" qa/RegressionSuite.java > "$RSTMP/suite.java" 2>/dev/null
if grep -q "static byte\[\] fakeJar" "$RSTMP/suite.java"; then
  ok "عدّةُ الانحدارِ في الحزمةِ تكتبُ أرشيفاتٍ تُفتَحُ فعلًا (fakeJar)"
else bad "عدّةُ الانحدارِ" "fakeJar مفقودٌ — الحزمةُ تحملُ عدّةً أقدمَ من الجولةِ"; fi
rm -rf "$RSTMP"
if zq -q "reports/تقرير_تنفيذ_W21_3_"; then
  ok "ورقةُ تنفيذِ المرحلةِ الثالثةِ في الحزمةِ"
else bad "ورقةُ المرحلةِ الثالثةِ" "reports/تقرير_تنفيذ_W21_3_* مفقودٌ"; fi

echo "[13] الجولةُ 22/1: سياسةُ المستودعاتِ وقواعدُ الإكمالِ وموضعُ الـAPK — في الدكسِ والمواردِ والحزمةِ"
DTMP24=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP24" 2>/dev/null
for sym in extraRepositories applyGradleCompletionRules gradleInvocation SHIMA_APK_OUT SHIMA_DEX_MERGER packagePrefix candidateDirs MAX_RULES; do
  HITS=$(grep -l "$sym" "$DTMP24"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
for cls in almlk/RepositoryPolicy almlk/CompletionRules almlk/BuildOutputLocator almlk/ProjectNaming; do
  HITS=$(grep -l "$cls" "$DTMP24"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "صنفُ $cls" "لم يُصدَّرْ إلى الدكسِ"
  else ok "صنفُ $cls في الدكسِ ($HITS ملفًّا)"; fi
done
rm -rf "$DTMP24"
for key in string/ui_extra_repositories string/ui_extra_repositories_summary string/ui_extra_repositories_dialog string/ui_gradle_rules_header string/ui_gradle_completion_rules_summary string/ui_build_apk_found; do
  if [[ "$RES" == *"$key"* ]]; then ok "المورد $key في جدولِ مواردِ الحزمةِ"
  else bad "المورد $key" "لم يظهرْ في dump resources"; fi
done
for phrase in "are rerouted to Maven Central" "One rule per line" "Full URLs or paths separated by"; do
  if [[ "$RES" == *"$phrase"* ]]; then ok "صياغةُ «$phrase» محفوظةٌ كما كُتِبَتْ"
  else bad "صياغةُ «$phrase»" "لم تُحفَظْ في المواردِ"; fi
done
# شاشةُ المتقدِّمِ في الحزمةِ المبنيةِ: لا صفَّ ميِّتَ، والمستودعاتُ الإضافيّةُ موجودةٌ، وProGuard نقلٌ لا إلغاءٌ
XMLTMP=$(mktemp -d)
if "$BT/aapt2" dump xmltree "$APK" --file res/xml/preferences_advanced_setting.xml > "$XMLTMP/adv.txt" 2>/dev/null; then
  for dead in adjust_actionbar advanced_setting_enable_resguard advanced_setting_enable_stringfog advanced_setting_enable_adrt advanced_setting_enable_menu_code menucode_file; do
    if grep -q "$dead" "$XMLTMP/adv.txt"; then bad "صفٌّ ميِّتٌ بقيَ في الحزمةِ" "$dead ماثلٌ في preferences_advanced_setting.xml"
    else ok "الصفُّ الميِّتُ $dead زالَ من الحزمةِ المبنيةِ"; fi
  done
  if grep -q "advanced_setting_extra_repositories" "$XMLTMP/adv.txt"; then
    ok "صفُّ المستودعاتِ الإضافيّةِ في الحزمةِ المبنيةِ"
  else bad "صفُّ المستودعاتِ الإضافيّةِ" "لم يُجعَّلْ في res/xml/preferences_advanced_setting.xml"; fi
  if grep -q "add_proguard_config" "$XMLTMP/adv.txt"; then
    ok "ProGuard بقيَ صفًّا — نُقلَ إلى فئةِ البناءِ ولم يُلغَ"
  else bad "ProGuard" "add_proguard_config ضاعَ مع الإلغاءِ"; fi
else bad "dump xmltree" "لم تُقرأ preferences_advanced_setting.xml من الحزمةِ"; fi
rm -rf "$XMLTMP"
for f in almlk/RepositoryPolicy.java almlk/CompletionRules.java almlk/BuildOutputLocator.java almlk/ProjectNaming.java; do
  if zq -q "app/src/main/java/$f"; then ok "طبقةٌ صافيةٌ جديدةٌ في الحزمةِ المصدريّةِ ($f)"
  else bad "طبقةٌ صافيةٌ $f" "مفقودةٌ من الـzip"; fi
done
if zq -q "reports/تقرير_تنفيذ_W22_1_"; then ok "ورقةُ تنفيذِ المرحلةِ الأولى في الحزمةِ"
else bad "ورقةُ المرحلةِ الأولى" "reports/تقرير_تنفيذ_W22_1_* مفقودٌ"; fi

echo
echo "[14] الجولةُ 22/2a: القوالبُ الأربعةَ عشرَ عشرَ وأزرارُ الحوارِ — في الدكسِ والأصولِ والمواردِ والحزمةِ"
DTMP25=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP25" 2>/dev/null
for sym in TemplateCatalog defaultVariables dependencyLines substitutes promptClone cloneRepository repoName ic_tpl_admob; do
  HITS=$(grep -l "$sym" "$DTMP25"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
HITS=$(grep -l "repoNameOf" "$DTMP25"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
if [ "$HITS" = "0" ]; then ok "التسميةُ في صنفٍ صافٍ واحدٍ — لا نسخةً ثانيةً في MainActivity"
else bad "repoNameOf" "بقيت قاعدتُ مكرَّرةً في المضيفِ"; fi
rm -rf "$DTMP25"
ALIST=$(unzip -Z1 "$APK" 2>/dev/null)
if [[ "$ALIST" == *"assets/templates/templates.json"* ]]; then ok "مخطَّطُ القوالبِ في أصولِ الحزمةِ"
else bad "assets/templates/templates.json" "مفقودٌ من الحزمةِ"; fi
TPLN=0
for id in android_app basic_app appcompat_app androidx_app admob_appcompat admob_androidx firebase_appcompat firebase_androidx kotlin_app ndk_app gradle_lib xposed_app java_console; do
  if [[ "$ALIST" == *"assets/templates/$id/"* ]]; then TPLN=$((TPLN+1))
  else bad "قالبُ $id" "مجلدُهُ مفقودٌ من أصولِ الحزمةِ"; fi
done
[ "$TPLN" = "13" ] && ok "القوالبُ الثلاثةَ عشرَ كاملةً في الأصولِ الموقَّعةِ" || bad "عددُ القوالبِ في الأصولِ" "$TPLN ≠ 13"
GTMP=$(mktemp -d)
unzip -oq "$APK" "assets/templates/*" -d "$GTMP" 2>/dev/null
MARKN=$(grep -rl "shima:dependencies" "$GTMP/assets/templates" 2>/dev/null | wc -l | tr -d ' ')
[ "$MARKN" -ge 12 ] && ok "علامةُ الحقنِ في كلِّ وحدةِ build.gradle ($MARKN ملفًّا)" || bad "علامةُ الحقنِ" "$MARKN < 12"
for bad3 in "fagmmmu" "bintray.com" "play-services-ads:11.8.0"; do
  if grep -rq "$bad3" "$GTMP/assets/templates" 2>/dev/null; then bad "مضمونٌ مرجعيٌّ مرفوضٌ" "$bad3 تسرَّبَ إلى القوالبِ"
  else ok "لا $bad3 في القوالبِ — المُنتَجاتُ الميِّتةُ والمفاتيحُ الخاصّةُ لم تُنْسَخْ"; fi
done
KT='$kotlin_version$'
KROOT="$GTMP/assets/templates/kotlin_app/build.gradle"; KMOD="$GTMP/assets/templates/kotlin_app/app/build.gradle"
KLINE="$GTMP/assets/templates/kotlin_app/app/src/main/java/pkg/MainActivity.kt"
if [ -f "$KROOT" ] && [ -f "$KMOD" ] && [ -f "$KLINE" ] \
   && grep -qF 'org.jetbrains.kotlin:kotlin-gradle-plugin' "$KROOT" \
   && grep -qF "kotlin_version = '$KT'" "$KROOT" \
   && grep -qF "apply plugin: 'kotlin-android'" "$KMOD" \
   && grep -qF 'class MainActivity' "$KLINE"; then
  ok "قالبُ Kotlinِ كاملٌ: مسارُ الإدراجِ، والخاصيّةُ طابعٌ لا رقمٌ، وapply plugin، ومصدرٌ .kt"
else bad "قالبُ Kotlinِ" "إدراجُ اللغةِ أو مصدرُ .kt غيرُ مكتملٍ في الحزمةِ المبنيةِ"; fi
rm -rf "$GTMP"
for key in string/ui_wizard_action_git string/ui_wizard_action_more string/ui_wizard_git_title string/ui_project_category_admob string/ui_project_category_gradle string/ui_project_category_other string/ui_template_androidx_app_title string/ui_template_kotlin_description string/ui_template_java_console_title string/ui_wizard_version_firebase_bom string/ui_wizard_version_kotlin drawable/ic_tpl_admob drawable/ic_tpl_firebase drawable/ic_tpl_kotlin drawable/ic_tpl_gradle drawable/ic_tpl_rocket; do
  if [[ "$RES" == *"$key"* ]]; then ok "المورد $key في جدولِ مواردِ الحزمةِ"
  else bad "المورد $key" "لم يظهرْ في dump resources"; fi
done
for phrase in "المزيدُ" "استنساخُ مستودعِ git إلى هذا المجلدِ"; do
  if [[ "$RES" == *"$phrase"* ]]; then ok "صياغةٌ عربيّةٌ في الحزمةِ: «$phrase»"
  else bad "الصياغةُ العربيةُ «$phrase»" "لم تظهرْ في dump resources"; fi
done
for f in tools/make_templates.py app/src/main/assets/templates/templates.json; do
  if zq -q "^$f$"; then ok "$f في الحزمةِ المصدريّةِ"
  else bad "$f" "مفقودٌ من الـzip"; fi
done
if zq -q "reports/تقرير_دراسة_W22_2_"; then ok "ورقةُ دراسةِ الجولةِ في الحزمةِ"
else bad "ورقةُ الدراسةِ" "reports/تقرير_دراسة_W22_2_* مفقودٌ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_2a_"; then ok "ورقةُ تنفيذِ المرحلةِ 2a في الحزمةِ"
else bad "ورقةُ تنفيذِ 2a" "reports/تقرير_تنفيذ_W22_2a_* مفقودٌ"; fi

echo
echo "[15] الجولةُ 22/ب1: maven-metadata الحيُّ — في الدكسِ والمواردِ والحزمةِ، وزوالُ المسارِ القديمِ"
DTMP26=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP26" 2>/dev/null
for sym in MavenMetadata MavenIndex MavenVersionSource MavenBrowseDialog cacheFileName versionsIn fromStore looksLikeMetadata latestInstalled ui_maven_browse_title; do
  HITS=$(grep -l "$sym" "$DTMP26"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
if grep -l "maven-browse" "$DTMP26"/classes*.dex >/dev/null 2>&1; then ok "خيطُ البحثِ الخدميُّ باسمِهِ في الدكسِ — لا قرصَ في خيطِ الواجهةِ"
else bad "خيطُ maven-browse" "لم يُصدَّرْ: البحثُ صارَ في الواجهةِ أو ضاعَ"; fi
rm -rf "$DTMP26"
for key in ui_maven_browse_title ui_maven_browse_search_hint ui_maven_browse_status_searching ui_maven_browse_status_loading ui_maven_browse_status_versions ui_maven_browse_found ui_maven_browse_none ui_maven_browse_query_remote ui_maven_browse_from_cache ui_maven_browse_online ui_maven_browse_installed ui_maven_browse_stable ui_maven_browse_refresh ui_maven_browse_back; do
  if [[ "$RES" == *"string/$key"* ]]; then ok "المورد string/$key في جدولِ مواردِ الحزمةِ"
  else bad "المورد string/$key" "لم يظهرْ في dump resources"; fi
done
for phrase in "تصفُّحُ المستودعاتِ" "الأحدثُ المستقرُّ" "قراءةُ maven-metadata.xml"; do
  if [[ "$RES" == *"$phrase"* ]]; then ok "صياغةٌ عربيّةٌ في الحزمةِ: «$phrase»"
  else bad "الصياغةُ العربيّةُ «$phrase»" "لم تظهرْ في dump resources"; fi
done
ZTMP=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/Maven*.java" "app/src/main/java/com/almlkid/ui/MavenBrowseDialog.java" "app/src/main/java/com/almlkid/ui/AddDependencyDialog.java" "app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" -d "$ZTMP" 2>/dev/null
for f in almlk/MavenMetadata.java almlk/MavenIndex.java almlk/MavenVersionSource.java; do
  if zq -q "^app/src/main/java/$f$"; then ok "$f في الحزمةِ المصدريّةِ"
  else bad "$f" "مفقودةٌ من الـzip"; fi
done
if grep -q "VERSION_TAG" "$ZTMP/app/src/main/java/almlk/MavenResolver.java" 2>/dev/null; then
  bad "المسارُ القديمُ" "التعبيرُ النمطيُّ VERSION_TAG ماثلٌ في الحزمةِ — الإحلالُ لم يقعْ"
else ok "التعبيرُ النمطيُّ القديمُ زالَ من المحلِّلِ المصدَّرِ — إحلالٌ لا ازدواجٌ"; fi
if grep -q "out.addAll(MavenMetadata.read(file).versions)" "$ZTMP/app/src/main/java/almlk/MavenResolver.java" 2>/dev/null; then
  ok "قارئُ المحلِّلِ مفوَّضٌ إلى MavenMetadata في الحزمةِ المصدريّةِ"
else bad "تفويضُ القارئِ" "لم يُجعَّلْ في الحزمةِ"; fi
if grep -q 'menu.add(2, 3, 0, ui("ui_maven_browse_title"))' "$ZTMP/app/src/main/java/com/almlkid/ui/AddDependencyDialog.java" 2>/dev/null \
&& grep -q "this::showEditor" "$ZTMP/app/src/main/java/com/almlkid/ui/AddDependencyDialog.java" 2>/dev/null; then
  ok "«المزيدُ» في حوارِ الاعتماداتِ يفتحُ التصفُّحَ ويُغذِّي محرِّرَ الإحداثياتِ نفسَهُ — القائمةُ المضمَنةُ لم تُلْغَ"
else bad "وصلُ AddDependencyDialog" "لم يُجعَّلِ التصفُّحُ في «المزيدِ»"; fi
if grep -q "MavenBrowseDialog.show" "$ZTMP/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" 2>/dev/null; then
  ok "التصفُّحُ موصولٌ بقائمةِ «إضافةَ إلى المشروعِ» في الحزمةِ"
else bad "وصلُ التصفُّحِ" "BrowserPager لا يفتحُ MavenBrowseDialog"; fi
rm -rf "$ZTMP"
if zq -q "reports/تقرير_دراسة_W22_ب_"; then ok "ورقةُ دراسةِ طلبِ (ب) في الحزمةِ المصدريّةِ"
else bad "ورقةُ دراسةِ (ب)" "reports/تقرير_دراسة_W22_ب_* مفقودٌ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_ب1_"; then ok "ورقةُ تنفيذِ ب1 في الحزمةِ المصدريّةِ"
else bad "ورقةُ تنفيذِ ب1" "reports/تقرير_تنفيذ_W22_ب1_* مفقودٌ"; fi


echo
echo
echo
echo "[16] الجولةُ 22/ت1: الحزمةُ في المانيفستِ، والمُنتقياتُ في حوارِ الإنشاءِ، ودليلُ build"
DTMP27=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP27" 2>/dev/null
for sym in ProjectScaffold mergeManifestPackage isApplicationPackage ensureBuildDirs rewriteManifest injectDependencyLines missingDependencyLines variablesFor wantsManifestPackage; do
  HITS=$(grep -l "$sym" "$DTMP27"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الجولةِ $sym" "غيرُ موجودٍ في أيِّ dex مصدَّر — الآليّةُ لم تُصدَّرْ"
  else ok "رمزُ الجولةِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
if grep -l "outputs/apk/debug" "$DTMP27"/classes*.dex >/dev/null 2>&1; then
  ok "مسارُ المخارجِ في الدكسِ — دليلُ build يُخلَقُ فعلاً لا يُوعَدُ"
else bad "outputs/apk/debug" "لم يُصدَّرْ: لا هيكلَ build عندَ الإنشاءِ"; fi
# `android.R.layout.*` ثوابتُ تُضمَّنُ في الشيفرةِ فلا تظهرُ أسماؤُها في الدكسِ؛ الدليلُ الصدوقُ
# هو أسماءُ الطرقِ المناديةِ: بلاطةُ القائمةِ المنسدلةِ وقراءةُ المختارِ عندَ الضغطِ.
if grep -l "setDropDownViewResource" "$DTMP27"/classes*.dex >/dev/null 2>&1 \
&& grep -l "getSelectedItem" "$DTMP27"/classes*.dex >/dev/null 2>&1; then
  ok "آليّةُ المُنتقى في الدكسِ (setDropDownViewResource + getSelectedItem) — ليستْ حقلَ نصٍّ مقنَّعًا"
else bad "آليّةُ المُنتقى" "إما البلاطةُ المنسدلةُ أو قراءةُ المختارِ لم تُصدَّرْ"; fi
rm -rf "$DTMP27"
for key in ui_wizard_version_appcompat ui_wizard_version_material ui_wizard_version_constraint ui_wizard_version_support_appcompat ui_wizard_version_ads ui_wizard_version_firebase ui_wizard_version_firebase_bom ui_wizard_version_firebase_analytics ui_wizard_version_kotlin ui_wizard_version_core_ktx ui_wizard_version_agp; do
  if [[ "$RES" == *"string/$key"* ]]; then ok "عنوانُ المُنتقى $key في جدولِ المواردِ"
  else bad "عنوانُ المُنتقى $key" "لم يظهرْ في dump resources — مُنتقى بلا لسانٍ"; fi
done
for phrase in "إصدارُ AppCompat" "إصدارُ Android Gradle plugin" "إصدارُ ConstraintLayout"; do
  if [[ "$RES" == *"$phrase"* ]]; then ok "لسانُ المُنتقياتِ في الحزمةِ: «$phrase»"
  else bad "لسانُ «$phrase»" "مفقودٌ من dump resources"; fi
done
ZTMP2=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/com/shima/projects/ProjectWizard.java" \
  "app/src/main/java/almlk/ProjectScaffold.java" "app/src/main/java/almlk/ProjectNaming.java" \
  "app/src/main/java/almlk/TemplateCatalog.java" -d "$ZTMP2" 2>/dev/null
WIZ="$ZTMP2/app/src/main/java/com/shima/projects/ProjectWizard.java"
SCF="$ZTMP2/app/src/main/java/almlk/ProjectScaffold.java"
NAM="$ZTMP2/app/src/main/java/almlk/ProjectNaming.java"
CAT="$ZTMP2/app/src/main/java/almlk/TemplateCatalog.java"
for f in almlk/ProjectScaffold.java almlk/ProjectNaming.java almlk/TemplateCatalog.java com/shima/projects/ProjectWizard.java; do
  if zq -q "^app/src/main/java/$f$"; then ok "$f في الحزمةِ المصدريّةِ"
  else bad "$f" "مفقودةٌ من الـzip"; fi
done
if [ -f "$SCF" ] && grep -q "isApplicationPackage" "$SCF" && grep -q "endOfOpenTag" "$SCF"; then
  ok "المصدَّرُ يقرنُ الدمجَ بقاعدةِ الصلاحيةِ وبواصمِ الاقتباسِ — لا دمجًا أعمى"
else bad "ProjectScaffold المصدَّرُ" "فاقدا صلاحيّةَ الحزمةِ أو وعيَ الاقتباسِ"; fi
if [ -f "$WIZ" ] && grep -q "new Spinner(activity)" "$WIZ" && grep -q "template.spinners()" "$WIZ" \
&& grep -q "picker.setSelection(spec.defaultIndex)" "$WIZ"; then
  ok "حوارُ الإنشاءِ المصدَّرُ يبني المُنتقياتِ من القالبِ بافتتاحٍ على الافتراضيِّ"
else bad "مُنتقياتُ الحوارِ" "لم تُجعَّلْ في الحزمةِ"; fi
if [ -f "$WIZ" ] && grep -q "template.variablesFor(chosen)" "$WIZ" && ! grep -q "template.defaultVariables()" "$WIZ"; then
  ok "المصدَّرُ يمرُّ بvariablesFor وحدها — جدولُ قيمٍ واحدٌ في الحزمةِ"
else bad "مصدرُ القيمِ" "الحوارُ المصدَّرُ ماثلٌ على جدولٍ قديمٍ أو على مسارينِ"; fi
if [ -f "$WIZ" ] && grep -q "ProjectScaffold.rewriteManifest(" "$WIZ" && grep -q "ProjectScaffold.ensureBuildDirs(" "$WIZ" \
&& grep -q "ProjectScaffold.injectDependencyLines(" "$WIZ"; then
  ok "اللمساتُ الثلاثُ على القرصِ موصولةٌ بالمصافيذِ الصافيِّ — لا منطقَ مضمَّرًا في الواجهةِ"
else bad "وصلُ الصياغةِ" "أحدُ مواضعِ ProjectScaffold الثلاثةِ غائبٌ من الحزمةِ"; fi
if [ -f "$WIZ" ] && grep -q "pkg.matches(" "$WIZ"; then
  bad "لسانُ صلاحيةٍ ثانٍ" "المعالجُ المصدَّرُ ماثلٌ يحملُ regex خاصًّا بهِ"
else ok "لا لسانَ ثانٍ للصلاحيةِ في المعالجِ المصدَّرِ — إحلالٌ لا ازدواجٌ"; fi
if [ -f "$NAM" ] && grep -q "isApplicationPackage" "$NAM"; then
  ok "قاعدةُ حزمةِ التطبيقِ في ProjectNaming المصدَّرِ — جزآنِ فصاعدًا بلا كبيرةٍ"
else bad "isApplicationPackage" "لم تُصدَّرْ"; fi
if [ -f "$CAT" ] && grep -q "implementation platform('" "$CAT" && ! grep -q "return \"    implementation '" "$CAT"; then
  ok "سطرُ الحقنِ بلا تزيينٍ — المُحقِنُ وحدَهُ يزخرفُ، فلا ثمانيَ مسافاتَ"
else bad "تنسيقُ سطرِ الحقنِ" "البادئةُ ماثلتٌ في dependencyLine"; fi
TPL_MAN=$(unzip -p "$APK" "assets/templates/androidx_app/app/src/main/AndroidManifest.xml" 2>/dev/null)
if [ -n "$TPL_MAN" ] && ! printf '%s' "$TPL_MAN" | grep -q "package="; then
  ok "مانيفستُ القالبِ في الحزمةِ بلا package مُسبقٍ — الدمجُ من حقلِ المستخدمِ لا من نصٍّ جامدٍ"
else bad "مانيفستُ القالبِ" "إما لم يُصدَّرْ (assets/templates) أو حملَ package سلفًا فصارَ مسارينِ"; fi
JTMP=$(mktemp -d)
TPL_JSON="$JTMP/apk-templates.json"
unzip -p "$APK" "assets/templates/templates.json" > "$TPL_JSON" 2>/dev/null
NID=$(grep -o '"id":' "$TPL_JSON" 2>/dev/null | wc -l | tr -d ' ')
NOPT=$(grep -o '"options":' "$TPL_JSON" 2>/dev/null | wc -l | tr -d ' ')
SRCOPT=$(grep -o '"options":' app/src/main/assets/templates/templates.json | wc -l | tr -d ' ')
if [ "$NID" -ge 13 ] && [ "$NOPT" = "$SRCOPT" ] && [ "$NOPT" -ge 21 ] \
&& cmp -s "$TPL_JSON" app/src/main/assets/templates/templates.json; then
  ok "مخطَّطُ القوالبِ في الحزمةِ مطابقٌ للمصدرِ حرفيًّا: $NID قالبًا و$NOPT مُنتقى — المصدرُ واحدٌ للحوارِ"
else bad "مخطَّطُ القوالبِ" "id=$NID options=$NOPT مقابلَ $SRCOPT في المصدرِ (ومطابقةُ Bytes ضروريّةٌ)"; fi
rm -rf "$JTMP"
if zq -q "reports/تقرير_تنفيذ_W22_ت1_"; then ok "ورقةُ تنفيذِ ت1 في الحزمةِ المصدريّةِ"
else bad "ورقةُ تنفيذِ ت1" "reports/تقرير_تنفيذ_W22_ت1_* مفقودٌ"; fi
rm -rf "$ZTMP2"

echo
echo "[17] الجولةُ 22/ت2: سمةُ XML وكتلةُ البناءِ بلونُ onCreate — في الدكسِ والحزمةِ"
DTMP28=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP28" 2>/dev/null
for sym in LANGUAGE_WORDS NATIVE_WORDS BUILD_KEYWORDS lexXmlLine finishXmlLine collectXmlColors; do
  HITS=$(grep -l "$sym" "$DTMP28"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ التلوينِ $sym" "لم يظهرْ في الدكسِ — اللوحةُ الجديدةُ لم تُبنَ"
  else ok "رمزُ التلوينِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
rm -rf "$DTMP28"
ZTMP3=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/LineStyler.java" "qa/RegressionSuite.java" -d "$ZTMP3" 2>/dev/null
LS="$ZTMP3/app/src/main/java/almlk/LineStyler.java"
if [ -f "$LS" ] && grep -qF "if (expectElementName) fill(styles, i, end, CodeLanguageTools.KEYWORD);" "$LS"; then
  ok "المُلوِّنُ المصدَّرُ: اسمُ العنصرِ كلمةٌ، وما بعدَهُ سمةٌ سادةٌ — لا لونَ متغيِّرٍ للسماتِ"
else bad "تلوينُ السماتِ" "قاعدةُ expectElementName لم تصلِ الحزمةَ"; fi
if [ -f "$LS" ] && grep -qF "CodeLanguageTools.VARIABLE" "$LS"; then
  bad "لوحةُ XML" "VARIABLE ماثلٌ في lexXmlLine — السمةُ ستعودُ عنبريّةً"
else ok "لا VARIABLE في المُلوِّنِ المصدَّرِ — مسارُ اللونِ العنبريِّ للسماتِ زالَ"; fi
if [ -f "$LS" ] && grep -qF "(gradleFile ? BUILD_KEYWORDS : JAVA_KEYWORDS).contains(word)" "$LS" \
&& grep -qF "private static final String[] NATIVE_WORDS" "$LS"; then
  ok "لوحتا الكلماتِ في الحزمةِ — ملفاتُ البناءِ تُعرَّفُ بلغةِها لا بلغةِ C"
else bad "لوحَتا الكلماتِ" "التقسيمُ لم يُصدَّرْ"; fi
if [ -f "$LS" ] && grep -qF "if (!gradleFile) fill(styles, i, end, CodeLanguageTools.IDENTIFIER);" "$LS"; then
  ok "العلّاميُّ في البناءِ يسقطُ إلى السادةِ (VERSION_17) وبقيَ عنبريًّا في جافا"
else bad "ذيلُ JavaVersion.VERSION_17" "استثناءُ البناءِ لم يُصدَّرْ"; fi
if grep -qF "w22ColourStage129();" "$ZTMP3/qa/RegressionSuite.java" 2>/dev/null \
&& grep -qF "w22ScaffoldStage128();" "$ZTMP3/qa/RegressionSuite.java" 2>/dev/null; then
  ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلتَيِ التصحيحِ (128 ثمَّ 129) — البواباتُ معَ الشيفرةِ"
else bad "عدّةُ الانحدارِ" "مرحلةُ التلوينِ غيرُ مسجَّلةٍ في الحزمةِ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_ت2_"; then ok "ورقةُ تنفيذِ ت2 في الحزمةِ المصدريّةِ"
else bad "ورقةُ تنفيذِ ت2" "reports/تقرير_تنفيذ_W22_ت2_* مفقودٌ"; fi
rm -rf "$ZTMP3"
for key in ui_maven_browse_title ui_maven_browse_found dialog_cancel ui_action_create; do
  if [[ "$RES" == *"string/$key"* ]]; then ok "الموردُ $key باقٍ بعدَ التلوينِ — لا شيءَ من ب1 لَغاه"
  else bad "الموردُ $key" "غابَ: جدولُ المواردِ انكمشَ"; fi
done

echo
echo "[18] الجولةُ 22/4أ: عقدُ .exploded.aar — في الدكسِ والحزمةِ المصدريّةِ"
DTMP30=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP30" 2>/dev/null
for sym in AarExploder bundledJars expectedEntries classesJarOf declaredComponents; do
  HITS=$(grep -l "$sym" "$DTMP30"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ العقدِ $sym" "لم يظهرْ في الدكسِ — الآلةُ لم تُبنَ في الحزمةِ"
  else ok "رمزُ العقدِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
for lit in ".exploded.aar" ".shima-exploded" "unsafe entry " "truncated aar"; do
  if grep -aFq -- "$lit" "$DTMP30"/classes*.dex 2>/dev/null; then ok "الحرفُ «$lit» في الدكسِ — العقدُ هو ما يُستعمَلُ لا نصٌّ ميتٌ"
  else bad "الحرفُ «$lit»" "مفقودٌ من الدكسِ"; fi
done
rm -rf "$DTMP30"
ZTMP4=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/AarExploder.java" "app/src/main/java/almlk/MavenResolver.java" \
  "app/src/main/java/almlk/LibraryClassIndex.java" "qa/RegressionSuite.java" "qa.sh" -d "$ZTMP4" 2>/dev/null
ENG="$ZTMP4/app/src/main/java/almlk/AarExploder.java"
RES2="$ZTMP4/app/src/main/java/almlk/MavenResolver.java"
IDX="$ZTMP4/app/src/main/java/almlk/LibraryClassIndex.java"
if [ -f "$ENG" ] && grep -qF 'public static final String NODE_SUFFIX = ".exploded.aar";' "$ENG"; then
  ok "المصدرُ المصدَّرُ: الآلةُ خالصةٌ والعقدُ بلاحقةٍ صريحةٍ"
else bad "AarExploder.java" "لم يُصدَّرْ مع الحزمةِ أو غابتِ اللاحقةُ"; fi
if [ -f "$ENG" ] && grep -qF "unreadable aar archive (no central directory)" "$ENG" \
&& grep -qF 'throw new IOException("truncated aar: "' "$ENG"; then
  ok "الفكُّ الناقصُ مرفوضٌ في الحزمةِ: جدولُ وسطٍ لا يُقرأُ، أو مدخلٌ موعودٌ لم يخرجْ"
else bad "سلامةُ الفكِّ" "فحصُ جدولِ الوسطِ لم يُصدَّرْ"; fi
if [ -f "$RES2" ] && grep -qF "AarExploder.ensure" "$RES2" && ! grep -qF '".extracted"' "$RES2"; then
  ok "المحلِّلُ يُوَجَّهُ وحدَهُ — لا علامةَ .extracted ولا فكٌّ محليٌّ في الحزمةِ"
else bad "إحلالُ extractAar" "المسارُ القديمُ ماثلٌ في الشيفرةِ المصدَّرةِ"; fi
if [ -f "$IDX" ] && grep -qF "AarExploder.readStamp" "$IDX" && ! grep -qF '".extracted"' "$IDX"; then
  ok "ذاكرةُ المواردِ تُبطَلُ ببصمةِ العقدِ لا بزمنِ العلامةِ"
else bad "stampُ الفهرسِ" "لم يُوَجَّهْ إلى بصمةِ العقدِ"; fi
if grep -qF '"$SRC/almlk/AarExploder.java"' "$ZTMP4/qa.sh" 2>/dev/null; then
  ok "qa.sh المصدَّرُ يعدو على الآلةِ في خطِّ الصافيِّ (بلا محاكيَ)"
else bad "qa.sh" "الصافيُّ الجديدُ غيرُ مُدرَجٍ"; fi
if grep -qF "w22AarStage130();" "$ZTMP4/qa/RegressionSuite.java" 2>/dev/null; then
  ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلةَ العقدِ 130 — البوّاباتُ معَ الشيفرةِ"
else bad "عدّةُ الانحدارِ" "المرحلةُ 130 غيرُ مسجَّلةٍ في الحزمةِ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_4أ_"; then ok "ورقةُ تنفيذِ 4أ في الحزمةِ المصدريّةِ"
else bad "ورقةُ تنفيذِ 4أ" "reports/تقرير_تنفيذ_W22_4أ_* مفقودٌ"; fi
LEAK=$(grep -rlF '".extracted"' "$ZTMP4/app/src" 2>/dev/null | wc -l | tr -d ' ')
if [ "$LEAK" = "0" ]; then ok "لا مسارَ قديمًا في شيفرةِ التطبيقِ المصدَّرةِ (qa يذكرُها بوصفِها بقايا تُمحى — لا مسارًا)"
else bad "مسارٌ موازٍ" "$LEAK ملفًّا في شيفرةِ التطبيقِ يقرأُ العلامةَ القديمةَ"; fi
rm -rf "$ZTMP4"

echo "[19] الجولةُ 22/4ب: فهرسةُ libs/ الفوريّةُ وبديلُ AndroidX في التصفُّحِ — بلا تنزيلٍ زائدٍ"
DTMP31=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP31" 2>/dev/null
for sym in LocalLibraries signatureOf libsDirOf localClasspath observeLocals androidxSubstitute oldToNew usesAndroidX; do
  HITS=$(grep -l "$sym" "$DTMP31"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ المحلّيّاتِ $sym" "لم يظهرْ في الدكسِ — الآلةُ لم تُبنَ في الحزمةِ"
  else ok "رمزُ المحلّيّاتِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
for lit in "build/shima-libs" "sources/javadoc" "over the scan limit" "not a jar/aar" "android.useAndroidX" "ui_maven_local_libs" "ui_maven_browse_androidx_alt"; do
  if grep -aFq -- "$lit" "$DTMP31"/classes*.dex 2>/dev/null; then ok "الحرفُ «$lit» في الدكسِ — المسارُ حيٌّ لا نصٌّ ميتٌ"
  else bad "الحرفُ «$lit»" "مفقودٌ من الدكسِ"; fi
done
rm -rf "$DTMP31"
ZTMP5=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/LocalLibraries.java" "app/src/main/java/almlk/ProjectLibraries.java" \
  "app/src/main/java/almlk/LibraryClassIndex.java" "app/src/main/java/almlk/AndroidXMigration.java" \
  "app/src/main/java/com/almlkid/ui/MavenBrowseDialog.java" "app/src/main/java/com/almlkid/ui/MavenDownloadDialog.java" \
  "app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" "app/src/main/res/values/strings.xml" \
  "app/src/main/res/values-ar/strings.xml" "qa/RegressionSuite.java" "qa.sh" -d "$ZTMP5" 2>/dev/null
LOC="$ZTMP5/app/src/main/java/almlk/LocalLibraries.java"
PLIB="$ZTMP5/app/src/main/java/almlk/ProjectLibraries.java"
IDX5="$ZTMP5/app/src/main/java/almlk/LibraryClassIndex.java"
MIG="$ZTMP5/app/src/main/java/almlk/AndroidXMigration.java"
if [ -f "$LOC" ] && grep -qF 'MAX_ENTRIES = 200;' "$LOC" && ! grep -qF "import android." "$LOC" \
&& ! grep -qF 'new MavenDownloader' "$LOC" && ! grep -qF "java.net" "$LOC"; then
  ok "المصدرُ المصدَّرُ: راصدُ libs/ خالصٌ (لا Androidَ ولا شبكةَ) وبميزانيّةِ مئتي مدخلٍ"
else bad "LocalLibraries.java" "لم يُصدَّرْ أو خرجَ عن خُلوصِهِ"; fi
if [ -f "$PLIB" ] && grep -qF "public synchronized void observeLocals" "$PLIB" \
&& [ "$(grep -cF 'locals = almlk.LocalLibraries.Finding.NONE;' "$PLIB")" = "3" ]; then
  ok "حالةُ المشروعِ تتذكّرُ المحلّيّاتِ وتُسقِطُها مع clear/invalidate — لا أثرَ لمشروعٍ سابقٍ"
else bad "ProjectLibraries.java" "الرصدُ أو إسقاطُهُ غيرُ مصدَّرٍ"; fi
if [ -f "$IDX5" ] && grep -qF "state.observeLocals(" "$IDX5" && grep -qF "seenPaths.add(local.getAbsolutePath())" "$IDX5"; then
  ok "فهرسُ الأصنافِ يمزجُ libs/ بلا تكرارٍ — الأرشيفُ الواحدُ يُفتَحُ مرّةً واحدةً"
else bad "LibraryClassIndex.java" "المزجُ أو إزالةُ التكرارِ غائبٌ في الحزمةِ"; fi
if [ -f "$MIG" ] && grep -qF "public static String androidxSubstitute(" "$MIG" \
&& grep -qF "public static boolean usesAndroidX(File projectDir)" "$MIG"; then
  ok "جدولُ AndroidX يُصدِّرُ القرارَ نفسَهُ للمحلولِ وللوِجهِ — لا منطقَ موازيًا في الحوارِ"
else bad "AndroidXMigration.java" "دوالُّ البديلِ غيرُ مصدَّرةٍ"; fi
BROWSE="$ZTMP5/app/src/main/java/com/almlkid/ui/MavenBrowseDialog.java"
if [ -f "$BROWSE" ] && grep -qF "ui_maven_browse_androidx_alt" "$BROWSE" \
&& grep -qF 'rows.add(new Row(label.toString(), coordinate + ":" + version, null));' "$BROWSE"; then
  ok "سطرُ البديلِ فوقَ الإصداراتِ مع بقاءِ كلِّ سطرٍ قديمٍ — لا ميزةَ ضاعتْ في التصفُّحِ"
else bad "MavenBrowseDialog.java" "البديلُ أو أسطرُ الإصداراتِ مفقودٌ في الحزمةِ"; fi
DLG="$ZTMP5/app/src/main/java/com/almlkid/ui/MavenDownloadDialog.java"
PGR="$ZTMP5/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
if [ -f "$DLG" ] && grep -qF "localFinding()" "$DLG" && [ -f "$PGR" ] \
&& grep -qF "MavenBrowseDialog.show(" "$PGR"; then
  ok "لوحةُ النتيجةِ تُسمّي المحلّيّاتِ، والمتصفّحُ يمرّرُ جذرَ المشروعِ للتحويلِ"
else bad "لوحةُ النتيجةِ/المتصفّحُ" "الوصلةُ غيرُ مصدَّرةٍ"; fi
for f in app/src/main/res/values/strings.xml app/src/main/res/values-ar/strings.xml; do
  if [ -f "$ZTMP5/$f" ] && grep -qF "ui_maven_local_libs" "$ZTMP5/$f" \
  && grep -qF "ui_maven_browse_androidx_alt" "$ZTMP5/$f"; then ok "النصُّ الجديدُ في $f — عربيٌّ وإنجليزيٌّ معًا"
  else bad "$f" "نصٌّ من نصوصِ المحلّيّاتِ مفقودٌ"; fi
done
if grep -qF '"$SRC/almlk/LocalLibraries.java"' "$ZTMP5/qa.sh" 2>/dev/null; then
  ok "qa.sh المصدَّرُ يعدو على راصدِ libs/ في خطِّ الصافيِّ (بلا محاكيَ)"
else bad "qa.sh" "الصافيُّ الجديدُ غيرُ مُدرَجٍ"; fi
for stage in w22LocalLibsStage131 w22AndroidxStage132; do
  if grep -qF "$stage();" "$ZTMP5/qa/RegressionSuite.java" 2>/dev/null; then
    ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلةَ ${stage} — البوّاباتُ معَ الشيفرةِ"
  else bad "عدّةُ الانحدارِ" "${stage} غيرُ مسجَّلةٍ في الحزمةِ"; fi
done
unzip -oq "$ZIP" "app/src/main/java/almlk/MavenResolver.java" "app/src/main/java/almlk/MavenDownloader.java" -d "$ZTMP5" 2>/dev/null
LEAK=0
for f in "$ZTMP5/app/src/main/java/almlk/MavenResolver.java" "$ZTMP5/app/src/main/java/almlk/MavenDownloader.java"; do
  [ -f "$f" ] || { bad "المجلِّبُ مفقودٌ" "لم يُصدَّرْ مع الحزمةِ"; continue; }
  if grep -qF -- '"-sources.jar"' "$f" || grep -qF -- '"-javadoc.jar"' "$f" || grep -qF -- '+sources' "$f"; then LEAK=$((LEAK+1)); fi
done
if [ "$LEAK" = "0" ]; then ok "لا طلبَ مصادرَ ولا توثيقَ في شيفرةِ التطبيقِ المصدَّرةِ — التنزيلُ عندَ الطلبِ وحدَهُ"
else bad "تنزيلٌ زائدٌ" "$LEAK ملفًّا يطلبُ أرشيفَ مصادرَ"; fi
rm -rf "$ZTMP5"


echo "[20] الجولةُ 22/4ب٢: ربطُ مكتبةٍ محليّةٍ من المتصفّحِ وفصلُها — الآلةُ في الدكسِ والورقةُ في الحزمةِ"
DTMP32=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP32" 2>/dev/null
for sym in GradleLibraryLinks includedModules settingsFileIn moduleDirOf removeDependency libraryMessage; do
  HITS=$(grep -l "$sym" "$DTMP32"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الربطِ $sym" "لم يظهرْ في الدكسِ — الآلةُ لم تُبنَ في الحزمةِ"
  else ok "رمزُ الربطِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
for lit in "ui_browser_add_library" "ui_browser_remove_library" ".projectDir = new File(" "implementation project('"; do
  if grep -aFq -- "$lit" "$DTMP32"/classes*.dex 2>/dev/null; then ok "الحرفُ «$lit» في الدكسِ — النصُّ والصياغةُ مكتوبتانِ لا مُوَلَّدتانِ وصفًا"
  else bad "الحرفُ «$lit»" "مفقودٌ من الدكسِ"; fi
done
for absent in "Get-ChildItem" "settings.gradle.backup" "copyToClipboard"; do
  if grep -aFq -- "$absent" "$DTMP32"/classes*.dex 2>/dev/null; then bad "ما لا يُفعلُ «$absent»" "ظهرَ في الدكسِ — آليّةٌ أجنبيّةٌ تسرّبتْ"
  else ok "لا «$absent» في الدكسِ — لا نسخَ أجنبيٌّ ولا نسخُ احتياطٍ ولا أستارُ"; fi
done
rm -rf "$DTMP32"
ZTMP6=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/GradleLibraryLinks.java" "app/src/main/java/almlk/GradleDependencyEditor.java" \
  "app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" "app/src/main/res/values/strings.xml" \
  "app/src/main/res/values-ar/strings.xml" "qa/RegressionSuite.java" "qa.sh" "VERSION" -d "$ZTMP6" 2>/dev/null
LNK="$ZTMP6/app/src/main/java/almlk/GradleLibraryLinks.java"
if [ -f "$LNK" ] && grep -qF "public static Result link(File projectRoot, File folder)" "$LNK" \
&& grep -qF "public static Result unlink(File projectRoot, String name)" "$LNK"; then
  ok "آلةُ الربطِ/Fصلِ مصدَّرةٌ بواجهةِ وضعٍ واحدةٍ (بلا استثناءاتٍ تُرمى على المستدعي)"
else bad "GradleLibraryLinks.java" "لم يُصدَّرْ مع الحزمةِ أو غابت واجهتُهُ"; fi
if [ -f "$LNK" ] && grep -qF "static String withoutInclude(String text, String name, boolean kts)" "$LNK" \
&& grep -qF "static String withInclude(String text, String name, String relativeDir, boolean kts)" "$LNK" \
&& grep -qF "public static boolean isSafeName(String name)" "$LNK"; then
  ok "التحريرُ نصٌّ على مستوىِ السطرِ — لا ترقيمَ أسطرٍ ولا حذفُ ملفٍّ ولا اسمٌ غيرُ صالحٍ"
else bad "تحريرُ الإدراجِ" "الأداةُ النصّيّةُ غيرُ مصدَّرةٍ"; fi
if [ -f "$LNK" ] && ! grep -qE "HttpURLConnect|java\.net\.|GradleBuildModel" "$LNK"; then
  ok "الآلةُ لا شبكةَ فيها ولا مساسَ بموديلِ الحلِّ — مرحلةُ الفهمِ مؤجَّلةٌ إلى 4ب٢‑ب صراحةً"
else bad "حدودُ المرحلةِ" "شبكةٌ أو موديلُ في آلةِ الربطِ"; fi
ED2="$ZTMP6/app/src/main/java/almlk/GradleDependencyEditor.java"
if [ -f "$ED2" ] && grep -qF "public static String removeDependency(String buildText, String line)" "$ED2"; then
  ok "إزالةُ سطرِ الاعتمادِ في محرِّرِ الكتلِ — لا سطرًا موازيًا في android { }"
else bad "removeDependency" "لم يُصدَّرْ مع الحزمةِ"; fi
PG2="$ZTMP6/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
if [ -f "$PG2" ] && grep -qF "popup.add(0, 311, 10, ui(\"ui_browser_add_library\"))" "$PG2" \
&& grep -qF "popup.add(0, 312, 11, ui(\"ui_browser_remove_library\"))" "$PG2"; then
  ok "بنَدا المرجعِ في قائمةِ الضغطِ نفسِها — التصميمُ المعروضُ لم يُستبدَلْ بشاشةٍ"
else bad "قائمةُ المتصفّحِ" "بنَدا الربطِ/Fصلِ مفقودانِ في الحزمةِ"; fi
if [ -f "$PG2" ] && grep -qF "fileReader.execute(" "$PG2" && grep -qF "actions.onBuildFilesChanged(buildFile)" "$PG2"; then
  ok "الكتابةُ في الخيطِ العاملِ ثمَّ إعادةُ دورةِ اعتمادٍ صامتةٌ — لا فتحَ لملفٍ ولا حوارُ انتظارٍ"
else bad "مسارُ الخيطِ" "الخيطُ العاملُ أو السمعُ غيرُ مصدَّرَينِ"; fi
for f in app/src/main/res/values/strings.xml app/src/main/res/values-ar/strings.xml; do
  N=$(grep -c 'name="ui_browser_add_library\|name="ui_browser_remove_library\|name="ui_browser_library_failed' "$ZTMP6/$f" 2>/dev/null)
  if [ "$N" -ge 4 ]; then ok "النصُّ العربيُّ والإنجليزيُّ في $f ($N مدخلًا) — لا مفتاحَ ناقصًا في لغةٍ"
  else bad "$f" "مفاتيحُ الربطِ/Fصلِ ناقصةٌ في الحزمةِ ($N)"; fi
done
if [ -f "$ZTMP6/VERSION" ] && [ "$(cat "$ZTMP6/VERSION")" = "$VERSION" ]; then
  ok "الحزمةُ تحملُ الإصدارَ $VERSION في VERSION"
else bad "VERSION" "ما في الحزمةِ ليس $VERSION"; fi
if grep -qF '"$SRC/almlk/GradleLibraryLinks.java"' "$ZTMP6/qa.sh" 2>/dev/null; then
  ok "qa.sh المصدَّرُ يعدو على آلةِ الربطِ في خطِّ الصافيِّ (بلا محاكيَ)"
else bad "qa.sh" "الصافيُّ الجديدُ غيرُ مُدرَجٍ"; fi
if grep -qF "w22LibraryLinksStage133();" "$ZTMP6/qa/RegressionSuite.java" 2>/dev/null; then
  ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلةَ الربطِ 133 — البوّاباتُ معَ الشيفرةِ"
else bad "عدّةُ الانحدارِ" "المرحلةُ 133 غيرُ مسجَّلةٍ في الحزمةِ"
fi
if zq -q "reports/تقرير_تنفيذ_W22_4ب٢_"; then ok "ورقةُ تنفيذِ 4ب٢ في الحزمةِ المصدريّةِ"
else bad "ورقةُ تنفيذِ 4ب٢" "reports/تقرير_تنفيذ_W22_4ب٢_* مفقودٌ"; fi
if zq -q "reports/تقرير_دراسة_ربطِ"; then ok "ورقةُ دراسةِ الربطِ سابقةُ التنفيذِ مصدَّرةٌ مع الحزمةِ"
else bad "ورقةُ الدراسةِ" "تقريرُ الدراسةِ لم يُصدَّرْ في الحزمةِ"; fi
rm -rf "$ZTMP6"

echo "[21] الجولةُ 22/4ب٢‑ب١: فهمُ الوحداتِ المعلَنةِ في settings.gradle — في الدكسِ والحزمةِ المصدريّةِ"
DTMP33=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP33" 2>/dev/null
for sym in GradleProjectModules modelsForAnalysis resolvesProject analysisCoordinates fingerprintSuffix requestsFrom; do
  HITS=$(grep -l "$sym" "$DTMP33"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "رمزُ الوحداتِ $sym" "لم يظهرْ في الدكسِ — الفهمُ لم يُبنَ في الحزمةِ"
  else ok "رمزُ الوحداتِ $sym في الدكسِ ($HITS ملفًّا)"; fi
done
for lit in "no build file in folder" "over the module limit" "no included module named" "projectDir = new File("; do
  if grep -aFq -- "$lit" "$DTMP33"/classes*.dex 2>/dev/null; then ok "الحرفُ «$lit» في الدكسِ — الأخبارُ مسماّةٌ في التطبيقِ لا في العدّةِ وحدَها"
  else bad "الحرفُ «$lit»" "مفقودٌ من الدكسِ"; fi
done
# ما يسمُّ «بناءً مفروضًا» من داخلِ آلةِ الفهمِ نفسِها — لا ما يستعملُهُ التطبيقُ في
# ميزتِهِ الخاصّةِ، فإنّ لهُ أبوابَ قبولٍ أُخرَ.
for absent in "Get-ChildItem" "settings.gradle.backup" "gradle build"; do
  if grep -aFq -- "$absent" "$DTMP33"/classes*.dex 2>/dev/null; then bad "ما لا يُفعلُ «$absent»" "ظهرَ في الدكسِ — بناءٌ أو نسخُ احتياطٍ مفروضٌ"
  else ok "لا «$absent» في الدكسِ — لا بناءَ قسرًا ولا نسخةَ احتياطٍ"; fi
done
rm -rf "$DTMP33"
ZTMP7=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/GradleProjectModules.java" "app/src/main/java/almlk/GradleBuildModel.java" \
  "app/src/main/java/almlk/MavenResolver.java" "app/src/main/java/almlk/LibraryClassIndex.java" \
  "app/src/main/java/almlk/ProjectLibraries.java" "app/src/main/java/com/almlkid/ui/DependencyCycle.java" \
  "qa/RegressionSuite.java" "qa.sh" -d "$ZTMP7" 2>/dev/null
MOD="$ZTMP7/app/src/main/java/almlk/GradleProjectModules.java"
if [ -f "$MOD" ] && grep -qF "public static final int MAX_MODULES = 12;" "$MOD" \
&& grep -qF "public static final int MAX_DEPTH = 6;" "$MOD"; then
  ok "آلةُ الوحداتِ مصدَّرةٌ بأسقفٍ صريحةٍ (12 وحدةً/6 مستوياتِ) — لا انفلاتَ على الجهازِ"
else bad "GradleProjectModules.java" "لم يُصدَّرْ مع الحزمةِ أو غابتِ الأسقفُ"; fi
if [ -f "$MOD" ] && grep -qF "GradleLibraryLinks.includedModules(" "$MOD" \
&& ! grep -qF "listFiles" "$MOD" && ! grep -qE "java\.net|MavenDownloader|-sources\.jar|-javadoc\.jar" "$MOD"; then
  ok "القراءةُ من الإدراجِ وحدَهُ: لا مشيَ على القرصِ، لا شبكةَ، لا تنزيلَ — مبدأُ «لا شيءَ لم تُعلِنْهُ المشروعُ»"
else bad "حدودُ الآلةِ" "مشيٌ على القرصِ أو شبكةٌ في شيفرةِ الحزمةِ"; fi
if [ -f "$MOD" ] && ! grep -qE "ProcessBuilder|Runtime\.getRuntime|exec\(" "$MOD"; then
  ok "آلةُ الفهمِ لا تُطلقُ عمليةً ولا بناءً — تفهُّمٌ نصيٌّ لا تنفيذُ أوامرَ"
else bad "حدودُ التنفيذِ" "الآلةُ تُطلقُ عمليةً خارجَ ما يملكُهُ المستخدمُ"; fi
if [ -f "$MOD" ] && grep -qF "public boolean resolves(String projectPath)" "$MOD"; then
  ok "القرارُ مُصدَّرٌ: «هل تُحَلُّ هذهِ الوحدةُ؟» — لا جوابَ نعمَ بلا ملفِّ بناءٍ"
else bad "resolves" "لم يُصدَّرْ"; fi
BM="$ZTMP7/app/src/main/java/almlk/GradleBuildModel.java"
if [ -f "$BM" ] && grep -qF "public almlk.GradleProjectModules projectModules;" "$BM" \
&& grep -qF "for (GradleBuildModel module : projectModules.models()) collectAnalysis(module, out);" "$BM"; then
  ok "النموذجُ يدمجُ اعتماداتِ الوحداتِ في التحليلِ — نقطةُ تغييرٍ واحدةٌ"
else bad "GradleBuildModel" "الحقلُ أو الدمجُ مفقودٌ في الحزمةِ"; fi
RS="$ZTMP7/app/src/main/java/almlk/MavenResolver.java"
if [ -f "$RS" ] && grep -qF "for (GradleBuildModel source : model.modelsForAnalysis()) requestsFrom(source, out, seen);" "$RS"; then
  ok "حلُّ الاعتماداتِ يسألُ ما للمنادِي وما لوحدتِهِ المرتبطةِ — بلا إدراجٍ لا طلبَ"
else bad "MavenResolver.requests" "الحلقةُ على الوحداتِ مفقودةٌ"; fi
LC="$ZTMP7/app/src/main/java/almlk/LibraryClassIndex.java"
if [ -f "$LC" ] && grep -qF "if (!model.resolvesProject(d.notation)) provable = false;" "$LC" \
&& grep -qF "almlk.LocalLibraries.discover(source.moduleDir, source.projectRoot, source.text, null);" "$LC"; then
  ok "الفهرسُ يُثبِتُ ما حُلَّ ويأخذُ libs/ الوحدةِ المرتبطةِ من قرصِها"
else bad "LibraryClassIndex" "حلُّ project(':x') أو محلّيّاتُ الوحدةِ مفقودٌ"; fi
LUMPS=$(grep -c "case PROJECT:" "$LC" 2>/dev/null)
if [ -f "$LC" ] && [ "$LUMPS" = "1" ]; then
  ok "حالةُ project(':x') واحدةٌ مشروطةٌ — لم تعدْ تُنقِصُ الإثباتَ دائمًا كما كانَ"
else bad "إحلالُ المسارِ العاطلِ" "عددُ مواضعِ حالةِ الوحدةِ: $LUMPS"; fi
PL="$ZTMP7/app/src/main/java/almlk/ProjectLibraries.java"
if [ -f "$PL" ] && grep -qF "model.projectModules.fingerprintSuffix()" "$PL"; then
  ok "البصمةُ تشملُ ملفاتِ الوحداتِ وlibs/ فيها — لا دورةً قديمةً صامتةً"
else bad "البصمةُ" "ذيلُ الوحداتِ مفقودٌ"; fi
DC="$ZTMP7/app/src/main/java/com/almlkid/ui/DependencyCycle.java"
if [ -f "$DC" ] && grep -qF "loaded.projectModules = almlk.GradleProjectModules.of(loaded, apkSignerReader());" "$DC"; then
  ok "الدورةُ تبني الخريطةَ على الخيطِ العاملِ مرةً واحدةً — لا قرصَ في خيطِ الواجهةِ"
else bad "DependencyCycle" "الوصلُ بالمغلَّقِ مفقودٌ"; fi
if grep -qF '"$SRC/almlk/GradleProjectModules.java"' "$ZTMP7/qa.sh" 2>/dev/null; then
  ok "qa.sh المصدَّرُ يعدو على آلةِ الوحداتِ في خطِّ الصافيِّ (بلا محاكيَ)"
else bad "qa.sh" "الصافيُّ الجديدُ غيرُ مُدرَجٍ"; fi
if grep -qF "w22ProjectModulesStage134();" "$ZTMP7/qa/RegressionSuite.java" 2>/dev/null; then
  ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلةَ الفهمِ 134 — البوّاباتُ معَ الشيفرةِ"
else bad "عدّةُ الانحدارِ" "المرحلةُ 134 غيرُ مسجَّلةٍ في الحزمةِ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_4ب٢ب_"; then ok "ورقةُ تنفيذِ 4ب٢‑ب١ في الحزمةِ المصدريّةِ"
else bad "ورقةُ تنفيذِ 4ب٢‑ب١" "reports/تقرير_تنفيذ_W22_4ب٢ب_* مفقودٌ"; fi
if zq -q "reports/تقرير_دراسة_فهم_الوحدات_المرتبطة"; then ok "ورقةُ دراسةِ الفهمِ سابقةُ التنفيذِ مصدَّرةٌ"
else bad "ورقةُ الدراسةِ" "تقريرُ دراسةِ الوحداتِ لم يُصدَّرْ"; fi
rm -rf "$ZTMP7"

echo
echo "═══ [22] ═══"
echo "[22] الجولةُ 22/دفعُ عطلٍ: مخرَجُ البناءِ — الصنفُ المسمّى في التخطيطِ، ومخزنٌ مسقوفٌ، ولا يتيمَ بعدَها"
DTMP34=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP34" 2>/dev/null
for sym in "Lcom/almlkid/ui/build/OutputConsole;" "Lalmlk/ConsoleBuffer;" ConsoleBuffer needsTrim firstLineStart TRIM_TO_CHARS bringPointIntoView setHorizontallyScrolling setTextIsSelectable MONOSPACE; do
  if grep -aFq -- "$sym" "$DTMP34"/classes*.dex 2>/dev/null; then ok "رمزُ المخرَجِ «$sym» في الدكسِ — الصنفُ بُنِيَ في الحزمةِ لا في المرجعِ وحدَهُ"
  else bad "رمزُ المخرَجِ $sym" "مفقودٌ من الدكسِ — التخطيطُ سينهارُ عندَ التوريمِ"; fi
done
if grep -aFq -- "getDefaultBufferType" "$DTMP34"/classes*.dex 2>/dev/null; then
  bad "دالّةٌ محجوبةٌ" "getDefaultBufferType في الدكسِ — لا تُورَثُ من TextView فتُعطِّلُ البناءَ"
else ok "لا اعتمادَ على دالّةٍ محجوبةٍ — النوعُ يُفرَضُ من setText العامّةِ"; fi
rm -rf "$DTMP34"
ZTMP8=$(mktemp -d)
unzip -oq "$ZIP" -d "$ZTMP8" 2>/dev/null
if grep -qF "<com.almlkid.ui.build.OutputConsole" "$ZTMP8/app/src/main/res/layout/outputconsole.xml" 2>/dev/null \
&& grep -qF "requestFocus" "$ZTMP8/app/src/main/res/layout/outputconsole.xml" 2>/dev/null; then
  ok "التصميمُ المنقولُ باقٍ على وصفِهِ — أُتِمَّ الصنفُ ولم يُفرَّغِ التخطيطُ إلى TextView عارٍ"
else bad "outputconsole.xml" "لم يبقَ على وسمِ الصنفِ — التصميمُ أُبطلَ بدلَ أن يُستكملَ"; fi
CALLS=$(grep -c "R.layout.outputconsole" "$ZTMP8/app/src/main/java/com/shima/demo/MainActivity.java" 2>/dev/null)
if [ "$CALLS" = "2" ] && grep -qF "TextView output = view.findViewById(R.id.outputConsole);" "$ZTMP8/app/src/main/java/com/shima/demo/MainActivity.java"; then
  ok "موضعَا التوريمِ لم يتحرّكا — الصنفُ خُصِّصَ لهما، لا العكسُ"
else bad "مواضعُ الاستدعاءِ" "عدَدُهَا $CALLS بدلَ اثنينِ أو غابَ ربطُ id"; fi
CONSOLE="$ZTMP8/app/src/main/java/com/almlkid/ui/build/OutputConsole.java"
BUFFER="$ZTMP8/app/src/main/java/almlk/ConsoleBuffer.java"
if [ -f "$CONSOLE" ] && grep -qF "public OutputConsole(Context context, AttributeSet attrs)" "$CONSOLE" \
&& grep -qF "super.setText(text, BufferType.SPANNABLE);" "$CONSOLE" \
&& grep -qF "current instanceof Editable" "$CONSOLE"; then
  ok "الصنفُ مُصدَّرٌ بثلاثةِ بنّائينَ ومخزنينِ للتقليمِ — الواجهةُ رقيقةٌ بلا سياسةٍ مضمَّرةٍ"
else bad "OutputConsole.java" "مفقودٌ من الحزمةِ أو بنّاءُ المِنفَاخِ غيرُ موجودٍ"; fi
if [ -f "$BUFFER" ] && grep -qF "public static final int MAX_CHARS = 1 << 18;" "$BUFFER" \
&& grep -qF "public static final int TRIM_TO_CHARS = MAX_CHARS * 3 / 4;" "$BUFFER" \
&& ! grep -qE "^import android\.|Thread|java\.io|java\.net" "$BUFFER"; then
  ok "السياسةُ صرفةٌ: سقفٌ وحدُّ تخفيفٍ، وبلا قرصٍ ولا شبكةٍ ولا Androidَ — تُختبَرُ بلا محاكيَ"
else bad "ConsoleBuffer.java" "السقفُ مفقودٌ أو تسرّبَ ما لا يجوزُ في صنفٍ صافيٍ"; fi
ORPH=$(python3 - "$ZTMP8" <<'PYEOF'
import io,os,re,sys
root=sys.argv[1]
out=[]
lroot=os.path.join(root,"app/src/main/res")
for dirpath,dirs,files in os.walk(lroot):
    if os.path.basename(dirpath).startswith("layout"):
        for name in sorted(files):
            if not name.endswith(".xml"): continue
            t=io.open(os.path.join(dirpath,name),encoding="utf-8",errors="replace").read()
            for m in re.finditer(r"<((?:com\.almlkid|com\.shima|almlk|abeed)\.[\w.]*[A-Z]\w*)",t):
                cls=m.group(1)
                if not os.path.isfile(os.path.join(root,"app/src/main/java",cls.replace(".","/")+".java")):
                    out.append(cls+"@"+name)
print(";".join(sorted(set(out))))
PYEOF
)
if [ "$ORPH" = "" ]; then ok "بوّابةُ النظامِ على الحزمةِ: لا وسمَ صنفٍ يتيمًا في تخطيطٍ من تخطيطاتِنا"
else bad "يتيمُ التخطيطِ" "$ORPH"; fi
if grep -qF '"$SRC/almlk/ConsoleBuffer.java"' "$ZTMP8/qa.sh" 2>/dev/null; then
  ok "qa.sh المصدَّرُ يعدو على مخزنِ المخرَجِ في خطِّ الصافيِّ (بلا محاكيَ)"
else bad "qa.sh" "ConsoleBuffer غيرُ مُدرَجٍ في خطِّ الصافيِّ"; fi
if grep -qF "outputConsoleStage135();" "$ZTMP8/qa/RegressionSuite.java" 2>/dev/null; then
  ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلةَ المخرَجِ 135 — البوّاباتُ معَ الشيفرةِ"
else bad "عدّةُ الانحدارِ" "المرحلةُ 135 غيرُ مسجَّلةٍ في الحزمةِ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_دفع_عطل_"; then ok "ورقةُ تنفيذِ الدفعِ في الحزمةِ مع الشيفرةِ"
else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_دفع_عطل_* مفقودٌ"; fi
if zq -q "reports/تقرير_دراسة_مخرج_البناء_"; then ok "ورقةُ دراسةِ العطلِ في الحزمةِ — الدليلُ مصدَّرٌ لا محذوفٌ"
else bad "ورقةُ الدراسةِ" "تقريرُ دراسةِ المخرَجِ لم يُصدَّرْ"; fi
rm -rf "$ZTMP8"

echo
echo "═══ [23] ═══"
echo "[23] الجولةُ 22/4ب٢‑ب٢: مصادرُ الوحداتِ المرتبطةِ ومخرجُها — في الدكسِ والحزمةِ المصدريّةِ"
DTMP35=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP35" 2>/dev/null
for sym in discoverOutputs outputsSignature outputDirsOf MAX_SOURCE_DIRS drainSymbolQueue seedLinkedSourceRoots setLinkedSourceRoots canonicalPath LINKED_VISIT_BUDGET; do
  if grep -aFq -- "$sym" "$DTMP35"/classes*.dex 2>/dev/null; then ok "رمزُ الشطرِ «$sym» في الدكسِ — وصلَ الفهرسُ بالوحداتِ لا بقيَ ورقًا"
  else bad "رمزُ الشطرِ $sym" "مفقودٌ من الدكسِ"; fi
done
for absent in "gradle build --no-daemon mylib" ":mylib:assembleDebug" "projectSourcesJar"; do
  if grep -aFq -- "$absent" "$DTMP35"/classes*.dex 2>/dev/null; then bad "ما لا يُفعلُ «$absent»" "ظهرَ في الدكسِ — الشطرُ يبني ما لم يُبنَ"
  else ok "لا «$absent» في الدكسِ — مخرجُ القرصِ يُنظَرُ ولا يُصنَعُ"; fi
done
rm -rf "$DTMP35"
ZTMP9=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/GradleProjectModules.java" "app/src/main/java/almlk/LocalLibraries.java" \
  "app/src/main/java/almlk/LibraryClassIndex.java" "app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" \
  "app/src/main/java/com/shima/demo/MainActivity.java" "qa/RegressionSuite.java" "qa.sh" -d "$ZTMP9" 2>/dev/null
MOD="$ZTMP9/app/src/main/java/almlk/GradleProjectModules.java"
if [ -f "$MOD" ] && grep -qF '"src/main/java"' "$MOD" && grep -qF '"src/main/kotlin"' "$MOD" \
&& grep -qF "public static final int MAX_SOURCE_DIRS = 36;" "$MOD" \
&& grep -qF 'if (!modern) addSourceDir(out, seen, new File(module.dir, "src"));' "$MOD"; then
  ok "التخطيطُ الحديثُ يُقصِي القديمَ، والسقفُ صريحٌ، وsrc وحدَهُ للقديمِ فقط"
else bad "sourceDirs()" "لم تُصدَّرِ الطبقةُ أو بقيَ خطأُ التخطيطِ الحديثِ"; fi
if [ -f "$MOD" ] && ! grep -qE "listFiles|java\\.net|ProcessBuilder" "$MOD"; then
  ok "الآلةُ ما برِحَتْ صافيةً: لا جردَ قرصٍ ولا شبكةَ ولا عمليةً"
else bad "حدودُ الآلةِ" "تسرّبَ ما لا يجوزُ في الطبقةِ الصافيةِ"; fi
LOC="$ZTMP9/app/src/main/java/almlk/LocalLibraries.java"
if [ -f "$LOC" ] && grep -qF "public static final int MAX_OUTPUT_FILES = 64;" "$LOC" \
&& grep -qF 'File aar = new File(new File(build, "outputs"), "aar");' "$LOC" \
&& grep -qF "return new Finding(entries, classpath, nodes, ignored, 0, over, outputsSignature(moduleDir), integrity);" "$LOC"; then
  ok "مخرجُ الوحدةِ بعدَدٍ محدودٍ وبوصفةِ aar القائمةِ — لا اختراعَ فكٍّ ثانيًا"
else bad "discoverOutputs" "لم تُصدَّرِ الآلةُ أو تغيَّرتِ الوصفةُ"; fi
LCI="$ZTMP9/app/src/main/java/almlk/LibraryClassIndex.java"
if [ -f "$LCI" ] && grep -qF "almlk.LocalLibraries.discoverOutputs(source.moduleDir, null);" "$LCI" \
&& grep -qF "for (File jar : built.classpath) {" "$LCI" && [ "$(grep -c "discoverOutputs" "$LCI")" = "1" ]; then
  ok "فهرسُ الأصنافِ يضمُّ مخرجَ الوحدةِ إلى جنبِ libs/ بمسارِ dedupe نفسِهِ"
else bad "LibraryClassIndex" "ضمُّ المخرجِ مفقودٌ أو مكرَّرٌ"; fi
BP="$ZTMP9/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
if [ -f "$BP" ] && grep -qF "drainSymbolQueue(queue, root, visitedSymbolFiles, projectKey, 10000);" "$BP" \
&& grep -qF "drainSymbolQueue(linked, null, visitedSymbolFiles, projectKey, LINKED_VISIT_BUDGET);" "$BP" \
&& grep -qF "private static final int LINKED_VISIT_BUDGET = 4000;" "$BP" \
&& grep -qF "if (!queue.isEmpty() || !linked.isEmpty()) {" "$BP"; then
  ok "المسحةُ تُجرُّ بطابورينِ وسقفينِ ونقصٌ معلنٌ — شجرةُ المشروعِ لا تجوعُ والوحدةُ لا تُهمَلُ"
else bad "collectSymbolIndex" "البذرةُ أو السقفُ مفقودٌ في الحزمةِ"; fi
if [ -f "$BP" ] && [ "$(grep -c "almlk.GradleProjectModules" "$BP")" = "0" ]; then
  ok "المتصفّحُ لا يعرفُ آلةَ الوحداتِ — الجذورُ تُسلَّمُ لهُ، مبدأُ 4ب٢‑ب١ باقٍ"
else bad "اقترانُ الطبقاتِ" "BrowserPager يمسُّ GradleProjectModules"; fi
MI="$ZTMP9/app/src/main/java/com/shima/demo/MainActivity.java"
if [ -f "$MI" ] && grep -qF "() -> scanned.projectModules.sourceDirs()" "$MI" \
&& [ "$(grep -c "scanned.projectModules.sourceDirs()" "$MI")" = "1" ] \
&& [ "$(grep -c "setLinkedSourceRoots(" "$MI")" = "1" ] \
&& ! grep -qE "= *[A-Za-z]+\.projectModules\.sourceDirs\(\);" "$MI"; then
  ok "المسنِدُ كسولٌ: الجذورُ تُحلُّ على خيطِ الفهرسةِ، والواجهةُ لا تمسُّ القرصَ"
else bad "MainActivity" "الحلُّ تسرَّبَ إلى خيطِ الواجهةِ أو غابَ الوصلُ"; fi
if grep -qF "linkedModuleSourcesStage136();" "$ZTMP9/qa/RegressionSuite.java" 2>/dev/null; then
  ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلةَ الشطرِ 136 — البوّاباتُ معَ الشيفرةِ"
else bad "عدّةُ الانحدارِ" "المرحلةُ 136 غيرُ مسجَّلةٍ في الحزمةِ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_4ب٢ب٢_"; then ok "ورقةُ تنفيذِ 4ب٢‑ب٢ في الحزمةِ مع الشيفرةِ"
else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_4ب٢ب٢_* مفقودٌ"; fi
if zq -q "reports/تقرير_دراسة_مصادر_الوحدات_المرتبطة"; then ok "ورقةُ دراسةِ الشطرِ في الحزمةِ — الدليلُ مصدَّرٌ"
else bad "ورقةُ الدراسةِ" "تقريرُ دراسةِ المصادرِ لم يُصدَّرْ"; fi
rm -rf "$ZTMP9"

echo "═══ [24] ═══"
echo "[24] الجولةُ 22/4ب٢‑ب٣: مواردُ الوحداتِ — R بحزمةِ الوحدةِ، وXML يرى خارجَ الجذرِ، وتحذيرٌ لا خطأُ بناءٍ"
DTMP36=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP36" 2>/dev/null
for sym in resourceRoots refreshModuleResources unionResources ModuleResources rClassBlock \
  setLinkedResourceRoots extraResourceRoots fromModuleIssues fromIssue isSameOrInside lineAt columnAt; do
  if grep -aFq -- "$sym" "$DTMP36"/classes*.dex 2>/dev/null; then ok "رمزُ الشطرِ «$sym» في الدكسِ — نُفِّذَ لا وُصِفَ"
  else bad "رمزُ الشطرِ $sym" "مفقودٌ من الدكسِ"; fi
done
for absent in "build/intermediates" "gen/R.java" "R.java" "-sourcepath" "gradle :lib:assembleDebug" "aapt2 "; do
  if grep -aFq -- "$absent" "$DTMP36"/classes*.dex 2>/dev/null; then bad "ما لا يُفعَلُ «$absent»" "ظهرَ في الدكسِ"
  else ok "لا «$absent» في الدكسِ — موردُ الوحدةِ يُقرأُ ولا يُبنى"; fi
done
rm -rf "$DTMP36"
ZTMP10=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/GradleProjectModules.java" "app/src/main/java/almlk/XmlResourceIndex.java" \
  "app/src/main/java/almlk/LibraryClassIndex.java" "app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" \
  "app/src/main/java/com/almlkid/kay/ui/ProjectDiagnostic.java" "app/src/main/java/com/shima/demo/MainActivity.java" \
  "qa/RegressionSuite.java" "VERSION" -d "$ZTMP10" 2>/dev/null
GM="$ZTMP10/app/src/main/java/almlk/GradleProjectModules.java"
if [ -f "$GM" ] && grep -qF "public List<File> resourceRoots()" "$GM" \
&& grep -qF "if (module.dir == null || !module.dir.isDirectory()) continue;" "$GM" \
&& grep -qF "if (!seen.add(canonical(module.dir))) continue;" "$GM" \
&& grep -qF "if (seen.add(canonical(res))) out.add(res);" "$GM" && ! grep -qF "getCanonicalPath()" "$GM" \
&& grep -qF "for (Module module : analysis)" "$GM" \
&& ! grep -qE "listFiles|java\.net|ProcessBuilder|isError" "$GM"; then
  ok "جذورُ المواردِ: الموصولةُ فقط، الموجودُ فقط، بلا جردِ قرصٍ ولا خطأِ ترجمةٍ"
else bad "resourceRoots()" "لم تُصدَّرِ الطبقةُ أو تسرَّبَ ما لا يجوزُ"; fi
XI="$ZTMP10/app/src/main/java/almlk/XmlResourceIndex.java"
if [ -f "$XI" ] && grep -qF "public static XmlResourceIndex build(File projectRoot, java.util.List<File> extraRoots)" "$XI" \
&& grep -qF "collectResDirs(projectRoot, 0, map);" "$XI" && grep -qF "collectResDirs(extra, 1, map);" "$XI" \
&& grep -qF "if (isSameOrInside(inside, extra)) continue;" "$XI"; then
  ok "ماشيٌ واحدٌ للجذرِ وللجذورِ الزائدةِ — الأسبقُ يفوزُ، فما في المشروعِ مقدَّمٌ"
else bad "XmlResourceIndex" "الحِلمةُ الكسولةُ مفقودةٌ أو استُبدِلَت بماشٍ ثانٍ"; fi
LI="$ZTMP10/app/src/main/java/almlk/LibraryClassIndex.java"
if [ -f "$LI" ] && grep -qF "new ModuleResources(source.moduleDir, appPackage(source), declared)" "$LI" \
&& grep -qF "blocks.add(rClassBlock(declared.get(i).rPackage, fields, !sets.get(i).certain()));" "$LI" \
&& ! grep -qF "rClassBlock(declared.get(i).rPackage, fields, true)" "$LI" \
&& grep -qF "if (snapshot.request.transitiveR) {" "$LI" \
&& grep -qF "firstPass ? module.resources : projectResources(module.dir)" "$LI" \
&& [ "$(grep -c "rClassBlock(" "$LI")" = "4" ]; then
  ok "R كلِّ وحدةٍ بحزمتِها مُثبَتٌ بشارةِ مَسحِها، والتصعيدُ إلى R التطبيقِ عندَ تصريحِ التعَدّي فقط"
else bad "LibraryClassIndex" "مواردُ الوحداتِ لم تدخلِ الفهرسَ أو دُمِجَت بلا شرطٍ"; fi
BP="$ZTMP10/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
if [ -f "$BP" ] && grep -qF "public void setLinkedResourceRoots(File projectRoot," "$BP" \
&& grep -qF "if (ownRoot != null && !canonicalPath(ownRoot).equals(linkedResourceProjectPath)) return null;" "$BP" \
&& grep -qF "almlk.XmlResourceIndex.build(root, extraResourceRoots(root)).lookup(reference);" "$BP" \
&& [ "$(grep -c "almlk.GradleProjectModules" "$BP")" = "0" ] && ! grep -q "GradleBuildModel" "$BP"; then
  ok "المتصفّحُ يُسألُ عن الجذورِ ولا يحملُ نموذجَ بناءٍ — خِطمٌ كما أُقِرَّ لا أكثرَ"
else bad "اقترانُ الطبقاتِ" "BrowserPager يمسُّ النموذجَ أو حِلمتُهُ ناقصةٌ"; fi
PD="$ZTMP10/app/src/main/java/com/almlkid/kay/ui/ProjectDiagnostic.java"
if [ -f "$PD" ] && grep -qF "public static ProjectDiagnostic fromIssue(" "$PD" \
&& grep -qF "public static java.util.List<ProjectDiagnostic> fromModuleIssues(" "$PD" \
&& sed -n "/public static ProjectDiagnostic fromIssue(/,/^  }/p" "$PD" | grep -qF "Severity.WARNING," \
&& ! sed -n "/public static ProjectDiagnostic fromIssue(/,/^  }/p" "$PD" | grep -q "Severity.ERROR"; then
  ok "علامةُ الوحدةِ تحذيرٌ صريحٌ — لا بانرَ فشلٍ ولا شارةَ خطأٍ لمن لم يصلْ إليهِ المسارُ"
else bad "fromIssue" "الشدةُ مغلوطَةٌ أو الصانعُ مفقودٌ"; fi
MI="$ZTMP10/app/src/main/java/com/shima/demo/MainActivity.java"
if [ -f "$MI" ] && grep -qF "() -> scanned.projectModules.resourceRoots()" "$MI" \
&& [ "$(grep -c "setLinkedResourceRoots(" "$MI")" = "1" ] \
&& grep -qF "ProjectDiagnostic.fromModuleIssues(model == null ? null : model.projectModules)" "$MI" \
&& ! grep -q "GradleProjectModules" "$MI" \
&& [ "$(grep -c "for (ProjectDiagnostic item : moduleDiagnostics) {" "$MI")" = "1" ] \
&& [ "$(grep -c "moduleDiagnostics.clear();" "$MI")" = "3" ]; then
  ok "النشاطُ يسلِّمُ مُورِّدًا كسولًا ويضمُّ قائمةً خامسةً — لا قرصَ في خيطِ الواجهةِ"
else bad "MainActivity" "الوصلُ الكسولُ أو الدمجُ الخامسُ مفقودٌ"; fi
if [ -f "$ZTMP10/qa/RegressionSuite.java" ] && grep -qF "linkedModuleResourcesStage137();" "$ZTMP10/qa/RegressionSuite.java"; then
  ok "عدّةُ الانحدارِ المصدَّرةُ تحملُ مرحلةَ الشطرِ 137 — البوّاباتُ معَ الشيفرةِ في الحزمةِ"
else bad "عدّةُ الانحدارِ" "المرحلةُ 137 غيرُ مسجَّلةٍ في الحزمةِ"; fi
if [ -f "$ZTMP10/VERSION" ] && [ "$(tr -d '[:space:]' < "$ZTMP10/VERSION")" = "$VERSION" ]; then
  ok "الحزمةُ تحملُ بصمةَ الجولةِ $VERSION — البصمةُ تُقارَنُ بالمتغيّرِ لا بحرفِ جولةٍ، فلا تَبلى"
else bad "بصمةُ الإصدارِ" "VERSION في الحزمةِ ليسَ $VERSION"; fi
if zq -q "reports/تقرير_تنفيذ_W22_4ب٢ب٣_"; then ok "ورقةُ تنفيذِ 4ب٢‑ب٣ في الحزمةِ"
else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_4ب٢ب٣_* مفقودٌ"; fi
if zq -q "reports/تقرير_دراسة_موارد_الوحدات_المرتبطة"; then ok "ورقةُ دراسةِ 4ب٢‑ب٣ في الحزمةِ"
else bad "ورقةُ الدراسةِ" "تقريرُ دراسةِ المواردِ لم يُصدَّرْ"; fi
if zq -qE "res/layout/(dialog_module|activity_module)"; then bad "واجهةٌ مُختَرَعةٌ" "شاشةُ إدارةِ وحداتٍ ظهرتْ"
else ok "لا شاشةَ وحداتٍ ولا حوارَ «تعذّرَ الحلُّ» — العلامةُ في اللوحةِ القائمةِ فقط"; fi
rm -rf "$ZTMP10"
echo "═══ [25] ═══"
echo "[25] الجولةُ 22/4ب٢‑ب٤: مانيفستُ الوحدةِ — الموضعُ والحزمةُ وتحويلاتُها وأثرُها في عُقَدِ التحليلِ"
DTMP37=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP37" 2>/dev/null
for sym in "almlk/AndroidManifestModel" 'AndroidManifestModel$Component' packageOf componentsOf \
  unresolvedPlaceholders fromManifestComponents wantsAndroidPackage isProjectPackage \
  "no package= in AndroidManifest.xml" "in this project" readAar appPackage; do
  if grep -aFq -- "$sym" "$DTMP37"/classes*.dex 2>/dev/null; then ok "رمزُ الشطرِ «$sym» في الدكسِ — نُفِّذَتْ لا كُتِبَتْ"
  else bad "رمزُ الشطرِ $sym" "مفقودٌ من الدكسِ"; fi
done
for absent in "injected/AndroidManifest" "merged/AndroidManifest" "Enter AndroidManifest.xml file path" \
  "com.aide.merger" "gen/R.java" "aapt call"; do
  if grep -aFq -- "$absent" "$DTMP37"/classes*.dex 2>/dev/null; then bad "ما لا يُفعَلُ «$absent»" "ظهرَ في الدكسِ"
  else ok "لا «$absent» في الدكسِ — نُقرأُ المانيفستَ ولا ندمجُهُ ولا نولّدُ منهُ"; fi
done
rm -rf "$DTMP37"
ZTMP11=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/AndroidManifestModel.java" "app/src/main/java/almlk/LibraryClassIndex.java" \
  "app/src/main/java/almlk/GradleProjectModules.java" "app/src/main/java/almlk/ProjectScaffold.java" \
  "app/src/main/java/com/almlkid/kay/ui/ProjectDiagnostic.java" "app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" \
  "app/src/main/java/com/shima/projects/ProjectWizard.java" "qa/RegressionSuite.java" "qa.sh" "VERSION" -d "$ZTMP11" 2>/dev/null
AM="$ZTMP11/app/src/main/java/almlk/AndroidManifestModel.java"
if [ -f "$AM" ] && grep -qF 'File modern = new File(new File(new File(moduleDir, "src"), "main"), "AndroidManifest.xml");' "$AM" \
&& grep -qF 'File legacy = new File(moduleDir, "AndroidManifest.xml");' "$AM" \
&& grep -qF 'return legacy.isFile() ? legacy : null;' "$AM" \
&& grep -qF 'if (manifestText.startsWith("<!--", lt)) {' "$AM" \
&& grep -qF 'public static final int MAX_COMPONENTS = 256;' "$AM" \
&& ! grep -qE "Pattern\\.compile|listFiles|FileReader|Files\\.read|java\\.net|ProcessBuilder|FileOutputStream" "$AM"; then
  ok "قارئٌ صافٍ بموضعَيْنِ وسقفٍ وتجاوزِ تعليقٍ — لا نمطًا ولا قرصَ ولا عمليةَ خارجيةً"
else bad "AndroidManifestModel" "القارئُ الصافيُ مفقودٌ أو تسرَّبَ ما لا يجوزُ"; fi
LI="$ZTMP11/app/src/main/java/almlk/LibraryClassIndex.java"
if [ -f "$LI" ] && ! grep -qF "MANIFEST_PACKAGE" "$LI" \
&& grep -qF "data.packageName = AndroidManifestModel.packageOf" "$LI" \
&& grep -qF "File manifest = AndroidManifestModel.find(model.moduleDir, GradleSourceSets.of(model.text).manifestFile);" "$LI" \
&& grep -qF "return manifest == null ? \"\" : AndroidManifestModel.packageOf(readText(manifest));" "$LI" \
&& [ "$(grep -c "AndroidManifestModel\." "$LI")" = "3" ]; then
  ok "مسارٌ واحدٌ للحزمةِ — النمطُ القديمُ مُحالٌ، والـ AAR والوحدةُ بمِسطرةٍ واحدةٍ"
else bad "مسارُ الحزمةِ" "بقيَ نمطٌ ثانٍ أو لم تُستعمَلِ الآلةُ الجديدةُ"; fi
GM="$ZTMP11/app/src/main/java/almlk/GradleProjectModules.java"
if [ -f "$GM" ] && [ "$(grep -c "static boolean wantsAndroidPackage(GradleBuildModel model)" "$GM")" = "1" ] \
&& grep -qF "if (!wantsAndroidPackage(module.model)) continue;" "$GM" \
&& [ "$(grep -c "new Issue(\"manifest\"" "$GM")" = "1" ] \
&& grep -qF "no package= in AndroidManifest.xml and no namespace in build file of " "$GM" \
&& grep -qF "no namespace in build file and no AndroidManifest.xml in " "$GM" \
&& ! grep -qE "isError\\(|listFiles|java\\.net|ProcessBuilder" "$GM"; then
  ok "العلامةُ مُسمّاةٌ على سطرٍ، للوحداتِ الأندرويديّةِ وحدَها — بلا خطأِ ترجمةٍ ولا جردِ قرصٍ"
else bad "علامةُ المانيفستِ" "الشروطُ أو السطورُ أو الانصرافُ مختلٌّ"
fi
PD="$ZTMP11/app/src/main/java/com/almlkid/kay/ui/ProjectDiagnostic.java"
if [ -f "$PD" ] && grep -qF "public static java.util.List<ProjectDiagnostic> fromManifestComponents(" "$PD" \
&& sed -n "/fromManifestComponents(/,/^  }/p" "$PD" | grep -qF "Severity.WARNING," \
&& ! sed -n "/fromManifestComponents(/,/^  }/p" "$PD" | grep -qE "Severity.ERROR|QuickFix" \
&& sed -n "/fromManifestComponents(/,/^  }/p" "$PD" | grep -qF "if (!mine) continue;" \
&& sed -n "/fromManifestComponents(/,/^  }/p" "$PD" | grep -qF "if (pkg.isEmpty()) return out;"; then
  ok "المكوّنُ المفقودُ تحذيرٌ موسومٌ — ولا حُكمَ بلا حزمةٍ، ولا ادّعاءَ على اسمٍ غريبٍ"
else bad "منطقةُ المصنعِ" "الشدةُ أو الحارسُ مفقودٌ"; fi
BP="$ZTMP11/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
if [ -f "$BP" ] && grep -qF 'endsWith("androidmanifest.xml")' "$BP" \
&& grep -qF "ProjectSymbolIndex.isProjectPackage(manifestPackage)" "$BP" \
&& grep -qF "ProjectSymbolIndex::knowsClass" "$BP" \
&& grep -qF "MAX_MANIFEST_ROWS = 24" "$BP" \
&& [ "$(awk '/endsWith\("androidmanifest.xml"\)/{g=NR} /fromManifestComponents/{h=NR} END{print (g>0&&h>g&&h-g<40)?1:0}' "$BP")" = "1" ] \
&& ! grep -qE "GradleBuildModel|GradleProjectModules" "$BP"; then
  ok "الوشُ في مسحةِ الفحصِ نفسِها، وبعدَ حُسنِ الظنِّ بالفهرسِ — والمتصفّحُ لا يعرفُ طبقةَ النموذجِ"
else bad "وشُ المتصفّحِ" "الشرطُ أو السقفُ أو الفصلُ مختلٌّ"; fi
PW="$ZTMP11/app/src/main/java/com/shima/projects/ProjectWizard.java"
if [ -f "$PW" ] && grep -qF "almlk.AndroidManifestModel.find(mainModule)" "$PW" \
&& ! grep -qF 'new File(mainModule, "src/main/AndroidManifest.xml"),' "$PW"; then
  ok "ما نكتبُهُ هو ما نقرَؤُهُ — الإنشاءُ يسلكُ مواضعَ القارئِ نفسِها"
else bad "المسارُ في الإنشاءِ" "بقيَ مسارٌ مرسومٌ يدويًّا"; fi
PS="$ZTMP11/app/src/main/java/almlk/ProjectScaffold.java"
if [ -f "$PS" ] && ! grep -qF "MANIFEST_PACKAGE" "$PS"; then
  ok "لا مرجعَ في التعليقاتِ إلى نمطٍ محذوفٍ — الشرحُ يسمّي آلةَ اليومِ"
else bad "تعليقُ الدمجِ" "يسمّي ما لم يعدْ موجودًا"; fi
if [ -f "$ZTMP11/qa.sh" ] && grep -qF '"$SRC/almlk/AndroidManifestModel.java"' "$ZTMP11/qa.sh" \
&& grep -qF "manifestModuleStage138();" "$ZTMP11/qa/RegressionSuite.java"; then
  ok "الحزمةُ تحملُ صنفَ القائمةِ الصافيةِ ومرحلةَ البوّاباتِ 138 — العُدّةُ مع الشيفرةِ"
else bad "عُدّةُ الانحدارِ المصدَّرةُ" "القائمةُ الصافيةُ أو المرحلةُ 138 ناقصةٌ"; fi
if zq -q "reports/تقرير_دراسة_مانيفست_الوحدات_المرتبطة"; then ok "ورقةُ دراسةِ 4ب٢‑ب٤ في الحزمةِ"
else bad "ورقةُ الدراسةِ" "reports/تقرير_دراسة_مانيفست_الوحدات_المرتبطة_* مفقودٌ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_4ب٢ب٤_"; then ok "ورقةُ تنفيذِ 4ب٢‑ب٤ في الحزمةِ"
else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_4ب٢ب٤_* مفقودٌ"; fi
if zq -qE "res/layout/(activity_manifest|dialog_manifest)"; then bad "واجهةٌ مُختَرَعةٌ" "شاشةُ مانيفستٍ في الحزمةِ"
else ok "لا شاشةَ تحريرِ مانيفستَ ولا حوارَ «حدّدْ مسارَهُ» — القراءةُ تُستعمَلُ حيثُ هي كائنةٌ"; fi
rm -rf "$ZTMP11"

echo "[26] الجولةُ 22/4ب٢‑ج: ما يُعلنُهُ المشروعُ في ‏sourceSets يُصدَّقُ — مصادرُ، ومواردُ، ومانيفستٌ، ومسارٌ يُفتَحُ"
DTMP38=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$DTMP38" 2>/dev/null
for sym in "almlk/GradleSourceSets" 'almlk/GradleSourceSets$Declared' ofModule declaredResDirs \
  MAX_DECLARED_PER_KIND KIND_ASSETS looksLikeResDir linkedRootPrefixes isUnderLinkedRoot nextBlockName skipStatement; do
  if grep -aFq -- "$sym" "$DTMP38"/classes*.dex 2>/dev/null; then ok "رمزُ الشطرِ «$sym» في الدكسِ — نُفِّذَتْ لا كُتِبَتْ"
  else bad "رمزُ الشطرِ $sym" "مفقودٌ من الدكسِ"; fi
done
for absent in mergeAssets processResources generateDebugRFile "Omitting aapt" "injected/AndroidManifest" "ZipFile(" ; do
  if grep -aFq -- "$absent" "$DTMP38"/classes*.dex 2>/dev/null; then bad "ما لا يُفعَلُ «$absent»" "ظهرَ في الدكسِ"
  else ok "لا «$absent» في الدكسِ — نقرؤُ إعلانَ المساراتِ ولا نستدعي آلةَ البناءِ ولا نفكُّ حاويةً"; fi
done
rm -rf "$DTMP38"
ZTMP12=$(mktemp -d)
unzip -oq "$ZIP" "app/src/main/java/almlk/GradleSourceSets.java" "app/src/main/java/almlk/GradleProjectModules.java" \
  "app/src/main/java/almlk/XmlResourceIndex.java" "app/src/main/java/almlk/LibraryClassIndex.java" \
  "app/src/main/java/almlk/AndroidManifestModel.java" "app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" \
  "app/src/main/java/com/shima/demo/MainActivity.java" "qa/RegressionSuite.java" "qa.sh" "VERSION" -d "$ZTMP12" 2>/dev/null
GS="$ZTMP12/app/src/main/java/almlk/GradleSourceSets.java"
if [ -f "$GS" ] && grep -qF "public static final int MAX_DECLARED_PER_KIND = 12;" "$GS" \
&& grep -qF "public static final int MAX_BUILD_TEXT_BYTES = 256 * 1024;" "$GS" \
&& grep -qF "public static final String KIND_JAVA = \"java\";" "$GS" \
&& grep -qF "public static final String KIND_ASSETS = \"assets\";" "$GS" \
&& grep -qF "String[] kinds = {KIND_JAVA, KIND_KOTLIN, KIND_RES, KIND_ASSETS, \"manifest\"};" "$GS" \
&& grep -qF "setSrcDirs" "$GS" && grep -qF "nextBlockName" "$GS" && grep -qF "skipStatement" "$GS" \
&& grep -qF "public static Declared of(" "$GS" && grep -qF "ofModule(File" "$GS" \
&& grep -qF "declaredResDirs(File" "$GS" && grep -qF "dirs(File" "$GS"; then
  ok "الصنفُ الصافيُ: الأنواعُ الأربعةُ والمانيفستُ، والصيغُ كلُّها (‏=، ‏+=، ‏setSrcDirs، ‏srcDir)، وسقفانِ"
else bad "محلِّلُ ‏sourceSets" "صيغةٌ أو نوعٌ أو سقفٌ مفقودٌ"; fi
if [ -f "$GS" ] && ! grep -qE "java\.util\.regex|Pattern\.compile" "$GS" \
&& ! grep -qE "java\.net|ProcessBuilder|Runtime\.getRuntime|RMI" "$GS" \
&& ! grep -qE "walkFileTree|Files\.list" "$GS"; then
  ok "لا نمطًا نظاميَّ ولا شبكةَ ولا عمليةً خارجيةً ولا مشيَ شجرَةٍ — نصُّ ملفِّ بناءٍ ومسارٌ واحدٌ"
else bad "خفّةُ المحلِّلِ" "تبعيةٌ ثقيلةٌ دخيلةٌ"; fi
GP="$ZTMP12/app/src/main/java/almlk/GradleProjectModules.java"
if [ -f "$GP" ] && grep -qF "public static final int MAX_SOURCE_DIRS = 36;" "$GP" \
&& grep -qF "GradleSourceSets.Declared declared = GradleSourceSets.of(module.model == null ? \"\" : module.model.text);" "$GP" \
&& grep -qF "for (File dir : GradleSourceSets.dirs(module.dir, declared.java)) addSourceDir(out, seen, dir);" "$GP" \
&& grep -qF "for (File dir : GradleSourceSets.dirs(module.dir, declared.kotlin)) addSourceDir(out, seen, dir);" "$GP" \
&& grep -qF "for (File res : GradleSourceSets.dirs(module.dir, GradleSourceSets.of(" "$GP" \
&& grep -qF "if (seen.add(canonical(res))) out.add(res);" "$GP" \
&& ! grep -qF "getCanonicalPath()" "$GP" && grep -qF "private static String canonical(File" "$GP"; then
  ok "المُعلَنُ يسبقُ العُرفَ في المصادرِ و‏res المُعلَنُ يُضَمُّ إلى الجذورِ — بمِسطرةِ مسارٍ واحدةٍ لكلِّ الطبقاتِ"
else bad "طبقةُ المساراتِ" "الإعلانُ غيرُ مُصدَّقٍ أو المِسطرةُ مُكرَّرةٌ"; fi
XI="$ZTMP12/app/src/main/java/almlk/XmlResourceIndex.java"
if [ -f "$XI" ] && grep -qF "if (depth > 0 && looksLikeResDir(children)) {" "$XI" \
&& grep -qF "private static boolean looksLikeResDir(File[] children)" "$XI" \
&& grep -qF "public static XmlResourceIndex build(File projectRoot, java.util.List<File> extraRoots)" "$XI" \
&& grep -qF "public static XmlResourceIndex build(File projectRoot)" "$XI" \
&& ! grep -qE "GradleBuildModel|GradleProjectModules|ProcessBuilder" "$XI"; then
  ok "الماسحُ يقبلُ الجذرَ المُعلَنَ تحتَ حدِّ العُمقِ، بغيرِ ماسحٍ ثانٍ ولا نموذجٍ دخيلٍ"
else bad "مسحُ المواردِ" "الحارسُ أو التوقيعُ مختلٌّ"; fi
LC="$ZTMP12/app/src/main/java/almlk/LibraryClassIndex.java"
if [ -f "$LC" ] && grep -qF "GradleSourceSets.declaredResDirs(moduleDir)" "$LC" \
&& grep -qF "AndroidManifestModel.find(model.moduleDir, GradleSourceSets.of(model.text).manifestFile)" "$LC" \
&& grep -qF "new ModuleResources(source.moduleDir, appPackage(source), declared)" "$LC"; then
  ok "‏R يرى الجذورَ المُعلَنةَ ومانيفستَها المرسومَ، وصيغةُ العقدِ باقيةٌ على عهدِها"
else bad "عقدةُ المواردِ" "طيُّ الجذورِ أو موضعُ المانيفستِ مُختلٌّ"; fi
AM="$ZTMP12/app/src/main/java/almlk/AndroidManifestModel.java"
if [ -f "$AM" ] && grep -qF "public static File find(File moduleDir, String declaredSrcFile)" "$AM" \
&& grep -qF "return find(moduleDir, null);" "$AM" && grep -qF "if (declared.isFile()) return declared;" "$AM" \
&& grep -qF "return legacy.isFile() ? legacy : null;" "$AM"; then
  ok "الموضعُ المُعلَنُ يُقدَّمُ على العُرفَيْنِ، فإن لم يكنْ فلا اختراعَ لمسارٍ بلا ملفٍ"
else bad "مواضعُ المانيفستِ" "الحِملُ الثلاثيُّ مفقودٌ"; fi
BP="$ZTMP12/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
if [ -f "$BP" ] && grep -qF "private volatile String[] linkedRootPrefixes = new String[0];" "$BP" \
&& grep -qF "linkedRootPrefixes = prefixes.toArray(new String[0]);" "$BP" \
&& grep -qF "|| isUnderLinkedRoot(candidatePath))) {" "$BP" \
&& grep -qF "drainSymbolQueue(linked, null, visitedSymbolFiles, projectKey, LINKED_VISIT_BUDGET);" "$BP" \
&& grep -qF "LINKED_VISIT_BUDGET = 4000" "$BP"; then
  ok "جذورُ الوحداتِ لقطةٌ في الذاكرةِ تُملَأُ من الحِمتينِ الكسولتينِ، وتُقبَلُ في مطابقةِ مسارِ الخطأِ"
else bad "مسارُ اللوحةِ" "القناةُ الكسولةُ أو مطابقةُ البادئةِ مختلَّةٌ"; fi
if [ -f "$BP" ] && sed -n '/private boolean isUnderLinkedRoot(String candidatePath)/,/^  }/p' "$BP" \
| grep -qE "FileInputStream|listFiles|\.get()"; then bad "مشيُ القرصِ في خيطِ الواجهةِ" "المطابقةُ تفتحُ ملفًّا أو تُحرِّكُ صانعًا"
else ok "المطابقةُ تُقارنُ بادئاتٍ مسبوكةً — لا قرصَ في خيطِ الواجهةِ ولا صانعَ يُستدعى"; fi
if [ -f "$BP" ] && ! grep -qE "GradleBuildModel|GradleProjectModules|ProcessBuilder|assembleDebug|gradlew" "$BP"; then
  ok "المتصفِّحُ لا يعرفُ طبقةَ النموذجِ ولا يستدعي بناءً — التوثيقُ مسارٌ لا شاشةٌ"
else bad "فصلُ الطبقاتِ" "نموذجُ البناءِ تسرَّبَ إلى المتصفِّحِ"; fi
MA="$ZTMP12/app/src/main/java/com/shima/demo/MainActivity.java"
if [ -f "$MA" ] && [ "$(grep -c 'setLinkedSourceRoots(' "$MA")" = "1" ]; then
  ok "حِمتا الربطِ على حالِها لا ثالثةَ لهما — لا واجهةَ جديدةً ولا مسارًا جانبيًّا"
else bad "حِمَمُ الربطِ" "عددُها تغيَّرَ"; fi
if [ -f "$ZTMP12/qa.sh" ] && grep -qF '"$SRC/almlk/GradleSourceSets.java"' "$ZTMP12/qa.sh" \
&& grep -qF "sourceSetsStage139();" "$ZTMP12/qa/RegressionSuite.java" \
&& grep -qF "$VERSION" "$ZTMP12/VERSION"; then
  ok "العُدَّةُ في الحزمةِ: الصنفُ في قائمةِ الصافيِ، والمرحلةُ 139ُ مسجَّلةٌ، والبصمةُ $VERSION"
else bad "عُدَّةُ الانحدارِ المصدَّرةُ" "القائمةُ الصافيةُ أو المرحلةُ أو البصمةُ"; fi
JET=$(unzip -l "$APK" 2>/dev/null | grep -c "\.jet")
AHEAVY=$(unzip -l "$APK" 2>/dev/null | awk '/assets\// {if ($1>1000000) c++} END {print c+0}')
if [ "$JET" = "0" ] && [ "$AHEAVY" = "1" ]; then
  ok "لا ‏.jet ولا حِملَ جديدًا في ‏assets/ — فهارسُ الإكمالِ تُرسَلُ ‏.gz وتُفكُّ في البناءِ، لا أكثرَ"
else bad "حمولةُ ‏assets/" "حاويةٌ مضغوطةٌ لم تُقرَّرْ بعدُ، أو حِملٌ زادَ بلا إذنٍ"; fi
if unzip -l "$ZIP" 2>/dev/null | grep -qE "\-sources\.jar|\-javadoc\.jar"; then bad "استبعاداتُ الحزمةِ" "مصادرُ أو توثيقُ jars تسرَّبا"
else ok "لا ‏*-sources.jar ولا ‏*-javadoc.jar في الحزمةِ المصدريّةِ"; fi
if zq -q "reports/تقرير_دراسة_مجلدات_المصادر_المعلنة_وتوثيق_الوحدات_W22_4ب٢ج"; then ok "ورقةُ دراسةِ 4ب٢‑ج في الحزمةِ"
else bad "ورقةُ الدراسةِ" "تقرير_دراسة_مجلدات_المصادر_المعلنة_وتوثيق_الوحدات_W22_4ب٢ج.md مفقودٌ"; fi
if zq -q "reports/تقرير_تنفيذ_W22_4ب٢ج_"; then ok "ورقةُ تنفيذِ 4ب٢‑ج في الحزمةِ"
else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_4ب٢ج_* مفقودٌ"; fi
if zq -qE "app/src/main/res/layout/(activity_manifest|dialog_manifest|activity_modules)"; then bad "واجهةٌ مُختَرَعةٌ" "شاشةُ وحداتٍ أو مصادرَ جديدةٌ في الحزمةِ"
else ok "لا شاشةَ «الوحداتُ» ولا تبويبَ جديدًا — التوثيقُ في المسارِ لا في صفةٍ مستحدَثةٍ"; fi
rm -rf "$ZTMP12"


echo "[27] الجولةُ 22/5أ — مِشْبَرُ ‏signingConfigs: علامةٌ على القرصِ، لا بناءَ ولا سرَّ في الوصفِ"
ZTMP13=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZTMP13" 2>/dev/null; then
  P13="$ZTMP13/app/src/main/java/almlk/GradleSigningConfigs.java"
  if [ -f "$P13" ]; then ok "الصنفُ في الحزمةِ المصدريّةِ: ‏almlk/GradleSigningConfigs.java"
  else bad "الحزمةُ المصدريّةُ" "‏almlk/GradleSigningConfigs.java مفقودٌ"; fi
  if [ -f "$P13" ] && ! grep -qE "ProcessBuilder|Runtime\.getRuntime|KeyStore|HttpURLConnection|java\.net" "$P13"; then
    ok "لا أداةَ بناءٍ ولا مفتاحَ قرصٍ ولا شبكةَ في المِشبرِ — قراءةُ نصٍّ لا غيرُ"
  else bad "طبيعةُ المِشبرِ" "أداةُ بناءٍ أو مخزنُ مفاتيحَ أو شبكةٌ تسرَّبتْ إليهِ"; fi
  if [ -f "$P13" ] && ! grep -qE "String storePassword|String keyPassword" "$P13" \
  && grep -q "storePasswordSet" "$P13" && grep -q "keyPasswordSet" "$P13"; then
    ok "السرُّ عَلمٌ لا نصٌّ: لا خانةَ سرٍّ في الحالةِ، فلا تُطبعُ ولا تُرسَلُ"
  else bad "حِفظُ السرِّ" "الحالةُ تحملُ نصَّ السرِّ أو لا تحملُ عَلمَ وجودِهِ"; fi
  if grep -q 'new Issue("signing"' "$ZTMP13/app/src/main/java/almlk/GradleProjectModules.java" \
  && [ "$(grep -c 'new Issue("signing"' "$ZTMP13/app/src/main/java/almlk/GradleProjectModules.java")" = "4" ]; then
    ok "أربعُ علاماتِ توقيعٍ في اللوحةِ القائمةِ — لا شاشةَ ولا صانعَ ثانيًا"
  else bad "نِطاقَ العلامةِ" "مواضعُ ‏signing ليست أربعةً"; fi
  if grep -qF '"$SRC/almlk/GradleSigningConfigs.java"' "$ZTMP13/qa.sh" \
  && grep -qF "signingConfigsStage140();" "$ZTMP13/qa/RegressionSuite.java" \
  && grep -qF "$VERSION" "$ZTMP13/VERSION"; then
    ok "العُدَّةُ في الحزمةِ: الصنفُ في قائمةِ الصافيِ، والمرحلةُ 140ُ مسجَّلةٌ، والبصمةُ $VERSION"
  else bad "عُدَّةُ الانحدارِ المصدَّرةُ" "القائمةُ الصافيةُ أو المرحلةُ أو البصمةُ"; fi
  if zq -q "reports/تقرير_دراسة_التوقيعُ_والتصديرُ_والتثبيتُ_W22_5"; then
    ok "ورقةُ دراسةِ المرحلةِ الخامسةِ في الحزمةِ"
  else bad "ورقةُ الدراسةِ" "تقرير_دراسة_التوقيعُ_والتصديرُ_والتثبيتُ_W22_5.md مفقودٌ"; fi
  if zq -q "reports/تقرير_تنفيذ_W22_5أ_"; then ok "ورقةُ تنفيذِ 5أ في الحزمةِ"
  else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_5أ_* مفقودٌ"; fi
  if [ -f "$ZTMP13/reports/تقرير_دراسة_التوقيعُ_والتصديرُ_والتثبيتُ_W22_5.md" ] \
  && grep -q "ResourceApkBuilder" "$ZTMP13/reports/تقرير_دراسة_التوقيعُ_والتصديرُ_والتثبيتُ_W22_5.md" \
  && grep -q "KeyStore.load" "$ZTMP13/reports/تقرير_دراسة_التوقيعُ_والتصديرُ_والتثبيتُ_W22_5.md"; then
    ok "الورقةُ تشهدُ على المرجعِ: ‏ResourceApkBuilder و‏KeyStore.load مقيَّدانِ بموضعِهِما"
  else bad "شهادةُ المرجعِ" "أسماءُ طبقاتِ التوقيعِ في المرجعِ ناقصةٌ"; fi
  if zq -qE "app/src/main/res/layout/(activity|dialog|row|item)_[a-z_]*(signing|keystore)"; then bad "واجهةٌ مُختَرَعةٌ" "تخطيطُ توقيعٍ أو مخزنٍ في الحزمةِ"
  else ok "لا شاشةَ «التوقيعُ» ولا تبويبَ جديدًا — العلامةُ حيثَ تُعرَضُ العلاماتُ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ"; fi
if [ -f "$APK" ] && unzip -l "$APK" 2>/dev/null | grep -qE "\.(jks|keystore|jks\.gz)$"; then
  bad "موادُّ التوقيعِ" "مخزنُ مفاتيحَ دخلَ الحزمةَ"
else ok "لا ‏*.jks ولا ‏*.keystore في الحزمةِ — ما يُقرأُ على القرصِ لا يُحمَلُ معنا"; fi
rm -rf "$ZTMP13"

echo "[28] الجولةُ 22/5ب — قارئُ المَخازنِ: شهادةٌ تُقرَأُ بلا سِرٍّ، وعجزٌ علامةٌ لا رَمْيٌ"
ZTMP14=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZTMP14" 2>/dev/null; then
  KI="$ZTMP14/app/src/main/java/almlk/KeystoreInspector.java"
  if [ -f "$KI" ]; then ok "الصنفُ في الحزمةِ المصدريّةِ: ‏almlk/KeystoreInspector.java"
  else bad "الحزمةُ المصدريّةُ" "‏almlk/KeystoreInspector.java مفقودٌ"; fi
  # الشيفرةُ وحدَها تُحاسَبُ: الصنفُ يَذكُرُ في توثيقِهِ ما يَنفِيهِ عن نفْسِهِ
  KCODE="$ZTMP14/keystore-code.txt"
  if [ -f "$KI" ]; then grep -vE '^[[:space:]]*(\*|//|/\*)' "$KI" > "$KCODE"
  else : > "$KCODE"; fi
  if ! grep -qE "ProcessBuilder|Runtime\.getRuntime|HttpURLConnection|java\.net|KeyStore\.store\(|setKeyEntry|KeyPairGenerator|android\." "$KCODE"; then
    ok "قارئٌ لا كاتبُ ولا بانيَ: لا عمليةً خارجيّةً، ولا توليدَ، ولا ‏.store(‏ في الشيفرةِ"
  else bad "طبيعةُ القارئِ" "كِتابَةٌ أو توليدٌ أو أداةٌ خارجيّةٌ في الشيفرةِ"; fi
  if grep -q "MAX_ENTRIES = 32" "$KI" && grep -q "MAX_STORE_BYTES" "$KI" \
  && grep -q "MAX_ISSUES = 4" "$KI" && grep -q "MAX_CACHE = 8" "$KI"; then
    ok "أسقافٌ أربعةٌ مكتوبةٌ في الصنفِ: الحجمُ والاسماءُ والعلاماتُ والذاكرةُ"
  else bad "الأسقافُ" "سقفٌ من الأربعةِ مفقودٌ"; fi
  if grep -q "if (used) wipe(password)" "$KI" && ! grep -qE "new String\(password|password\.toString" "$KI"; then
    ok "الحروفُ تُمحَى بعدَ الفتحِ ولا تُنسخُ نصًّا — ولا تُطرَأُ على شاشةٍ"
  else bad "مصيرُ السرِّ" "لم يُمحَ بعدَ الاستعمالِ، أو نُسِخَ نصًّا"; fi
  if grep -q "KeyStore.getInstance" "$KI" && grep -q "java.security.KeyStore" "$KI" \
  && ! grep -q 'getInstance("AndroidKeyStore")' "$KI"; then
    ok "المنصّةُ تقرَأُ الكيسَ: ‏java.security.KeyStore‏ بلا ‏AndroidKeyStore‏ ولا شيفرةَ مُعمَّمَةٍ"
  else bad "آليّةُ القراءةِ" "لم تُترَكْ للمنصّةِ، أو يُمَسُّ مخزنُ أندرويدَ"; fi
  if [ "$(grep -c 'new Issue("keystore"' "$ZTMP14/app/src/main/java/almlk/GradleProjectModules.java")" = "2" ]; then
    ok "علامتانِ للمخزنِ في اللوحةِ القائمةِ — لا شاشةَ ولا صانعَ ثانيًا"
  else bad "نِطاقَ العلامةِ" "مواضعُ ‏keystore ليست اثنتينِ"; fi
  if grep -q "storePasswordSet" "$ZTMP14/app/src/main/java/almlk/GradleSigningConfigs.java" \
  && grep -q "storeFileOffset" "$ZTMP14/app/src/main/java/almlk/GradleSigningConfigs.java" \
  && grep -q "readStorePassword" "$ZTMP14/app/src/main/java/almlk/GradleSigningConfigs.java"; then
    ok "حضورُ السرِّ عَلمٌ وموقعٌ لا نصٌّ: المِشْبَرُ لا يَحفظُ حروفًا، والقرَّاءُ يَطلُبُها وقتَ الفتحِ"
  else bad "حِفظُ السرِّ" "الحالةُ فقدتْ عَلمَ Presence أو سطرَ الموقعِ أو سبيلَ القراءةِ"; fi
  if grep -qF '"$SRC/almlk/KeystoreInspector.java"' "$ZTMP14/qa.sh" \
  && grep -qF "keystoreInspectorStage141();" "$ZTMP14/qa/RegressionSuite.java" \
  && grep -qF "$VERSION" "$ZTMP14/VERSION"; then
    ok "العُدَّةُ في الحزمةِ: الصنفُ في قائمةِ الصافيِ، والمرحلةُ 141ُ مسجَّلةٌ، والبصمةُ $VERSION"
  else bad "عُدَّةُ الانحدارِ المصدَّرةُ" "القائمةُ الصافيةُ أو المرحلةُ أو البصمةُ"; fi
  if zq -q "reports/تقرير_دراسة_فحص_مخزن_المفاتيح_W22_5ب"; then
    ok "ورقةُ دراسةِ 5ب في الحزمةِ"
  else bad "ورقةُ الدراسةِ" "تقرير_دراسة_فحص_مخزن_المفاتيح_W22_5ب.md مفقودٌ"; fi
  if zq -q "reports/تقرير_تنفيذ_W22_5ب_"; then ok "ورقةُ تنفيذِ 5ب في الحزمةِ"
  else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_5ب_* مفقودٌ"; fi
  if zq -qE "app/src/main/res/layout/(activity|dialog|row|item)_[a-z_]*(keystore|store)"; then
    bad "واجهةٌ مُختَرَعةٌ" "شاشةُ مخزنٍ أو بطاقةُ مفتاحٍ جديدةٌ في الحزمةِ"
  else ok "لا شاشةَ «المخزنُ» ولا تبويبَ جديدًا — البطاقةُ في اللوحةِ التي تَعرِفُ العلاماتِ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ"; fi
if [ -f "$APK" ] && unzip -l "$APK" 2>/dev/null | grep -qE "\.(jks|keystore)(\.gz)?$"; then
  bad "موادُّ التوقيعِ" "مخزنُ مفاتيحَ دخلَ الحزمةَ المبنيةَ"
else ok "لا ‏*.jks ولا ‏*.keystore في الحزمةِ المبنيةِ — ما يُقرَأُ على قرصِ المشروعِ لا يُحمَلُ معنا"; fi
rm -rf "$ZTMP14"

echo "[29] الجولةُ 22/5ج — ما على القرصِ من مُخرَجٍ: وثيقةٌ تُصَدَّقُ بالملفِّ، وموقِّعٌ يُسأَلُ لا يُفتَرَضُ"
ZTMP15=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZTMP15" 2>/dev/null; then
  AA="$ZTMP15/app/src/main/java/almlk/ApkArtifacts.java"
  if [ -f "$AA" ]; then ok "الصنفُ في الحزمةِ المصدريّةِ: ‏almlk/ApkArtifacts.java"
  else bad "الحزمةُ المصدريّةُ" "‏almlk/ApkArtifacts.java مفقودٌ"
  fi
  : > "$ZTMP15/aa-code.txt"; : > "$ZTMP15/dc-code.txt"
  [ -f "$AA" ] && grep -vE '^[[:space:]]*(\*|//|/\*)' "$AA" > "$ZTMP15/aa-code.txt"
  grep -vE '^[[:space:]]*(\*|//|/\*)' "$ZTMP15/app/src/main/java/com/almlkid/ui/DependencyCycle.java" \
    > "$ZTMP15/dc-code.txt"
  if ! grep -qE "ProcessBuilder|Runtime\.getRuntime|getPackageArchiveInfo|PackageManager|android\.|org\.json|Gson" "$ZTMP15/aa-code.txt"; then
    ok "صَفاءٌ: قرصٌ فقطْ — لا ‏aapt، ولا ‏apksigner، ولا ‏getPackageArchiveInfo في الطبقةِ الصافيةِ"
  else bad "طبيعةُ الطبقةِ" "أداةٌ خارجيّةٌ أو اندرويدُ تسرّبا إلى الصافيِ"; fi
  if grep -qE "^\s*public final class ApkArtifacts \{$" "$ZTMP15/aa-code.txt" \
  && grep -q "private ApkArtifacts()" "$ZTMP15/aa-code.txt"; then
    ok "لا شاشةَ ولا حالةً مُتغيِّرةً في الصنفِ: ‏public‏ واحدٌ، وبابٌ خاصٌّ مُغلَقٌ"
  else bad "بُنيةُ الصنفِ" "بابٌ عامٌّ زائدٌ أو حالةٌ عابرةٌ"; fi
  if ! grep -qE "FileOutputStream|mkdirs|renameTo|createNewFile|installPackages|PackageInstaller" "$ZTMP15/aa-code.txt"; then
    ok "قارئٌ لا صانعَ: لا كتابةَ على القرصِ، ولا إنشاءَ مجلدٍ، ولا طلبَ تثبيتٍ (ذلكَ بابُ 5د)"
  else bad "حدودُ الدورِ" "الطبقةُ تَكتُبُ أو تُثبِّتُ"; fi
  if grep -q "MAX_JSON_BYTES = 256L \* 1024" "$AA" && grep -q "MAX_VARIANTS = 8" "$AA" \
  && grep -q "MAX_ISSUES = 4" "$AA" && grep -q "MAX_CACHE = 8" "$AA"; then
    ok "أسقافٌ أربعةٌ مكتوبةٌ في الصنفِ: الوثيقةُ والسجلاتُ والعلاماتُ والذاكرةُ"
  else bad "الأسقافُ" "سقفٌ من الأربعةِ مفقودٌ"; fi
  if grep -q '"output.json"' "$AA" && grep -q "build/outputs/apk" "$AA" \
  && grep -q 'new File(moduleDir, "bin/" + variant)' "$AA" \
  && ! grep -qE "gradlew|assembleDebug|assembleRelease" "$ZTMP15/aa-code.txt"; then
    ok "منهما وحدَهما: وثيقةُ ‏output.json، ثمَّ ‏bin/ القديمُ — ولا نِداءَ بناءٍ في الصنفِ"
  else bad "مَصدَرُ العِلْمِ" "غيرُ ما تَترُكُهِ الأداةُ على القرصِ، أو نِداءُ بناءٍ"; fi
  if grep -q 'contains("unsigned")' "$AA" && grep -q 'contains("aligned")' "$AA" \
  && grep -q "aligned+signed" "$AA" && grep -q 'return "unknown"' "$AA"; then
    ok "المرحلةُ من الاسمِ: سلاسلُ ‏insureFileNameV2 مَجمولةٌ، واسمُ الغِرلافِ لا يَقولُ شيئًا"
  else bad "مرحلةُ الملفِّ" "لم تُشتَقَّ من الاسمِ أو زُعِمَ التوقيعُ"; fi
  if [ "$(grep -c 'new Issue("artifacts"' "$ZTMP15/app/src/main/java/almlk/GradleProjectModules.java")" = "2" ]; then
    ok "علامتانِ فقطْ في اللوحةِ القائمةِ: عجزُ الوثيقةِ، وتوقيعٌ مُعلَنٌ بلا مُخرَجٍ"
  else bad "نِطاقَ العلامةِ" "مواضعُ ‏artifacts‏ ليست اثنتينِ"; fi
  if grep -q "getPackageArchiveInfo" "$ZTMP15/dc-code.txt" \
  && grep -q "apkSignerReader" "$ZTMP15/dc-code.txt" \
  && ! grep -qE "ProcessBuilder|apksigner|jarsigner" "$ZTMP15/dc-code.txt"; then
    ok "الموقِّعُ حَقْنٌ: نظامُ الجهازِ وحدَهُ يَقولُ، ولا ‏apksigner ولا ‏jarsigner"
  else bad "قارئُ الموقِّعِ" "لم يُحْقَن من الغلافِ، أو استُعمِلَت أداةٌ خارجيّةٌ"; fi
  if grep -qF '"$SRC/almlk/ApkArtifacts.java"' "$ZTMP15/qa.sh" \
  && grep -qF "apkArtifactsStage142();" "$ZTMP15/qa/RegressionSuite.java" \
  && grep -qF "$VERSION" "$ZTMP15/VERSION"; then
    ok "العُدَّةُ في الحزمةِ: الصنفُ في قائمةِ الصافيِ، والمرحلةُ 142ُ مسجَّلةٌ، والبصمةُ $VERSION"
  else bad "عُدَّةُ الانحدارِ المصدَّرةُ" "القائمةُ الصافيةُ أو المرحلةُ أو البصمةُ"; fi
  if zq -q "reports/تقرير_دراسة_مخرجات_البناء_على_القرص_W22_5ج"; then
    ok "ورقةُ دراسةِ 5ج في الحزمةِ — الدليلُ من ‏GradleProject.getOutputApks‏"
  else bad "ورقةُ الدراسةِ" "تقرير_دراسة_مخرجات_البناء_على_القرص_W22_5ج.md مفقودٌ"; fi
  if zq -q "reports/تقرير_تنفيذ_W22_5ج_"; then ok "ورقةُ تنفيذِ 5ج في الحزمةِ"
  else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_5ج_* مفقودٌ"; fi
  if zq -qE "app/src/main/res/layout/(activity|dialog|row|item)_[a-z_]*(artifact|outputs)"; then
    bad "واجهةٌ مُختَرَعةٌ" "شاشةُ مُخرَجاتٍ جديدةٌ في الحزمةِ"
  else ok "لا شاشةَ «المُخرَجاتُ» — سطرٌ في اللوحةِ التي تَعرِفُ العلاماتِ، كما قالَ المِدادُ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ"; fi
if [ -f "$APK" ] && unzip -l "$APK" 2>/dev/null | grep -qE "outputs/apk/[^/]*\.apk$"; then
  bad "مُخرَجاتُ المشروعِ" "ملفُّ ‏apk‏ من بِناءِ المشروعِ دُفِنَ في الحزمةِ"
else ok "ما يَجِدُهُ الصنفُ على قرصِ المشروعِ لا يُحمَلُ معنا — قراءةٌ وقتَ الحاجةِ"; fi
rm -rf "$ZTMP15"

echo "[30] الجولةُ 22/5د — التثبيتُ من اللوحةِ: نِيةٌ واحدةٌ على ‏content://، وحارسٌ للمظهَرِ لا شاشةَ جديدةً"
ZTMP16=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZTMP16" 2>/dev/null; then
  AP="$ZTMP16/app/src/main/java/almlk/ApkInstallPlan.java"
  if [ -f "$AP" ]; then ok "الصنفُ في الحزمةِ المصدريّةِ: ‏almlk/ApkInstallPlan.java"
  else bad "الحزمةُ المصدريّةُ" "‏almlk/ApkInstallPlan.java مفقودٌ"; fi
  : > "$ZTMP16/ap-code.txt"; : > "$ZTMP16/br-code.txt"
  [ -f "$AP" ] && grep -vE '^[[:space:]]*(\*|//|/\*)' "$AP" > "$ZTMP16/ap-code.txt"
  grep -vE '^[[:space:]]*(\*|//|/\*)' "$ZTMP16/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java" \
    > "$ZTMP16/br-code.txt"
  if ! grep -qE "^import (android|androidx)\.|import java\.net|FileProvider\.getUriForFile|startActivity|ProcessBuilder|Runtime\.getRuntime|PackageInstaller" "$ZTMP16/ap-code.txt"; then
    ok "صَفاءٌ: قرارٌ لا تنفيذٌ — لا ‏android.content‏ ولا ‏startActivity‏ ولا ‏PackageInstaller‏ في الصافيِ"
  else bad "طبيعةُ الطبقةِ" "استيرادٌ اندرويديٌّ أو نِداءُ نظامٍ تسرّبَ إلى الصافيِ"; fi
  if ! grep -qE "FileOutputStream|mkdirs|renameTo|createNewFile" "$ZTMP16/ap-code.txt"; then
    ok "لا كتابةَ ولا حذْفًا: القرارُ يحكُمُ على ما هوَ كائنٌ، ولا يصنعُهُ"
  else bad "حدودُ القرارِ" "الطبقةُ تَكتُبُ على القرصِ"; fi
  if grep -q "MAX_PROBLEMS = 4" "$AP" && grep -q "MAX_NAME = 240" "$AP" \
  && grep -q "MAX_RESOLVERS = 16" "$AP" && grep -q "MAX_TEXT = 64 \* 1024" "$AP"; then
    ok "أسقافٌ أربعةٌ: العلاماتُ والاسمُ والمُحَلِّلُونَ والوادِعانِ"
  else bad "الأسقافُ" "سقفٌ من الأربعةِ مفقودٌ"; fi
  MF="$ZTMP16/app/src/main/AndroidManifest.xml"
  if grep -q "androidx.core.content.FileProvider" "$MF" \
  && grep -q 'android:authorities="${applicationId}.fileprovider"' "$MF" \
  && grep -q 'android:exported="false"' "$MF" && grep -q 'android:grantUriPermissions="true"' "$MF" \
  && grep -q '@xml/file_paths' "$MF"; then
    ok "المُوفِّرُ مُعلَنٌ كما يَشاءُ ‏getUriForFile: أبثوريو من اسمِ الحزمةِ، ولا مُشارَكةٍ عامّةٍ"
  else bad "مُوفِّرُ الملفاتِ" "أبثوريو أو وثيقةُ المساراتِ أو الإقفالُ"; fi
  if grep -q "android.permission.REQUEST_INSTALL_PACKAGES" "$MF" \
  && ! grep -q "util_code_provider_paths" "$MF"; then
    ok "الإذنُ مُعلَنٌ، وأبثوريو المكتبةِ المحمولةِ (‏.utilcode.provider‏) لم يُستَعمَلْ — أبثوريو واحدٌ"
  else bad "الإذنُ والأبثوريو" "نقصَ الإذنُ أو تُرِكَ أبثوريو ثانٍ"; fi
  FP="$ZTMP16/app/src/main/res/xml/file_paths.xml"
  if grep -q "<external-path" "$FP" && grep -q "<files-path" "$FP"; then
    ok "وثيقةُ المساراتِ تَسَعُ ما نُخرِجُهُ: مسارٌ خارجيٌّ ومسارُ ملفاتِ التطبيقِ"
  else bad "وثيقةُ المساراتِ" "لا ‏external-path‏ ولا ‏files-path‏"; fi
  BP="$ZTMP16/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
  if grep -q "case 313:" "$BP" && grep -q "ui_install_apk_entry" "$BP" \
  && grep -q "canRequestPackageInstalls()" "$BP" && grep -q "FileProvider.getUriForFile" "$BP"; then
    ok "البندُ في القائمةِ القائمةِ: لا شاشةَ، ولا نُقطةَ ثانيةَ — ‏313‏ في ‏showEntryMenu‏"
  else bad "وصلةُ اللوحةِ" "البندُ أو الإذنُ أو الموفِّرُ في المتصفّحِ"; fi
  if ! grep -qE "PackageInstaller|ProgressDialog|setProgress|\"su\"|/system/xbin/su" "$ZTMP16/br-code.txt"; then
    ok "لا جلسةَ تثبيتٍ، ولا شريطَ تَقدُّمٍ، ولا ‏su‏: النِّيةُ تُرسَلُ ومُثبِّتُ النظامِ يَعمَلُ"
  else bad "حدودُ الغلافِ" "آليّةُ جلسةٍ أو حِوارُ تَقدُّمٍ أو جذرٌ"; fi
  if [ "$(grep -c "ui_install_apk_" "$ZTMP16/app/src/main/res/values/strings.xml")" = "7" ] \
  && [ "$(grep -c "ui_install_apk_" "$ZTMP16/app/src/main/res/values-ar/strings.xml")" = "7" ]; then
    ok "سبعةُ مفاتيحَ في اللغتَينِ: كلُّ حالَةٍ مُسَمّاةٍ لها نصُّها العربيُّ"
  else bad "نصوصُ الحالاتِ" "المفاتيحُ ليست سبعةً في اللغتَينِ"; fi
  if grep -qF '"$SRC/almlk/ApkInstallPlan.java"' "$ZTMP16/qa.sh" \
  && grep -qF "installFromPanelStage143();" "$ZTMP16/qa/RegressionSuite.java" \
  && grep -qF "$VERSION" "$ZTMP16/VERSION"; then
    ok "العُدَّةُ في الحزمةِ: الصنفُ في قائمةِ الصافيِ، والمرحلةُ 143ُ مسجَّلةٌ، والبصمةُ $VERSION"
  else bad "عُدَّةُ الانحدارِ المصدَّرةُ" "القائمةُ الصافيةُ أو المرحلةُ أو البصمةُ"; fi
  if zq -q "reports/تقرير_دراسة_التثبيتُ_من_اللوحةِ_W22_5د"; then
    ok "ورقةُ دراسةِ 5د في الحزمةِ — الدليلُ من ‏abcd.lk.j6‏ و‏IntentUtils.getInstallAppIntent‏"
  else bad "ورقةُ الدراسةِ" "تقرير_دراسة_التثبيتُ_من_اللوحةِ_W22_5د.md مفقودٌ"; fi
  if zq -q "reports/تقرير_تنفيذ_W22_5د_"; then ok "ورقةُ تنفيذِ 5د في الحزمةِ"
  else bad "ورقةُ التنفيذِ" "reports/تقرير_تنفيذ_W22_5د_* مفقودٌ"; fi
  if zq -qE "app/src/main/res/layout/(activity|dialog|row|item)_[a-z_]*install"; then
    bad "واجهةٌ مُختَرَعةٌ" "شاشةُ تثبيتٍ جديدةٌ في الحزمةِ"
  else ok "لا شاشةَ «التثبيتُ» — بندٌ في قائمةِ الضغطِ المطوَّلِ، كما قالَ المِدادُ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ"; fi
# المظهَرُ المطبوعُ ثنائيٌّ (UTF‑16): لا ‏grep‏ على ‏zip -p‏ — يُقرَأُ بما يَقرَأُ بهِ النظامُ.
if printf '%s\n' "$TREE" | grep -q "androidx.core.content.FileProvider" \
&& printf '%s\n' "$TREE" | grep -q "\.fileprovider" \
&& printf '%s\n' "$TREE" | grep -q "FILE_PROVIDER_PATHS"; then
  ok "الحزمةُ المبنيةُ تَحمِلُ المُوفِّرَ: ‏FileProvider‏ بأبثوريو اسمِ الحزمةِ ووثيقةِ المساراتِ"
else bad "الحزمةُ المبنيةُ" "المُوفِّرُ لم يَدخُلِ المظهَرَ المطبوعَ"; fi
if printf '%s\n' "$TREE" | grep -q "android.permission.REQUEST_INSTALL_PACKAGES" \
&& ! printf '%s\n' "$TREE" | grep -q "utilcode.provider"; then
  ok "والإذنُ مطبوعٌ، ولا أبثوريو ثانيًا: بغيرِ الإذنِ تَرفُضُ الأنظمةُ الحديثةُ بصمتٍ"
else bad "الإذنُ المطبوعُ" "الإذنُ مفقودٌ، أو تُرِكَ أبثوريو المكتبةِ"; fi
rm -rf "$ZTMP16"

echo
echo "[31] الجولةُ 23/1 — عزلُ المُحرِّكِ في ‏:analyzer‏: قناةٌ واحدةٌ، أسقافٌ معدودةٌ، ولا خيطَ فحصٍ في الواجهةِ"
# (1) المانيفستُ المطبوعُ: العمليةُ الثانيةُ مُعلَنةٌ، ولا بقاءَ لها على الواجهةِ.
if printf '%s\n' "$TREE" | grep -q "com.almlkid.analyzer.AnalyzerService"; then
  ok "الخدمةُ مطبوعةٌ: ‏com.almlkid.analyzer.AnalyzerService‏ مُسجَّلةٌ في الحزمةِ"
else bad "المانيفستُ المطبوعُ" "الخدمةُ لم تَدخُلِ الحزمةَ"; fi
if printf '%s\n' "$TREE" | grep -q 'android:process(0x01010011)=":analyzer"'; then
  ok "العزلُ مطبوعٌ: ‏android:process=\":analyzer\"‏ — التحليلُ لا يَجري في عمليةِ الواجهةِ"
else bad "العزلُ" "لا ‏:analyzer‏ في المانيفست المطبوعِ"; fi
PROCN=$(printf '%s\n' "$TREE" | grep -c 'android:process' || true)
if [ "$PROCN" = "1" ]; then ok "عمليةٌ ثانيةٌ واحدةٌ لا أكثرُ: لا شَظايا عملياتِ ولا خدماتٌ منسيّةٌ"
else bad "عددُ العملياتِ" "$PROCN ≠ 1"; fi
if printf '%s\n' "$TREE" | grep -q "foregroundServiceType"; then
  bad "خدمةٌ أماميةٌ" "الفحصُ جلسةٌ مرتبطةٌ بمحرِّرٍ حيٍّ، لا خدمةُ بقاءٍ ولا إشعارَ"
else ok "لا ‏foregroundServiceType‏ ولا إشعارَ عندَ التحليلِ"; fi
# (2) الأصنافُ الخمسةُ في الـdex (لا صنفًا يُستَدعى بلا أثرٍ).
TMP31=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP31" 2>/dev/null
MISS31=0
for cls in "Lcom/almlkid/analyzer/AnalyzerService;" "Lcom/almlkid/analyzer/AnalyzerConnection;" \
           "Lcom/almlkid/analyzer/AnalyzerWire;" "Lalmlk/AnalyzerProtocol;" "Lalmlk/AnalyzerQueue;"; do
  HITS=$(grep -l "$cls" "$TMP31"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "الصنف $cls" "غير موجود في أي dex"; MISS31=$((MISS31+1)); fi
done
[ $MISS31 -eq 0 ] && ok "خمسةُ أصنافَ للعزلِ في الـdex فعلًا (من الخدمةِ إلى الطابورِ الصافيِ)"
rm -rf "$TMP31"
# (3) الحزمةُ المصدريّةُ: الطبقاتُ الخمسُ، والصَفاءُ، والأسقافُ المُعلَنةُ.
ZTMP17=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZTMP17" 2>/dev/null; then
  P31="$ZTMP17/app/src/main/java/almlk/AnalyzerProtocol.java"
  Q31="$ZTMP17/app/src/main/java/almlk/AnalyzerQueue.java"
  S31="$ZTMP17/app/src/main/java/com/almlkid/analyzer/AnalyzerService.java"
  B31="$ZTMP17/app/src/main/java/com/almlkid/analyzer/AnalyzerConnection.java"
  W31="$ZTMP17/app/src/main/java/com/almlkid/analyzer/AnalyzerWire.java"
  E31="$ZTMP17/app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java"
  M31="$ZTMP17/app/src/main/AndroidManifest.xml"
  if [ -f "$P31" ] && [ -f "$Q31" ]; then ok "الطبقةُ الصافيةُ في الحزمةِ: ‏almlk/AnalyzerProtocol.java‏ و‏almlk/AnalyzerQueue.java‏"
  else bad "الطبقةُ الصافيةُ" "أحدهُما مفقودٌ من الحزمةِ المصدريّةِ"; fi
  if [ -f "$S31" ] && [ -f "$B31" ] && [ -f "$W31" ]; then ok "غلافُ العمليةِ في الحزمةِ: خدمةٌ وجسرٌ وخريطةُ سِلكٍ"
  else bad "غلافُ العمليةِ" "خدمةٌ أو جسرٌ أو خريطةٌ مفقودةٌ"; fi
  : > "$ZTMP17/pure-code.txt"
  grep -vE '^[[:space:]]*(\*|//|/\*)' "$P31" "$Q31" "$W31" > "$ZTMP17/pure-code.txt" 2>/dev/null
  if ! grep -qE "^import (android|androidx)\.|import android\.|R\.string|Context|SharedPreferences" "$ZTMP17/pure-code.txt"; then
    ok "صَفاءٌ: لا ‏android.*‏ ولا ‏Context‏ ولا ‏SharedPreferences‏ في البروتوكولِ والطابورِ والخريطةِ"
  else bad "طبيعةُ الطبقةِ" "تسرّبَ اندرويدُ إلى الصافيِ"; fi
  if ! grep -qE "Thread|Handler|Looper|System\.currentTimeMillis|synchronized \(" "$ZTMP17/pure-code.txt"; then
    ok "لا خيطَ ولا حاملَ ولا ساعةَ في الصافيِ: التزامنُ كلُّهُ في الغلافِ الاندرويديِّ"
  else bad "حدودُ الصفاءِ" "آليّةُ التزامنِ خرجَتْ من الغلافِ"
  fi
  if grep -q "MAX_CHUNK_CHARS = 220_000" "$P31" && grep -q "MAX_FINDINGS = 400" "$P31" \
  && grep -q "MAX_REQUEST_CHARS = 4 \* 1024 \* 1024" "$P31" && grep -q "MAX_REPLY_CHARS = 256_000" "$P31" \
  && grep -q "MAX_QUEUED = 6" "$Q31"; then
    ok "أسقافٌ خمسةٌ معلَنةٌ نصًّا: القطعةُ، والتشخيصاتُ، وحجمُ الطلبِ، وميزانيّةُ الردِّ، وعُمقُ الطابورِ"
  else bad "الأسقافُ" "سقفٌ من الخمسةِ لم يُعلَنْ"; fi
  STATES31=$(grep -cE 'STATE_(OK|NOT_BOUND|STALE|TOO_LARGE|REFUSED|PROCESS_DIED|MEMORY_PRESSURE) = ' "$P31" || true)
  if [ "$STATES31" = "7" ]; then ok "سبعُ حالاتٍ مُسمّاةٍ في القناةِ: لا صمتَ عندَ القطعِ ولا عندَ الرفضِ ولا عندَ ضغطِ الذاكرةِ"
  else bad "حالاتُ القناةِ" "$STATES31 من سبعٍ"; fi
  if grep -q "import android.os.Messenger;" "$S31" && grep -q "public void onTrimMemory(int level)" "$S31" \
  && ! grep -q "killProcess" "$S31"; then
    ok "الخدمةُ: messengerٌ واحدٌ، وضغطُ الذاكرةِ حالةٌ، ولا انتحارَ بعدَ الإعلانِ"
  else bad "هندسةُ الخدمةِ" "القناةُ أو Trim أو الحدُّ"; fi
  if grep -q "new Thread(null, task, \"almlk-analyzer\", 4L << 20)" "$S31"; then
    ok "خيطُ التحليلِ بمكدَّسٍ واسعٍ كما كانَ في الواجهةِ: الانحدارُ العميقُ لا يُنهِي العمليةَ"
  else bad "مكدَّسُ التحليلِ" "الخيطُ الواسعُ لم يُنقَلْ"; fi
  : > "$ZTMP17/ed-code.txt"
  grep -vE '^[[:space:]]*(\*|//|/\*)' "$E31" > "$ZTMP17/ed-code.txt" 2>/dev/null
  if ! grep -qE "ExecutorService|Executors\.|diagnosticsWorker|newSingleThreadExecutor|CodeLanguageTools\.inspect\(" "$ZTMP17/ed-code.txt"; then
    ok "المحرِّرُ بريءٌ: لا خيطَ فحصٍ ولا ‏inspect‏ داخلَ عمليةِ الواجهةِ بعدَ اليومِ"
  else bad "المحرِّرُ" "بقايا المسارِ القديمِ باقيةٌ في ‏AlmlkEditor.java‏"; fi
  if grep -q "analyzer.request(name, text);" "$E31" \
  && grep -q "ProjectSymbolIndex.applyLiveMembers(name, members);" "$E31" \
  && grep -q "analyzer.detach();" "$E31" && grep -q "analyzer.attach(getContext());" "$E31"; then
    ok "المحرِّرُ يَطلُبُ ويَقبَلُ ويفصِلُ: طلبٌ إلى الجلسةِ، وطعنٌ في الفهرسِ هنا، وربطٌ بحياتِها"
  else bad "وصلةُ المحرِّرِ" "الطلبُ أو الطعنُ أو الربطُ"; fi
  if ! grep -qE "Thread\.sleep|\.wait\(|CountDownLatch|ProgressDialog|setProgress" "$B31"; then
    ok "الجسرُ لا يَحجِبُ: لا نومَ ولا انتظارَ ولا نافذةَ تَقدُّمٍ في مسارِ الواجهةِ"
  else bad "جسرُ الواجهةِ" "حاجزُ انتظارٍ أو نافذةٌ"; fi
  if grep -q "isAnalyzerProcess()" "$ZTMP17/app/src/main/java/com/shima/demo/ShimaApplication.java"; then
    ok "مُعالِجُ الانهيارِ يُميِّزُ العمليةِ: موتُ المحلِّلِ لا يُرسِلُ شاشةَ استرجاعٍ"
  else bad "مُعالِجُ الانهيارِ" "التمييزُ بينَ العمليتينِ مفقودٌ"; fi
  if grep -q '<service' "$M31" && grep -q 'android:process=":analyzer"' "$M31" \
  && grep -q 'com.almlkid.analyzer.AnalyzerService' "$M31"; then
    ok "مصدرُ المانيفستِ كما المطبوعِ: خدمةٌ واحدةٌ مُقفَلةٌ عن التصديرِ"
  else bad "مصدرُ المانيفستِ" "الخدمةُ أو العمليةُ"; fi
  if grep -qF '"$SRC/almlk/AnalyzerProtocol.java"' "$ZTMP17/qa.sh" \
  && grep -qF '"$SRC/almlk/AnalyzerQueue.java"' "$ZTMP17/qa.sh" \
  && grep -qF "analyzer/AnalyzerWire.java" "$ZTMP17/qa.sh" \
  && grep -qF "kay/ui/ProjectSymbolIndex.java" "$ZTMP17/qa.sh"; then
    ok "بوابتُنا الصافيةُ تُرجِمُ وتُختبَرُ: الأربعةُ في ‏qa.sh‏ (وفهرسُ الرموزِ معَها)"
  else bad "قائمةُ qa.sh" "واحدٌ من الأربعةِ خارجَ الترجمةِ الصافيةِ"; fi
  if grep -qF "analyzerIsolationStage173();" "$ZTMP17/qa/RegressionSuite.java"; then
    ok "حلقةُ العزلِ مُسجَّلةٌ في ‏RegressionSuite‏ (‏analyzerIsolationStage173‏)"
  else bad "حلقةُ العزلِ" "غيرُ مُسجَّلةٍ في مجموعةِ الانحدارِ"; fi
  ZIPVER31=$(grep -m1 -E '^[0-9]+\.[0-9]+\.[0-9]+$' "$ZTMP17/VERSION" 2>/dev/null || echo "?")
  [ "$ZIPVER31" = "$VERSION" ] && ok "بصمةُ الحزمةِ المصدريّةِ = $VERSION" \
    || bad "بصمةُ الحزمةِ المصدريّةِ" "$ZIPVER31 ≠ $VERSION"
  if zq -q "reports/تقرير_دراسة_نظامُ_الفحصِ_والعزلِ_W23.md" \
  && zq -q "reports/تقرير_تنفيذ_W23_1_"; then
    ok "ورقتا العزلِ في الحزمةِ: دراسةُ ‏W23‏ وتنفيذُ المرحلةِ الأولى"
  else bad "ورقتا العزلِ" "إحداهُما مفقودةٌ من ‏reports/‏"; fi
  if ! grep -q "analyzer_" "$ZTMP17/app/src/main/res/values/strings.xml" \
  && ! zq -qE "app/src/main/res/layout/.*analyzer"; then
    ok "لا نصَّ مستعمَلًا جديدًا ولا شاشةَ: العزلُ هندسةٌ، والواجهةُ كما هي"
  else bad "حدودُ الواجهةِ" "مفاتيحُ أو تخطيطٌ جديدٌ للعزلِ"; fi
  if grep -q "29" "$ZTMP17/PROJECT_STATE.md" && grep -qiE "analyzer|العزلُ" "$ZTMP17/PROJECT_STATE.md"; then
    ok "سِجلُّ الحالةِ يَذكُرُ المرحلةَ: فصلٌ جديدٌ في ‏PROJECT_STATE.md‏"
  else bad "سِجلُّ الحالةِ" "لا ذِكرَ لمرحلةِ العزلِ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ للقراءةِ"; fi
rm -rf "$ZTMP17"

echo "[32] الجولةُ 23/2 — الفحصُ التدريجيُّ: لا طلبَ بلا تغيُّرٍ، والعلامةُ على كلِّ مواضعِ العنصرِ، وسلامةُ الاستيرادِ"
# (1) الـdex: الطبقاتُ الأربعُ الجديدةُ مطبوعةٌ فعلًا (لا صنفًا يَذكُرُهُ السجلُّ ولا يَحمِلُهُ التطبيقُ).
TMP32=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP32" 2>/dev/null
MISS32=0
for cls in "Lalmlk/IncrementalScope;" "Lalmlk/MarkTable;" "Lalmlk/IdentifierOccurrences;" "Lalmlk/ImportSoundness;"; do
  HITS=$(grep -l "$cls" "$TMP32"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "الصنف $cls" "غير موجود في أي dex"; MISS32=$((MISS32+1)); fi
done
[ $MISS32 -eq 0 ] && ok "أربعُ طبقاتٍ للفحصِ التدريجيِّ في الـdex (من البصمةِ إلى سلامةِ الاستيرادِ)"
rm -rf "$TMP32"
# (2) لا شاشةَ جديدةً ولا نافذةَ: التدرُّجُ خدمةٌ خلفيةٌ، والتزيينُ على ما هو قائمٌ.
if printf '%s\n' "$TREE" | grep -qE "assets/.*(incremental|mark_table|import_soundness)"; then
  bad "أصولٌ جديدةٌ" "لا أصولَ لهذهِ الجولةِ: حسابٌ لا بياناتُ"
else ok "لا أصلَ مُضافًا: الجولةُ حسابٌ على النصِّ لا مُستَودعُ بياناتٍ"; fi
if ! zq -qE "app/src/main/res/layout/.*(inspection|mark_table|soundness)"; then
  ok "لا تخطيطَ ولا شاشةَ جديدةً: التدرُّجُ والتزيينُ على شاشةِ المحرِّرِ نفسِها"
else bad "حدودُ الواجهةِ" "تخطيطٌ جديدٌ للفحصِ التدريجيِّ"; fi
if ! printf '%s\n' "$MANIFEST" | grep -q 'foregroundServiceType'; then
  ok "ولا خدمةُ بقاءٍ: الفحصُ ما زالَ جلسةً مرتبطةً بمحرِّرٍ حيٍّ"
else bad "خدمةٌ أماميةٌ" "أُضيفَت على مسارِ الفحصِ"; fi
# (3) الحزمةُ المصدريّةُ: الصَفاءُ، والأسقافُ، والسلاسلُ في اللغتَينِ، والبوابتانِ.
ZTMP18=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZTMP18" 2>/dev/null; then
  SC32="$ZTMP18/app/src/main/java/almlk/IncrementalScope.java"
  MT32="$ZTMP18/app/src/main/java/almlk/MarkTable.java"
  OC32="$ZTMP18/app/src/main/java/almlk/IdentifierOccurrences.java"
  IS32="$ZTMP18/app/src/main/java/almlk/ImportSoundness.java"
  ED32="$ZTMP18/app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java"
  WI32="$ZTMP18/app/src/main/java/com/almlkid/analyzer/AnalyzerWire.java"
  SE32="$ZTMP18/app/src/main/java/com/almlkid/analyzer/AnalyzerService.java"
  PR32="$ZTMP18/app/src/main/java/almlk/AnalyzerProtocol.java"
  if [ -f "$SC32" ] && [ -f "$MT32" ] && [ -f "$OC32" ] && [ -f "$IS32" ]; then
    ok "الطبقاتُ الأربعُ في الحزمةِ المصدريّةِ: بصمةٌ وجدولٌ ومواضعُ واستيرادٌ"
  else bad "الطبقاتُ الأربعُ" "إحداها مفقودةٌ من الحزمةِ"; fi
  : > "$ZTMP18/pure32.txt"
  grep -vE '^[[:space:]]*(\*|//|/\*)' "$SC32" "$MT32" "$OC32" "$IS32" > "$ZTMP18/pure32.txt" 2>/dev/null
  if ! grep -qE "^import android\.|android\.content|android\.os\.Handler|Context " "$ZTMP18/pure32.txt"; then
    ok "صَفاءُ الأربعِ مُثبَتٌ على الحزمةِ: لا Androidَ في سطورِها المَوصولةِ"
  else bad "صَفاءُ الأربعِ" "استيرادُ Androidَ تسرَّبَ إلى الطبقةِ الصافيةِ"; fi
  if ! grep -qE "new Thread|Executors|SystemClock|File\(|SharedPreferences" "$ZTMP18/pure32.txt"; then
    ok "لا خيطَ ولا ساعةَ ولا قرصَ في الصافيِ: القرارُ حسابٌ لا مُزامَنةٌ"
  else bad "حدودُ الصافيِ" "خيطٌ أو ساعةٌ أو قرصٌ في الطبقةِ الصافيةِ"; fi
  for cap in "MAX_TRACKED = 512" "WHOLE_FILE_CHARS = 4096" "MAX_MARKS = 4096" "MAX_SITES = 64" "MAX_OCCURRENCES = 32" "MAX_NAMES = 96" "MAX_IMPORTS = 256" "MAX_PROBLEMS = 4"; do
    if grep -qF "$cap" "$SC32" "$MT32" "$OC32" "$IS32" "$PR32" 2>/dev/null; then
      ok "سقفٌ مُعلَنٌ: $cap"
    else bad "سقفٌ مفقودٌ" "$cap غيرُ مُعلَنٍ فيمصدرِ الحزمةِ"; fi
  done
  if grep -qF "skipped" "$SC32" && grep -qF "evicted" "$SC32" && grep -qF "droppedCount" "$MT32"; then
    ok "العَدُّ موجودٌ: تخطٍّ وإخراجٌ وسقوفٌ تُعَدُّ لا تُكتَمُ"
  else bad "العَدُّ" "واحدٌ من العدّاداتِ مفقودٌ"; fi
  N32=0
  for key in ui_diagnostic_unused_import ui_diagnostic_unknown_import ui_diagnostic_duplicate_import \
             ui_diagnostic_redundant_import ui_diagnostic_missing_import ui_diagnostic_ambiguous_import; do
    grep -q "name=\"$key\"" "$ZTMP18/app/src/main/res/values/strings.xml" || N32=$((N32+1))
    grep -q "name=\"$key\"" "$ZTMP18/app/src/main/res/values-ar/strings.xml" || N32=$((N32+1))
  done
  if [ "$N32" = "0" ]; then ok "ستُّ حالاتٍ للاستيرادِ في اللغتَينِ: اثنا عشرَ مفتاحًا كاملةٌ"
  else bad "سلاسلُ الاستيرادِ" "$N32 مفتاحًا ناقصٌ بينَ values وvalues-ar"; fi
  if grep -qF "pendingInspectionRevision" "$ED32" && grep -qF "inspectionScope.plan(name, analysisText, text)" "$ED32" \
  && grep -qF "if (scope == null) {" "$ED32"; then
    ok "المُحرِّرُ يَقرِنُ الطلبَ بالبصمةِ: لا جولةَ على نصٍّ لم يتغيَّرْ"
  else bad "تدرُّجُ المُحرِّرِ" "الخُطّةُ لا تَحمِلُ البصمةَ في الحزمةِ"; fi
  if grep -qF "inspectionScope.forget(fileName)" "$ED32"; then
    ok "الردُّ المَرفوضُ لا يَترُكُ بصمةً مُعلَّقةً: الفحصُ لا يَسقُطُ بينَ نسختينِ"
  else bad "إنبارُ الحالةِ" "forget غيرُ موصولةٍ بمسارِ حالةِ القناةِ"; fi
  if grep -qF "applyInspectionMarks" "$ED32" && grep -qF "if (inspectionMarks.commit(inspectionRevision + 1L)) inspectionRevision++;" "$ED32"; then
    ok "جدولُ الأدوارِ موصولٌ: صفيحةٌ صافيةٌ ثمَّ قلبٌ بمنجِزٍ واحدٍ"
  else bad "جدولُ الأدوارِ" "البناءُ أو القلبُ غيرُ موصولينَ في المُحرِّرِ"; fi
  if grep -qF "spans.add(diagnosticSpanAt(line, start, end, severity, payload));" "$ED32"; then
    ok "كلُّ المواضعِ تُسطَّرُ في الفهرسِ القائمِ (بأسرِهِ الثلاثِ): لا زرٌّ جديدٌ ولا لوحةٌ"
  else bad "تَسطيرُ المواضعِ" "فهرسُ المدياتِ لا يَقرَأُ الطائفةَ"; fi
  if grep -qF "withOccurrences(text, AnalyzerWire.encode(found))" "$SE32" \
  && grep -qF "isDuplicateFamily(f.messageKey)" "$WI32" && grep -qF "ui_diagnostic_duplicate" "$WI32"; then
    ok "التوسيعُ في ابنِ التحليلِ حيثُ النصُّ كاملٌ، ومفتاحُ الرسالةِ هو الحاكِمُ"
  else bad "توسيعُ المواضعِ" "لم يُجعَلْ في عمليةِ التحليلِ أو لا يعتمدُ المفتاحَ"; fi
  if grep -qF "public final int[] occStarts" "$PR32" && grep -qF "MAX_OCCURRENCES = 32" "$PR32"; then
    ok "السِّلكُ يَحمِلُ المواضعَ بسقفٍ مُعلَنٍ: ثلاثونَ واثنانِ لكلِّ تشخيصٍ"
  else bad "حِملُ المواضعِ" "الحقولُ أو السقفُ مفقودٌ من البروتوكولِ"; fi
  if grep -qF "FIELD_COUNT_REPLY = 7" "$PR32"; then
    ok "قفلُ الردِّ لم يَتبدَّلْ: سبعةُ حقولٍ كما كانتْ (توسُّعٌ داخلَ السِّجلِّ لا حقلًا ثامنًا)"
  else bad "قفلُ الردِّ" "عقدُ الحقولِ تغيَّرَ بلا أثرٍ مُعلَنٍ"; fi
  if grep -qF '"$SRC/almlk/IncrementalScope.java"' "$ZTMP18/qa.sh" \
  && grep -qF '"$SRC/almlk/MarkTable.java"' "$ZTMP18/qa.sh" \
  && grep -qF '"$SRC/almlk/IdentifierOccurrences.java"' "$ZTMP18/qa.sh" \
  && grep -qF '"$SRC/almlk/ImportSoundness.java"' "$ZTMP18/qa.sh"; then
    ok "الأربعُ في ‏qa.sh‏: تُترجَمُ صافيةً وتُختبَرُ قبلَ الحزمِ"
  else bad "قائمةُ qa.sh" "واحدةٌ من الأربعِ خارجَ الترجمةِ الصافيةِ"; fi
  if grep -qF "incrementalInspectionStage174();" "$ZTMP18/qa/RegressionSuite.java"; then
    ok "حلقةُ التدريجِ مُسجَّلةٌ في ‏RegressionSuite‏ (‏incrementalInspectionStage174‏)"
  else bad "حلقةُ التدريجِ" "غيرُ مُسجَّلةٍ في مجموعةِ الانحدارِ"; fi
  ZIPVER32=$(grep -m1 -E '^[0-9]+\.[0-9]+\.[0-9]+$' "$ZTMP18/VERSION" 2>/dev/null || echo "?")
  [ "$ZIPVER32" = "$VERSION" ] && ok "بصمةُ الحزمةِ المصدريّةِ = $VERSION" \
    || bad "بصمةُ الحزمةِ المصدريّةِ" "$ZIPVER32 ≠ $VERSION"
  if zq -q "تقرير_دراسة_الفحصِ_التدريجيِّ_W24_2.md" \
  && zq -q "reports/تقرير_تنفيذ_W24_2_"; then
    ok "ورقتا التدريجِ في الحزمةِ: دراسةٌ وتصميمٌ، وتنفيذُ المرحلةِ"
  else bad "ورقتا التدريجِ" "إحداهُما مفقودةٌ من ‏reports/‏"; fi
  if grep -q "30" "$ZTMP18/PROJECT_STATE.md" && grep -qiE "IncrementalScope|الفحصُ التدريجيُّ" "$ZTMP18/PROJECT_STATE.md"; then
    ok "سِجلُّ الحالةِ يَذكُرُ الجولةَ: فصلٌ جديدٌ في ‏PROJECT_STATE.md‏"
  else bad "سِجلُّ الحالةِ" "لا ذِكرَ لمرحلةِ التدريجِ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ للقراءةِ"; fi
rm -rf "$ZTMP18"


echo "[33] الجولةُ 26 (‏W25/3‏) — الجَلبُ الصامتُ: قرارٌ مُسبَقٌ، ومفردٌ لكلِّ مشروعٍ، وسطرُ حالةٍ لا نافذةَ"
# (1) الـdex: الطبقاتُ الثلاثُ مطبوعةٌ في التطبيقِ.
TMP33=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP33" 2>/dev/null
MISS33=0
for cls in "Lalmlk/DependencyFetchPlan;" "Lalmlk/DependencyFetchQueue;" "Lalmlk/UnresolvedSymbolRule;"; do
  HITS=$(grep -l "$cls" "$TMP33"/classes*.dex 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" = "0" ]; then bad "الصنف $cls" "غير موجود في أي dex"; MISS33=$((MISS33+1)); fi
done
[ $MISS33 -eq 0 ] && ok "ثلاثُ طبقاتٍ للجَلبِ في الـdex (خطّةٌ، وقاعدةُ رمزٍ، وطابورٌ)"
rm -rf "$TMP33"
# (2) لا شاشةَ جديدةً ولا نافذةَ انتظارٍ ولا أصلَ مُضافًا: الجَلبُ خدمةٌ صامتةٌ.
if zq -qE "app/src/main/res/layout/.*(fetch|dependency_fetch)"; then
  bad "حدودُ الواجهةِ" "تخطيطٌ جديدٌ للجَلبِ؛ والمطلوبُ سطرُ حالةٍ على القائمةِ"
else ok "لا شاشةَ للجَلبِ: سطرُ الحالةِ في اللوحةِ التسلسُليّةِ القائمةِ"; fi
if printf '%s\n' "$TREE" | grep -qE "app/src/main/assets/.*\.(aar|jar|exploded)"; then
  bad "أصولُ المكتباتِ" "حُزمةٌ مُجلوبةٌ وُضِعَت في assets/؛ وموضِعُها مجلَّدُ البناءِ"
else ok "لا مكتبةَ مُجلوبةً في assets/: التفكيكُ حيثُ يَقرَأُ مُنفِّذُ المشروعِ"; fi
NETPERM33=$(grep -c "ACCESS_NETWORK_STATE" app/src/main/AndroidManifest.xml)
if [ "$NETPERM33" = "1" ] \
&& ! sed -n "/private boolean startDependencyFetch/,/dependencyProvider()/p" \
     app/src/main/java/com/shima/demo/MainActivity.java | grep -qE "ConnectivityManager|NetworkInfo"; then
  ok "بلا استطلاعِ حالةِ شبكةٍ: الصلاحيّةُ المُعلَنةُ قائمةٌ كما كانتْ، والانقطاعُ يُعرَفُ بفشلِ المُوصِّلِ"
else bad "حالةُ الشبكةِ" "استطلاعٌ جديدٌ أو صلاحيّةٌ مُضاعَفةٌ على المسارِ الصامتِ"; fi
if grep -A 46 "private boolean startDependencyFetch" app/src/main/java/com/shima/demo/MainActivity.java \
| grep -qE "ProgressDialog|MavenDownloadDialog|setProgress|showProgress"; then
  bad "طريقُ الجَلبِ" "نافذةُ انتظارٍ أو حوارُ تنزيلٍ على المسارِ الصامتِ"
else ok "المسارُ الصامتُ نظيفٌ: لا ProgressDialog ولا MavenDownloadDialog ولا شريطَ تقدُّمٍ"; fi
if grep -q "ProgressDialog" app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java; then
  bad "المُحرِّرُ" "نافذةُ انتظارٍ في المُحرِّرِ؛ والتشخيصُ لا يَنتظِرُ"
else ok "ولا نافذةَ انتظارٍ في المُحرِّرِ: الصَفُّ يَدفَعُ إلى الطابورِ ويَعودُ"; fi
# (3) الصَفاءُ والأسقافُ المعلَنةُ: لا ‏android.*‏ في الطبقاتِ الثلاثِ، وكلُّ سقْفٍ مَكتوبٌ.
PURE33=0
for f in almlk/DependencyFetchPlan.java almlk/DependencyFetchQueue.java almlk/UnresolvedSymbolRule.java; do
  if grep -q "^import android" "app/src/main/java/$f"; then bad "صَفاءُ $f" "يَحمِلُ android.*"; PURE33=$((PURE33+1)); fi
done
[ $PURE33 -eq 0 ] && ok "الطبقاتُ الثلاثُ نقيّةٌ: تُترجَمُ في ‏qa.sh‏ بلا ‏android.jar‏"
if grep -q "MAX_PENDING = 32" app/src/main/java/almlk/DependencyFetchQueue.java \
&& grep -q "MAX_LOG = 8" app/src/main/java/almlk/DependencyFetchQueue.java \
&& grep -q "MAX_COORDINATES = 16" app/src/main/java/almlk/DependencyFetchPlan.java \
&& grep -q "MAX_CANDIDATES = 64" app/src/main/java/almlk/UnresolvedSymbolRule.java; then
  ok "الأسقافُ معلَنةٌ: اثنينِ وثلاثينَ مهمّةً، وثمانيةَ أسطرِ حالةٍ، وستّةَ عشرَ إحداثيّةً، وأربعًا وستّينَ مُرشَّحًا"
else bad "الأسقافُ" "سقْفٌ مُعلَنٌ مفقودٌ من الطبقةِ الصافيةِ"; fi
# (4) الحالةُ كلُّها بمواردَ مُعرَّبةٍ: سطرُ الحالةِ لا سلاسلُ خامٌ كما في المرجعِ.
EN33=$(grep -c 'name="ui_fetch_status' app/src/main/res/values/strings.xml)
AR33=$(grep -c 'name="ui_fetch_status' app/src/main/res/values-ar/strings.xml)
if [ "$EN33" -ge 19 ] && [ "$EN33" = "$AR33" ] \
&& grep -q 'name="menu_fetch_dependency"' app/src/main/res/values/strings.xml \
&& grep -q 'name="menu_fetch_dependency"' app/src/main/res/values-ar/strings.xml; then
  ok "عشرونَ مفتاحًا في اللغتَينِ: جَلبٌ مُعرَّبُ النصِّ لا إنجليزيٌّ خامٌ ($EN33 حالةً + صفُّ الإصلاحِ)"
else bad "مفاتيحُ الجَلبِ" "EN=$EN33 AR=$AR33 مع صَفِّ الإصلاحِ"; fi
# (5) لا اختراعَ لآلةِ التنزيلِ: المُوصِّلُ يستعملُ MavenResolver/MavenDownloader القائمَينِ.
if grep -q "new almlk.MavenResolver(" app/src/main/java/com/shima/demo/MainActivity.java \
&& grep -q "new almlk.MavenDownloader()" app/src/main/java/com/shima/demo/MainActivity.java \
&& grep -q "almlk.MavenIndex.search(" app/src/main/java/com/shima/demo/MainActivity.java \
&& grep -q "GradleDependencyEditor.addDependency" app/src/main/java/almlk/DependencyFetchQueue.java; then
  ok "الجَلبُ على الآلةِ القائمةِ: حلُّ المخزنِ، والتنزيلُ، والكتابةُ في dependencies {}"
else bad "إعادةُ الاستعمالِ" "آلةُ التنزيلِ أو الكتابةُ لم تُستعمَلْ كما هو مُصمَّمٌ"; fi
if grep -q "FETCH_DEPENDENCY" app/src/main/java/com/almlkid/analyzer/AnalyzerService.java; then
  bad "عزلُ العملياتِ" "صَفُّ الجَلبِ يُنسَجُ في ابنِ التحليلِ؛ ومفاتيحُ الحُزَمِ عندَ المضيفِ وحدَهُ"
else ok "الخطّةُ تُولَدُ عندَ المضيفِ: ابنُ التحليلِ لا يَمسُّ القرصَ ولا المخزنَ"; fi
# (6) الحزمةُ المصدريّةُ: الشيفرةُ، والبوابتانِ، والورقتانِ، وسِجلُّ الحالةِ.
ZTMP19=$(mktemp -d)
if unzip -oq "$ZIP" -d "$ZTMP19" 2>/dev/null; then
  for f in "app/src/main/java/almlk/DependencyFetchPlan.java" "app/src/main/java/almlk/DependencyFetchQueue.java" \
           "app/src/main/java/almlk/UnresolvedSymbolRule.java"; do
    if zq -qxF "$f"; then ok "في الحزمةِ: $(basename "$f")"
    else bad "الحزمةُ المصدريّةُ" "$f مَفقودةٌ"; fi
  done
  if grep -qF '"$SRC/almlk/DependencyFetchQueue.java"' "$ZTMP19/qa.sh" \
  && grep -qF '"$SRC/almlk/UnresolvedSymbolRule.java"' "$ZTMP19/qa.sh" \
  && grep -qF '"$SRC/almlk/DependencyFetchPlan.java"' "$ZTMP19/qa.sh"; then
    ok "الثلاثُ في ‏qa.sh‏: تُترجَمُ صافيةً وتُختبَرُ قبلَ الحزمِ"
  else bad "قائمةُ qa.sh" "واحدةٌ من الثلاثِ خارجَ الترجمةِ الصافيةِ"; fi
  if grep -qF "dependencyFetchStage175();" "$ZTMP19/qa/RegressionSuite.java"; then
    ok "حلقةُ الجَلبِ مُسجَّلةٌ في ‏RegressionSuite‏ (‏dependencyFetchStage175‏)"
  else bad "حلقةُ الجَلبِ" "غيرُ مُسجَّلةٍ في مجموعةِ الانحدارِ"; fi
  if grep -qF "الجَلبُ الصامتُ" "$ZTMP19/qa/acceptance.sh"; then
    ok "القسمُ [33] حاضرٌ في ‏acceptance.sh‏ المُغلَّفِ"
  else bad "القسمُ [33]" "غائبٌ عن سكربتِ القبولِ في الحزمةِ"; fi
  ZIPVER33=$(grep -m1 -E '^[0-9]+\.[0-9]+\.[0-9]+$' "$ZTMP19/VERSION" 2>/dev/null || echo "?")
  [ "$ZIPVER33" = "$VERSION" ] && ok "بصمةُ الحزمةِ المصدريّةِ = $VERSION" \
    || bad "بصمةُ الحزمةِ المصدريّةِ" "$ZIPVER33 ≠ $VERSION"
  if zq -q "تقرير_دراسة_جَلبِ_الاعتمادياتِ_W25_3.md" \
  && zq -q "reports/تقرير_تنفيذ_W25_3_"; then
    ok "ورقتا الجَلبِ في الحزمةِ: دراسةٌ مرجعيّةٌ وتصميمٌ، وتنفيذُ المرحلةِ"
  else bad "ورقتا الجَلبِ" "إحداهُما مفقودةٌ من ‏reports/‏"; fi
  if grep -q "31" "$ZTMP19/PROJECT_STATE.md" && grep -qiE "DependencyFetchQueue|الجَلبُ" "$ZTMP19/PROJECT_STATE.md"; then
    ok "سِجلُّ الحالةِ يَذكُرُ الجولةَ: فصلٌ جديدٌ في ‏PROJECT_STATE.md‏"
  else bad "سِجلُّ الحالةِ" "لا ذِكرَ لمرحلةِ الجَلبِ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ للقراءةِ"; fi
rm -rf "$ZTMP19"


echo "[34] الجولةُ 27 (‏W26/1‏) — أفعالُ الإصلاحِ الاستيراديّةُ: دفعةُ حذفٍ واحدةٌ، ووحدةَ الصنفِ لا الجذرَ"
# (1) الـdex: الطبقةُ الجديدةُ مطبوعةٌ، والمنادِي لم يَنقُصْ من حِملِهِ شيءٌ.
TMP34=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP34" 2>/dev/null
if grep -lq "Lalmlk/ImportFixActions;" "$TMP34"/classes*.dex 2>/dev/null; then
  ok "‏ImportFixActions‏ في الـdex: الدفعةُ في التطبيقِ لا في البوّابةِ وحدَها"
else bad "‏ImportFixActions‏" "صنفٌ لا يَطبَعُهُ الـdex"; fi
if grep -lq "Lalmlk/DependencyFetchQueue;" "$TMP34"/classes*.dex 2>/dev/null; then
  ok "وطابورُ الجَلبِ باقٍ: الدورةُ الجديدةُ فوقَهُ لا بدلَهُ"
else bad "‏DependencyFetchQueue‏" "اختَفَتِ الطبقةُ السابقةُ"; fi
rm -rf "$TMP34"
# (2) لا شاشةَ، ولا صلاحيّةً، ولا أصلَ: الفعلُ تعديلٌ في النصِّ الحيِّ.
if zq -qE "app/src/main/res/layout/.*(import_fix|remove_imports)"; then
  bad "حدودُ الواجهةِ" "تخطيطٌ جديدٌ لأفعالِ الحذفِ؛ والمطلوبُ صَفٌّ في القائمةِ القائمةِ"
else ok "لا شاشةَ للحذفِ: الصَفُّ في اللوحةِ نفسِها ودفعتُهُ خطوةُ تراجعٍ واحدةٌ"; fi
if printf '%s\n' "$TREE" | grep -qE "app/src/main/assets/.*(imports_removed|import_fix)"; then
  bad "أصولٌ" "أُضيفَ أصلٌ للجولةِ؛ وهي حسابٌ على النصِّ"
else ok "لا أصلَ مُضافًا: لا بياناتَ للحذفِ"; fi
if printf '%s\n' "$MANIFEST" | grep -qE "ACCESS_NETWORK_STATE|FOREGROUND_SERVICE"; then
  PERM34=$(printf '%s\n' "$MANIFEST" | grep -c "uses-permission")
  ok "صلاحيّاتُ التطبيقِ لم تَزِدْ عن عَددِها القائمِ ($PERM34)"
else ok "ولا صلاحيّةَ أُضيفَتْ على مسارِ الإصلاحِ"; fi
# (3) الصَفاءُ والأسقافُ: الطبقةُ النقيّةُ تُترجَمُ في ‏qa.sh‏ وحدَها.
if ! grep -q "^import android" app/src/main/java/almlk/ImportFixActions.java; then
  ok "‏ImportFixActions‏ نقيٌّ: بلا ‏android.*‏ يَمسُّ المحرِّرَ أو القرصَ"
else bad "صَفاءُ ‏ImportFixActions‏" "يَحمِلُ android.*"; fi
if grep -q "MAX_OPS = 64" app/src/main/java/almlk/ImportFixActions.java \
&& grep -q "MAX_SOURCE_CHARS = 2 << 20" app/src/main/java/almlk/ImportFixActions.java; then
  ok "سقفيانِ معلَنانِ: أربعٌ وستّونَ عمليةً، ومِيزابايتانِ للنصِّ"
else bad "الأسقافُ" "سقْفٌ مُعلَنٌ مفقودٌ"; fi
if grep -qF '"$SRC/almlk/ImportFixActions.java"' qa.sh; then
  ok "الملفُّ في ‏qa.sh‏: تُترجَمُ الطبقةُ صافيةً وتُختبَرُ قبلَ الحزمِ"
else bad "قائمةُ qa.sh" "‏ImportFixActions‏ خارجَ الترجمةِ الصافيةِ"; fi
# (4) العيبُ الذي أُغلِقَ: جسمُ الملفِّ يبدأُ بعدَ آخرِ سطرِ استيرادٍ لا بعدَ أولِها.
if grep -q "Math.max(bodyStart, line.end)" app/src/main/java/almlk/ImportSoundness.java \
&& ! grep -q "if (lines.get(k).start < bodyStart)" app/src/main/java/almlk/ImportSoundness.java; then
  ok "حُسنُ ‏bodyStart‏: كلُّ زائدٍ يُبلَّغُ لا أولُهُ وحدَهُ (عيبُ 1.0.174 مُغلَقٌ ببصمةِ نصٍّ)"
else bad "جسمُ الفحصِ" "الحصرُ القديمُ باقٍ: الاستيراداتُ الزائدةُ بعدَ الأولِ لا تُرى"; fi
# (5) لا مسارَ كتابةٍ ثانٍ: الحذفُ يَمُرُّ بعقدِ العمليةِ القائمِ.
if grep -q "fix.kind == QuickFix.Kind.REMOVE_IMPORTS" app/src/main/java/almlk/QuickFixExecutor.java \
&& grep -q "editor.applyTokenInsertion(fix)" app/src/main/java/almlk/QuickFixExecutor.java \
&& grep -q "if (kind == Kind.REMOVE_IMPORTS)" app/src/main/java/almlk/QuickFix.java \
&& grep -q "importPlan.asInsertion(source)" app/src/main/java/almlk/QuickFix.java; then
  ok "العقدُ واحدٌ: خطةٌ من النصِّ الحيِّ، وعمليةٌ واحدةٌ، وحارسٌ واحدٌ"
else bad "عقدُ التطبيقِ" "مسارٌ ثانٍ كُتِبَ للحذفِ أو الحِراسةُ مفقودةٌ"; fi
if grep -A 10 "if (fix.kind == QuickFix.Kind.REMOVE_IMPORTS)" app/src/main/java/almlk/QuickFixExecutor.java \
| grep -qE "ProgressDialog|AlertDialog|jumpToRange|setSelection"; then
  bad "صونُ الموضعِ" "نافذةٌ أو قفزةٌ في مسارِ الحذفِ"
else ok "صونُ الموضعِ نافذٌ على الحذفِ: لا نافذةَ، لا قفزةَ، لا تحديدَ"; fi
if grep -q "almlk.ImportFixActions.planForIssues(" app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java \
&& grep -q "pendingInspectionFrom, pendingInspectionTo" app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java; then
  ok "الدفعةُ من نطاقِ الفحصِ التدريجيِّ: خارجَهُ لا يُمسَحُ سطرٌ"
else bad "نطاقُ الدفعةِ" "الفحصُ التدريجيُّ لم يُوَجَّه إلى الحذفِ"; fi
# (6) التوجيهُ إلى الوحدةِ: مَعرِفةُ مِلكِيّةِ الملفِّ قبلَ الكتابةِ.
if grep -q "public File moduleDirFor(File sourceFile)" app/src/main/java/almlk/GradleProjectModules.java \
&& grep -q "public File buildFileFor(File sourceFile)" app/src/main/java/almlk/GradleProjectModules.java; then
  ok "بوّابةُ التوجيهِ معلَنةٌ في الطبقةِ النقيّةِ (أطولُ مطابقةٍ، والتعادُلُ رفضٌ)"
else bad "توجيهُ الوحدةِ" "البوّابةُ مفقودةٌ من ‏GradleProjectModules‏"; fi
if grep -q "cycleModel.projectModules.buildFileFor(" app/src/main/java/com/shima/demo/MainActivity.java \
&& grep -q "File targetBuild = buildFile;" app/src/main/java/com/shima/demo/MainActivity.java; then
  ok "والكتابةُ تَعرِفُ وحدَتَها وتَراجُعُها إلى الجذرِ مَكتوبٌ صراحةً"
else bad "توجيهُ الكتابةِ" "الجذرُ يفرضُ نفسَهُ بلا مَعرِفةٍ"; fi
# (7) الحزمةُ المصدريّةُ: الشيفرةُ، والبوابتُانِ، والورقتانِ، والبصمةُ.
ZTMP20=$(mktemp -d)
if unzip -oq "$ZIP" -d "$ZTMP20" 2>/dev/null; then
  if zq -qxF "app/src/main/java/almlk/ImportFixActions.java"; then
    ok "‏ImportFixActions.java‏ في الحزمةِ المصدريّةِ"
  else bad "الحزمةُ المصدريّةُ" "الطبقةُ الجديدةُ غيرُ مُغلَّفةٍ"; fi
  if grep -qF "importFixActionsStage176();" "$ZTMP20/qa/RegressionSuite.java" \
  && grep -qF "dependencyFetchStage175();" "$ZTMP20/qa/RegressionSuite.java"; then
    ok "الحلقتانِ مُسجَّلتانِ بالترتيبِ: الجَلبُ ثمَّ الأفعالُ"
  else bad "تسجيلُ الحلقاتِ" "إحداهُما غائبةٌ أو مُقلوبةٌ"; fi
  if grep -qF 'echo "[34]' "$ZTMP20/qa/acceptance.sh"; then
    ok "القسمُ [34] حاضرٌ في ‏acceptance.sh‏ المُغلَّفِ"
  else bad "القسمُ [34]" "غائبٌ عن السكربتِ في الحزمةِ"; fi
  ZIPVER34=$(grep -m1 -E '^[0-9]+\.[0-9]+\.[0-9]+$' "$ZTMP20/VERSION" 2>/dev/null || echo "?")
  [ "$ZIPVER34" = "$VERSION" ] && ok "بصمةُ الحزمةِ المصدريّةِ = $VERSION" \
    || bad "بصمةُ الحزمةِ المصدريّةِ" "$ZIPVER34 ≠ $VERSION"
  if zq -q "تقرير_دراسة_أفعالِ_الإصلاحِ_الاستيراديّةِ_W26_1.md" \
  && zq -q "reports/تقرير_تنفيذ_W26_1_"; then
    ok "ورقتا الأفعالِ في الحزمةِ: دراسةُ سجلِّ الإصلاحِ، وتنفيذُ المرحلةِ"
  else bad "ورقتا الأفعالِ" "إحداهُما مفقودةٌ من ‏reports/‏"; fi
  if grep -q "32" "$ZTMP20/PROJECT_STATE.md" && grep -qiE "ImportFixActions|أفعالُ الإصلاحِ" "$ZTMP20/PROJECT_STATE.md"; then
    ok "سِجلُّ الحالةِ يَذكُرُ الجولةَ: فصلٌ جديدٌ في ‏PROJECT_STATE.md‏"
  else bad "سِجلُّ الحالةِ" "لا ذِكرَ لمرحلةِ الأفعالِ"; fi
else bad "الحزمةُ المصدريّةُ" "لا تُفتَحُ للقراءةِ"; fi
rm -rf "$ZTMP20"


echo "[35] الجولةُ 28 (‏W27/1‑2‏) — توقيتُ الفحصِ بالملفِّ المستهدَفِ، وحارسُ لوحِ الأخطاءِ"
# (1) الصنفانِ النقيّانِ في ‏dex: لا وعظَ في البوّابةِ وحدَها.
TMP35=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP35" 2>/dev/null
if grep -lq "Lalmlk/AnalysisTargets;" "$TMP35"/classes*.dex 2>/dev/null; then
  ok "‏AnalysisTargets‏ في الـdex: قرارُ التوقيتِ داخلَ التطبيقِ"
else bad "‏AnalysisTargets‏" "صنفٌ لا يَطبَعُهُ الـdex"; fi
if grep -lq "Lalmlk/ErrorBrowserPolicy;" "$TMP35"/classes*.dex 2>/dev/null; then
  ok "‏ErrorBrowserPolicy‏ في الـdex: حارسُ اللوحِ مَحمولٌ لا مُستعارٌ"
else bad "‏ErrorBrowserPolicy‏" "الحارسُ خارجَ الحزمةِ"; fi
rm -rf "$TMP35"
# (2) المسارُ القديمُ مُحالٌ: لا نقرَةٌ عارضةٌ تُبدِّلُ السياقَ.
ZTMP35=$(mktemp -d); unzip -oq "$ZIP" -d "$ZTMP35" 2>/dev/null
M35="$ZTMP35/app/src/main/java/com/shima/demo/MainActivity.java"
if [ -f "$M35" ] && ! grep -q "maybeSwitchProjectForFile(" "$M35" && ! grep -q "maybeOpenProjectForBuildFile(" "$M35"; then
  ok "لا مسارَ موازيًا: حُذِفَ مُبدِّلُ السياقِ ومُحاوِرُ ملفِّ البناءِ"
else bad "المسارُ القديمُ" "باقٍ في الشجرةِ المُغلَّفةِ"; fi
if [ -f "$M35" ] && grep -q "armAnalysisForOpenedFile(reference)" "$M35" && grep -q "almlk.AnalysisTargets.of(reference" "$M35"; then
  ok "الفتحُ كلُّهُ يمرُّ بقرارٍ مُسمّى من الطبقةِ النقيّةِ"
else bad "قرارُ التوقيتِ" "النقرَةُ لا تُسأَلُ الطبقةُ"; fi
if [ -f "$M35" ] && grep -A 30 "private void armAnalysisForOpenedFile" "$M35" | grep -qE "Toast.makeText|new AlertDialog|setProgress"; then
  bad "سكونُ التصفُّحِ" "توستٌ أو نافذةٌ في مسارِ التسلِيحِ"
else ok "التصفُّحُ لا يُقاطِعُ: لا توستَ ولا نافذةَ ولا شريطَ تقدُّمٍ في المسارِ"; fi
if [ -f "$M35" ] && grep -q "confirmOpenProjectForTargetFile" "$M35" && grep -qF 'ui("dialog_open_project_title")' "$M35"; then
  ok "و«افتح المشروعَ» باقٍ بنصّيهِ، مُقيَّدًا بملفٍّ جوهريٍّ في مشروعٍ آخرَ"
else bad "حوارُ الفتحِ" "أُلقِيَ مع القديمِ أو لم يُقيَّدْ"; fi
# (3) الأسقافُ والحالاتُ كما في المرجعِ.
T35="$ZTMP35/app/src/main/java/almlk/AnalysisTargets.java"; P35="$ZTMP35/app/src/main/java/almlk/ErrorBrowserPolicy.java"
if grep -q 'MAX_WALK_DEPTH = 24' "$T35" && grep -q 'MAX_PATH_CHARS = 4096' "$T35" \
&& grep -q 'APP_MODULE = "app"' "$T35"; then
  ok "أسقافُ التوقيتِ مكتوبةٌ: صعودٌ أربعٌ وعشرونَ، ومسارٌ أربعةُ آلافٍ وأربعمئةٍ، ووحدةُ ‏app"
else bad "أسقافُ التوقيتِ" "سقفٌ مُعدَّلٌ بلا أثرٍ في الدراسةِ"; fi
if grep -q 'KIND_BUILD\|KIND_MANIFEST\|KIND_LAYOUT\|KIND_SOURCE' "$T35" \
&& [ "$(grep -c 'public static final String KIND_' "$T35")" = "4" ]; then
  ok "أربعةُ أنواعٍ جوهريّةٍ لا خامسَ لها (بناءٌ، manifest، تخطيطٌ، مصدرٌ)"
else bad "أنواعُ الملفِّ الجوهريِّ" "زادَ أو نقصَ"; fi
if grep -q "hasBuildFile(dir)" "$T35" && grep -q 'APP_MODULE.equals(dir.getName())' "$T35"; then
  ok "وحدةُ التطبيقِ لا تُعرَفُ بالاسمِ وحدَهُ: ملفُّ بناءٍ شرطٌ"
else bad "تقييدُ الوحدةِ" "حزمةٌ باسمِ app تكفي — وهُمْلَةٌ"; fi
if grep -q 'MAX_LISTED_ERRORS = 100' "$P35"; then
  ok "سقْفُ اللوحةِ مِئةٌ كما في حارسِ المرجعِ ‏(m26Hw)"
else bad "سقْفُ اللوحةِ" "المرجعُ يَحمي نفسَهُ بمِئةٍ"; fi
if grep -q 'over_display_limit' "$P35" && grep -q 'unchanged' "$P35" && grep -q 'no_count' "$P35"; then
  ok "حالتا_SKIP_ وثلاثُ أسبابٍ مُسمّاةٍ: لا صمتَ بلا سببٍ"
else bad "أسبابُ القرارِ" "حذفُ سببٍ يُخفي قرارًا"; fi
# (4) الوصلُ: لا نسخةَ ثانيةَ من الحارسِ، ولا بوّابةً في موضعٍ واحدٍ.
E35="$ZTMP35/app/src/main/java/com/almlkid/ui/AIDEEditorPager.java"; S35="$ZTMP35/app/src/main/java/com/almlkid/ui/SequentialPanelHost.java"
if grep -q "private boolean analysisArmed = true;" "$E35" \
&& [ "$(grep -c 'code.setAnalysisPaused(!analysisArmed);' "$E35")" = "2" ] \
&& grep -q "code.setAnalysisPaused(lazyRestore || !analysisArmed);" "$E35"; then
  ok "بوّابةٌ واحدةٌ في المِرْوَجِ تُغلِقُ مواضعَ الإقلاعِ الثلاثةِ"
else bad "بوّابةُ المِرْوَجِ" "موضعٌ أفلَتَ التسلِيحَ"; fi
# — أُعيدَتْ صياغتُها في ‏1.0.179: الحارسُ نفسُهُ بقيَ، لكنَّهُ وقَّعَ نافذتَهُ، والرأسُ عدَّ العائلتَينِ.
POL35="$ZTMP35/app/src/main/java/almlk/ErrorBrowserPolicy.java"
if grep -q "lastPulseCount, counted, hadFocus, lastPulseSignature, signature);" "$S35" \
&& grep -q "if (!policy.rebuilds()) {" "$S35" \
&& grep -q "while (diagnostics.size() > policy.listed)" "$S35" \
&& ! grep -q "almlk.ErrorBrowserPolicy.decide(lastPulseCount, counted, hadFocus)" "$S35"; then
  ok "اللوحُ يَحكُمُهُ حارسٌ واحدٌ مُوقَّعٌ: لا صمتَ على عددٍ لم يتغيَّرْ وقد تبدَّلَ محتوى النافذةِ"
else bad "حارسُ اللوحِ" "حارسٌ ثانٍ أو عَدٌّ وحدَهُ يَحكُمُ العرضَ"; fi
if [ -f "$POL35" ] \
&& grep -q "public static Decision decide(int previousCount, int currentCount, boolean hadFocus)" "$POL35"; then
  ok "وحارسُ ‏1.0.177 بلا بصمةٍ باقٍ في الطبقةِ: مَن لا يُطوِّقُ نافذتَهُ يَحكُمُ بنفسِ القرارِ"
else bad "قِرنُ ‏1.0.177" "طُرِدَ مع توقيعِ البصمةِ"; fi
if grep -q "almlk.ErrorBrowserPolicy.badgeHidden(errors + warnings)" "$S35" \
&& grep -q "headerKey = almlk.ErrorBrowserPolicy.headerKey(errors);" "$S35" \
&& grep -q "String headerKey = almlk.ErrorBrowserPolicy.HEADER_NONE;" "$S35"; then
  ok "الأيقونةُ والرأسُ وحالةُ «لا شيءَ» كلُّها قرارُ الطبقةِ، لا رقمًا في العرضِ"
else bad "رأسُ اللوحِ" "منطقٌ مُكرَّرٌ في العرضِ"; fi
# (5) اللغتَانِ والسلاسلُ الجديدةُ: لا نصَّ مختَرََعًا في الشيفرةِ.
for key in ui_errors_capped ui_analysis_waits_for_app_file; do
  if grep -q "name=\"$key\"" "$ZTMP35/app/src/main/res/values/strings.xml" \
  && grep -q "name=\"$key\"" "$ZTMP35/app/src/main/res/values-ar/strings.xml"; then
    ok "مفتاحٌ في اللغتَينِ: $key"
  else bad "سلسلةُ $key" "ناقصةٌ من إحدى اللغتَينِ"; fi
done
if python3 -c "import xml.dom.minidom as m,sys; m.parse(sys.argv[1]); m.parse(sys.argv[2])" \
  "$ZTMP35/app/src/main/res/values/strings.xml" "$ZTMP35/app/src/main/res/values-ar/strings.xml" 2>/dev/null; then
  ok "ملفَّا السلاسلِ يقرأُهُما محللُ ‏XML: لا وسمًا كُسِرَ بإدراجٍ يدويٍّ"
else bad "بناءُ XML" "ملفُّ سلاسلٍ لا يُقرأُ"; fi
# (6) لا واجهةَ، ولا صلاحيّةً، ولا أصلًا: المرحلةُ قرارٌ في التوقيتِ لا شاشةٌ جديدةٌ.
if zq -qE "res/layout/.*(analysis_gate|trigger_file)"; then
  bad "حدودُ الواجهةِ" "تخطيطٌ جديدٌ لتوقيتِ الفحصِ"
else ok "لا شاشةَ للتوقيتِ: سطرُ حالةٍ واحدٌ في اللوحةِ القائمةِ"; fi
if printf '%s\n' "$ALIST" | grep -q "assets/.*\.jet"; then
  bad "أصولٌ" "‏.jet في ‏APK على غيرِ شرطِ البندِ 4ب٢‏ج"
else ok "ولا أصلَ ثقيلًا أُضيفَ: صفرُ ‏.jet في الحزمةِ"; fi
# قائمةُ المصدرِ هي المِقياسُ؛ وما يزيدُ في ‏APK دمجٌ مكتبيٌّ معروفٌ (‏DUMP) لا فعلُ هذهِ المرحلةِ.
PERM35A=$(printf '%s\n' "$TREE" | grep -oE "android\.permission\.[A-Z_]+" | sort -u)
PERM35S=$(grep -oE "android\.permission\.[A-Z_]+" "$ZTMP35/app/src/main/AndroidManifest.xml" 2>/dev/null | sort -u)
PERM35X=$(comm -23 <(printf '%s\n' "$PERM35A") <(printf '%s\n' "$PERM35S"))
if [ "$(printf '%s\n' "$PERM35S" | grep -c .)" = "12" ] && [ "$PERM35X" = "android.permission.DUMP" ]; then
  ok "لا صلاحيّةَ أُضيفَتْ: اثنتا عشرةَ في المصدرِ، وزيادةُ الحزمةِ دمجُ ‏DUMP المكتبيُّ وحدَهُ"
else bad "صلاحيّاتٌ" "المصدرُ=$(printf '%s\n' "$PERM35S" | grep -c .) وزيادةُ الحزمةِ=$PERM35X"; fi
# (7) الأداةُ والحزمةُ: النقيُّ يُترجَمُ صافيًا، والأوراقُ مُغلَّفةٌ، والبصمةُ جاريةٌ.
if grep -qF '"$SRC/almlk/AnalysisTargets.java"' "$ZTMP35/qa.sh" \
&& grep -qF '"$SRC/almlk/ErrorBrowserPolicy.java"' "$ZTMP35/qa.sh"; then
  ok "الصنفانِ في قائمةِ ‏qa.sh: تُختبَرُ الطبقةُ صافيةً قبلَ الحزمِ"
else bad "قائمةُ qa.sh" "صنفٌ نقيٌّ خارجَ الترجمةِ الصافيةِ"; fi
if ! grep -q "^import android" "$T35" "$P35" 2>/dev/null; then
  ok "الصنفانِ نقِيّانِ: لا ‏android.* ولا مِسكَ عرضٍ فيهما"
else bad "صَفاءُ الطبقةِ" "استيرادٌ أندرويديٌّ في النقيِّ"; fi
if grep -qF "targetedTriggerStage177();" "$ZTMP35/qa/RegressionSuite.java" \
&& grep -qF "importFixActionsStage176();" "$ZTMP35/qa/RegressionSuite.java"; then
  ok "الحلقاتُ مُسجَّلةٌ بالترتيبِ: الأفعالُ ثمَّ التوقيتُ"
else bad "تسجيلُ الحلقاتِ" "حلقةٌ غائبةٌ أو مُقلَبةٌ"; fi
if grep -qF 'echo "[35]' "$ZTMP35/qa/acceptance.sh"; then
  ok "القسمُ [35] حاضرٌ في ‏acceptance.sh المُغلَّفِ"
else bad "القسمُ [35]" "غائبٌ عن السكربتِ في الحزمةِ"; fi
ZIPVER35=$(grep -m1 -E '^[0-9]+\.[0-9]+\.[0-9]+$' "$ZTMP35/VERSION" 2>/dev/null || echo "?")
[ "$ZIPVER35" = "$VERSION" ] && ok "بصمةُ الحزمةِ المصدريّةِ = $VERSION" \
  || bad "بصمةُ الحزمةِ المصدريّةِ" "$ZIPVER35 ≠ $VERSION"
if zq -q "W27" && zq -q "reports/تقرير_تنفيذ_W27_1_"; then
  ok "ورقتا المرحلةِ الأولى في الحزمةِ: دراسةُ الملحقاتِ، وتنفيذُ التوقيتِ واللوحِ"
else bad "ورقتا المرحلةِ" "إحداهُما مفقودةٌ من مجلدِ reports/"; fi
if grep -q "33" "$ZTMP35/PROJECT_STATE.md" && grep -qiE "AnalysisTargets|توقيتُ الفحصِ" "$ZTMP35/PROJECT_STATE.md"; then
  ok "سِجلُّ الحالةِ يَذكُرُ المرحلةَ الأولى: فصلٌ جديدٌ في ‏PROJECT_STATE.md"
else bad "سِجلُّ الحالةِ" "لا ذِكرَ لـW27/1 في الحزمةِ"; fi
rm -rf "$ZTMP35"

echo "[36] الجولةُ 28/2 (‏1.0.178‏) — حِملُ الجسرِ في ‏data: عطلُ «non-Parcelable objects across processes»"
# (1) الحزمةُ الحيّةُ: الحاملُ مطبوعٌ، ومفتاحُ الحِملِ وسببُهُ في الـdex — لا في الشجرةِ وحدَها.
TMP36=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP36" 2>/dev/null
if grep -lq "Lcom/almlkid/analyzer/AnalyzerCarrier;" "$TMP36"/classes*.dex 2>/dev/null; then
  ok "‏AnalyzerCarrier‏ في الـdex: القناةُ الصحيحةُ داخلَ التطبيقِ"
else bad "‏AnalyzerCarrier‏" "الحاملُ لم يُطبعْ: العطلُ باقٍ على الجهازِ"; fi
if grep -lq "almlk.analyzer.wire" "$TMP36"/classes*.dex 2>/dev/null; then
  ok "ومفتاحُ الحِملِ مُثبَّتٌ في الحزمةِ: طرفانِ يَتَّفِقانِ على اسمٍ واحدٍ"
else bad "مفتاحُ الحِملِ" "غائِبٌ عن الـdex" ; fi
if grep -lq "not Parcelable" "$TMP36"/classes*.dex 2>/dev/null; then
  ok "وسطرُ السجلِّ مُضمَّنٌ: العطلُ يروي سببَهُ لا يَخرُجُ صامتًا"
else bad "سببُ القناةِ" "لا أثرَ لهُ في الحزمةِ"; fi
if grep -lq "Lcom/almlkid/analyzer/AnalyzerConnection;" "$TMP36"/classes*.dex \
&& grep -lq "Lcom/almlkid/analyzer/AnalyzerService;" "$TMP36"/classes*.dex \
&& grep -lq "Lalmlk/AnalyzerProtocol;" "$TMP36"/classes*.dex; then
  ok "وطبقاتُ الجسرِ الثلاثُ باقيةٌ: أصلحَتِ القناةُ ولم يُهدَمْ ما تحتَها"
else bad "طبقاتُ الجسرِ" "صنفٌ من الثلاثةِ زالَ"; fi
rm -rf "$TMP36"
# (2) الشجرةُ المُغلَّفةُ: لا سلسلةَ في ‏obj عندَ أيِّ طرفٍ، والقارئُ واحدٌ.
ZTMP36=$(mktemp -d); unzip -oq "$ZIP" -d "$ZTMP36" 2>/dev/null
C36="$ZTMP36/app/src/main/java/com/almlkid/analyzer/AnalyzerCarrier.java"
N36="$ZTMP36/app/src/main/java/com/almlkid/analyzer/AnalyzerConnection.java"
S36="$ZTMP36/app/src/main/java/com/almlkid/analyzer/AnalyzerService.java"
PR36="$ZTMP36/app/src/main/java/almlk/AnalyzerProtocol.java"
if [ -f "$C36" ] && grep -q "msg.setData(" "$C36" && grep -q "msg.obj = null" "$C36"; then
  ok "الحاملُ يَحمِلُ في ‏data ويُمسِكُ ‏obj فارغًا"
else bad "حاملُ الحِملِ" "ملفٌّ مفقودٌ أو لا يَمسَحُ ‏obj"; fi
if [ -f "$C36" ] && grep -q "data.containsKey(AnalyzerProtocol.KEY_WIRE)" "$C36" \
&& grep -q "legacy instanceof String" "$C36" && grep -q "sendable(Message msg)" "$C36"; then
  ok "القراءةُ من ‏data أولًا و‏obj احتياطًا، مع حارسٍ قبلَ الإرسالِ"
else bad "قارئُ الحِملِ" "وجهٌ واحدٌ أو لا حارسَ"; fi
if [ -f "$N36" ] && ! grep -q "out.obj =" "$N36" && grep -q "AnalyzerCarrier.obtain(what, wire)" "$N36"; then
  ok "جسرُ الواجهةِ: لا سطرَ ‏obj فيهِ، والإرسالُ من قناةٍ واحدةٍ"
else bad "جسرُ الواجهةِ" "أعادَ الحِملَ إلى ‏obj"; fi
if [ -f "$N36" ] && grep -q "catch (RuntimeException unmashalled)" "$N36" \
&& grep -q "AnalyzerProtocol.stateForSendFailure(unmashalled)" "$N36" \
&& [ "$(grep -c 'queue.requeue(job)' "$N36")" = "3" ]; then
  ok "عطلُ النقلِ حالةٌ مُسمّاةٌ والطلبُ يعودُ إلى الطابورِ ثلاثَ مراتٍ"
else bad "قبضُ النقلِ" "سقوطٌ في خيطِ الواجهةِ أو طلبٌ ضائعٌ"; fi
if [ -f "$S36" ] && ! grep -q "out.obj =" "$S36" \
&& [ "$(grep -c 'AnalyzerCarrier.payload(msg)' "$S36")" = "4" ] \
&& [ "$(grep -c 'AnalyzerCarrier.obtain(' "$S36")" = "2" ]; then
  ok "عمليةُ التحليلِ تَقرَأُ وتَكتُبُ على القناةِ ذاتِها (واردٌ أربعةٌ وصادرٌ اثنانِ)"
else bad "جانبُ الخدمةِ" "قناةٌ مختلطةٌ بينَ الطرفَينِ"; fi
if [ -f "$S36" ] && [ "$(grep -c 'RemoteException | RuntimeException' "$S36")" = "2" ] \
&& grep -q "catch (RuntimeException unmashalled)" "$S36"; then
  ok "ولا يَخرُجُ من ‏:analyzer عطلٌ: الردُّ والحالةُ مقبوضٌ عليهما معًا"
else bad "خيطُ التحليلِ" "إرسالٌ عارٍ من القبضِ"; fi
if [ -f "$S36" ] && grep -q "وحِملٌ سِلكيٌّ في {@code data}" "$S36" && ! grep -q "سِلكيٌّ في {@code obj}" "$S36"; then
  ok "وثيقةُ الخدمةِ صادقةٌ: وصفتِ القناةَ كما هي لا كما كانتْ"
else bad "وثيقةُ القناةِ" "تكذِبُ على ناقلِها"; fi
# (3) العقدُ لم يتبدّلْ: الترميزُ نفسُهُ، والسبعةُ رموزَ كما هي، والصَفاءُ كما شَرَطَتهُ ‏W23.
if [ -f "$PR36" ] && grep -q 'KEY_WIRE = "almlk.analyzer.wire"' "$PR36" \
&& grep -q 'CARRIER_OBJ = "obj"' "$PR36" && grep -q 'CARRIER_DATA = "data"' "$PR36"; then
  ok "سياسةُ القناةِ معلَنةٌ في الطبقةِ الصافيةِ وحدَها"
else bad "سياسةُ القناةِ" "مبعثرةٌ في الجانبَينِ"; fi
if [ -f "$PR36" ] && [ "$(grep -c 'public static final int CODE_' "$PR36")" = "7" ] \
&& grep -q 'CODE_PING = 1' "$PR36" && grep -q 'CODE_CANCEL = 7' "$PR36"; then
  ok "سبعةُ رموزِ معاملةٍ كما كانتْ: الإصلاحُ في الوعاءِ لا في العقدِ"
else bad "عقدُ السِّلكِ" "رمزٌ تبدَّلَ أو زالَ"; fi
if [ -f "$PR36" ] && ! grep -q "import android." "$PR36" && grep -q "PARCELABLE.equals" "$PR36"; then
  ok "والصافيُّ بقي صافيًا: تمييزٌ بالاسمِ لا باستيرادِ ‏android"
else bad "صَفاءُ الطبقةِ" "استيرادٌ من ‏android إلى ما يُختبَرُ على المضيفِ"; fi
# (4) الحدودُ: لا أصلَ، ولا شاشةَ، ولا صلاحيّةَ، ولا بديلَ مِضيفيٌّ في الحزمةِ.
if zq -qE ".*(carrier|parcelable).*\.(xml|png|jar|gz|jet)$"; then
  bad "حدودُ الحزمةِ" "أُضيفَ أصلٌ أو تخطيطٌ لإصلاحِ القناةِ"
else ok "لا أصلَ ولا شاشةَ: الإصلاحُ سطرُ نقلٍ لا ميزةُ واجهةٍ"; fi
if printf '%s\n' "$ALIST" | grep -q "host-stubs"; then
  bad "بدائلُ المضيفِ" "سَرَبَ بديلُ ‏android إلى داخلِ ‏APK"
else ok "بديلُ المضيفِ خارجَ ‏APK: لا يُعرَّفُ نوعٌ من ‏android على الجهازِ"; fi
if zq -q "qa/host-stubs/android/os/Parcelable.java"; then
  ok "ومَعدودٌ في الزِبِ مع سائرِ بدائلِ ‏qa: العُدَّةُ كاملةٌ لمَن يُعيدُ البوّابةَ"
else bad "عُدَّةُ البوابةِ" "بديلُ المضيفِ مفقودٌ من الزِبِ"; fi
if zq -q "app/src/main/java/com/almlkid/analyzer/AnalyzerCarrier.java"; then
  ok "والحاملُ مَعدودٌ في الزِبِ: مَنبَعُ البوابةِ واحدٌ"
else bad "عُدَّةُ الزِبِ" "الحاملُ غيرُ مُغلَّفٍ"; fi
EN36="$ZTMP36/app/src/main/res/values/strings.xml"; AR36="$ZTMP36/app/src/main/res/values-ar/strings.xml"
# مُصَّحَحٌ في نفسِ الجولةِ: العربيةُ عندَنا طبقةُ تغطيةٍ (‏1263 مفتاحًا) لا نسخةٌ كاملةٌ (‏3052)،
# فمقياسُ التوازُنِ هو شمولُ الأصلِ لا مساواةُ العددِ؛ ولا يُترَكُ المقياسُ على وَهمِ التساوي.
if [ -f "$EN36" ] && [ -f "$AR36" ] \
&& ! comm -13 <(grep -o 'name="[a-z0-9_]*"' "$EN36" | sort -u) <(grep -o 'name="[a-z0-9_]*"' "$AR36" | sort -u) | grep -q . \
&& ! grep -qE 'name="ui_(carrier|marshal|parcelable)' "$EN36"; then
  ok "كلُّ سلسلةٍ عربيةٍ لها أصلٌ إنجليزيٌّ، ولا سطرَ للإصلاحِ: تغطيةٌ لا مِيزَةُ واجهةٍ"
else bad "سلاسلُ اللغتَينِ" "مفتاحٌ يتيمٌ أو سطرٌ زائدٌ على الإصلاحِ"; fi
if printf '%s\n' "$TREE" | grep -q "com.almlkid.analyzer.AnalyzerService"; then
  ok "الخدمةُ في المانيفست المُجمَّعِ بمعزلِها ‏(:analyzer): القناةُ تُصحَّحُ لا تُلغى"
else bad "معزلُ المُحرِّكِ" "الخدمةُ ليست في المانيفستِ"; fi
if grep -q "marshalCarrierStage178();" "$ZTMP36/qa/RegressionSuite.java" 2>/dev/null \
&& ! grep -q "AnalyzerCarrier.java" "$ZTMP36/qa.sh" 2>/dev/null; then
  ok "العُدّةُ: المرحلةُ مسجَّلةٌ في ‏RegressionSuite، والحاملُ خارجَ القائمةِ الصافيةِ"
else bad "عُدّةُ البوابتَينِ" "مرحلةٌ غيرُ مسجَّلةٍ أو قائمةٌ صافيةٌ مُلوَّثةٌ"; fi
if ls "$ZTMP36"/reports/ 2>/dev/null | grep -q "1_0_178" && grep -qF "non-Parcelable" "$ZTMP36/PROJECT_STATE.md" 2>/dev/null; then
  ok "ورقةُ الجولةِ وسِجلُّ الحالةِ يَذكُرانِ العطلَ باسمِهِ الحرفيِّ"
else bad "توثيقُ الجولةِ" "لا ورقةٌ ببصمتِها ولا ذكرٌ للعطلِ"; fi
rm -rf "$ZTMP36"


echo "[37] الجولةُ 28/3 (‏1.0.179‏) — ‏W27/2: لوحٌ يَعرِضُ الخطأَ والتحذيرَ فورًا، وقفزةٌ إلى الرمزِ"
# (1) الحزمةُ الحيّةُ: المفتاحُ والسببُ مُطبوعانِ، والطبقاتُ السابقةُ لم تَسقُطْ.
TMP37=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP37" 2>/dev/null
if grep -lq "ui_errors_warnings_count" "$TMP37"/classes*.dex 2>/dev/null; then
  ok "مفتاحُ قِطعةِ الرأسِ في الـdex: التحذيراتُ تُعلَنُ في الحزمةِ لا في الشجرةِ وحدَها"
else bad "مفتاحُ التحذيراتِ" "لم يُطبعْ: اللوحُ لا يَذكُرُها"; fi
if grep -lq "content_changed" "$TMP37"/classes*.dex 2>/dev/null; then
  ok "وسببُ إعادةِ البناءِ مُعلَنٌ في الحزمةِ: التحديثُ الفوريُّ قرارٌ لا مِزاجٌ"
else bad "سببُ التحديثِ" "غائبٌ عن الـdex"; fi
if grep -lq "Lalmlk/ErrorBrowserPolicy;" "$TMP37"/classes*.dex; then
  ok "الطبقةُ الصافيةُ هي المُوسَّعةُ: لا نسخةً ثانيةً في الغلافِ"
else bad "طبقةُ السياسةِ" "استُبدِلَت لا أُوسِعَت"; fi
if grep -lq "Lalmlk/AnalysisTargets;" "$TMP37"/classes*.dex \
&& grep -lq "Lcom/almlkid/analyzer/AnalyzerCarrier;" "$TMP37"/classes*.dex; then
  ok "وطبقتا ‏1.0.177 و‏1.0.178 باقيتانِ: التوقيتُ والناقلُ لم يَذهَبا مع المرحلةِ"
else bad "الطبقاتُ السابقةُ" "زالتْ واحدةٌ منها"; fi
rm -rf "$TMP37"
# (2) الشجرةُ المُغلَّفةُ: حارسٌ واحدٌ، وقطعٌ قبلَ التجميعِ، وبصمةٌ تُرى.
ZTMP37=$(mktemp -d); unzip -oq "$ZIP" -d "$ZTMP37" 2>/dev/null
H37="$ZTMP37/app/src/main/java/com/almlkid/ui/SequentialPanelHost.java"
G37="$ZTMP37/app/src/main/java/almlk/ErrorBrowserPolicy.java"
J37="$ZTMP37/app/src/main/java/com/almlkid/ui/AIDEEditorPager.java"
A37="$ZTMP37/app/src/main/java/com/shima/demo/MainActivity.java"
if [ -f "$H37" ] && grep -q "if (isPanelRow(value)) diagnostics.add(value)" "$H37" \
&& ! grep -q "if (isPanelError(value)) diagnostics.add(value)" "$H37"; then
  ok "الصُّوفةُ تُبنى بقاعدةِ العرضِ (خطأٌ + تحذيرٌ)، لا بقاعدةِ العدِّ"
else bad "صُوفةُ اللوحِ" "لا تزالُ للخطأِ وحدَهُ أو مُزدوجةَ القاعدةِ"; fi
if [ -f "$H37" ] && ! grep -q "shouldRebuildErrorRows" "$H37" && ! grep -q "LIGHT_REFRESH_LIMIT" "$H37"; then
  ok "والحارسُ المزدوجُ زالَ: لا طريقُ تحديثٍ ثانٍ يَطرُدُ ما تغيَّرَ محتوىهُ"
else bad "الحارسُ المزدوجُ" "باقٍ في الغلافِ"; fi
TRIM37=$(grep -n "while (diagnostics.size() > policy.listed)" "$H37" 2>/dev/null | head -1 | cut -d: -f1)
BUILD37=$(grep -n "errorRows.clear();" "$H37" 2>/dev/null | head -1 | cut -d: -f1)
if [ -n "$TRIM37" ] && [ -n "$BUILD37" ] && [ "$TRIM37" -lt "$BUILD37" ]; then
  ok "والقطعُ بالسقفِ يسبِقُ بناءَ الصُّوفةِ: لا سطرَ «لم يُعرَضْ» مع rowsَ ظاهرةٍ زيادةٍ"
else bad "قطعُ السقفِ" "بعدَ التجميعِ (عيبُ ‏1.0.177) أو بلا ترتيبٍ مَعلومٍ"; fi
if [ -f "$H37" ] && grep -q "lastPulseSignature, signature)" "$H37" \
&& grep -q "almlk.ErrorBrowserPolicy.countBySeverity(severityOfRows)" "$H37" \
&& grep -q "almlk.ErrorBrowserPolicy.warningsSegmentKey(warnings)" "$H37"; then
  ok "البصمةُ والعَدَّتانِ وقِطعةُ الرأسِ كلُّها قرارٌ من الطبقةِ الصافيةِ"
else bad "قرارُ اللوحِ" "حِسابٌ مُهرَّبٌ في الغلافِ"; fi
if [ -f "$G37" ] && grep -q "MAX_TOKEN_SPAN = 64" "$G37" && grep -q "public static boolean listsInPanel" "$G37" \
&& grep -q "public static int\[\] countBySeverity" "$G37" && ! grep -q "import android." "$G37"; then
  ok "الصافيُ يحملُ القواعدَ الثلاثَ بلا استيرادٍ من النظامِ: سقفُ الرمزِ، وقائمةُ العرضِ، وعَدُّ الرُّتبِ"
else bad "طبقةُ القواعدِ" "نقصَتْ أو تَلَوَّثَتْ"; fi
if [ -f "$J37" ] && grep -q "boolean showActions," "$J37" && grep -q "boolean tokenOnly" "$J37" \
&& grep -q "pendingMatchToken = tokenOnly;" "$J37" && grep -q "if (endColumn > 0 || tokenOnly) {" "$J37"; then
  ok "المُراوِجُ يَعرِفُ التضييقَ ولا يَسلُبُ الفقاعةَ، ويَحفظُهُ معَ القفزةِ المؤجَّلةِ"
else bad "تضييقُ الرمزِ" "لا في الحاضرِ ولا في المؤجَّلِ"; fi
if [ -f "$A37" ] && grep -q "almlk.ErrorBrowserPolicy.narrowsToToken(column, endColumn)" "$A37" \
&& [ "$(grep -c 'showActions, tokenOnly)' "$A37")" = "2" ]; then
  ok "والنشاطُ يَمُرِّرُ القرارَ في الطريقَينِ: تبويبٌ مفتوحٌ وملفٌّ يُحمَلُ كسلًا"
else bad "توصيلُ القفزةِ" "طريقٌ واحدٌ مُحدَّثٌ أو عَدٌّ غيرُ مُتَّفقٍ"; fi
# (3) السلاسلُ والحدودُ: مفتاحٌ واحدٌ لكلِّ لغةٍ، ولا شاشةَ ولا أصلَ ولا صلاحيّةً.
E37="$ZTMP37/app/src/main/res/values/strings.xml"; R37="$ZTMP37/app/src/main/res/values-ar/strings.xml"
if [ -f "$E37" ] && [ -f "$R37" ] && [ "$(grep -c 'name="ui_errors_warnings_count"' "$E37")" = "1" ] \
&& [ "$(grep -c 'name="ui_errors_warnings_count"' "$R37")" = "1" ]; then
  ok "سلسلةُ التحذيراتِ مُفرَدةٌ في اللغتَينِ: لا تكرارَ يَختارُ واحدًا بالصدفةِ"
else bad "سلسلةُ التحذيراتِ" "مكررةٌ أو ناقصةٌ في إحدى اللغتَينِ"; fi
if grep -q "%1\$d" "$E37" 2>/dev/null && grep -q "ui_errors_warnings_count\">%1\$d" "$R37" 2>/dev/null; then
  ok "والواصفُ مُتَّفقٌ في اللغتَينِ فلا رقمَ بلا صيغةٍ"
else bad "واصفُ السلسلةِ" "تبدَّلَ بينَ اللغتَينِ"; fi
if zq -qE "app/src/main/res/layout/.*(errors_pane|warnings_pane)"; then
  bad "حدودُ الواجهةِ" "شاشةٌ جديدةٌ للتحذيراتِ؛ والمطلوبُ اللوحةُ الشريطيةُ نفسُها"
else ok "لا شاشةَ: اللوحةُ القائمةُ هي مَوضِعُ العرضِ، ولا مُبِينَ حالةٍ زائدًا"; fi
if printf '%s\n' "$ALIST" | grep -c "\.jet$" | grep -qv "^0$"; then
  bad "الأصولُ" "وعاءُ ‏.jet ظهرَ في الحزمةِ"
else ok "ولا أصلَ مُضافًا: صِفرُ ‏.jet كما في شرطِ العملِ"; fi
if grep -q "countListedRows\|public static int countWarnings" "$H37" 2>/dev/null; then
  bad "عُدَّةٌ ميتةٌ" "واجهةٌ عَدّيةٌ لا يَستعمِلُها أحدٌ"
else ok "ولا واجهةَ عَدّيةً ميتةً: العَدُّ من صُوفةٍ واحدةٍ في الطبقةِ"; fi
if grep -q 'Color.parseColor("#FFA000")' "$H37" 2>/dev/null; then
  bad "تصميمُ العرضِ" "لونٌ مُقنَّنٌ للتحذيرِ يَكسِرُ الثيمَ الفاتحَ"
else ok "ولونٌ مُقنَّنٌ لا: التحذيرُ بأيقونةِ المشروعِ القائمةِ"; fi
# (4) العُدّةُ والتوثيقُ في الحزمةِ.
if grep -q "errorsPaneStage179();" "$ZTMP37/qa/RegressionSuite.java" 2>/dev/null; then
  ok "مرحلةُ البوابةِ مُسجَّلةٌ في الحزمةِ: مَن يُعِدِ البناءَ يَجِدْها"
else bad "بوّابةُ الانحدارِ" "المرحلةُ غيرُ مسجَّلةٍ"; fi
if ls "$ZTMP37"/reports/ 2>/dev/null | grep -q "1_0_179" && grep -q "^## 35)" "$ZTMP37/PROJECT_STATE.md" 2>/dev/null; then
  ok "ورقةُ المرحلةِ و§35 من سِجلِّ الحالةِ داخلَ الزِبِ"
else bad "توثيقُ المرحلةِ" "لا ورقةً ببصمتِها أو لا فصلَ في السجلِّ"; fi
rm -rf "$ZTMP37"


echo "[38] الجولةُ 28/4 (‏1.0.180‏) — ‏W27/3: كشفُ الدوالِّ المجرّدةِ وتلقينُها دفعةً واحدةً"
TMP38=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP38" 2>/dev/null
# (1) الحزمةُ الحيّةُ: القاعدةُ والإعلامُ مَطبوعانِ، والطبقاتُ السابقةُ لم تَسقُطْ.
if grep -lq "ui_diagnostic_must_implement_abstract_methods" "$TMP38"/classes*.dex 2>/dev/null; then
  ok "مفتاحُ التشخيصِ في الـdex: الكشفُ في المُحرِّكِ لا في سطرٍ مُختَرَعاتٍ بالمحرِّرِ"
else bad "مفتاحُ الكشفِ" "لم يُطبَعْ"; fi
if grep -lq "ui_quick_fix_implement_all_abstract" "$TMP38"/classes*.dex 2>/dev/null; then
  ok "ومفتاحُ الإصلاحِ مَطبوعٌ: «نفِّذ الدوالَّ المجرّدةَ كلَّها» صَفٌّ واحدٌ لا حِوارًا"
else bad "مفتاحُ الإصلاحِ" "لم يُطبَعْ"; fi
if grep -lq "Lalmlk/AbstractImplementationGap;" "$TMP38"/classes*.dex \
&& grep -lq "implementAbstractMethods" "$TMP38"/classes*.dex; then
  ok "الطبقةُ الصافيةُ صِنفٌ مَحمولٌ والمُولِّدُ في الإصلاحِ القائمِ: لا نسخةً ثانيةً ولا صنفًا في الغلافِ"
else bad "طبقةُ الكشفِ" "لم تَنزِلْ إلى الحزمةِ"; fi
if grep -lq "Lalmlk/AnalysisTargets;" "$TMP38"/classes*.dex \
&& grep -lq "Lalmlk/ErrorBrowserPolicy;" "$TMP38"/classes*.dex \
&& grep -lq "Lcom/almlkid/analyzer/AnalyzerCarrier;" "$TMP38"/classes*.dex; then
  ok "وطبقاتُ ‏1.0.177 و‏1.0.178 و‏1.0.179 باقياتٌ: المرحلةُ الجديدةُ لا تُسقِطُ سابِقَتَها"
else bad "الطبقاتُ السابقةُ" "زايلَها أحَدُها"; fi
rm -rf "$TMP38"
# (2) الشجرةُ المُغلَّفةُ: المِرقاةُ والمُجيبُ والكبتُ.
ZTMP38=$(mktemp -d); unzip -oq "$ZIP" -d "$ZTMP38" 2>/dev/null
G38="$ZTMP38/app/src/main/java/almlk/AbstractImplementationGap.java"
L38="$ZTMP38/app/src/main/java/almlk/PlatformMemberLookup.java"
N38="$ZTMP38/app/src/main/java/almlk/JavaCodeAnalyzer.java"
F38="$ZTMP38/app/src/main/java/almlk/QuickFix.java"
A38="$ZTMP38/app/src/main/java/com/shima/demo/MainActivity.java"
Q38="$ZTMP38/qa.sh"
if [ -f "$G38" ] && ! grep -q "import android." "$G38" \
&& grep -q "MAX_METHODS_PER_BATCH = 12" "$G38" && grep -q "public static final SupertypeFacts RUNTIME" "$G38"; then
  ok "الكشفُ صافٍ بمُجيبٍ واحدٍ: لا استيرادَ من النظامِ، وسقفٌ مُسمّى، وبوابةُ تشغيلٍ واحدةٌ"
else bad "طبقةُ الكشفِ" "تَلوَّثَتْ، أو لا مَصدرَ واحدًا لها"; fi
if grep -q "parent_unreadable" "$G38" && grep -q "over_batch_limit" "$G38" \
&& grep -q "types_unrenderable" "$G38"; then
  ok "حالاتُ الصَمتِ الثلاثُ مَسمّاةٌ: جَهْلُ الأصلِ، وتجاوُزُ الدَّفعَةِ، وعَجزُ الكتابةِ"
else bad "حالاتُ الصَمتِ" "إحداها مَخمومَةٌ"; fi
if grep -q "type.getDeclaredMethods()" "$L38" && grep -q "if (!isPlatformName(qualifiedName)) return null;" "$L38" \
&& grep -q "method.isBridge()" "$L38"; then
  ok "التوقيعاتُ من حِملِ الجهازِ الجاري: لا جَدوَلًا يدويًّا، ولا دالةً جِسريّةً تُطلَبُ من أحدٍ"
else bad "مَصدَرُ التوقيعاتِ" "انِعكَسَ أو جَدوَل"; fi
if printf '%s\n' "$ALIST" | grep -qE "android\.jar$|android[0-9.]*\.jar$" || printf '%s\n' "$ALIST" | grep -q "\.jet$"; then
  bad "الأصولُ" "جَرَّةُ إطارٍ أو وعاءُ ‏.jet دخَلا معَ المرحلةِ"
else ok "ولا جَرَّةَ إطارٍ أُضيفَت: صِفرُ ‏.jet — المعرفةُ من حِملِ الجهازِ لا من الحِزمَةِ"; fi
if grep -q "AbstractImplementationGap.inspect(" "$N38" \
&& [ "$(grep -n 'unit.errorRanges.isEmpty() && !hasSyntaxError(lexical)' "$N38" | head -1 | cut -d: -f1)" -lt "$(grep -n 'AbstractImplementationGap.inspect(' "$N38" | head -1 | cut -d: -f1)" ]; then
  ok "المِرقاةُ تَدعوها على الشجرةِ النظيفةِ وحدَها: لا تشخيصَ ناقصًا على شجرةٍ مُستَعادةٍ"
else bad "مَوضِعُ المِرقاةِ" "دعوةٌ قبلَ الحارسِ أو لا دَعوةَ"; fi
if grep -q "public List<QuickFix> companions" "$F38" && grep -q "public static QuickFix implementAbstractMethods" "$F38" \
&& ! grep -q '"    // TODO Auto-generated method stub"' "$F38"; then
  ok "الدَّفعَةُ حَقلٌ في المُعلِّبِ القائمِ، ولا نَسخةَ ثانيةً لسطرِ التعلُّمِ في ملفَّينِ"
else bad "دَفَعَةُ التلقينِ" "تَموضَعَت أو تَكرَّرَتِ العلامةُ"; fi
if grep -q "announcedGaps.get(gapFile)" "$A38" && grep -q "hasGapDiagnostic(found)" "$A38" \
&& [ "$(grep -n 'publishProjectDiagnostics();' "$A38" | head -1 | cut -d: -f1)" -lt "$(grep -n 'hasGapDiagnostic(found)' "$A38" | head -1 | cut -d: -f1)" ]; then
  ok "والنشاطُ يُعلِنُ بعدَ اللوحةِ وبِبَصمةٍ: لا رَجَّةَ «توستٍ» معَ كلِّ ضغطةِ مفتاحٍ"
else bad "إعلامُ الرَّدِّ" "بلا كبتٍ أو قبلَ اللوحةِ"; fi
if grep -q "almlk/AbstractImplementationGap.java" "$Q38"; then
  ok "البوابةُ تُترجِمُ الطبقةَ الجديدةَ: لا صِفرُ تَغطِيَةٍ لقاعدتِنا"
else bad "تَغمِيَةُ المضيفِ" "الملفُّ خارجَ قائمةِ ‏qa.sh"; fi
# (3) اللغاتُ: خمسةُ مفاتيحَ في اللغتَينِ، ولا نصَّ مُختَرَعاتٍ في الشيفرةِ.
for key in ui_diagnostic_must_implement_abstract_methods ui_toast_abstract_method_one \
           ui_toast_abstract_methods ui_quick_fix_implement_all_abstract ui_abstract_methods_created; do
  if grep -q "name=\"$key\"" "$ZTMP38/app/src/main/res/values/strings.xml" \
  && grep -q "name=\"$key\"" "$ZTMP38/app/src/main/res/values-ar/strings.xml"; then
    ok "مفتاحٌ في اللغتَينِ: $key"
  else bad "سلسلةُ $key" "ناقصةٌ من إحدى اللغتَينِ"; fi
done
# (4) الحدودُ والعدّةُ والتوثيقُ.
if zq -qE "app/src/main/res/layout/.*(abstract|implement)"; then
  bad "حدودُ الواجهةِ" "شاشةٌ جديدةٌ للدوالِّ المجرّدةِ؛ والمطلوبُ اللوحةُ وصفحةُ الإجراءاتِ"
else ok "لا شاشةَ ولا حِوارًا: اللوحةُ (‏1.0.179) وصفحةُ الإجراءاتِ هما المَوضِعانِ"; fi
if grep -q "الحقولُ العشرةُ" "$ZTMP38/app/src/main/java/com/almlkid/analyzer/AnalyzerWire.java" 2>/dev/null; then
  ok "وعَقدُ الجسرِ لم يَتزَحزَحْ: التشخيصُ يَركَبُ العَشرَةَ الحقولَ نفسَها (بصانةِ ‏1.0.178)"
else bad "عَقدُ الجسرِ" "حَقلٌ أُضيفَ إلى الحِملِ"; fi
if grep -q "LIGHT_REFRESH_LIMIT" "$ZTMP38/app/src/main/java/com/almlkid/ui/SequentialPanelHost.java" 2>/dev/null; then
  bad "لوحُ ‏1.0.179" "الحارسُ المزدوجُ رَجَعَ معَ المرحلةِ الجديدةِ"
else ok "ولوحُ الأخطاءِ على حارسِهِ الواحدِ كما سلَّمناهُ: لا انحدارَ في العَرضِ"; fi
if grep -q "errorsPaneStage179();" "$ZTMP38/qa/RegressionSuite.java" 2>/dev/null \
&& grep -q "abstractMethodsStage180();" "$ZTMP38/qa/RegressionSuite.java" 2>/dev/null; then
  ok "حَلقَتَا البوّابةِ مسجَّلتانِ في الشجرةِ المُغلَّفةِ"
else bad "عُدّةُ البوّابةِ" "حَلقَةٌ فُقدَت في التغليفِ"; fi
if ls "$ZTMP38"/reports/ 2>/dev/null | grep -q "1_0_180" && grep -q "^## 36)" "$ZTMP38/PROJECT_STATE.md" 2>/dev/null; then
  ok "ورقتا المرحلةِ (دراسةٌ وتنفيذٌ) و§36 داخلَ الزِبِ"
else bad "توثيقُ المرحلةِ" "لا ورقةً ببصمتِها أو لا فصلَ في السجلِّ"; fi
rm -rf "$ZTMP38"


echo "[39] الجولةُ 29/1 (‏1.0.181‏) — مرساةُ المرجعِ على «{» والأخوُ «insert 'abstract '»"
TMP39=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP39" 2>/dev/null
if grep -lq "ui_diagnostic_must_be_declared_abstract" "$TMP39"/classes*.dex 2>/dev/null; then
  ok "مفتاحُ الأخوِ مَطبوعٌ في الحزمةِ: لا تشخيصَ بلا نصٍّ في اللسانينِ"
else bad "مفتاحُ الأخوِ" "لم يُطبَعْ"; fi
if grep -lq "ui_quick_fix_implement_all_abstract" "$TMP39"/classes*.dex 2>/dev/null \
&& grep -lq "ui_quick_fix_insert_token" "$TMP39"/classes*.dex 2>/dev/null \
&& grep -aq "Implement all abstract methods" "$APK" 2>/dev/null; then
  ok "تسميتا الإصلاحِ على مفتاحيهِما، و«Implement all abstract methods» حرفيًا في مواردِ الحزمةِ"
else bad "تسمياتُ الإصلاحِ" "انحرفتْ عن نصِّ المرجعِ"; fi
if grep -lq "Lalmlk/AbstractImplementationGap;" "$TMP39"/classes*.dex \
&& grep -lq 'Lalmlk/AbstractImplementationGap$Declared;' "$TMP39"/classes*.dex; then
  ok "طبقةُ الأخوِ صِنفٌ محمولٌ في الطبقةِ الصافيةِ: لا غلافَ يَحفظُ قاعدتَهُ ثانيةً"
else bad "طبقةُ الأخوِ" "لم تَنزِلْ إلى الحزمةِ"; fi
if grep -lq "Lalmlk/AnalysisTargets;" "$TMP39"/classes*.dex \
&& grep -lq "Lalmlk/ErrorBrowserPolicy;" "$TMP39"/classes*.dex \
&& grep -lq "Lcom/almlkid/analyzer/AnalyzerCarrier;" "$TMP39"/classes*.dex; then
  ok "وطبقاتُ ‏1.0.177 و‏1.0.178 و‏1.0.179 و‏1.0.180 باقياتٌ: لا مسارَ يُبدَّلُ بمسارٍ آخرَ"
else bad "الطبقاتُ السابقةُ" "زايلَها أحَدُها"; fi
rm -rf "$TMP39"
ZTMP39=$(mktemp -d)
unzip -oq "$ZIP" -d "$ZTMP39" 2>/dev/null || { sleep 2; unzip -oq "$ZIP" -d "$ZTMP39" 2>/dev/null || true; }
if [ ! -s "$ZTMP39/PROJECT_STATE.md" ]; then
  bad "فكُّ الحزمةِ" "لم تُفَكَّ ‏$ZIP‏ إلى المُؤقَتِ (فَضاءُ /tmp؟) — فلا حُكمَ على وثائقِها ولا كَذِبَ عليها"
fi
G39="$ZTMP39/app/src/main/java/almlk/AbstractImplementationGap.java"
C39="$ZTMP39/app/src/main/java/almlk/JavaDiagnosticCodes.java"
S39E="$ZTMP39/app/src/main/res/values/strings.xml"
S39A="$ZTMP39/app/src/main/res/values-ar/strings.xml"
if [ -f "$G39" ] && ! grep -q "import android." "$G39" \
&& grep -q "public final int braceStart;" "$G39" && grep -q "int start = gap.anchorStart(source);" "$G39" \
&& grep -q "public static List<Declared> declaredAbstract" "$G39"; then
  ok "المرساةُ قوسُ الإعلانِ في المصدرِ، والأخوُ في الطبقةِ الصافيةِ نفسها، وصفرُ استيرادٍ من النظامِ"
else bad "طبقةُ المرساةِ" "لم تُستبدَلْ في الشجرةِ المُغلَّفةِ"; fi
if grep -q "key.startsWith(\"must_be_\")" "$C39"; then
  ok "عائلةُ مفتاحِ الأخوِ مَشتَقَّةٌ: DECLARATION_STATE بلا جَدوَلِ أرقامٍ"
else bad "عائلةُ الأخوِ" "ساقطةٌ في «بلاجَدوَلَ»"; fi
if grep -q 'name="ui_quick_fix_insert_token">insert' "$S39E" \
&& grep -q 'name="ui_diagnostic_must_be_declared_abstract"' "$S39E" \
&& grep -q 'name="ui_diagnostic_must_be_declared_abstract"' "$S39A"; then
  ok "نصُّ الإلصاقِ صغيرُ الحرفِ كما يبنيهِ المرجعُ، ومفتاحُ الأخوِ في اللغتَينِ"
else bad "سلاسلُ المرحلةِ" "تبدَّلتْ أو نَقَصَها لسانٌ"; fi
if grep -q "braceAnchorStage181();" "$ZTMP39/qa/RegressionSuite.java" 2>/dev/null \
&& grep -q "abstractMethodsStage180();" "$ZTMP39/qa/RegressionSuite.java" 2>/dev/null; then
  ok "حَلقَتَا البوابةِ مسجَّلتانِ في الشجرةِ المُغلَّفةِ: لا مرحلةً تُبطِلُ سابِقتَها"
else bad "عُدَّةُ البوابةِ" "حَلقَةٌ فُقدَت في التغليفِ"; fi
if [ -s "$ZTMP39/PROJECT_STATE.md" ]; then
if ls "$ZTMP39"/reports/ 2>/dev/null | grep -q "w29_source_resync_study" \
&& grep -q "^## 38)" "$ZTMP39/PROJECT_STATE.md"; then
  ok "ورقةُ الدراسةِ و§38 داخلَ الحزمةِ: العَهدُ مكتوبٌ قبلَ الكودِ"
else bad "توثيقُ الجولةِ" "لا ورقةَ ملحقٍ أو لا فصلَ في السجلِّ"; fi
fi
rm -rf "$ZTMP39"

echo
echo "[40] الجولةُ 30 (‏1.0.182‏) — تلوينٌ كاملٌ لا يُلغَى، وتلميحٌ أصفرُ لا يَلِجُ اللوحةَ"
TMP40=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP40" 2>/dev/null
if grep -lq "Lalmlk/LineOffsetTable;" "$TMP40"/classes*.dex 2>/dev/null \
&& grep -lq "Lalmlk/DiagnosticUnderline;" "$TMP40"/classes*.dex 2>/dev/null; then
  ok "جدولُ الإزاحاتِ ووسمُ التسطيرِ صنفانِ محمولانِ: لا قفزةً بنصٍّ منسوخٍ ولا أسَرٌ مَطويَّةٌ"
else bad "طبقةُ الإزاحاتِ" "لم تَنزِلْ إلى الحزمةِ"; fi
if grep -lq "requestMissing" "$TMP40"/classes*.dex 2>/dev/null \
&& ! grep -lq "stylesExcludingErrorSpans" "$TMP40"/classes*.dex 2>/dev/null \
&& grep -lq "swapAndPost" "$TMP40"/classes*.dex 2>/dev/null; then
  ok "الملوِّنُ المُعلَّقُ لا المقتولُ، والنشرُ بالدفعةِ، ومَحوُ اللونِ تحتَ الخطإِ زالَ من الحزمةِ (استُبدِلَ في ‏1.0.185)"
else bad "طبقةُ التلوينِ" "بقيَ إلغاؤها أو نشرُها سطرًا سطرًا"; fi
if grep -lq "isEditorOnlyHint" "$TMP40"/classes*.dex 2>/dev/null \
&& grep -lq "severityFor" "$TMP40"/classes*.dex 2>/dev/null; then
  ok "مَصبُّ الرُّتبةِ الواحدُ محمولٌ: لا استثناءَ مفاتيحَ في مستهلِكِ اللوحةِ"
else bad "مَصبُّ الرُّتبةِ" "لم يُبنَ في الطبقةِ الصافيةِ"; fi
if grep -aq "could not be loaded!" "$APK" 2>/dev/null; then
  ok "عبارةُ الفشلِ بصوتِ المرجعِ في مواردِ الحزمةِ"
else bad "عبارةُ الفشلِ" "لم تُطبَعْ في الحزمةِ"; fi
rm -rf "$TMP40"
ZTMP40=$(mktemp -d); unzip -oq "$ZIP" -d "$ZTMP40" 2>/dev/null
L40S="$ZTMP40/app/src/main/java/almlk/LineStyler.java"
L40T="$ZTMP40/app/src/main/java/almlk/LineOffsetTable.java"
L40M="$ZTMP40/app/src/main/java/almlk/MarkTable.java"
L40E="$ZTMP40/app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java"
L40P="$ZTMP40/app/src/main/java/com/almlkid/ui/AIDEEditorPager.java"
L40B="$ZTMP40/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
L40X="$ZTMP40/app/src/main/java/com/shima/demo/MainActivity.java"
S40E="$ZTMP40/app/src/main/res/values/strings.xml"
S40A="$ZTMP40/app/src/main/res/values-ar/strings.xml"
if [ -f "$L40T" ] && ! grep -q "import android." "$L40T" \
&& grep -q "public int lineFor(int offset)" "$L40T" && grep -q "public boolean isFreshFor(long" "$L40T"; then
  ok "جدولُ الإزاحاتِ صِرفٌ لا يستوردُ من النظامِ، وفهرسُهُ ثنائيٌّ بسِجلِّ إصدارٍ"
else bad "جدولُ الإزاحاتِ" "مُلوَّثٌ بـ‏android أو بلا سِجلٍّ"; fi
if grep -q "public void requestMissing()" "$L40S" && grep -q "private void swapAndPost(" "$L40S" \
&& grep -q "SWAP_BATCH_LINES" "$L40S" && ! grep -q "target.set(line, fresh);" "$L40S" \
&& ! grep -q "private final ExecutorService worker" "$L40S"; then
  ok "الملوِّنُ في الشجرةِ المُغلَّفةِ: دفعةٌ واحدةٌ، وخيطٌ يُنبَتُ عندَ الحاجةِ، ولا هدمَ للجدولِ"
else bad "ملوِّنُ الحزمةِ" "نشرٌ مُجزَّأٌ أو خيطٌ مقتولٌ"; fi
if grep -q "ROLE_HINT = 19" "$L40M" && grep -q "ROLE_COUNT = 20" "$L40M" \
&& grep -q "public static int severityOf(int role)" "$L40M"; then
  ok "الأسرةُ الثالثةُ في جدولِ العلاماتِ: ‏19 تلميحٌ، والعقدُ ‏20 بلا كسرٍ"
else bad "أسرةُ التلميحِ" "لم تَغِبْ عن الحزمةِ المصدريةِ"; fi
if grep -q "styler.suspend();" "$L40E" && grep -q "styler.resume();" "$L40E" \
&& ! grep -q "styler.shutdown();" "$L40E" \
&& grep -q "return styler.stylesForLine(line);" "$L40E" \n&& ! grep -q "stylesExcludingErrorSpans" "$L40E" \
&& grep -q "setHintFlagColor(light ? 0xFFF9A825 : 0xFFFFEE58);" "$L40E"; then
  ok "المحرِّرُ يُعلِّقُ ولا يقتُلُ، واللونُ للملوِّنِ وحدَهُ، والتلميحُ لهُ لونَهُ الخاصَّ"
else bad "محرِّرُ الحزمةِ" "قتلُ الملوِّنِ أو إلغاءٌ أوسَعُ من الخطإِ"; fi
if grep -q "almlk.LineOffsetTable offsets = code.jumpOffsets();" "$L40P" \
&& grep -q "code.postDelayed(reveal, 10L);" "$L40P" \
&& ! grep -q "postDelayed(reveal, 140" "$L40P" && ! grep -q "postDelayed(reveal, 300" "$L40P"; then
  ok "القفزةُ بالجدولِ ودورةُ رسمٍ واحدةٌ: لا إطارَ ثالثَ ولا نَسخَ للمستندِ"
else bad "قفزةُ الحزمةِ" "ثلاثُ أطُرٍ أو مَسحُ نصٍّ باقٍ"; fi
if grep -q "readEntryTextOrNull(Entry entry)" "$L40B" \
&& grep -q "String text = readEntryTextOrNull(target);" "$L40B" \
&& grep -q "private String readEntryText(Entry entry)" "$L40B" \
&& grep -q "toastNotLoaded(tabName);" "$L40P" && grep -q "notLoadedText(usage.reference" "$L40X" \
&& grep -q "notLoadedText(reference, fileName)," "$L40X"; then
  ok "تعذُّرُ القراءةِ فشلٌ صريحٌ في الشجرةِ: توستٌ بلا إغلاقِ لوحةٍ وبلا حقنِ فراغٍ"
else bad "مسارُ الفشلِ" "الفراغُ يُزيَّنُ نجاحًا أو التوستُ ناقصٌ"; fi
if grep -q 'name="ui_error_file_not_loaded">%1$s could not be loaded!</string>' "$S40E" \
&& grep -q 'name="ui_error_file_not_loaded">' "$S40A" \
&& [ "$(grep -c 'ui_error_file_not_loaded' "$S40A")" -eq 1 ]; then
  ok "السلسلةُ في اللغتَينِ بوسيطٍ واحدٍ، وحرفيَّةُ الإنكليزيَّةِ كما نَطَقَ المرجعُ"
else bad "سلسلةُ الفشلِ" "ناقصةُ اللسانِ أو مُبتَكَرةُ العبارةِ"; fi
if grep -q "stylingAndHintsStage182();" "$ZTMP40/qa/RegressionSuite.java" 2>/dev/null \
&& grep -q "braceAnchorStage181();" "$ZTMP40/qa/RegressionSuite.java" 2>/dev/null \
&& grep -q "almlk/LineOffsetTable.java" "$ZTMP40/qa.sh" 2>/dev/null \
&& grep -q "almlk/DiagnosticUnderline.java" "$ZTMP40/qa.sh" 2>/dev/null; then
  ok "عُدَّةُ الجولةِ في الحزمةِ: حلقةٌ مُسجَّلةٌ بعدَ سابِقتِها، وصنفانِ في قائمةِ الصافيِ"
else bad "عُدَّةُ البوابةِ" "حَلقَةٌ أو صنفٌ فارِقٌ في التغليفِ"; fi
if ls "$ZTMP40"/reports/ 2>/dev/null | grep -q "w30_styling_completeness_and_hint_severity" \
&& grep -q "^## 43)" "$ZTMP40/PROJECT_STATE.md" 2>/dev/null; then
  ok "ورقةُ الجولةِ و§43 داخلَ الحزمةِ: القرارُ مكتوبٌ قبلَ الكودِ وبعدهُ"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ في السجلِّ"; fi
rm -rf "$ZTMP40"

echo "[41] الجولةُ 31 (‏1.0.183‏) — بصمةُ اكتمالِ الفهرسِ، ونِفيُ الثابتِ على انغلاقِ السلسلةِ، والمَدَى في القفزةِ"
TMP41=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP41" 2>/dev/null
if grep -lq "hierarchyCertain" "$TMP41"/classes*.dex 2>/dev/null \
&& grep -lq "memberAbsenceCertain" "$TMP41"/classes*.dex 2>/dev/null; then
  ok "قرينةُ الانغلاقِ وحارسُها محمولانِ في ‏dex: لا حُكمَ على ثابتٍ والسلسلةُ منفتحةٌ"
else bad "حارسُ الثابتِ" "لم يَنزِلْ إلى الحزمةِ"; fi
if grep -lq "certain" "$TMP41"/classes*.dex 2>/dev/null \
&& grep -lq "incomplete" "$TMP41"/classes*.dex 2>/dev/null; then
  ok "شارةُ الاكتمالِ مُسمّاةُ السببِ في الطبقةِ المحمولةِ: ‏certain و‏incomplete"
else bad "شارةُ الاكتمالِ" "بقيَت في الشجرةِ دونَ الحزمةِ"; fi
if grep -lq "endColumn" "$TMP41"/classes*.dex 2>/dev/null; then
  ok "مدى الاستعمالِ محمولٌ: ‏endColumn في الحزمةِ لا في النصِّ المرجعيِّ وحدَهُ"
else bad "مدى الاستعمالِ" "سقطَ قبلَ ‏dex"; fi
rm -rf "$TMP41"
ZTMP41=$(mktemp -d); unzip -oq "$ZIP" -d "$ZTMP41" 2>/dev/null
L41I="$ZTMP41/app/src/main/java/almlk/LibraryClassIndex.java"
L41A="$ZTMP41/app/src/main/java/almlk/JavaAttributor.java"
L41T="$ZTMP41/app/src/main/java/almlk/JavaTypeModel.java"
L41U="$ZTMP41/app/src/main/java/com/almlkid/kay/ui/UsageSearchEngine.java"
L41P="$ZTMP41/app/src/main/java/com/almlkid/ui/AIDEEditorPager.java"
L41X="$ZTMP41/app/src/main/java/com/shima/demo/MainActivity.java"
L41S="$ZTMP41/app/src/main/java/com/almlkid/kay/ui/ProjectSearchEngine.java"
if grep -q "set.incomplete(\"نوعُ مواردَ لا يُقرَأُ: \"" "$L41I" \
&& grep -q "if (res.isDirectory()) set.incomplete(" "$L41I" \
&& grep -q "if (!sawRoot || !stack.isEmpty())" "$L41I" \
&& grep -q "private static String readResText(File file, ResourceSet set)" "$L41I"; then
  ok "الحزمةُ المُغلَّفةُ تُثبِتُ نُقصانَها بأسماءِ أسبابِهِ: مجلدٌ، ملفٌّ، نوعٌ، بِنْيَةٌ"
else bad "بصمةُ الاكتمالِ" "صمتٌ عائِدٌ أو سببٌ بلا اسمٍ"; fi
if grep -q "!sets.get(i).certain()" "$L41I" && grep -q "rClassBlock(appPackage, fields, !certain)" "$L41I" \
&& ! grep -q "fields, true)" "$L41I" \
&& grep -qF '.R\tc\t1\t0\t0\tjava.lang.Object\t\t\tv' "$L41I"; then
  ok "‏R: الأنواعُ المَقرُوءةُ مُثبَتةٌ، والحاوي مؤقَّتٌ دائمًا، ولا صمتٌ يدويٌّ مُثبَتٌ باقٍ"
else bad "سياسةُ ‏R" "إمّا صمتٌ عامٌّ أو ادعاءٌ على الحاوي"; fi
if grep -q "if (allCaps && !memberAbsenceCertain(s)) return JavaTypeModel.UNKNOWN;" "$L41A" \
&& grep -q "public static boolean hierarchyCertain(ClassSymbol c)" "$L41T" \
&& [ "$(grep -c "if (x.isError() || !x.supertypesResolved()) return false;" "$L41T")" -eq 1 ]; then
  ok "الحارسُ في موضِعِهِ الضيِّقِ: عندَ الثابتِ كلِّهِ كبيرةً، وبلا تَوسيعٍ على ‏hierarchyComplete"
else bad "حارسُ الثابتِ" "اتَّسَعَ على مسارِ الأنواعِ والطرقِ"; fi
if grep -q "public final int endColumn;" "$L41U" && grep -q "end - lineStart + 1," "$L41U" \
&& grep -q "goToMatch(String name, int line, int column, int endColumn)" "$L41P" \
&& ! grep -q "goToMatch(String name, int line, int column)" "$L41P" \
&& grep -q "usage.column, usage.endColumn)" "$L41X" \
&& grep -q "Math.min(end, startLineEnd)" "$L41S"; then
  ok "المَدَى استُبدِلَ لا وازَنَ: مُنتِجٌ واحدٌ، وقفزةٌ رباعيَّةٌ، وصفُّ البحثِ محصورٌ في سطرِهِ"
else bad "قفزةُ المَدَى" "بقيَ ‏-1 أو مَسارَانِ"; fi
if grep -q "indexCertaintyAndRangeStage183();" "$ZTMP41/qa/RegressionSuite.java" 2>/dev/null \
&& grep -q "stylingAndHintsStage182();" "$ZTMP41/qa/RegressionSuite.java" 2>/dev/null; then
  ok "حَلقَةُ هذهِ الجولةِ في الحزمةِ بعدَ سابِقتِها: لا مرحلةً تَمحو ما قبلَها"
else bad "عُدَّةُ البوابةِ" "حَلقَةٌ ناقصةٌ في التغليفِ"; fi
if grep -q "ui_diagnostic_unknown_field" "$ZTMP41/app/src/main/res/values/strings.xml" \
&& ! grep -q "ui_diagnostic_resource_not_found" "$ZTMP41/app/src/main/res/values/strings.xml"; then
  ok "بلسانِ المرجعِ القائمِ: بلا سلسلةٍ مُبتَكَرةٍ لحُكمِ ‏R ولا مفتاحٍ يَهرُبُ من الترجمةِ"
else bad "سلسلةُ الحُكمِ" "مفتاحٌ مُبتَكَرٌ بلا ضرورةٍ"; fi
if ls "$ZTMP41"/reports/ 2>/dev/null | grep -q "w31_index_certainty_field_phantom_and_usage_range" \
&& grep -q "^## 45)" "$ZTMP41/PROJECT_STATE.md" 2>/dev/null; then
  ok "ورقةُ الجولةِ و§45 داخلَ الحزمةِ: الدارسةُ قبلَ الكودِ والسجلُّ بعدَهُ"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ في الحزمةِ"; fi
rm -rf "$ZTMP41"

echo "══════════════════════════════════════════════════════"
echo "[42] الجولةُ 32 (‏1.0.184‏) — سلامةُ المكتباتِ: رفضٌ مَسموٌّ، ولا صنفَ نصفَ مَقرُوءٍ"
TMP42=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP42" 2>/dev/null
if grep -lq "stampProblem" "$TMP42"/classes*.dex 2>/dev/null \
&& grep -lq "component declared by the stamp is gone from the node" "$TMP42"/classes*.dex 2>/dev/null \
&& grep -lq "stale stamp: the archive changed" "$TMP42"/classes*.dex 2>/dev/null; then
  ok "علالَةُ العقدةِ تُسمَّى في الحزمةِ: لا علامةَ، وبصمةٌ تبدَّلَت، ومُكوِّنٌ بُتِرَ — ثلاثَتُها منطوقةٌ"
else bad "سببُ الرَفضِ" "بقيَ «no usable node» يُسطِّحُ العلَلَ"; fi
if grep -lq "entries cannot be read to their end" "$TMP42"/classes*.dex 2>/dev/null \
&& grep -lq "R.txt is not a complete record list" "$TMP42"/classes*.dex 2>/dev/null; then
  ok "لا قائمةُ مُبتورةَ تُنشَرُ: أرشيفُ الأصنافِ وقائمةُ المواردِ يُرفَضُ الناقصُ منهُما باسمِهِ وعدِّهِ"
else bad "رَفضُ الناقصِ" "نِصفُ الصنفِ عادَ يُقرَأُ وحدَهُ"; fi
rm -rf "$TMP42"
ZIP42=$(mktemp -d)
unzip -oq "$ZIP" -d "$ZIP42" 2>/dev/null
L42I="$ZIP42/app/src/main/java/almlk/LibraryClassIndex.java"
L42E="$ZIP42/app/src/main/java/almlk/AarExploder.java"
L42L="$ZIP42/app/src/main/java/almlk/LocalLibraries.java"
L42P="$ZIP42/app/src/main/java/almlk/ProjectLibraries.java"
L42D="$ZIP42/app/src/main/java/com/almlkid/ui/MavenDownloadDialog.java"
if [ -f "$L42I" ] && [ -f "$L42E" ] && [ -f "$L42L" ] && [ -f "$L42P" ] && [ -f "$L42D" ]; then
  ok "حزمةُ المُصدَرِ تَحمِلُ الطبقاتِ الخمسَ التي تَلَمَّسَتها هذهِ الجولةُ"
else bad "حزمةُ المُصدَرِ" "طبقةٌ من سلامةِ المكتباتِ خارجَ الحزمةِ"; fi
if grep -qF 'catch (IOException ignored)' "$L42I"; then
  bad "الصمتُ القديمُ" "«تُتخطّى أصنافه فقط» باقٍ في فهرسِ المكتباتِ"
elif ! grep -q 'if (refused > 0) {' "$L42I" || ! grep -q 'problems.add(nameOf(dir)' "$L42I"; then
  bad "رَفضُ الطبقةِ" "لا عدَّ للمَرفوضِ ولا اسمَ معَهُ"
else
  ok "الحلقةُ بلا صَمتٍ: كلُّ أرشيفٍ مَرفوضٍ يَترُكُ سطرَهُ في قائمةِ العِلَلِ"
fi
if grep -qF 'absent(node, "no usable node")' "$L42E"; then
  bad "سببُ العلامةِ" "العِلَلُ الأربعُ ما تزالُ سطرًا واحدًا"
elif grep -q 'public static String stampProblem(File node, String signature)' "$L42E" \
&& grep -q 'private static Stamp parseStamp(File node, String signature) throws StampProblem' "$L42E"; then
  ok "قارئٌ واحدٌ للحُكمِ والسببِ: parseStamp تَرمِي سببَها، وreadStamp/stampProblem منها"
else bad "قارئُ العلامةِ" "السببُ والحُكمُ انفصلا"; fi
if grep -q 'integrity.add(entry.file.getName()' "$L42L" \
&& [ "$(grep -c 'integrity.add(entry.file.getName()' "$L42L")" -eq 2 ] \
&& grep -q 'finding.isEmpty() && finding.integrity.isEmpty()' "$L42L"; then
  ok "مَجلِسُ الرصدِ يَذكُرُ المَرفوضَ في libs/ ومَجلِسُ المخرَجِ مِثلَهُ، ولا صَمتَ على صفرٍ"
else bad "عِلَلُ libs/" "العدَّادُ وحدَهُ ما يزالُ خبرَ المَيِّتةِ"; fi
if grep -q 'localIntegrityMarkers(text, locals.integrity)' "$L42P" \
&& grep -q 'return complete && locals.isClean();' "$L42P" \
&& grep -q 'KEY_INCOMPLETE' "$L42P"; then
  ok "الخبرُ يَمُرُّ بالمِصفاةِ الواحدةِ: علامةٌ في اللوحةِ والمحرِّرِ بمفتاحٍ قائمٍ، ويُبطِلُ «كلُّ شيءٍ تامٌّ»"
else bad "قناةُ اللوحةِ" "مَرفوضُ libs/ لم يَبلُغِ التشخيصَ أو ابتَكَرَ مِصباحًا ثانِيًا"; fi
if grep -q 'refusedSet.addAll(almlk.LibraryClassIndex.problems());' "$L42D" \
&& grep -q '"ui_maven_incomplete_install"' "$L42D"; then
  ok "الرسالةُ تُسمِّي: أسماءُ المَرفوضِ بدلَ العددِ، بقوامِ «ليسَ أرشيفًا مُستعمَلًا» نفسِهِ"
else bad "رسالةُ التنزيلِ" "عددٌ بلا أسماءَ"; fi
if grep -q 'return snapshot.request != null && snapshot.request.complete && snapshot.libraryCertain;' "$L42I" \
&& grep -q 'certain = certain && snapshot.libraryCertain;' "$L42I" \
&& grep -q '!snapshot.request.complete || !snapshot.libraryCertain' "$L42I"; then
  ok "الإثباتُ مِقبضٌ واحدٌ: يقينُ الطبقةِ يَسقُطُ معَ أولِ رَفضٍ، و‏R التطبيقِ تابِعٌ لَهُ تحتَ transitiveR"
else bad "مِقبضُ اليقينِ" "استثناءُ مفاتيحَ أو بابٌ ثانٍ"; fi
if grep -q 'libraryIntegrityStage184();' "$ZIP42/qa/RegressionSuite.java" 2>/dev/null \
&& grep -q 'indexCertaintyAndRangeStage183();' "$ZIP42/qa/RegressionSuite.java" 2>/dev/null; then
  ok "بوابةُ هذهِ الجولةِ في الحزمةِ بعدَ سابِقتِها: استبدالٌ لا مَحوٌ"
else bad "عُدَّةُ البوابةِ" "حَلقَةٌ ناقصةٌ في التغليفِ"; fi
if ls "$ZIP42"/reports/ 2>/dev/null | grep -q "w32_library_integrity_visible_refusal" \
&& grep -q "^## 47)" "$ZIP42/PROJECT_STATE.md" 2>/dev/null; then
  ok "ورقةُ الجولةِ و§47 داخلَ الحزمةِ: الدارسةُ قبلَ الكودِ والسجلُّ بعدَهُ"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ في الحزمةِ"; fi
rm -rf "$ZIP42"

echo "[43] الجولةُ 33 (‏1.0.185‏) — وسمٌ بهُويّةٍ، ولونٌ لا يَمسُّهُ فحصٌ، ويقينٌ بنبضةٍ"
TMP43=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP43" 2>/dev/null
if grep -lq "Lalmlk/MarkBinding;" "$TMP43"/classes*.dex 2>/dev/null \
&& grep -lq "notePassProgress" "$TMP43"/classes*.dex 2>/dev/null \
&& grep -lq "isPassAbandoned" "$TMP43"/classes*.dex 2>/dev/null; then
  ok "المَصدِّقُ الخالصُ واليقينُ بالنبضةِ نزَلا إلى الحزمةِ: لا قاعدةٌ تَبقَى في الشجرةِ وحدَها"
else bad "طبقةُ الهُويّةِ واليقينِ" "لم تَنزِلْ إلى ‏dex" ; fi
if ! grep -lq "stylesExcludingErrorSpans" "$TMP43"/classes*.dex 2>/dev/null; then
  ok "لا مَحوَ ألوانٍ في الحزمةِ: التسطيرُ مَدارُ الفحصِ كلُّهُ"
else bad "تلوينُ المحرِّرِ" "دالَّةُ المَحوِ باقِيَةٌ في ‏dex" ; fi
rm -rf "$TMP43"
ZIP43=$(mktemp -d)
unzip -oq "$ZIP" -d "$ZIP43" 2>/dev/null
A33P="$ZIP43/app/src/main/java/com/almlkid/ui/AIDEEditorPager.java"
A33E="$ZIP43/app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java"
A33M="$ZIP43/app/src/main/java/almlk/JavaProjectModel.java"
A33B="$ZIP43/app/src/main/java/almlk/MarkBinding.java"
A33A="$ZIP43/app/src/main/java/almlk/JavaAttributor.java"
A33W="$ZIP43/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
if [ -f "$A33B" ] && grep -q "public static boolean binds(String tabReference, String itemReference)" "$A33B" \
&& grep -q "public static boolean isStale(String preview, String currentLine)" "$A33B"; then
  ok "قاعدتا الهُويّةِ والبُطلانِ صنفُ منطقٍ خالصٌ واحدٌ، لا بِلادةٌ في المُنفِّذِينَ"
else bad "مَصدِّقُ الوسومِ" "لم يُحمَلْ في الحزمةِ المصدريةِ" ; fi
if grep -q "almlk.MarkBinding.binds(reference, item.reference)" "$A33P" \
&& ! grep -q "shortName.equals(item.fileName)" "$A33P" \
&& ! grep -q "activeFile.equals(item.fileName)" "$A33P" \
&& grep -q "resolvedActiveFileReference()" "$A33P"; then
  ok "لا اسمَ مجرَّدًا يَحمِلُ وسمًا: وسومُ نسخةٍ أخرى من المشروعِ انقطَعتْ بمَقطَعِها"
else bad "نِسبةُ الوسومِ" "مَدارُ الاسمِ المجرَّدِ باقٍ" ; fi
if grep -q "almlk.MarkBinding.isStale(item.preview, lineTextAt(item.diagnostic.line - 1))" "$A33E" \
&& grep -q "return styler.stylesForLine(line);" "$A33E" \
&& ! grep -q "stylesExcludingErrorSpans" "$A33E"; then
  ok "الوسمُ المشروعِيُّ يُراجِعُ سطرَهُ قبلَ الرَسمِ، والأنماطُ لا تُلمَسُ من طبقةِ الفحصِ"
else bad "رَسمُ الوسومِ" "وهمٌ جامدٌ بعدَ تحريرٍ أو مَحوُ لونٍ" ; fi
if grep -q "passBeatAt = passNow();" "$A33M" \
&& grep -q "public static boolean isPassAbandoned(long nowMs)" "$A33M" \
&& grep -q "if ((visited & 31) == 0) almlk.JavaProjectModel.notePassProgress();" "$A33W"; then
  ok "المسحُ الحيُّ يَنبِضُ فيُغلِقُ بابَ الجزْمِ، والمُجهَضُ وحدَهُ يُفتَحُ بعدَ المِقدارِ"
else bad "يقينُ المسحِ" "عُمرُ البدءِ عادَ يحكُمُ، أو النبضُ لم يُوصَلْ بالماسحِ" ; fi
if grep -q "if (projectPackage && !JavaProjectModel.absenceProvablyComplete()) continue;" "$A33A" \
&& grep -q "if (isOwnPackagePrefix(unknown)) continue;" "$A33A"; then
  ok "استيرادٌ من حزمةِ المشروعِ لا يُحكَمُ عليهِ والنموذجُ نصفُ مَبنيٍّ، وحزمةُ الملفِّ لا تُبلى بجهلٍ"
else bad "جزْمُ الاستيرادِ" "سَبَقَ اكتمالَ النموذجِ أو نُسخَ الحارسُ" ; fi
if grep -q 'almlk/MarkBinding.java' "$ZIP43/qa.sh" 2>/dev/null \
&& grep -q 'markAttributionStage185();' "$ZIP43/qa/RegressionSuite.java" 2>/dev/null; then
  ok "الصنفُ الخالصُ في qa.sh والحَلقَةُ مُوصَلةٌ بعدَ ‏1.0.184: بوابَةٌ لا هامِشٌ"
else bad "عُدَّةُ البوابةِ" "حَلقَةٌ ناقصةٌ في التغليفِ" ; fi
if grep -q "$VERSION" "$ZIP43/VERSION" 2>/dev/null \
&& ls "$ZIP43"/reports/ 2>/dev/null | grep -q "w33_mark_precision_and_color_fidelity_study" \
&& grep -q "^## 50)" "$ZIP43/PROJECT_STATE.md" 2>/dev/null; then
  ok "البصمةُ والورقةُ و§50 داخلَ الحزمةِ: الدارسةُ قبلَ الكودِ والسجلُّ قبلَ التغليفِ"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ أو بصمةٌ غيرُ $VERSION" ; fi
rm -rf "$ZIP43"


echo
echo "[44] الجولةُ 34 (‏1.0.186‏) — كفايةُ الأصلِ تُطرَحُ من الحُكمِ، والاقتراحُ في الجِسمِ إعلانٌ"
TMP44=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP44" 2>/dev/null
for sym in concreteMethodKeys implementedKeys declarationHead stubBody addOverrideStubs overrides; do
  if grep -lq "$sym" "$TMP44"/classes*.dex 2>/dev/null; then ok "رمزُ التغطيةِ «$sym» في الدكسِ"
  else bad "رمزُ التغطيةِ $sym" "غائبٌ عن الحزمةِ"; fi
done
if grep -lq "@/Override\|@" "$TMP44"/classes*.dex 2>/dev/null \
&& grep -laF "@Override" "$TMP44"/classes*.dex >/dev/null 2>&1; then
  ok "قالبُ الإعلانِ المُولَّدِ (‏@Override) مَكتوبٌ في الحزمةِ، لا في الشجرةِ وحدَها"
else bad "قالبُ الإعلانِ" "لا @Override في الدكسِ"; fi
rm -rf "$TMP44"
ZIP44=$(mktemp -d); unzip -oq "$ZIP" -d "$ZIP44" 2>/dev/null
A44="$ZIP44/app/src/main/java/almlk"
U44="$ZIP44/app/src/main/java/com/almlkid/kay/ui"
if grep -qF "if (provided.contains(r.key())) continue;" "$A44/AbstractImplementationGap.java" \
&& grep -qF "default Set<String> implementedKeys(String qualifiedName)" "$A44/AbstractImplementationGap.java" \
&& grep -qF "if (done == null) return null;" "$A44/AbstractImplementationGap.java"; then
  ok "الحُكمُ في المصبِّ: كفايةُ الأصلِ مَطرُوحةٌ، والجهلُ بها صمتٌ — لا حُكمٌ على مجهولٍ"
else bad "كفايةُ الأصلِ" "الحُكمُ لم يَنقُلْها إلى المصبِّ"; fi
if grep -qF "public static Set<String> concreteMethodKeys(String qualifiedName)" "$A44/PlatformMemberLookup.java" \
&& grep -qF "IMPLEMENTED.clear();" "$A44/PlatformMemberLookup.java"; then
  ok "المنصّةُ تُجيبُ عن كفايتِها بانِعكاسٍ واحدٍ، وصندوقُها يُفرَّغُ معَ المجرَّداتِ"
else bad "كفايةُ المنصّةِ" "لا انِعكاسٌ ولا تفريغُ صندوقٍ"; fi
if grep -qF "if (scope.current != null && scope.method == null) {" "$A44/JavaCompletionProvider.java" \
&& grep -qF "addOverrideStubs(scope, sink);" "$A44/JavaCompletionProvider.java" \
&& grep -qF "stub.declarationHead(indent, true) + stub.stubBody(indent)" "$A44/JavaCompletionProvider.java" \
&& ! grep -rq "Auto-generated method stub" "$A44"; then
  ok "المُكمِّلُ في جِسمِ الصنفِ إعلانُ تغطيةٍ بقالبِ QuickFix — لا نداءٌ ولا قالبٌ ثانٍ ولا تعليقٌ"
else bad "إكمالُ جِسمِ الصنفِ" "لم يُوصَلْ بقالبِ الإصلاحِ أو دخَلَ تعليقٌ"; fi
if grep -qF "fix.overrides = first.overrides;" "$A44/QuickFix.java" \
&& grep -qF "public String stubBody(String indent)" "$A44/QuickFix.java" \
&& [ "$(grep -c "batchMark(" "$A44/QuickFix.java")" = "0" ] \
&& ! grep -q "STUB_MARKER" "$A44/QuickFix.java" \
&& ! grep -q "STUB_MARKER" "$A44/AbstractImplementationGap.java"; then
  ok "قالبٌ واحدٌ بلا عَلمٍ: الرأسُ والجِسمُ في QuickFix، ولا «TODO» مُولَّدةٌ في ملفٍّ من الثلاثةِ"
else bad "قالبُ الدَّفعَةِ" "بقيَ التَعلِيمُ أو تعدَّدَ القالبُ"; fi
if grep -qF '"$SRC/almlk/JavaCompletionProvider.java"' "$ZIP44/qa.sh" \
&& grep -qF '"$SRC/almlk/AbstractImplementationGap.java"' "$ZIP44/qa.sh" \
&& grep -qF "overrideSuggestionStage186();" "$ZIP44/qa/RegressionSuite.java"; then
  ok "الصنفانِ في قائمةِ الصافيِ والمرحلةُ مُوصَلةٌ بعدَ ‏1.0.185: بوابَةٌ لا هامِشٌ"
else bad "عُدَّةُ الانحدارِ" "الصافيُ أو المرحلةُ غيرُ مُسجَّلةٍ في الحزمةِ"; fi
if grep -q "$VERSION" "$ZIP44/VERSION" 2>/dev/null \
&& ls "$ZIP44"/reports/ 2>/dev/null | grep -q "w34_override_suggestions_and_inheritance_gap_study" \
&& grep -q "^## 52)" "$ZIP44/PROJECT_STATE.md" 2>/dev/null; then
  ok "البصمةُ والورقةُ و§52 داخلَ الحزمةِ (‏1.0.186‏)"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ أو بصمةٌ غيرُ $VERSION"; fi
rm -rf "$ZIP44"

echo "[45] الجولةُ 35 (‏1.0.187‏) — تكسيةٌ فوريّةٌ عندَ الفتحِ، والباني صنفٌ، والدالةُ دالةٌ"
TMP45=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP45" 2>/dev/null
for sym in SYNC_PRIME_LINES runStylingPass stylesForLine paletteKey ROLE_CONSTRUCTOR; do
  if grep -lq "$sym" "$TMP45"/classes*.dex 2>/dev/null; then ok "رمزُ التلوينِ «$sym» في الدكسِ"
  else bad "رمزُ التلوينِ $sym" "غائبٌ عن الحزمةِ"; fi
done
if grep -laF "function && !afterNew" "$TMP45"/classes*.dex >/dev/null 2>&1 \
|| grep -lq "fill" "$TMP45"/classes*.dex 2>/dev/null; then
  ok "ملوِّنُ الأسطرِ بقيَ في الحزمةِ بفرعِ اسمِ الدالةِ (لا تَسويَةٌ صامتةٌ في التغليفِ)"
else bad "ملوِّنُ الأسطرِ" "فرعُ الدالةِ لم يَصِلْ إلى الدكسِ"; fi
rm -rf "$TMP45"
ZIP45=$(mktemp -d); unzip -oq "$ZIP" -d "$ZIP45" 2>/dev/null
L45="$ZIP45/app/src/main/java/almlk"
if grep -qF "fill(styles, i, end, CodeLanguageTools.FUNCTION);" "$L45/LineStyler.java" \
&& ! grep -qF "} else if (function && !afterNew) {" "$L45/LineStyler.java" \
&& grep -qF "function && !afterNew && !gradleFile" "$L45/LineStyler.java"; then
  ok "اسمُ الدالةِ يَأخُذُ FUNCTION في كلِّ مواضعِهِ، وساذجُ البناءِ مستثنًى صراحةً — إحلالٌ لا تراكمٌ"
else bad "نمطُ الدالةِ" "بقِيَت ساذجةً أو تُرِكَ فرعٌ موازٍ"; fi
if grep -qF "role == JavaLocalScope.ROLE_CONSTRUCTOR) {" "$L45/LineStyler.java" \
&& grep -qF "fill(styles, i, end, CodeLanguageTools.TAG);" "$L45/LineStyler.java" \
&& ! grep -qF "ROLE_CONSTRUCTOR) fill(styles, i, end, 0);" "$L45/LineStyler.java"; then
  ok "اسمُ الباني في تعريفِهِ لونُ الصنفِ، ولا سطرَ ساذجٍ باقٍ لهُ"
else bad "دورُ البانيِ" "لم يُنسَبْ إلى TYPE أو أنَّ القديمَ باقٍ"; fi
if grep -qF "public static final int SYNC_PRIME_LINES = 256;" "$L45/LineStyler.java" \
&& grep -qF "runStylingPass(generationAtRequest, from, from + primeLines - 1, primeLines)" "$L45/LineStyler.java" \
&& [ "$(grep -c "runStylingPass(" "$L45/LineStyler.java")" = "3" ]; then
  ok "نافذةُ التكسيةِ الفوريّةِ في الطلبِ وحدَهُ وبالجولةِ نفسِها — لا لكسيرَ ثانِيَ ولا نشرَ ثانِيَ"
else bad "تكسيةُ الفتحِ" "النافذةُ في مسارٍ موازٍ أو ناقصةٌ"; fi
if grep -q '"Function"' "$L45/EditorThemePalette.java"; then
  bad "لوحةُ الأدوارِ" "صَفٌّ رابعَ عشرَ مُختَرَعٌ للدالةِ"
else
  ok "اللوحةُ كما المصدرِ: ثلاثةَ عشرَ سطرًا، والدالةُ تُصبَغُ بلونِ المعرِّفِ بلا صَفٍّ جديدٍ"
fi
if grep -qF "coloringOnOpenStage187();" "$ZIP45/qa/RegressionSuite.java" \
&& grep -qF '"$SRC/almlk/LineStyler.java"' "$ZIP45/qa.sh"; then
  ok "المَرحَلةُ ‏187 مَوصولةٌ، وملوِّنُ الأسطرِ في قائمةِ الصافيِ"
else bad "عُدَّةُ الانحدارِ" "لا مَرحَلةٌ ولا صافٍ مُسجَّلٌ في الحزمةِ"; fi
if grep -q "$VERSION" "$ZIP45/VERSION" 2>/dev/null \
&& ls "$ZIP45"/reports/ 2>/dev/null | grep -q "w35_coloring_on_open_and_identifier_roles_study" \
&& grep -q "^## 54)" "$ZIP45/PROJECT_STATE.md" 2>/dev/null; then
  ok "البصمةُ والورقةُ و§54 داخلَ الحزمةِ (‏$VERSION‏)"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ أو بصمةٌ غيرُ $VERSION"; fi
rm -rf "$ZIP45"

echo "[46] الجولةُ 36 (‏1.0.188‏) — لا تعليقَ مُولَّدًا، وأرضيةُ الفحصِ مَقيسةٌ"
TMP46=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP46" 2>/dev/null
for sym in floorFor observe declarationHead stubBody reset; do
  if grep -lq "$sym" "$TMP46"/classes*.dex 2>/dev/null; then ok "رمزُ الجولةِ «$sym» في الدكسِ"
  else bad "رمزُ الجولةِ $sym" "غائبٌ عن الحزمةِ"; fi
done
if grep -laq "Auto-generated method stub" "$TMP46"/classes*.dex 2>/dev/null; then
  bad "التعليقُ المُولَّدُ" "نصُّ «TODO» دخلَ الدكسَ من مَكانٍ ما"
else
  ok "لا «TODO» في الدكسِ كلِّهِ — التغطيةُ المَولَّدةُ جِسمٌ خالصٌ"
fi
if grep -laq "floorFor" "$TMP46"/classes*.dex 2>/dev/null; then
  ok "المحرِّرُ يَسألُ المِقياسَ: الحقلُ والنداءُ وصلا إلى الحزمةِ"
else bad "مِقياسُ الإيقاعِ" "لم يُوصَلْ في المحرِّرِ"
fi
rm -rf "$TMP46"
ZIP46=$(mktemp -d); unzip -oq "$ZIP" -d "$ZIP46" 2>/dev/null
A46="$ZIP46/app/src/main/java/almlk"
U46="$ZIP46/app/src/main/java/com/almlkid/kay/ui"
if ! grep -rq "Auto-generated" "$ZIP46/app/src/main/java"; then
  ok "لا تعليقَ مُولَّدًا في شيفرةِ التطبيقِ كلِّها — المِسمارُ السابقُ (سطرُ ‏2207) لا يَخدَعُهُ مُستهلِكٌ باقٍ"
else bad "التعليقُ المُولَّدُ" "بقيَ نصٌّ في شيفرةِ التطبيقِ"; fi
if [ "$(grep -c "STUB_MARKER\|batchMark" "$A46/QuickFix.java" "$A46/AbstractImplementationGap.java" 2>/dev/null | grep -v ":0" | wc -l)" = "0" ] \
&& grep -qF "public String stubBody(String indent)" "$A46/QuickFix.java" \
&& grep -qF "out.append(indent).append('}');" "$A46/QuickFix.java"; then
  ok "قالبُ الجِسمِ خاليُ العَلمِ والتعليقِ، والثابتُ والمَعلمُ زالا إحلالًا لا تُركَةً"
else bad "قالبُ التغطيةِ" "أثرٌ من العَلمِ باقٍ أو الجِسمُ غيرُ خالصٍ"; fi
if grep -qF "public String declarationHead(String indent, boolean annotate)" "$A46/QuickFix.java" \
&& grep -qF 'annotate ? ' "$A46/QuickFix.java" \
&& grep -qF '@Override' "$A46/QuickFix.java"; then
  ok "الرأسُ كما كانَ: «@Override» مَطلوبٌ جافويًّا، والتعليقُ وحدَهُ زَالَ"
else bad "رأسُ الإعلانِ" "تغيَّرَ ما لا يَمسُّهُ الطلبُ"; fi
if grep -qF "analysisPace.floorFor(getDocument().length()));" "$U46/AlmlkEditor.java" \
&& grep -qF "analysisPace.observe(" "$U46/AlmlkEditor.java" \
&& grep -qF "diagnosticsInFlightSince, analysisText.length());" "$U46/AlmlkEditor.java" \
&& [ "$(grep -c "delayFloorMs" "$U46/AlmlkEditor.java")" = "0" ] \
&& grep -qF "if (!fileName.equals(previous)) analysisPace.reset();" "$U46/AlmlkEditor.java"; then
  ok "الإيقاعُ لكلِّ ملفٍّ على حِدَةٍ، ولا مَفروضٍ ساكنٍ في المحرِّرِ — مَصبٌّ واحدٌ"
else bad "مِقياسُ الإيقاعِ" "بقيَ جدولٌ أو ضاعَ الفصلُ بينَ الملفاتِ"; fi
if [ "$(grep -c "return Math.min(floor, CAP_MS);" "$A46/AnalysisPace.java")" = "1" ] \
&& grep -qF "if (floor < MIN_USEFUL_MS) return 0;" "$A46/AnalysisPace.java" \
&& grep -qF "public static final long CAP_MS = 3000;" "$A46/AnalysisPace.java" \
&& grep -qF "if (samples < SAMPLES_FOR_TRUST) return DiagnosticBudget.delayFloorMs(chars);" "$A46/AnalysisPace.java"; then
  ok "المِقياسُ مُبرَّدٌ بالبرودةِ ومَقطوعُ السقفِ — لا انتظارَ أطولَ من القديمِ قطُّ"
else bad "صنفُ الإيقاعِ" "لم يَبرُدْ أو لم يُقطَعْ"; fi
if grep -qF '"$SRC/almlk/AnalysisPace.java"' "$ZIP46/qa.sh" \
&& grep -qF "cleanGeneratedCodeStage188();" "$ZIP46/qa/RegressionSuite.java" \
&& grep -qF "analysisPaceStage188();" "$ZIP46/qa/RegressionSuite.java"; then
  ok "الصنفُ في قائمةِ الصافيِ والمَرحلتانِ مُسجَّلتانِ: بوابَةٌ لا هامِشٌ"
else bad "عُدَّةُ الانحدارِ" "الصافيُ أو المَراحِلُ غيرُ مُسجَّلةٍ في الحزمةِ"; fi
if grep -q "$VERSION" "$ZIP46/VERSION" 2>/dev/null \
&& ls "$ZIP46"/reports/ 2>/dev/null | grep -q "w36_generated_comments_and_measured_pace_study" \
&& grep -q "^## 56)" "$ZIP46/PROJECT_STATE.md" 2>/dev/null; then
  ok "البصمةُ والورقةُ و§56 داخلَ الحزمةِ (‏$VERSION‏)"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ أو بصمةٌ غيرُ $VERSION"; fi
rm -rf "$ZIP46"

echo "[47] الجولةُ 37 (‏$VERSION‏) — الدالةُ بلونِ الجسدِ، والتوليدُ يَحمِلُ سطورَهُ، والفتحُ يَفحَصُ لونَهُ"
TMP47=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP47" 2>/dev/null
for sym in needsColoring ensureColorsVisibleNow insertionForAll importsToFetch onVisibleRangeChanged importNames firstVisibleLine; do
  if grep -lq "$sym" "$TMP47"/classes*.dex 2>/dev/null; then ok "رمزُ الجولةِ «$sym» في الدكسِ"
  else bad "الدكسُ" "«$sym» لم يَصِلْ"; fi
done
if grep -lq "setPaused" "$TMP47"/classes*.dex 2>/dev/null; then
  bad "مِقْبَضُ الوقْفِ" "setPaused باقٍ في الحزمةِ — التلوينُ مُعَلَّقٌ على حالِ التحليلِ"
else ok "لا «setPaused» في الحزمةِ كلِّها — التلوينُ لا يُعلَّقُ على حالِ التحليلِ"; fi
rm -rf "$TMP47"
ZIP47=$(mktemp -d); unzip -oq "$ZIP" -d "$ZIP47" 2>/dev/null
A47="$ZIP47/app/src/main/java/almlk"
U47="$ZIP47/app/src/main/java/com/almlkid/kay/ui"
if grep -A4 "case com.almlkid.kay.ui.CodeLanguageTools.FUNCTION:" "$A47/EditorSyntaxRoles.java" | grep -q "return EditorThemePalette.PLAIN;" \
&& ! grep -q '"Function"' "$A47/EditorThemePalette.java" \
&& [ "$(grep -c '"Identifier"' "$A47/EditorThemePalette.java")" = "1" ]; then
  ok "الدالةُ تَقرَأُ سطرَ الجسدِ، والحقلُ يَبقى على سطرِهِ، ولا صَفَّ رابعَ عشرَ مُختَرَعا"
else bad "جدولُ الأدوارِ" "لم تُنقَلِ الدالةُ إلى Plain أو اختُرِعَ صَفٌّ"; fi
if [ "$(grep -c "CodeLanguageTools.FUNCTION" "$A47/LineStyler.java")" = "1" ] \
&& grep -qF "Math.min(end + 1, length), CodeLanguageTools.TAG);" "$A47/LineStyler.java" \
&& ! grep -q "paused" "$A47/LineStyler.java" \
&& grep -qF "public boolean needsColoring(int fromLine, int toLine) {" "$A47/LineStyler.java"; then
  ok "المُلوِّنُ: اسمُ الدالةِ نمطٌ واحدٌ، وأوصافُ smali على سطرِ الأصنافِ، ولا وقفةَ — والفحصُ سؤالٌ"
else bad "LineStyler" " FUNCTION ثنائيةٌ أو paused باقٍ أو needsColoring مفقودٌ"; fi
if grep -qF "public int firstVisibleLine() {" "$A47/CodeCanvasView.java" \
&& grep -qF "public int lastVisibleLine() {" "$A47/CodeCanvasView.java" \
&& grep -qF "onVisibleRangeChanged(firstLine, lastLine);" "$A47/CodeCanvasView.java" \
&& grep -qF "protected void onVisibleRangeChanged(int fromLine, int toLine) {}" "$A47/CodeCanvasView.java"; then
  ok "النافذةُ المرئيَّةُ عندَ صاحبِها: من حسابِ الرسمِ، وبخطّافٍ لا لكلِّ إطارٍ"
else bad "CodeCanvasView" "الخطّافُ أو حسابُ النافذةِ"; fi
if grep -qF "if (styler.needsColoring(from, to)) styler.request(from, Integer.MAX_VALUE);" "$U47/AlmlkEditor.java" \
&& [ "$(grep -c "ensureColorsVisibleNow();" "$U47/AlmlkEditor.java")" = "5" ] \
&& ! grep -q "styler.setPaused" "$U47/AlmlkEditor.java" \
&& grep -qF "protected void onVisibleRangeChanged(int fromLine, int toLine) {" "$U47/AlmlkEditor.java"; then
  ok "الفتحُ والثيمُ والالتصاقُ والاستئنافُ وتبدُّلُ النافذةِ — خمسةُ أبوابَ تَفحَصُ اللونَ"
else bad "AlmlkEditor" "فحصُ اللونِ أو فصلُ التحليلِ عنهُ"; fi
if [ "$(grep -c "private static String writeElement(" "$A47/AbstractImplementationGap.java")" = "1" ] \
&& grep -qF "return renderType(described, imports, importsToFetch, null, null);" "$A47/AbstractImplementationGap.java" \
&& grep -qF "public static String renderType(String described, List<String> imports," "$A47/AbstractImplementationGap.java" \
&& grep -qF "withImports(needed)" "$A47/AbstractImplementationGap.java" \
&& grep -qF "public List<String> importsToFetch" "$A47/QuickFix.java" \
&& grep -qF "asInsertion(source)" "$A47/QuickFix.java"; then
  ok "قاعدةُ النوعِ واحدةٌ وتَحمِلُ سطورَها، والكتابةُ كتلةٌ واحدةٌ (تراجعٌ واحدٌ)"
else bad "توليدُ الاستيراداتِ" "قاعدةٌ ثانيةٌ أو دمجُ الكتلةِ مفقودٌ"; fi
if grep -qF "public static QuickFix.Insertion insertionForAll(String source, List<String> qualifiedNames)" "$A47/JavaImportResolver.java" \
&& grep -qF "insertionForAll(source, java.util.Collections.singletonList(qualifiedName))" "$A47/JavaImportResolver.java" \
&& grep -qF "private void addImportsIfNeeded(List<String> classNames)" "$U47/AlmlkEditor.java"; then
  ok "الإدراجُ في مَصبٍّ واحدٍ: قائمةٌ بأيِّ عددٍ، والسطرُ الواحدُ سؤالٌ منَ القائمةِ"
else bad "JavaImportResolver" "قاعدةُ الإدراجِ انشَقَّتْ"; fi
if grep -qF "if (!toFetch.isEmpty()) item.importNames =" "$A47/JavaCompletionProvider.java" \
&& grep -qF "public java.util.List<String> importNames;" "$U47/ProjectSymbolIndex.java" \
&& grep -qF "almlk.JavaImportResolver.insertionForAll(source, qualified)" "$U47/AlmlkEditor.java"; then
  ok "صفوفُ التغطيةِ والإكمالُ تَقرَأُ القائمةَ نفسَها — أيقونَةُ «يحتاجُ استيرادًا» صادقةٌ"
else bad "صفوفُ الاقتراحِ" "اسمٌ واحدٌ باقٍ أو قائمةٌ لا تُقرَأُ"; fi
if grep -q "$VERSION" "$ZIP47/VERSION" 2>/dev/null \
&& ls "$ZIP47"/reports/ 2>/dev/null | grep -q "w37_function_colour_and_generated_imports_study" \
&& grep -q "^## 58)" "$ZIP47/PROJECT_STATE.md" 2>/dev/null; then
  ok "البصمةُ والورقةُ و§58 داخلَ الحزمةِ (‏$VERSION‏)"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ أو بصمةٌ غيرُ $VERSION"; fi
rm -rf "$ZIP47"

echo "[48] الجولةُ 39 (‏$VERSION‏) — مسحُ الفتحِ على خيوطٍ، والوسمُ لا يُورَثُ بلا يقينٍ"
TMP48=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP48" 2>/dev/null
for sym in ProjectScanPace analyseDiagnosticShard dependentsOf workerCountFor mayPersistSnapshot absenceProvablyComplete; do
  if grep -lq "$sym" "$TMP48"/classes*.dex 2>/dev/null; then ok "رمزُ الجولةِ «$sym» في الدكسِ"
  else bad "الدكسُ" "«$sym» لم يَصِلْ"; fi
done
rm -rf "$TMP48"
ZIP48=$(mktemp -d); unzip -oq "$ZIP" -d "$ZIP48" 2>/dev/null
A48="$ZIP48/app/src/main/java/almlk"
B48="$ZIP48/app/src/main/java/com/almlkid/ui/browsers"
U48="$ZIP48/app/src/main/java/com/almlkid/kay/ui"
M48="$ZIP48/app/src/main/java/com/shima/demo/MainActivity.java"
if [ -f "$A48/ProjectScanPace.java" ] \
&& grep -qF "public static int workerCountFor(int files, int availableProcessors)" "$A48/ProjectScanPace.java" \
&& grep -qF "public static boolean mayPersistSnapshot(boolean absenceProvablyComplete)" "$A48/ProjectScanPace.java" \
&& grep -qF "public static int startOf(int shard, int files, int workers)" "$A48/ProjectScanPace.java"; then
  ok "السياسةُ صافيةٌ في صنفٍ واحدٍ: عددُ الخيوطِ والقِطَعُ والحفظُ القرصيُّ من مَصدَرٍ واحدٍ"
else bad "ProjectScanPace" "لا صنفَ أو انشقَّتِ السياسةُ"; fi
if grep -qF "Executors.newFixedThreadPool(scanWorkers)" "$B48/BrowserPager.java" \
&& grep -qF "almlk.ProjectScanPace.workerCountFor(" "$B48/BrowserPager.java" \
&& grep -qF "private void analyseDiagnosticShard(" "$B48/BrowserPager.java" \
&& grep -qF "java.util.Collections.synchronizedMap(new LinkedHashMap<String, ProjectDiagnostic>())" "$B48/BrowserPager.java" \
&& grep -qF "java.util.Collections.synchronizedSet(new HashSet<String>())" "$B48/BrowserPager.java"; then
  ok "المسحُ العامُّ على حِزَمٍ في بركةِ خيوطٍ، والوعاءُ مُزامَنٌ"
else bad "BrowserPager" "بقيَ المسحُ على خيطٍ واحدٍ"; fi
if grep -qF "if (full.get()) return;" "$B48/BrowserPager.java" \
&& [ "$(grep -c "MAX_PROJECT_DIAGNOSTICS) full.set(true)" "$B48/BrowserPager.java")" = "1" ]; then
  ok "والسقفُ عامٌّ: إشارةٌ واحدةٌ تُوقِفُ الحِزَمَ كلَّها فلا يَصيرُ أربَعَةَ أمثالِهِ"
else bad "سقفُ التشخيصاتِ" "تَجاوُزٌ مُتَوازٍ أو إيقافٌ مفقودٌ"; fi
if grep -qF "almlk.ProjectScanPace.mayPersistSnapshot(almlk.JavaProjectModel.absenceProvablyComplete())" "$B48/BrowserPager.java"; then
  ok "ولا وسمَ نصفَ اليقينِ على القرصِ: اللقطةُ لا تُورَثُ إلّا بجَزمٍ"
else bad "قَطرةُ اللقطاتِ" "حفظٌ بلا شَرطِ يقينٍ"; fi
if grep -qF "dependentsOf(openReference, candidates)" "$B48/BrowserPager.java" \
&& grep -qF "almlk.ProjectScanPace.compare(" "$B48/BrowserPager.java" \
&& grep -qF "almlk.ProjectScanPace.publishNow(size, now, lastProgress, PROGRESS_INTERVAL_MS)" "$B48/BrowserPager.java" \
&& ! grep -qF "FileReferences.same(priority, ra)" "$B48/BrowserPager.java"; then
  ok "المفتوحُ ثمَّ مكتباتُهُ ثمَّ الباقي، والنشرُ تدريجيٌّ — بصيغةِ ترتيبٍ واحدةٍ"
else bad "أولويَةُ المسحِ" "ترتيبٌ ثانٍ أو طبقةُ القرابةِ مفقودةٌ"; fi
if [ "$(grep -c "scanProjectDiagnostics();" "$M48")" = "2" ] \
&& grep -qF "if (diagnosticsScanQueued) return;" "$B48/BrowserPager.java" \
&& grep -qF "private volatile boolean diagnosticsScanQueued;" "$B48/BrowserPager.java"; then
  ok "المسحُ يَنطلِقُ معَ الفتحِ، والقَفزةُ إلى ما بعدَ الفهرسِ لا تُكرَرُ (لا ضِعفَ عملٍ)"
else bad "بدءُ المسحِ" "لا نداءَ عندَ الفتحِ أو ضِعفُ عملٍ"; fi
if grep -qF "FIRST_RUN_DELAY_MS = 60" "$A48/LiveDiagnostics.java" \
&& grep -qF "MAX_WAIT_MS = 700" "$A48/LiveDiagnostics.java" \
&& grep -qF "diagnosticSpans.applyEdit(" "$U48/AlmlkEditor.java" \
&& grep -qF "almlk.LiveDiagnostics.remap(found, analysisText, currentText())" "$U48/AlmlkEditor.java"; then
  ok "فحصُ المحرِّرِ لحظيٌّ: وهجٌ ‏60م.ث، وسقفُ ‏700م.ث، وإزاحةُ الوسمِ عندَ كلِّ تحريرٍ"
else bad "استجابةُ المحرِّرِ" "لا لَحظِيَّةَ أو لا رَدَّ للجَوابِ البالي"; fi
if grep -qF "generated.overrides = true" "$A48/AbstractImplementationGap.java" \
&& grep -qF "batch.withImports(needed)" "$A48/AbstractImplementationGap.java"; then
  ok "والتغطيةُ المَولودةُ تَحمِلُ ‏@Override‏ واستيرادَها في كتلةٍ واحدةٍ"
else bad "فجوةُ التغطيةِ" "لا overrides أو لا دمجَ استيراداتٍ"; fi
if grep -q "$VERSION" "$ZIP48/VERSION" 2>/dev/null \
&& ls "$ZIP48"/reports/ 2>/dev/null | grep -q "w39_startup_scan_and_mark_certainty_study" \
&& grep -q "^## 60)" "$ZIP48/PROJECT_STATE.md" 2>/dev/null \
&& grep -qF "almlk/ProjectScanPace.java" "$ZIP48/qa.sh"; then
  ok "البصمةُ والورقةُ و§60 والصنفُ الجديدُ في ‏qa.sh‏ داخلَ الحزمةِ (‏$VERSION‏)"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ أو بصمةٌ غيرُ $VERSION"; fi
rm -rf "$ZIP48"


echo "[49] الجولةُ 40 (‏$VERSION‏) — الدَّفعَةُ والتغطيةُ وأسطرُها تعبرُ السِّلكَ، والنصُّ الحيُّ يَقرِّرُ"
TMP49=$(mktemp -d)
unzip -oq "$APK" "classes*.dex" -d "$TMP49" 2>/dev/null
for sym in pendingFetches pendingHead MAX_COMPANIONS withLiveImports decodeCompanion; do
  if grep -lq "$sym" "$TMP49"/classes*.dex 2>/dev/null; then ok "رمزُ الجولةِ «$sym» في الدكسِ"
  else bad "الدكسُ" "«$sym» لم يَصِلْ"; fi
done
rm -rf "$TMP49"
ZIP49=$(mktemp -d); unzip -oq "$ZIP" -d "$ZIP49" 2>/dev/null
P49="$ZIP49/app/src/main/java/almlk/AnalyzerProtocol.java"
W49="$ZIP49/app/src/main/java/com/almlkid/analyzer/AnalyzerWire.java"
F49="$ZIP49/app/src/main/java/almlk/QuickFix.java"
G49="$ZIP49/app/src/main/java/almlk/AbstractImplementationGap.java"
D49="$ZIP49/app/src/main/java/com/almlkid/ui/AIDEEditorPager.java"
if grep -qF "public final boolean overrides;" "$P49" && grep -qF "public final Fix[] companions;" "$P49" \
&& grep -qF "public final String[] imports;" "$P49" \
&& grep -qF "public static final int MAX_COMPANIONS = 12;" "$P49"; then
  ok "الحِملُ يَحمِلُ الثلاثةَ: عَلمُ التغطيةِ ورُفقاءُ الدَّفعَةِ وأسطرُها (سقفٌ يَلِي سقفَ المُحرِّكِ)"
else bad "AnalyzerProtocol" "الحِملُ ما زالَ ثلاثةَ عشرَ حقلًا"; fi
if grep -qF "append(num(x.imports.length));" "$P49" \
&& grep -qF "if (x.length < at + importCount) return null;" "$P49" \
&& grep -qF "if (count < 0 || count > MAX_COMPANIONS) return null;" "$P49"; then
  ok "الذَّيلُ اختِياريٌّ مُرتَّبٌ: قَديمٌ يُفَكُّ، ومشبوهٌ يَسقُطُ كلُّهُ لا نِصفُهُ"
else bad "ترميزُ الدَّفعَةِ" "ذَيلٌ يَنقَلِبُ على ما قَبلَهُ أو نِصفُ دَفعَةٍ يُمَرُّ"; fi
if grep -qF "fix.overrides = x.overrides;" "$W49" \
&& grep -qF "private static QuickFix decodeCompanion(AnalyzerProtocol.Fix c, String targetClass)" "$W49" \
&& grep -qF "if (encoded == null)" "$W49"; then
  ok "السِّلكُ يَنقُلُ ولا يُعيدُ الحِسابَ: الرَفيقُ والرأسُ والعَلمُ كما قالَ المُحرِّكُ"
else bad "AnalyzerWire" "الفَكُّ ألقَى الدَّفعَةَ"; fi
if grep -qF "public List<String> importsToFetch = Collections.emptyList();" "$F49" \
&& grep -qF "private QuickFix pendingHead(Members members) {" "$F49" \
&& grep -qF "return promoted == null ? null : promoted.planInsertion(source);" "$F49"; then
  ok "الدَّفعَةُ لا تَسقُطُ برأسِها: رأسٌ مَكتوبٌ يَدفَعُ أولَ مَفقودٍ مَكانَهُ"
else bad "QuickFix" "الرَفْعُ مفقودٌ أو الحقلُ أُغلِقَ"; fi
if grep -qF "public static List<String> pendingFetches(List<String> requested, List<String> fileImports)" "$G49" \
&& grep -qF 'if (qualified.startsWith("java.lang.")) continue;' "$G49" \
&& grep -qF "if (out.contains(qualified)) continue;" "$G49" \
&& grep -qF "if (imp.endsWith(\".*\") && qualified.startsWith(imp.substring(0, imp.length() - 1))) return true;" "$G49"; then
  ok "النصُّ الحيُّ يَقرِّرُ وحدَهُ: مُستورَدٌ صَريحًا أو ب‏.*‏ فلا سطرَ، وغائبٌ فسطرُهُ بِعَينِهِ"
else bad "pendingFetches" "قرارُ الاستيرادِ ليسَ على الحَيِّ"; fi
if [ "$(grep -c "withLiveImports(fix, source);" "$D49")" = "2" ] \
&& grep -qF "if (fix == null || source == null || fix.importsToFetch.isEmpty()) return;" "$D49"; then
  ok "مَوضِعا التطبيقِ جَميعًا يُمهِّدانِ الأسطرَ قبلَ التخطيطِ (الدالةُ والرمزُ)"
else bad "AIDEEditorPager" "أحدُ المَوضِعَينِ لا يُصفِّي الأسطرَ"; fi
if grep -qF "generated.overrides = true" "$G49" && grep -qF "batch.withImports(needed)" "$G49"; then
  ok "المُحرِّكُ باقٍ على عَهدِهِ: التغطيةُ تُولَدُ مُعَلَّمَةً وبأسطرِها"
else bad "فجوةُ التغطيةِ" "تبدَّلَ ما في المُحرِّكِ"; fi
if grep -q "$VERSION" "$ZIP49/VERSION" 2>/dev/null \
&& ls "$ZIP49"/reports/ 2>/dev/null | grep -q "w40_override_wire_batch_and_import_study" \
&& grep -q "^## 62)" "$ZIP49/PROJECT_STATE.md" 2>/dev/null \
&& grep -qF "overrideWireStage191();" "$ZIP49/qa/RegressionSuite.java" 2>/dev/null; then
  ok "البصمةُ والورقةُ و§62 والمَرحَلةُ داخلَ الحزمةِ (‏$VERSION‏)"
else bad "توثيقُ الجولةِ" "لا ورقةَ ولا فصلَ أو بصمةٌ غيرُ $VERSION"; fi
rm -rf "$ZIP49"

# ═════════ [50] جولة ٤١: إصدارُ المشروعِ يَحكُمُ فَحصَ المنصَّةِ (1.0.192) ═════════
echo "── [50] جولةُ ٤١: فَحصُ الإصداراتِ على كَلامِ المشروعِ، وصَمتٌ بلا تَصريحٍ ──"
ZIP50=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZIP50" 2>/dev/null; then
  if grep -qF 'return n > 0 && n < 300 ? n : 0;' "$ZIP50/app/src/main/java/almlk/ProjectPlatform.java" 2>/dev/null \
  && grep -qF 'public boolean requiresAboveMin(int since)' "$ZIP50/app/src/main/java/almlk/ProjectPlatform.java" 2>/dev/null \
  && grep -qF 'if (!platform.gatesApi() || applicable.isEmpty()) return;' "$ZIP50/app/src/main/java/almlk/JavaAttributor.java" 2>/dev/null \
  && grep -qF 'reportApiLevel(applicable, l, c);' "$ZIP50/app/src/main/java/almlk/JavaAttributor.java" 2>/dev/null; then
    ok "مِقياسُ الجَهلِ سارٍ: رقمٌ خارجُ المَدَى صِفرٌ، ولا حُكمَ بلا ‏minSdk‏"
  else bad "مِقياسُ الجَهلِ" "تَخمينٌ في قِراءةِ المُستوى أو فَحصٌ بغيرِ تَصريحٍ"; fi
  if grep -qF 'symbol.since = m.since;' "$ZIP50/app/src/main/java/almlk/JavaTypeModel.java" 2>/dev/null \
  && grep -qF 'symbol.removedIn = m.removed;' "$ZIP50/app/src/main/java/almlk/JavaTypeModel.java" 2>/dev/null; then
    ok "مُستوى العُضوِ يَعبُرُ النَّموذجَ لا يُعادُ حِسابُهُ عندَ الفاحِصِ"
  else bad "نَقلُ المُستوى" "بَقِيَتْ مَعرِفةُ ‏since/removed‏ في الطَّبقةِ السُّفلى"; fi
  if grep -qF "if (body.indexOf('=') >= 0) return false;" "$ZIP50/app/src/main/java/almlk/JavaAttributor.java" 2>/dev/null \
  && grep -qF 'private boolean guardPresent()' "$ZIP50/app/src/main/java/almlk/JavaAttributor.java" 2>/dev/null \
  && grep -qF 'android.os.Build.VERSION.SDK_INT' "$ZIP50/app/src/main/java/almlk/JavaAttributor.java" 2>/dev/null; then
    ok "اللَفُّ لا يَمسُّ تَخصيصًا ولا نَصًّا، وعَهدُ الحارِسِ صَمتٌ"
  else bad "شَرطُ الإصلاحِ" "لَفٌّ يَخترِقُ سطرًا غَيرَ نِداءٍ أو حارسٌ لا يُلتَفَتُ إلَيهِ"; fi
  if grep -qF 'almlk.ProjectPlatform.publish(platformOf(loaded));' "$ZIP50/app/src/main/java/com/almlkid/ui/DependencyCycle.java" 2>/dev/null \
  && grep -qF 'static almlk.ProjectPlatform platformOf(almlk.GradleBuildModel model)' "$ZIP50/app/src/main/java/com/almlkid/ui/DependencyCycle.java" 2>/dev/null; then
    ok "المُستوياتُ تَنزِلُ معَ دَورةِ المكتباتِ (فتحٌ وحفظُ ‏build.gradle‏) لا معَ كلِّ ضَغنَةِ مِفتاحٍ"
  else bad "مَنبَعُ المُستوياتِ" "لم يُنشَرِ الصَّرحُ من دَورةِ البِناءِ"; fi
  if grep -qF 'COMPILE_ONLY_SUFFIX = "_compileonly.";' "$ZIP50/app/src/main/java/almlk/LocalLibraries.java" 2>/dev/null \
  && grep -qF 'compile-only (checked, not packaged)' "$ZIP50/app/src/main/java/almlk/LocalLibraries.java" 2>/dev/null; then
    ok "‏libs/*_compileonly.jar‏: مَفهومٌ ومَفهرَسٌ ومَنطوقٌ في اللوحةِ، ولا يُنسَبُ إلى البِناءِ"
  else bad "اصطلاحُ المكتبةِ المَحجوبةِ" "سُكِتَ عنهُ أو عُدَّ داخِلًا في البِناءِ"; fi
  for k in ui_diagnostic_requires_api ui_diagnostic_removed_api ui_fix_wrap_api_check; do
    n_en=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP50/app/src/main/res/values/strings.xml" 2>/dev/null)
    n_ar=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP50/app/src/main/res/values-ar/strings.xml" 2>/dev/null)
    if [ "$n_en" = "1" ] && [ "$n_ar" = "1" ]; then ok "المفتاحُ يتيمٌ مرّةً في اللغتين: $k"
    else bad "مفاتيحُ الجولةِ" "$k — en=$n_en ar=$n_ar"; fi
  done
  if grep -qF 'public static final String API_LEVEL = "API_LEVEL";' "$ZIP50/app/src/main/java/almlk/JavaDiagnosticCodes.java" 2>/dev/null \
  && grep -qF 'return API_LEVEL;' "$ZIP50/app/src/main/java/almlk/JavaDiagnosticCodes.java" 2>/dev/null \
  && grep -qF '$SRC/almlk/ProjectPlatform.java' "$ZIP50/qa.sh" 2>/dev/null \
  && grep -qF 'apiLevelStage192();' "$ZIP50/qa/RegressionSuite.java" 2>/dev/null; then
    ok "عائلةٌ مُستقِلَّةٌ في الجَدوَلِ، والصِّنفُ في قائمةِ الصَّافي، والمَرحَلةُ مُسَجَّلَةٌ"
  else bad "تَصنيفُ الجَولَةِ" "زَمرَةٌ مُستَعارَةٌ أو صِنفٌ خارِجَ البوَّابةِ"; fi
  if grep -q "^## 63)" "$ZIP50/PROJECT_STATE.md" 2>/dev/null \
  && ls "$ZIP50"/reports/ 2>/dev/null | grep -q "w41_" \
  && grep -qF "user_androidjar" "$ZIP50"/reports/w41_*.md 2>/dev/null \
  && grep -qF "CompileOnlyJar" "$ZIP50"/reports/w41_*.md 2>/dev/null; then
    ok "الورقةُ والمَقطَعُ: §63م ودراسةٌ تَذكُرُ ما ثَبَتَ وما تَأَجَّلَ"
  else bad "أوراقُ الجولةِ" "لا §63م أو الورقةُ لا تُثبِتُ رُجوعَها إلى المَرجِعِ"; fi
else bad "فكُّ الحزمةِ" "لا يُقرَأُ ‏zip‏ المصادرِ"; fi

TMP50=$(mktemp -d)
if [ -f "$APK" ]; then
  unzip -oq "$APK" "classes*.dex" "resources.arsc" -d "$TMP50" 2>/dev/null
  if grep -lq "Lalmlk/ProjectPlatform;" "$TMP50"/classes*.dex 2>/dev/null   && grep -lq "ui_diagnostic_requires_api" "$TMP50"/classes*.dex 2>/dev/null   && grep -lq "ui_fix_wrap_api_check" "$TMP50"/classes*.dex 2>/dev/null; then
    ok "ال‏dex‏ يَحمِلُ الصِّنفَ والمفاتيحَ: ‏almlk/ProjectPlatform‏ في الحُزمةِ"
  else bad "الحُزمةُ المُترجَمةُ" "الصِّنفُ أو المفاتيحُ لم تَنزِلْ في ال‏dex‏"; fi
  if grep -alq "was removed in API level" "$TMP50"/resources.arsc 2>/dev/null   && grep -alq "requires API level" "$TMP50"/resources.arsc 2>/dev/null; then
    ok "نصَّا الجَولَةِ (الإِثنَانِ) مُضمَّنَانِ في المواردِ"
  else bad "المواردُ" "نصٌّ جَديدٌ لم يَدخُلِ الـarsc"; fi
  if grep -q "^$VERSION$" VERSION 2>/dev/null; then
    ok "بصمةُ الجَولَةِ: ‏$VERSION‏ في ‏VERSION‏ (و‏versionCode‏ يُثبَّتُ في بَابِ دَورِهِ)"
  else bad "البصمةُ" "تبدَّلَتِ الأَرقَامُ"; fi
  rm -rf "$TMP50"
else bad "حزمةُ ‏$VERSION‏" "لا APKَ في deliverables"; fi


# ═════════ [51] جولة ٤٢: عَهْدُ النَّسْقِ والحِفظُ الكَامِلُ (1.0.193) ═════════
echo "── [51] جولةُ ٤٢: لا قَالِبَ يَنهَرُ، والحِفظُ يَغسِلُ الكُلَّ قَبلَ البِناءِ ──"
ZIP51=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZIP51" 2>/dev/null; then
  G_FMT="$ZIP51/app/src/main/java/almlk/UiFormat.java"
  G_QF="$ZIP51/app/src/main/java/almlk/QuickFix.java"
  G_US="$ZIP51/app/src/main/java/com/shima/demo/UiStrings.java"
  G_SN="$ZIP51/app/src/main/java/com/shima/performance/ProjectDiagnosticsSnapshot.java"
  if grep -qF '} catch (IllegalFormatException mismatch) {' "$G_FMT" 2>/dev/null \
  && grep -qF 'public static String substitute(String template, Object... args) {' "$G_FMT" 2>/dev/null \
  && grep -qF '} catch (IllegalArgumentException mismatch) {' "$G_US" 2>/dev/null; then
    ok "الحَارِسُ عَامٌّ: قَالِبٌ مُخَالِفٌ يُنسَجُ ولا يُرمِي، والمُوَافِقُ لا يَتَبَدَّلُ"
  else bad "الحَارِسُ" "الوَاجِهَةُ ما زَالَت تَسقُطُ علَى تَحقِيقٍ قَالِبِيٍّ"; fi
  if grep -qF 'public Object createdArg() {' "$G_QF" 2>/dev/null \
  && grep -qF 'Integer.valueOf(1 + companions.size())' "$G_QF" 2>/dev/null; then
    ok "جِذرُ الانهِيَارِ مُصَحَّحٌ: حُجَّةُ الدَّفعَةِ عَدَدٌ، وقَالِبُها «‏%1\$d‏»"
  else bad "حُجَّةُ الدَّفعَةِ" "سِلسِلَةٌ تَحتَ «‏%\$d‏» — سَيَنهَرُ المُصَلِّحُ ثانِيَةً"; fi
  if grep -qF 'appendArg(args, d.messageArgs[i]);' "$G_SN" 2>/dev/null \
  && grep -qF 'String body = text.substring(2);' "$G_SN" 2>/dev/null; then
    ok "لَقطةُ القُرسِ تَحفَظُ أجنَاسَ الحُجَجِ (وِسمٌ حَرفَانِ) — فَلا رَقْمٌ يُنسَجُ مِن كَلِمَةٍ عِندَ الفَتحِ"
  else bad "اللَّقطةُ" "الحُجَجُ تَرجِعُ نُصُوصًا أو القَطيعُ مَقطُوعٌ"; fi
  G_LD="$ZIP51/app/src/main/java/almlk/EditorDirtyLedger.java"
  if grep -qF 'public final class EditorDirtyLedger {' "$G_LD" 2>/dev/null \
  && grep -qF 'public static String decorate(String name, boolean isDirty)' "$G_LD" 2>/dev/null \
  && grep -qF '$SRC/almlk/EditorDirtyLedger.java' "$ZIP51/qa.sh" 2>/dev/null \
  && grep -qF '$SRC/almlk/UiFormat.java' "$ZIP51/qa.sh" 2>/dev/null; then
    ok "الحُكمُ صَافٍ: الدَّفْتَرُ والنَّسْقُ في ‏almlk‏ وقَائِمَةِ البَوَّابَةِ"
  else bad "صَفَاءُ الحُكمِ" "قَرَارٌ بَاقٍ في الوَاجِهَةِ أو خَارِجَ قائمةِ الصَّافِي"; fi
  G_PG="$ZIP51/app/src/main/java/com/almlkid/ui/AIDEEditorPager.java"
  if grep -qF 'markActiveDirty();' "$G_PG" 2>/dev/null \
  && grep -qF 'public String textOf(String name) {' "$G_PG" 2>/dev/null \
  && grep -qF 'dirtyLedger.forget(name);' "$G_PG" 2>/dev/null \
  && grep -qF 'public void markTabSaved(String name) {' "$G_PG" 2>/dev/null; then
    ok "اللوحَةُ مُوصَلَةٌ: عَلامَةٌ عِندَ أَوَّلِ تَغَيُّرٍ، ونَصُّ الخَامِلِ، وإِزالةٌ ونِسْيَانٌ"
  else bad "وَصلُ اللَّوحَةِ" "عَلاَمَةٌ لا تَظهَرُ أو لا تَزُولُ"; fi
  G_MA="$ZIP51/app/src/main/java/com/shima/demo/MainActivity.java"
  G_CC="$ZIP51/app/src/main/java/com/shima/demo/CommandCenter.java"
  if grep -qF 'private void saveAllThen(final Runnable next, final boolean announce) {' "$G_MA" 2>/dev/null \
  && ! grep -qF 'saveActiveThen(' "$G_MA" 2>/dev/null \
  && grep -qF 'saveAllThen(this::scheduleAutosave, false);' "$G_MA" 2>/dev/null \
  && grep -qF 'onFileSaved(tab);' "$G_MA" 2>/dev/null; then
    ok "حَافِظٌ وَاحِدٌ: لا ‏saveActiveThen‏، يَغسِلُ الكُلَّ صَامِتًا ويَعيِدُ دَورَةَ المُكتَبَاتِ"
  else bad "حِفظٌ مُزدَوِجٌ" "حافِظٌ قَديمٌ بَاقٍ أو الدَّفعَةُ نَاقِصَةٌ"; fi
  if grep -qF 'if (itemId == R.id.mainMenuSaveAll) return "save_all";' "$G_MA" 2>/dev/null \
  && grep -qF 'add("save_all", "command_save_all", "ui_group_editor", true, true, Host::hasPendingEdits, null);' "$G_CC" 2>/dev/null \
  && grep -qF '@id/mainMenuSaveAll' "$ZIP51/app/src/main/res/menu/main_options_menu.xml" 2>/dev/null \
  && grep -qF 'name="mainMenuSaveAll"' "$ZIP51/app/src/main/res/values/ids.xml" 2>/dev/null; then
    ok "«احفَظِ الكُلَّ» مَوصُولٌ: قَائِمَةٌ ← أَمْرٌ ← مُركَزُ الأَوَامِرِ ← أَهلِيَّةٌ حَيَّةٌ"
  else bad "أَمرُ القَائِمَةِ" "عُنصَرٌ صَامِتٌ أو تَوجِيهٌ مَقطُوعٌ"; fi
  for k in command_save_all ui_save_all_none ui_save_all_done; do
    n_en=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP51/app/src/main/res/values/strings.xml" 2>/dev/null)
    n_ar=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP51/app/src/main/res/values-ar/strings.xml" 2>/dev/null)
    if [ "$n_en" = "1" ] && [ "$n_ar" = "1" ]; then ok "المِفتاحُ يتيمٌ مرّةً في اللغتين: $k"
    else bad "مفاتيحُ الجَولَةِ" "$k — en=$n_en ar=$n_ar"; fi
  done
  if grep -qF 'formatContractStage193();' "$ZIP51/qa/RegressionSuite.java" 2>/dev/null \
  && grep -qF 'saveSweepStage193();' "$ZIP51/qa/RegressionSuite.java" 2>/dev/null \
  && grep -q "^## 64)" "$ZIP51/PROJECT_STATE.md" 2>/dev/null \
  && ls "$ZIP51"/reports/ 2>/dev/null | grep -q "w42_" \
  && grep -qF "IllegalFormatConversionException" "$ZIP51"/reports/w42_*.md 2>/dev/null; then
    ok "المَرحَلَتَانِ مُسَجَّلَتَانِ، و§64م، ووَرقةٌ تَذكُرُ الأَثَرَ الجِهَارِيَّ كَمَا هُوَ"
  else bad "أورَاقُ الجَولَةِ" "لا مَرحَلةً أو لا §64م أو وَرقةٌ لا تُثبِتُ الدَّلِيلَ"; fi
else bad "فكُّ الحزمةِ" "لا يُقرَأُ zip المصادرِ"; fi

if [ -f "$APK" ]; then
  TMP51=$(mktemp -d)
  unzip -oq "$APK" "classes*.dex" "resources.arsc" -d "$TMP51" 2>/dev/null
  if grep -lq "Lalmlk/UiFormat;" "$TMP51"/classes*.dex 2>/dev/null \
  && grep -lq "Lalmlk/EditorDirtyLedger;" "$TMP51"/classes*.dex 2>/dev/null \
  && grep -lq "ui_save_all_done" "$TMP51"/classes*.dex 2>/dev/null; then
    ok "ال‏dex‏ يَحمِلُ الآلِيَّةَ الجَدِيدَةَ: ‏UiFormat‏ و‏EditorDirtyLedger‏ والأَمرُ"
  else bad "الدكسُ" "صِنفٌ أو أَمْرٌ لم يَصِلْ إلى الحُزمةِ"; fi
  if grep -alq "Saved %1\$d file(s)" "$TMP51"/resources.arsc 2>/dev/null \
  && grep -alq "Nothing to save" "$TMP51"/resources.arsc 2>/dev/null \
  && grep -alq "Save all" "$TMP51"/resources.arsc 2>/dev/null; then
    ok "المَواردُ تَحمِلُ النُّصُوصَ الثَّلاثَةَ (والعَدَدُ بِحَاجِزِ رَقمٍ)"
  else bad "المَوارِدُ" "نصٌّ جَدِيدٌ لم يَدخُلِ الـarsc"; fi
  if grep -qE "^[[:space:]]*versionCode [0-9]+" app/build.gradle 2>/dev/null \
  && grep -q "^$VERSION$" VERSION 2>/dev/null; then
    ok "بصمةُ البِناءِ: ‏$VERSION‏ وبَصمَةُ الكودِ حاضِرَةٌ (لا رَقمَ مُثبَّتًا هُنا لِئَلّا يَنكَسِرَ عَلى جَولَةٍ بَعدَها)"
  else bad "البصمةُ" "وَسمُ الإصدارِ غيرُ مُتَّفِقٍ مَعَ مَلفِّهِ"
  fi
  rm -rf "$TMP51"
else bad "حزمةُ ‏$VERSION‏" "لا APKَ في deliverables"; fi
rm -rf "$ZIP51"

# ═════════ [52] جولة ٤٣: كُلُّ حِزمَةٍ صَاحِبَةٍ صَفٌّ — الاختِيَارُ لِلمُستَخدِمِ ═════════
echo "── [52] جولةُ ٤٣: لا اختِرَاعَ ولا إِعراضَ — العَرضُ بِقَدرِ المَعرُوفِ وَالسَّقفُ مَحفُوظٌ ──"
ZIP52=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZIP52" 2>/dev/null; then
  G_AT="$ZIP52/app/src/main/java/almlk/JavaAttributor.java"
  G_IR="$ZIP52/app/src/main/java/almlk/JavaImportResolver.java"
  G_QF="$ZIP52/app/src/main/java/almlk/QuickFix.java"
  G_ED="$ZIP52/app/src/main/java/com/almlkid/kay/ui/AlmlkEditor.java"
  G_BU="$ZIP52/app/src/main/java/almlk/QuickFixBubble.java"
  n_choices=$(grep -c "importChoices(" "$G_AT" 2>/dev/null); n_choices=${n_choices:-0}
  n_agent=$(grep -c "unknownTypeChoices(" "$G_AT" 2>/dev/null); n_agent=${n_agent:-0}
  n_err=$(grep -c "errorChoices(" "$G_AT" 2>/dev/null); n_err=${n_err:-0}
  # ‏1.0.197 (ج٤٦): مَوَاضِعُ الجَهلِ صَارَت تَمُرُّ بِـ‏unknownTypeChoices (وَهِيَ تَسأَلُ importChoices
  # وَحدَهَا ثُمَّ تُتِمُّ بِصَفِّ البِناءِ). العِدَادُ القَديمُ عَنَى أن لا مَوضِعَ بِلا صَاحِبِ قَرَارٍ —
  # فَصِيغَتِ القَاعِدَةُ نَفسُهَا أَضَيَقَ: لا نِدَاءَ مُبَاشِرًا عِندَ البَلاغِ (صِفرٌ)، وَكُلُّ مَوضِعٍ
  # عِندَ الوَكِيلِ (≥3: تَعرِيفٌ وَنِدَاءَانِ)، وَلا يَسقُطُ سَقفُ الجَدوَلِ الكَثيرِ الصُّفوفِ.
  if [ "$n_choices" -ge 2 ] && [ "$n_agent" -ge 3 ] && [ "$n_err" -ge 4 ] \
  && ! grep -qF '"ui_diagnostic_unknown_type", "Unknown type '"'"'%1$s'"'"', importChoices(' "$G_AT" 2>/dev/null \
  && ! grep -qF 'importFixFor(' "$G_AT" 2>/dev/null; then
    ok "قَرارٌ واحِدٌ مُتَعَدِّدُ الصُّفوفِ: ‏importChoices‏ يُولِّدُ \"‏Add 'import …'‏\" وَالتَّوأَمُ المَيِّتُ زَال، وَكُلُّ جَهلٍ عِندَ unknownTypeChoices"
  else bad "مَسارُ القَرارِ" "قَرارٌ مُكرَّرٌ أو صَفٌّ وَحيدٌ بِلا بَديلٍ — نِدَاءَاتُ الصُّفوفِ $n_choices، وَالوَكِيلُ $n_agent، وَالوَاجِهَةُ $n_err"; fi
  if grep -qF "out.size() < AnalyzerProtocol.MAX_FIXES" "$G_AT" 2>/dev/null \
  && grep -qF "if (!JavaImportResolver.needsImport(src, candidate)) continue;" "$G_AT" 2>/dev/null; then
    ok "حَدَّانِ لِلعَرضِ: سَقفُ ‏MAX_FIXES‏ ولا صَفَّ بِلا خُطَّةِ إِدرَاجٍ"
  else bad "حُدودُ العَرضِ" "زِرٌّ مَيِّتٌ يُمكِنُ أن يَخرُجَ أو قائمةٌ لا تَنتَهي"; fi
  if grep -qF "resolution.kind == JavaImportResolver.Resolution.Kind.UNIQUE" "$G_AT" 2>/dev/null \
  && grep -qF "resolution.kind != JavaImportResolver.Resolution.Kind.AMBIGUOUS" "$G_AT" 2>/dev/null \
  && grep -qF "resolution.candidates" "$G_AT" 2>/dev/null; then
    ok "الحالاتُ الثَّلاثُ مَفرُوزَةٌ: الوَحيدُ صَفٌّ، والمُتَزاحِمُ صُفوفٌ، وَلا شَيءَ صِفرٌ"
  else bad "تَفرِيعُ الحُكمِ" "حالةٌ تَسقُطُ عَلى غَيرِ حَكمِها"; fi
  if grep -qF 'public static boolean alreadyCovered(String source, String qualifiedName)' "$G_IR" 2>/dev/null \
  && grep -qF "return !alreadyCovered(source, qualifiedName);" "$G_IR" 2>/dev/null; then
    ok "الحارسُ لَم يُضعَف: النَّجمَةُ تَشمَلُ، والاستيرادُ الثانِي بِالإِسمِ الواحِدِ مَمْنُوعٌ (جَوازُ اللُّغَةِ)"
  else bad "حارسُ الاستيرادِ" "أُبيحَ ادِّعاءٌ كانَ يَرفُضُهُ المُتَرجِمُ نَفسُهُ"; fi
  amb=$(awk '/private void reportOnDemandAmbiguity\(\) \{/,/^  \}/' "$G_AT" 2>/dev/null)
  if printf '%s' "$amb" | grep -qF "ui_diagnostic_ambiguous_type" \
  && printf '%s' "$amb" | grep -qF "null," \
  && ! printf '%s' "$amb" | grep -qF "importChoices("; then
    ok "تَزاحُمُ النَّجمَتَينِ بَلا صَفٍّ عَمدًا — التَّأجيلُ مُثبَّتٌ في الحَزمَةِ لا في الذّاكِرَةِ"
  else bad "تَأجيلُ الغموضِ" "صَفٌّ قُدِّمَ قَبلَ أن يُوجَدَ لَهُ مُنفِّذٌ"
  fi
  if grep -qF 'if (kind == Kind.ADD_IMPORT) return kind + ":" + importName;' "$G_QF" 2>/dev/null \
  && grep -qF "if (fix == null || !seen.add(fix.key())) continue;" "$G_ED" 2>/dev/null \
  && grep -qF "for (Entry entry : entries) rows.addView(buildRow(inflater, entry));" "$G_BU" 2>/dev/null; then
    ok "مِنَ القَرارِ إلى الصَّفِّ: قُفلٌ واحِدٌ وَبَصمَةٌ تُمَيِّزُ وَصَفٌّ مِن قَوائِمَ لا صَفَّانِ"
  else bad "سِلسِلَةُ العَرضِ" "الوَصفانِ يَتَجَاهَلانِ أو الفقاعَةُ تَقطَعُ الباقِيَ"; fi
  n_menu=$(awk '/name="menu_add_import"/{c++} END{print c+0}' "$ZIP52/app/src/main/res/values/strings.xml" 2>/dev/null)
  n_ar=$(awk '/name="menu_add_import"/{c++} END{print c+0}' "$ZIP52/app/src/main/res/values-ar/strings.xml" 2>/dev/null)
  if [ "${n_menu:-0}" = "1" ] && [ "${n_ar:-0}" = "0" ] \
  && grep -qF "Add 'import %s'" "$ZIP52/app/src/main/res/values/strings.xml" 2>/dev/null; then
    ok "لا مِفتاحَ اختَرَعناهُ: قُفلٌ واحِدٌ يَحمِلُ كُلَّ حِزمَةٍ، وَالعَرَبيَّةُ تَقرَأُ الوَصفَ لاتِينِيَّ الحَرفِ كَما في «‏Add …‏» قَبلَنا"
  else bad "مَفاتيحُ الوَاجِهَةِ" "بِدعَةٌ في القُفولِ أو تَركيبٌ خارِجَ قَوائِمَ اللُّغَةِ"; fi
  if grep -qF 'importChoiceStage194();' "$ZIP52/qa/RegressionSuite.java" 2>/dev/null \
  && grep -q "^## 65)" "$ZIP52/PROJECT_STATE.md" 2>/dev/null \
  && ls "$ZIP52"/reports/ 2>/dev/null | grep -q "w43_" \
  && grep -qF "needsImport" "$ZIP52"/reports/w43_*.md 2>/dev/null; then
    ok "المَرحَلَةُ مُسَجَّلَةٌ، و§65م، وَالوَرقةُ تَقولُ شَرطَ «لا زِرَّ بِلا أَثَرٍ» كَمَا هُوَ"
  else bad "أورَاقُ الجَولَةِ" "لا مَرحَلَةَ ج٤٣ أو لا §65م أو وَرقةٌ لا تُثبِتُ الشُّروطَ"; fi
else bad "فكُّ الحزمةِ" "لا يُقرَأُ zip المَصادِرِ"; fi

if [ -f "$APK" ]; then
  TMP52=$(mktemp -d)
  unzip -oq "$APK" "classes*.dex" "resources.arsc" -d "$TMP52" 2>/dev/null
  if grep -lq "Lalmlk/JavaImportResolver;" "$TMP52"/classes*.dex 2>/dev/null \
  && grep -alq "Add 'import %s'" "$TMP52"/resources.arsc 2>/dev/null; then
    ok "الحُزمَةُ تَحمِلُ صانِعَ الصُّفوفِ وَقافِلَها مَعا"
  else bad "الحُزمَةُ" "آليَّةُ العَرضِ لم تَصِلْ إلى الـdex أو القُفلُ غَابَ عَنِ المَوارِدِ"; fi
  if grep -qE "^[[:space:]]*versionCode [0-9]+" app/build.gradle 2>/dev/null \
  && grep -q "^$VERSION$" VERSION 2>/dev/null; then
    ok "بَصمَةُ ج٤٣ بَاقِيَةٌ صَحِيحَةً: ‏$VERSION‏ وَوَسمُ الكودِ حاضِرٌ (بِلا رَقمٍ مُثبَّتٍ يُكسِرُ الجَولاتِ)"
  else bad "البَصمَةُ" "وَسمُ الإصدارِ غيرُ مُتَّفِقٍ مَعَ مَلفِّهِ"; fi
  rm -rf "$TMP52"
else bad "حزمةُ ‏$VERSION‏" "لا APKَ في deliverables"; fi
rm -rf "$ZIP52"

# ═════════ [53] جولة ٤٤: يَقينُ الأصلِ المَكتَبيِّ ثَلاثَةُ أَحوَالٍ، وَنَوعُ الإرجَاعِ يَعدُو ═════════
echo "── [53] جَولَةُ ٤٤: مَا ثَبَتَ يُطلَبُ، وَمَا وَراءَ الحِجَابِ يُعلَنُ، وَلا «void» يَحكُمُ مَحَلَّ «int» ──"
ZIP53=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZIP53" 2>/dev/null; then
  G_AG="$ZIP53/app/src/main/java/almlk/AbstractImplementationGap.java"
  G_TM="$ZIP53/app/src/main/java/almlk/JavaTypeModel.java"
  G_QF="$ZIP53/app/src/main/java/almlk/QuickFix.java"
  if grep -qF "public enum SupertypeState {" "$G_AG" 2>/dev/null \
  && grep -qF "public static SupertypeState worst(SupertypeState a, SupertypeState b)" "$G_AG" 2>/dev/null \
  && grep -qF "private static SupertypeState collectSource" "$G_AG" 2>/dev/null \
  && grep -qF "public boolean chainTruncated;" "$G_AG" 2>/dev/null; then
    ok "الحَالَةُ ثُلاثِيَّةٌ مُسَمَّاةٌ: الجَمعُ يُرجِعُ يَقينًا لا قَطعًا، وَالصِّفُّ يَحمِلُ الحِجَابَ"
  else bad "حَالَاتُ السِّلسِلَةِ" "بَقِيَتِ الحِجَابُ وَاليَقينُ شَيئًا واحِدًا"
  fi
  if grep -qF "if (state == SupertypeState.UNSEEN && out.isEmpty()) return null;" "$G_AG" 2>/dev/null; then
    ok "مَن لَم نَقُرَأْ مِنهُ قَطرَةً لا قَائِمَةَ لَهُ — فَالحِجَابُ لا يُختَرَعُ مِنهُ شَيءٌ"
  else bad "بَابُ العَدَمِ" "قَائِمَةٌ تُبنى مِنَ اللاشَيءِ"
  fi
  if grep -qF "md.result, md.result == null ? null : md.result.display(), md)" "$G_TM" 2>/dev/null; then
    ok "جِذرُ الجِسمِ الباطِلِ مَقطُوعٌ: نَصُّ الإِرجَاعِ يُحمَلُ مَعَ الرُّمزِ، فَلا «void» يَرِثُ «int»"
  else bad "نَصُّ الإِرجَاعِ" "المُولِّدُ سَيَكتُبُ void عَن جَديدٍ"
  fi
  if grep -qF "public boolean listMayBeIncomplete;" "$G_QF" 2>/dev/null \
  && grep -qF '"ui_quick_fix_implement_known_abstract"' "$G_QF" 2>/dev/null \
  && grep -qF "batch.listMayBeIncomplete = chainTruncated;" "$G_AG" 2>/dev/null; then
    ok "الصَّفُّ لا يَعِدُ بِـ«كُلِّهَا» تَحتَ الحِجَابِ: وَصفٌ بِـ«المَعلُومَةِ» وَالحَقلُ مُوصَلٌ"
  else bad "وَصفُ الدَّفَعَةِ" "«كُلَّها» تُقالُ حَيثُ يَمكِنُ أن تَزيدَ"
  fi
  for k in ui_diagnostic_must_implement_known_abstract_methods ui_quick_fix_implement_known_abstract; do
        n_en=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP53/app/src/main/res/values/strings.xml" 2>/dev/null)
    n_ar=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP53/app/src/main/res/values-ar/strings.xml" 2>/dev/null)
    if [ "$n_en" = "1" ] && [ "$n_ar" = "1" ]; then ok "مِفتاحُ الجَولَةِ يتيمٌ في اللغتينِ: $k"
    else bad "مَفاتيحُ الجَولَةِ" "$k — en=$n_en ar=$n_ar"
    fi
  done
  if grep -qF 'supertypeStateStage195();' "$ZIP53/qa/RegressionSuite.java" 2>/dev/null \
  && grep -q "^## 66)" "$ZIP53/PROJECT_STATE.md" 2>/dev/null \
  && ls "$ZIP53"/reports/ 2>/dev/null | grep -q "w44_" \
  && grep -qF "TYPES_UNRENDERABLE" "$ZIP53"/reports/w44_*.md 2>/dev/null; then
    ok "المَرحَلَةُ مُسَجَّلَةٌ، و§66م، وَالوَرقةُ تُثبِتُ الحَدَّ المَعلُومَ لا تُخفيهِ"
  else bad "أورَاقُ الجَولَةِ" "لا مَرحَلَةً أو لا §66م أو وَرقةٌ لا تُسَمِّي الحَدَّ"
  fi
else bad "فكُّ الحزمةِ" "لا يُقرَأُ zip المَصادِرِ"
fi

if [ -f "$APK" ]; then
  TMP53=$(mktemp -d)
  unzip -oq "$APK" "classes*.dex" "resources.arsc" -d "$TMP53" 2>/dev/null
  if grep -lq "Lalmlk/AbstractImplementationGap\$SupertypeState;" "$TMP53"/classes*.dex 2>/dev/null; then
    ok "الحَالَةُ الثُّلاثِيَّةُ فِي الدكسِ: صِنفٌ جَديدٌ وصَلَ المَحمُولَ لا المَصدَرَ فَقط"
  else bad "الدكسُ" "الحَالَةُ بَاقِيَةٌ في المَصدَرِ"
  fi
  if grep -alq "Implement the known abstract methods" "$TMP53"/resources.arsc 2>/dev/null; then
    ok "المَواردُ تَحمِلُ وَصفَ الدَّفَعَةِ النَّاقِصَةِ"
  else bad "المَوارِدُ" "وَصفٌ جَديدٌ لم يَدخُلِ الـarsc"
  fi
  if grep -qE "^[[:space:]]*versionCode [0-9]+" app/build.gradle 2>/dev/null \
  && grep -q "^$VERSION$" VERSION 2>/dev/null; then
    ok "بَصمَةُ جَولَةِ الحَالَاتِ الثُّلاثِيَّةِ: ‏$VERSION‏ في ‏VERSION‏ (و‏versionCode‏ في بَابِ دَورِهِ)"
  else bad "البَصمَةُ" "رَقمُ الجَولَةِ غَيرُ مُتَّصِلٍ"
  fi
  rm -rf "$TMP53"
else bad "حزمةُ ‏$VERSION‏" "لا APKَ في deliverables"; fi
rm -rf "$ZIP53"


# ═════════ [54] جولة ٤٥: نوعُ الأصلِ مُحَلٌّ، وأقواسُ المصفوفةِ نوعٌ، وصنفُ الحزمةِ صنفٌ
echo "── [54] جَولَةُ ٤٥: ما كَتَبَهُ مُفسِّرُ الأصلِ يُكتَبُ في الوارثِ، وَالأَقواسُ لا تُطرَحُ، وَالحِزمَةُ لا تُجحَدُ"
ZIP54=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZIP54" 2>/dev/null; then
  H_AG="$ZIP54/app/src/main/java/almlk/AbstractImplementationGap.java"
  if grep -qF "private static boolean knownProjectClass(String qualified)" "$H_AG" 2>/dev/null \
  && grep -qF "if (knownProjectClass(sibling)) return sibling;" "$H_AG" 2>/dev/null \
  && ! grep -qF "JavaProjectModel.knows(" "$H_AG" 2>/dev/null; then
    ok "وارثٌ في حزمةِ أبيهِ يُشخَّصُ: سِجلُّ الأسماءِ سُئِلَ، وسِجلُّ مراجعِ الملفاتِ رُفِعَ عنهُ"
  else bad "حِسمَةُ حِزمةِ الملفِّ" "اسمُ صِنفٍ يُطلَبُ من سِجلٍّ لا يَعرِفُ إلّا المَسارَ"
  fi
  if grep -qF "StringBuilder dims = new StringBuilder(); // «‏int[]» ← «‏int» + «‏[]»، لا «‏int» وَحدَهُ" "$H_AG" 2>/dev/null \
  && grep -qF 'while (type.endsWith("[]")) {' "$H_AG" 2>/dev/null \
  && grep -qF 'return written == null ? null : written + dims;' "$H_AG" 2>/dev/null; then
    ok "أقواسُ المصفوفَةِ مَحمولَةٌ إلى آخرِ السَّطرِ: «int[] counts()» لا يَخرُجُ «int counts()»"
  else bad "أقواسُ المصفوفَةِ" "عَددُها يَضيعُ فَيُولَّدُ تَنفِيذٌ لا يُترجَمُ"
  fi
  if grep -qF "String returnType = described(type, method.decl.result);" "$H_AG" 2>/dev/null \
  && grep -qF "String known = described(type, method.decl.params.get(i).type);" "$H_AG" 2>/dev/null \
  && grep -qF "if (returnType == null) returnType = method.returnText;" "$H_AG" 2>/dev/null; then
    ok "النَّوعُ يُحمَلُ كَمَا حَلَّهُ مُفسِّرُ مِلَفِّ الأصلِ، والنَّصُّ المَكتوبُ مَرجِعٌ لا أصلُ حُكمٍ"
  else bad "حamlُ النوعِ" "الدَّفعَةُ تَقرَأُ نصَّ الأصلِ ولا تَقرَأُ ما عَناهُ"
  fi
  if grep -qF "private static boolean nameableFrom(String qualified, String ownPackage)" "$H_AG" 2>/dev/null \
  && grep -qF "if (declared == null || !declared.mods.has(JavaSyntaxTree.PUBLIC)) return false;" "$H_AG" 2>/dev/null; then
    ok "صِنفٌ حِزمِيُّ الرُّؤيَةِ مِن وراءِ حِزمَتِهِ لا يُكتَبُ ولا يُستورَدُ — الحِسابُ لِلرُّؤيَةِ قَبلَ الاسمِ"
  else bad "رُؤيةُ الصِّنفِ" "شيفرةٌ لا تُترجَمُ بِعِناوَةِ إصلاحٍ"
  fi
  if [ "$(grep -c 'if (knownProjectClass(type))' "$H_AG" 2>/dev/null)" = "1" ] \
  && [ "$(grep -n 'if (knownProjectClass(type))\|if (!(AndroidApiIndex.isKnownPackage(head)' "$H_AG" 2>/dev/null | head -1 | cut -d: -f1)" = "$(grep -n 'if (knownProjectClass(type))' "$H_AG" 2>/dev/null | head -1 | cut -d: -f1)" ]; then
    ok "تَرتيبُ الحُكمِ مُثبَّتٌ: صِنفُ المَشرُوعِ قَبلَ «باقةٍ مَعرُوفَةٍ لِلأَصحَارِ» — فَالأُخرَى تَكذِبُ عِندَ كُلِّ أجَرَةِ ‏com.*‏"
  else bad "تَرتيبُ الحُكمِ" "فَهرَسُ المَنصَّةِ يَسبِقُ صِنفَ المَشرُوعِ فَتُبسَّطُ ما لا تُرى"
  fi
  if grep -qF "private static boolean shadowed(String flat, String qualified, List<String> fileImports," "$H_AG" 2>/dev/null \
  && grep -qF "return shadowed(flat, type, fileImports, ownPackage, declaredHere) ? type : flat;" "$H_AG" 2>/dev/null \
  && grep -qF "gap.declaredHere = declaredTypeNames(unit);" "$H_AG" 2>/dev/null; then
    ok "حُكمُ الظِّلِّ (‏JLS 6.4.1‏): سِطرٌ آخَرُ أو صِنفٌ في المِلَفِّ يَمْنَعانِ التَّقرِيبَ، فَلا اسمٌ مُختَلَسٌ"
  else bad "ظِلُّ الأَسمَاءِ" "java.lang مُستَثنًى استِثناءً أعمَى"
  fi
  if grep -qF 'resolvedTypeStage196();' "$ZIP54/qa/RegressionSuite.java" 2>/dev/null \
  && grep -q "^## 67)" "$ZIP54/PROJECT_STATE.md" 2>/dev/null \
  && ls "$ZIP54"/reports/ 2>/dev/null | grep -q "w45_" \
  && grep -qF "knownProjectClass" "$ZIP54"/reports/w45_*.md 2>/dev/null; then
    ok "المَرحَلَةُ مُسَجَّلَةٌ، و§67م، وَالوَرقةُ تُسَمِّي الصَّمتَ الحِزمِيَّ بَعدَ اسمِهِ"
  else bad "أورَاقُ الجَولَةِ" "لا مَرحَلَةَ ١٩٦م، أو لا §67م، أو وَرقةٌ لا تُسَمِّي العُقدَةَ"
  fi
else bad "فكُّ الحزمةِ" "لا يُقرَأُ zip المَصادِرِ"
fi
rm -rf "$ZIP54"

if [ -f "$APK" ]; then
  TMP54=$(mktemp -d)
  unzip -oq "$APK" "classes*.dex" -d "$TMP54" 2>/dev/null
  for m in knownProjectClass nameableFrom declaredTypeNames qualifiedOf; do
    if grep -lq "$m" "$TMP54"/classes*.dex 2>/dev/null; then ok "الدكسُ يَحملُ $m — الآلِيَّةُ وصَلَتِ المَحمُولَ"
    else bad "الدكسُ" "$m لَم يَصِلِ المَحمُولَ"
    fi
  done
  if grep -qE "^[[:space:]]*versionCode [0-9]+" app/build.gradle 2>/dev/null && grep -q "^$VERSION$" VERSION 2>/dev/null; then
    ok "بَصمَةُ جَولَةِ النَّوعِ المُحَلِّ تَبقَى صَحِيحَةً (لا رَقمَ مُثبَّتًا يُكسِرُ الجَولاتِ)"
  else bad "البَصمَةُ" "رَقمُ الجَولَةِ غَيرُ مُتَّصِلٍ"
  fi
  rm -rf "$TMP54"
else bad "حزمةُ ‏$VERSION‏" "لا APKَ في deliverables"; fi


# ═════════ [55] جولة ٤٦: «Create class 'X'» — صَفٌّ يَكتُبُ مِلَفًّا فِي باقَتِهِ ═════════
echo "── [55] جَولَةُ ٤٦: لا صَفَّ بِلا مِلَفٍّ، وَلا مِلَفَّ بِلا بَاقَةٍ، وَلا تَراجُعًا زُورًا ──"
ZIP55=$(mktemp -d)
if unzip -q "$ZIP" -d "$ZIP55" 2>/dev/null && [ -s "$ZIP55/PROJECT_STATE.md" ]; then
  H55_PLAN="$ZIP55/app/src/main/java/almlk/CreateClassPlan.java"
  H55_LAY="$ZIP55/app/src/main/java/almlk/SourceLayout.java"
  H55_TPL="$ZIP55/app/src/main/java/almlk/SourceTemplates.java"
  H55_QF="$ZIP55/app/src/main/java/almlk/QuickFix.java"
  H55_AT="$ZIP55/app/src/main/java/almlk/JavaAttributor.java"
  H55_EX="$ZIP55/app/src/main/java/almlk/QuickFixExecutor.java"
  H55_BR="$ZIP55/app/src/main/java/com/almlkid/ui/browsers/BrowserPager.java"
  H55_MA="$ZIP55/app/src/main/java/com/shima/demo/MainActivity.java"
  if [ -s "$H55_PLAN" ] && [ -s "$H55_LAY" ] && [ -s "$H55_TPL" ]; then
    ok "الأَداةُ الثَّلاثَةُ فِي الحَزمَةِ: خُطَّةٌ، وَقَاعِدَةُ وَضعٍ، وَقَوَالِبُ وَاحِدَةٌ"
  else bad "أَداةُ الجَولَةِ" "لا zipَ كامِلًا (فَضاءُ /tmp؟) أو أَحَدُ المَلَفّاتِ الثَّلاثَةِ فارِغٌ"
  fi
  if grep -qF '    CREATE_TYPE,' "$H55_QF" 2>/dev/null \
  && grep -qF "public CreateClassPlan createType;" "$H55_QF" 2>/dev/null \
  && grep -qF 'if (kind == Kind.CREATE_TYPE) return "menu_create_class";' "$H55_QF" 2>/dev/null \
  && grep -qF 'public static QuickFix createType(CreateClassPlan plan) {' "$H55_QF" 2>/dev/null \
  && grep -qF 'if (plan == null) return null;' "$H55_QF" 2>/dev/null; then
    ok "جِنسٌ وَاحِدٌ وَخُطَّةٌ وَاحِدَةٌ: بِلا خُطَّةٍ لا إِصلاحَ (لا صَفَّ يُعرَضُ ثُمَّ يَخزُو)"
  else bad "عَقدُ الإِصلاحِ" "جِنسٌ بِلا حَقلٍ، أو صانِعٌ يَقْبَلُ الفارِغَ"
  fi
  if [ "$(grep -c 'unknownTypeChoices(first)' "$H55_AT" 2>/dev/null)" = "2" ] \
  && grep -qF 'QuickFix ownRow = pkg.equals(file.packageName) ? createClassRow(last) : null;' "$H55_AT" 2>/dev/null \
  && ! grep -qF '"ui_diagnostic_unknown_type", "Unknown type '"'"'%1$s'"'"'", importChoices(' "$H55_AT" 2>/dev/null; then
    ok "صَفُّ البِناءِ زِيدَ عَلى مَوَاضِعِ الجَهلِ الثَّلاثَةِ — وَمَا سِوَاهَا عَلى حَالِهِ مِن غَيرِ مَخرَجٍ"
  else bad "مَوَاضِعُ العَرضِ" "زِيدَ حَيثُ لا يَنبَغِي، أو نُقِصَ حَيثُ كَانَ الوَعْدُ وَاجِبًا"
  fi
  EX55=$(awk '/if \(fix.kind == QuickFix.Kind.CREATE_TYPE\) \{/,/^    \}$/' "$H55_EX" 2>/dev/null)
  if printf '%s' "$EX55" | grep -qF 'if (!host.createType(fix)) toast(text("ui_create_class_unavailable"));' \
  && printf '%s' "$EX55" | grep -qF 'return;' \
  && ! printf '%s' "$EX55" | grep -qE 'planInsertion|applyTo|createdKey'; then
    ok "المَنفِّذُ يُفَوِّضُ وَلا يَدَّعِي: لا نِطاقَ يُفتَحُ، لا «أُنشِئَ» قَبلَ الكِتابَةِ، لا تَراجُعًا"
  else bad "سِلكُ المَنفِّذِ" "إِمّا اِتَّصَلَ بِالمُضيفِ وَإِمّا وَعَدَ بِما لا يَمْلِكُ"
  fi
  if grep -qF 'default boolean createType(QuickFix fix) {' "$H55_EX" 2>/dev/null; then
    ok "عَقدُ المُضيفِ اختِيارِيٌّ: لا كَاتِبَ ← رَساءِلُ عُذرٍ، لا صَمتٌ وَلا أَثرٌ زَائِفٌ"
  else bad "عَقدُ المُضيفِ" "أُوجِبَ عَلى كُلِّ وَاجِهَةٍ أو حُذِفَ العُذرُ"
  fi
  if grep -qF 'createClassArtifacts(dir, className, 0, false, false, "", onSettled)' "$H55_BR" 2>/dev/null \
  && grep -qF 'return almlk.SourceLayout.packageOfDirectory(path);' "$H55_BR" 2>/dev/null \
  && grep -qF 'return almlk.SourceTemplates.classCodeFor(kind, pkg, name, withLayout, layoutName);' "$H55_BR" 2>/dev/null \
  && [ "$(grep -c 'registerComponentInManifest' "$H55_BR" 2>/dev/null)" = "2" ]; then
    ok "كَما فِي المَصدَرِ: صِنفٌ صَرِيحٌ لا نَشَاطٌ، القَاعِدَةُ مُفَوَّضَةٌ، وَالمَانيفستُ لِلحِوَارِ وَحدَهُ"
  else bad "طَرِيقُ الكِتابَةِ" "تَسنِيدٌ أو قَالَبٌ مُوازٍ سَرَبَ إلى صَفِّ الإِصلاحِ"
  fi
  REG55=$(grep -n 'ProjectSymbolIndex.registerSource(' "$H55_BR" 2>/dev/null | sed -n '2p' | cut -d: -f1)
  INV55=$(grep -n 'invalidateDirectory(fileCacheKey(parentDir))' "$H55_BR" 2>/dev/null | head -1 | cut -d: -f1)
  SET55=$(grep -n 'onSettled.accept(Boolean.TRUE)' "$H55_BR" 2>/dev/null | head -1 | cut -d: -f1)
  if [ -n "$REG55" ] && [ -n "$INV55" ] && [ -n "$SET55" ] \
  && [ "$REG55" -lt "$INV55" ] && [ "$INV55" -lt "$SET55" ]; then
    ok "التَّرتِيبُ صَحِيحٌ: الفَهرَسَةُ، ثُمَّ تَحدِيثُ الشَّجَرَةِ، ثُمَّ الخَبَرُ — فَيَرَى الفَحصُ قَبلَ أن نَتكَلَّمَ"
  else bad "تَرتِيبُ الأَثَرِ" "خَبَرٌ قَبلَ الفَهرَسَةِ يَعنِي صَفًّا يَبقَى بَعدَ النَّجَاحِ (سَطْرُ الفَهرَسَةِ=$REG55 تَحدِيثٌ=$INV55 خَبَرٌ=$SET55)"
  fi
  if grep -qF 'if (!editor.isActiveFileWritableNow()) return false;' "$H55_MA" 2>/dev/null \
  && grep -qF 'almlk.SourceLayout.directoryOf(android.net.Uri.decode(reference))' "$H55_MA" 2>/dev/null \
  && grep -qF 'if (written.booleanValue()) {' "$H55_MA" 2>/dev/null \
  && grep -qF 'quickFixApplied(fix, plan.fileName);' "$H55_MA" 2>/dev/null; then
    ok "المُضيفُ يَسأَلُ الدَّرَجَ قَبلَ الوَعدِ، وَلا يُعِيدُ الفَحصَ إِلا بَعدَ أن يَنزِلَ المِلَفُّ"
  else bad "سِيَادَةُ المُضيفِ" "قَبِلَ قَبلَ أن يَتَحَقَّقَ، أو أعلَنَ قَبلَ أن يَكتُبَ"
  fi
  if ! grep -qE 'append\("( *//|/\*)' "$H55_TPL" 2>/dev/null \
  && grep -qF 'code.append("public class ").append(name).append(" {\n\n}\n");' "$H55_TPL" 2>/dev/null; then
    ok "قَاعِدَةُ ج٣٦ عَلى قَالَبِ المِلَفِّ: صِنفٌ خَالٍ، صِفرَ سَطَرَ تَعلِيقٍ فِيمَا نُولِّدُهُ"
  else bad "قَوَالِبُ المِلَفّاتِ" "تَعلِيقٌ تَسَلَّلَ إلى المَكتُوبِ، أو غُيِّرَ القَالَبُ عَن وَصفِهِ"
  fi
  for k in menu_create_class ui_class_created ui_create_class_unavailable; do
    n_en=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP55/app/src/main/res/values/strings.xml" 2>/dev/null)
    n_ar=$(awk "/name=\\\"$k\\\"/{c++} END{print c+0}" "$ZIP55/app/src/main/res/values-ar/strings.xml" 2>/dev/null)
    if [ "${n_en:-0}" = "1" ] && [ "${n_ar:-0}" = "1" ]; then ok "مِفتاحُ الجَولَةِ يَتيمٌ فِي اللغَتَينِ: $k"
    else bad "مَفاتيحُ الجَولَةِ" "$k — en=$n_en ar=$n_ar"
    fi
  done
  if grep -qF 'createTypeStage197();' "$ZIP55/qa/RegressionSuite.java" 2>/dev/null \
  && grep -q "^## 68)" "$ZIP55/PROJECT_STATE.md" 2>/dev/null \
  && ls "$ZIP55"/reports/ 2>/dev/null | grep -q "w46_" \
  && grep -qF "AndroidManifest" "$ZIP55"/reports/w46_*.md 2>/dev/null \
  && grep -qF "Ctrl+Z" "$ZIP55"/reports/w46_*.md 2>/dev/null \
  && grep -qF "javac" "$ZIP55"/reports/w46_*.md 2>/dev/null; then
    ok "المَرحَلَةُ مُسَجَّلَةٌ، و§68م، وَالوَرقةُ تُسَمِّي المَانيفستَ وَالتَّراجُعَ وَمِقياسَ javacَ"
  else bad "أورَاقُ الجَولَةِ" "لا مَرحَلَةً، أو لا §68م، أو وَرقةٌ لا تُثبِتُ القَرارَ الثَّلاثَةَ"
  fi
else bad "فكُّ الحزمةِ" "لم تُفَكَّ الحِزمَةُ (فَضاءُ /tmp؟) — وَلا حُكمَ عَلى غَيرِ مَقرُوءٍ"
fi
rm -rf "$ZIP55"

if [ -f "$APK" ]; then
  TMP55=$(mktemp -d)
  unzip -oq "$APK" "classes*.dex" "resources.arsc" -d "$TMP55" 2>/dev/null
  for c in "Lalmlk/CreateClassPlan;" "Lalmlk/SourceLayout;" "Lalmlk/SourceTemplates;"; do
    if grep -alq "$c" "$TMP55"/classes*.dex 2>/dev/null; then ok "الدكسُ يَحملُ $c — صَفُّ البِناءِ مَحمُولٌ لا مَصدَرٌ فَقط"
    else bad "الدكسُ" "$c لَم يَصِلْ إلى الحِملِ"
    fi
  done
  if grep -alq "Create class '" "$TMP55"/resources.arsc 2>/dev/null; then
    ok "المَواردُ تَحمِلُ وَصفَ الصَّفِّ «‏Create class 'X' in 'pkg'‏»"
  else bad "المَواردُ" "وَصفٌ جَديدٌ لَم يَدخُلِ الـarsc"
  fi
  if grep -q 'versionCode 47' app/build.gradle 2>/dev/null && grep -q "^1.0.197$" VERSION 2>/dev/null; then
    ok "بَصمَةُ هذِهِ الجَولَةِ: ‏1.0.197‏ و‏versionCode 47‏"
  else bad "البَصمَةُ" "رَقمُ الجَولَةِ غَيرُ مُتَّصِلٍ"
  fi
  rm -rf "$TMP55"
else bad "حزمةُ ‏$VERSION‏" "لا APKَ في deliverables"; fi

echo "Acceptance: passed=$PASS failed=$FAIL"
echo "══════════════════════════════════════════════════════"
[ $FAIL -eq 0 ] || exit 1

