package almlk;

/**
 * مسبار اختباري فقط — ليس جزءًا من الشيفرة المشحونة.
 *
 * <p>بنّاء {@link XmlColorLiteral} مقصودًا package-private (يُنتَج من {@code LineStyler} وحده).
 * بدل توسيع API الإنتاج لأجل الاختبار، يقف هذا المسبار داخل الحزمة نفسها فيشغّل البنّاء كما هو.
 * موجود تحت {@code qa/probes/} فلا يراه Gradle ولا يدخل الحزمة.
 */
public final class ColorLiteralFactory {

  private ColorLiteralFactory() {}

  public static XmlColorLiteral make(
      int line, int startColumn, int endColumn, int argb, XmlColorLiteral.Format format) {
    return new XmlColorLiteral(line, startColumn, endColumn, argb, format);
  }
}
