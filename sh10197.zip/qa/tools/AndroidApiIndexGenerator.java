import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import javax.tools.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/**
 * Builds the offline completion indexes shipped in {@code assets/completion/} from the official
 * Android SDK platform (never from the reference project):
 *
 * <ul>
 *   <li>{@code android-api.idx.gz} — public classes with members, typed signatures and parameter
 *       names (from {@code android-stubs-src.jar}) plus API levels (from {@code api-versions.xml}).
 *   <li>{@code android-xml.idx.gz} — XML attributes with formats/enum values (data/res attrs.xml),
 *       and styleables (the element list is derived at runtime from the class hierarchy).
 * </ul>
 *
 * Usage: java AndroidApiIndexGenerator.java &lt;platformDir&gt; &lt;assetsCompletionDir&gt;
 */
public final class AndroidApiIndexGenerator {

  static final class Level { int since, deprecated, removed; }

  static final Map<String, Level> CLASS_LEVELS = new HashMap<>();
  static final Map<String, Level> MEMBER_LEVELS = new HashMap<>(); // binary#name(desc
  static final Map<String, Level> MEMBER_LEVELS_LOOSE = new HashMap<>(); // binary#name/argc
  static final Set<String> BINARY_NAMES = new HashSet<>();

  public static void main(String[] args) throws Exception {
    Path platform = Paths.get(args[0]);
    Path out = Paths.get(args[1]);
    Files.createDirectories(out);
    readApiVersions(platform.resolve("data/api-versions.xml"));
    writeGz(out.resolve("android-api.idx.gz"), buildApi(platform.resolve("android-stubs-src.jar")));
    writeGz(out.resolve("android-xml.idx.gz"), buildXml(platform));
  }

  // ───────────────────────────── api-versions.xml ─────────────────────────────

  static Level level(Element e, Level parent) {
    Level l = new Level();
    l.since = intAttr(e, "since", parent == null ? 1 : parent.since);
    l.deprecated = intAttr(e, "deprecated", parent == null ? 0 : parent.deprecated);
    l.removed = intAttr(e, "removed", parent == null ? 0 : parent.removed);
    return l;
  }

  static int intAttr(Element e, String name, int fallback) {
    String v = e.getAttribute(name);
    if (v == null || v.isEmpty()) return fallback;
    try { return Integer.parseInt(v.split(":")[0].trim()); } catch (NumberFormatException ex) { return fallback; }
  }

  static void readApiVersions(Path file) throws Exception {
    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file.toFile());
    NodeList classes = doc.getElementsByTagName("class");
    for (int i = 0; i < classes.getLength(); i++) {
      Element c = (Element) classes.item(i);
      String binary = c.getAttribute("name").replace('/', '.');
      BINARY_NAMES.add(binary);
      Level cl = level(c, null);
      CLASS_LEVELS.put(binary, cl);
      NodeList kids = c.getChildNodes();
      for (int k = 0; k < kids.getLength(); k++) {
        if (!(kids.item(k) instanceof Element)) continue;
        Element m = (Element) kids.item(k);
        String tag = m.getTagName();
        if (!tag.equals("method") && !tag.equals("field")) continue;
        Level ml = level(m, cl);
        String name = m.getAttribute("name");
        if (tag.equals("field")) {
          MEMBER_LEVELS.put(binary + "#" + name, ml);
        } else {
          int paren = name.indexOf('(');
          String simple = name.substring(0, paren);
          String desc = name.substring(paren, name.indexOf(')') + 1);
          MEMBER_LEVELS.put(binary + "#" + simple + desc, ml);
          MEMBER_LEVELS_LOOSE.putIfAbsent(binary + "#" + simple + "/" + argCount(desc), ml);
        }
      }
    }
  }

  static int argCount(String desc) {
    int n = 0;
    for (int i = 1; i < desc.length() && desc.charAt(i) != ')'; i++) {
      char ch = desc.charAt(i);
      while (ch == '[') ch = desc.charAt(++i);
      if (ch == 'L') i = desc.indexOf(';', i);
      n++;
    }
    return n;
  }

  // ───────────────────────────── stubs → class/member lines ─────────────────────────────

  static final class TypeScope {
    final Map<String, String> bounds = new HashMap<>();
    final TypeScope parent;
    TypeScope(TypeScope parent) { this.parent = parent; }
    String bound(String name) {
      for (TypeScope s = this; s != null; s = s.parent) if (s.bounds.containsKey(name)) return s.bounds.get(name);
      return null;
    }
  }

  static String buildApi(Path stubs) throws Exception {
    JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
    StringBuilder out = new StringBuilder(4 << 20);
    out.append("#shima-android-api 1\n");
    TreeMap<String, String> blocks = new TreeMap<>();
    try (ZipFile zip = new ZipFile(stubs.toFile())) {
      List<JavaFileObject> sources = new ArrayList<>();
      for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements(); ) {
        ZipEntry entry = e.nextElement();
        if (!entry.getName().endsWith(".java")) continue;
        String text = new String(zip.getInputStream(entry).readAllBytes(), StandardCharsets.UTF_8);
        sources.add(new SimpleJavaFileObject(java.net.URI.create("string:///" + entry.getName()), JavaFileObject.Kind.SOURCE) {
          @Override public CharSequence getCharContent(boolean ignore) { return text; }
        });
      }
      JavacTask task = (JavacTask) javac.getTask(null, null, d -> {}, List.of("-proc:none"), null, sources);
      for (CompilationUnitTree unit : task.parse()) {
        String pkg = unit.getPackageName() == null ? "" : unit.getPackageName().toString();
        for (Tree t : unit.getTypeDecls())
          if (t instanceof ClassTree) emitClass(blocks, pkg, pkg, (ClassTree) t, new TypeScope(null), false);
      }
    }
    addOrphans(blocks);
    for (String block : blocks.values()) out.append(block);
    return out.toString();
  }

  static boolean visible(ModifiersTree mods, boolean inInterface) {
    Set<javax.lang.model.element.Modifier> f = mods.getFlags();
    return inInterface || f.contains(javax.lang.model.element.Modifier.PUBLIC)
        || f.contains(javax.lang.model.element.Modifier.PROTECTED);
  }

  static void emitClass(TreeMap<String, String> blocks, String pkg, String outerSource, ClassTree c,
      TypeScope outerScope, boolean outerInterface) {
    if (!visible(c.getModifiers(), outerInterface)) return;
    String sourceName = (outerSource.isEmpty() ? "" : outerSource + ".") + c.getSimpleName();
    String binary = binaryOf(sourceName);
    Level cl = CLASS_LEVELS.get(binary);
    if (cl == null) return; // not part of the public SDK surface
    boolean isInterface = c.getKind() == Tree.Kind.INTERFACE || c.getKind() == Tree.Kind.ANNOTATION_TYPE;
    TypeScope scope = new TypeScope(c.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.STATIC) || isInterface ? null : outerScope);
    StringBuilder typeParams = new StringBuilder();
    for (TypeParameterTree tp : c.getTypeParameters()) {
      scope.bounds.put(tp.getName().toString(), tp.getBounds().isEmpty() ? "java.lang.Object" : erasure(tp.getBounds().get(0), null));
      if (typeParams.length() > 0) typeParams.append(',');
      typeParams.append(tp.getName());
    }
    String kind = c.getKind() == Tree.Kind.INTERFACE ? "i" : c.getKind() == Tree.Kind.ENUM ? "e"
        : c.getKind() == Tree.Kind.ANNOTATION_TYPE ? "a" : "c";
    if (c.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.ABSTRACT) && kind.equals("c")) kind = "b";
    String sup = c.getExtendsClause() == null ? (kind.equals("e") ? "java.lang.Enum" : kind.equals("c") || kind.equals("b") ? "java.lang.Object" : "") : typeText(c.getExtendsClause());
    if (sourceName.equals("java.lang.Object")) sup = "";
    StringBuilder ifaces = new StringBuilder();
    for (Tree i : c.getImplementsClause()) { if (ifaces.length() > 0) ifaces.append(','); ifaces.append(typeText(i)); }
    StringBuilder b = new StringBuilder();
    // C name kind since deprecated removed super interfaces typeParams
    b.append("C\t").append(sourceName).append('\t').append(kind).append('\t').append(cl.since).append('\t')
        .append(cl.deprecated).append('\t').append(cl.removed).append('\t').append(sup).append('\t')
        .append(ifaces).append('\t').append(typeParams).append('\n');
    for (Tree member : c.getMembers()) {
      if (member instanceof VariableTree) {
        VariableTree v = (VariableTree) member;
        if (!visible(v.getModifiers(), isInterface)) continue;
        boolean enumConstant = kind.equals("e") && v.getType() != null && typeText(v.getType()).equals(sourceName);
        // A public member absent from api-versions.xml is one metalava copied from a hidden superclass
        // (e.g. StringBuilder ← AbstractStringBuilder): it is public API with the owner's level.
        Level ml = MEMBER_LEVELS.get(binary + "#" + v.getName());
        if (ml == null && !enumConstant) {
          orphan(sourceName, "F:" + v.getName(), "F\t" + v.getName() + "\t" + flags(isInterface
              || v.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.STATIC), v.getModifiers())
              + "\t" + typeText(v.getType()) + "\t\n");
          continue;
        }
        if (ml == null) ml = cl;
        declared(sourceName, "F:" + v.getName());
        boolean isStatic = isInterface || v.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.STATIC);
        b.append("F\t").append(v.getName()).append('\t').append(flags(isStatic, v.getModifiers())).append('\t')
            .append(typeText(v.getType())).append('\t').append(levelText(ml, cl)).append('\n');
      } else if (member instanceof MethodTree) {
        MethodTree m = (MethodTree) member;
        if (!visible(m.getModifiers(), isInterface)) continue;
        TypeScope ms = new TypeScope(scope);
        for (TypeParameterTree tp : m.getTypeParameters())
          ms.bounds.put(tp.getName().toString(), tp.getBounds().isEmpty() ? "java.lang.Object" : erasure(tp.getBounds().get(0), scope));
        boolean ctor = m.getReturnType() == null;
        String name = ctor ? "<init>" : m.getName().toString();
        StringBuilder desc = new StringBuilder("(");
        StringBuilder params = new StringBuilder();
        List<? extends VariableTree> parameters = m.getParameters();
        for (int pi = 0; pi < parameters.size(); pi++) {
          VariableTree p = parameters.get(pi);
          desc.append(descriptor(erasure(p.getType(), ms)));
          if (params.length() > 0) params.append(", ");
          String shown = simpleText(typeText(p.getType()));
          // Varargs keep their "..." (the analyzer accepts any number of trailing arguments).
          if (pi == parameters.size() - 1 && shown.endsWith("[]")
              && p.toString().trim().endsWith("... " + p.getName()))
            shown = shown.substring(0, shown.length() - 2) + "...";
          params.append(shown).append(' ').append(p.getName());
        }
        desc.append(')');
        Level ml = MEMBER_LEVELS.get(binary + "#" + name + desc);
        if (ml == null) ml = MEMBER_LEVELS_LOOSE.get(binary + "#" + name + "/" + m.getParameters().size());
        boolean isStatic = m.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.STATIC);
        if (ml == null) {
          if (!ctor) orphan(sourceName, "M:" + name + "/" + parameters.size(), "M\t" + name + "\t"
              + flags(isStatic, m.getModifiers()) + "\t" + returnText(m, ms) + "\t" + params + "\t\n");
          continue;
        }
        if (!ctor) declared(sourceName, "M:" + name + "/" + parameters.size());
        if (ctor) {
          b.append("K\t").append(params).append('\t').append(levelText(ml, cl)).append('\n');
        } else {
          b.append("M\t").append(name).append('\t').append(flags(isStatic, m.getModifiers())).append('\t')
              .append(returnText(m, ms)).append('\t').append(params).append('\t')
              .append(levelText(ml, cl)).append('\n');
        }
      } else if (member instanceof ClassTree) {
        emitClass(blocks, pkg, sourceName, (ClassTree) member, scope, isInterface);
      }
    }
    blocks.put(sourceName, b.toString());
    List<String> supers = new ArrayList<>();
    if (!sup.isEmpty()) supers.add(stripArgs(sup));
    for (Tree i : c.getImplementsClause()) supers.add(stripArgs(typeText(i)));
    SUPERS.put(sourceName, supers);
  }

  // A public stub member absent from api-versions.xml is either an override (already reachable through
  // a supertype, so skipped) or one metalava copied from a hidden superclass such as
  // StringBuilder ← AbstractStringBuilder (setCharAt/setLength…): that one is real API with the
  // owner's level, so it is kept when no known supertype declares it.
  static final Map<String, List<String>> SUPERS = new HashMap<>();
  static final Map<String, Set<String>> DECLARED = new HashMap<>();
  static final Map<String, LinkedHashMap<String, String>> ORPHANS = new TreeMap<>();

  static void declared(String owner, String key) {
    DECLARED.computeIfAbsent(owner, k -> new HashSet<>()).add(key);
  }

  static void orphan(String owner, String key, String line) {
    ORPHANS.computeIfAbsent(owner, k -> new LinkedHashMap<>()).merge(key, line, (a, b) -> a + b);
  }

  static String stripArgs(String type) {
    int lt = type.indexOf('<');
    return lt < 0 ? type : type.substring(0, lt);
  }

  static boolean inheritsMember(String owner, String key) {
    ArrayDeque<String> queue = new ArrayDeque<>(SUPERS.getOrDefault(owner, List.of()));
    Set<String> seen = new HashSet<>();
    while (!queue.isEmpty()) {
      String type = queue.poll();
      if (!seen.add(type)) continue;
      if (DECLARED.getOrDefault(type, Set.of()).contains(key)) return true;
      queue.addAll(SUPERS.getOrDefault(type, List.of()));
    }
    // Every class and interface inherits Object's public methods.
    return !owner.equals("java.lang.Object") && DECLARED.getOrDefault("java.lang.Object", Set.of()).contains(key);
  }

  static void addOrphans(TreeMap<String, String> blocks) {
    for (Map.Entry<String, LinkedHashMap<String, String>> e : ORPHANS.entrySet()) {
      String block = blocks.get(e.getKey());
      if (block == null) continue;
      StringBuilder extra = new StringBuilder();
      for (Map.Entry<String, String> m : e.getValue().entrySet())
        if (!inheritsMember(e.getKey(), m.getKey())) extra.append(m.getValue());
      if (extra.length() > 0) blocks.put(e.getKey(), block + extra);
    }
  }

  /** Return type with method-level type variables erased to their bound: <T extends View> T → View. */
  static String returnText(MethodTree m, TypeScope ms) {
    String ret = typeText(m.getReturnType());
    String base = ret.replace("[]", "");
    for (TypeParameterTree tp : m.getTypeParameters())
      if (tp.getName().contentEquals(base)) return ms.bounds.get(base) + ret.substring(base.length());
    return ret;
  }

  static String flags(boolean isStatic, ModifiersTree mods) {
    String f = isStatic ? "s" : "";
    if (mods.getFlags().contains(javax.lang.model.element.Modifier.PROTECTED)) f += "p";
    if (mods.getFlags().contains(javax.lang.model.element.Modifier.ABSTRACT)) f += "a";
    return f.isEmpty() ? "-" : f;
  }

  /** "since,deprecated,removed" — empty fields when equal to the owning class. */
  static String levelText(Level ml, Level cl) {
    String since = ml.since == cl.since ? "" : String.valueOf(ml.since);
    String dep = ml.deprecated == 0 || ml.deprecated == cl.deprecated ? "" : String.valueOf(ml.deprecated);
    String rem = ml.removed == 0 || ml.removed == cl.removed ? "" : String.valueOf(ml.removed);
    String s = since + "," + dep + "," + rem;
    return s.equals(",,") ? "" : s;
  }

  static String binaryOf(String sourceName) {
    if (BINARY_NAMES.contains(sourceName)) return sourceName;
    String candidate = sourceName;
    int dot;
    while ((dot = candidate.lastIndexOf('.')) > 0) {
      candidate = candidate.substring(0, dot) + "$" + candidate.substring(dot + 1);
      if (BINARY_NAMES.contains(candidate)) return candidate;
    }
    return sourceName;
  }

  static String typeText(Tree t) {
    if (t == null) return "void";
    String s = t.toString();
    s = s.replaceAll("@[A-Za-z_$][A-Za-z0-9_$.]*(\\([^)]*\\))?\\s*", "");
    return s.replaceAll("\\s+", " ").trim();
  }

  static final Pattern QUALIFIER = Pattern.compile("\\b(?:[a-z_][a-z0-9_]*\\.)+([A-Z])");

  static String simpleText(String type) {
    return QUALIFIER.matcher(type).replaceAll("$1");
  }

  static String erasure(Tree t, TypeScope scope) {
    if (t instanceof ParameterizedTypeTree) return erasure(((ParameterizedTypeTree) t).getType(), scope);
    if (t instanceof ArrayTypeTree) return erasure(((ArrayTypeTree) t).getType(), scope) + "[]";
    if (t instanceof AnnotatedTypeTree) return erasure(((AnnotatedTypeTree) t).getUnderlyingType(), scope);
    String s = typeText(t);
    if (s.endsWith("...")) return s.substring(0, s.length() - 3) + "[]";
    if (scope != null && !s.contains(".")) {
      String b = scope.bound(s);
      if (b != null) return b;
    }
    return s;
  }

  static String descriptor(String erased) {
    StringBuilder d = new StringBuilder();
    String s = erased;
    while (s.endsWith("[]")) { d.append('['); s = s.substring(0, s.length() - 2); }
    switch (s) {
      case "int": return d + "I";
      case "long": return d + "J";
      case "short": return d + "S";
      case "byte": return d + "B";
      case "char": return d + "C";
      case "boolean": return d + "Z";
      case "float": return d + "F";
      case "double": return d + "D";
      case "void": return d + "V";
      default:
        if (!s.contains(".")) s = "java.lang." + s;
        return d + "L" + binaryOf(s).replace('.', '/') + ";";
    }
  }

  // ───────────────────────────── XML: attrs, styleables, widgets ─────────────────────────────

  static String buildXml(Path platform) throws Exception {
    StringBuilder out = new StringBuilder();
    out.append("#shima-android-xml 1\n");
    LinkedHashMap<String, String[]> attrs = new LinkedHashMap<>(); // name -> {format, values}
    LinkedHashMap<String, List<String>> styleables = new LinkedHashMap<>();
    for (String file : new String[] {"attrs.xml", "attrs_manifest.xml"}) {
      Path p = platform.resolve("data/res/values/" + file);
      if (!Files.exists(p)) continue;
      Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(p.toFile());
      Element root = doc.getDocumentElement();
      for (Node n = root.getFirstChild(); n != null; n = n.getNextSibling()) {
        if (!(n instanceof Element)) continue;
        Element e = (Element) n;
        if (e.getTagName().equals("attr")) defineAttr(attrs, e);
        else if (e.getTagName().equals("declare-styleable")) {
          List<String> names = styleables.computeIfAbsent(e.getAttribute("name"), k -> new ArrayList<>());
          for (Node a = e.getFirstChild(); a != null; a = a.getNextSibling()) {
            if (!(a instanceof Element) || !((Element) a).getTagName().equals("attr")) continue;
            Element ae = (Element) a;
            String name = ae.getAttribute("name");
            if (name.startsWith("android:")) name = name.substring(8);
            defineAttr(attrs, ae);
            if (!names.contains(name)) names.add(name);
          }
        }
      }
    }
    for (Map.Entry<String, String[]> a : attrs.entrySet()) {
      String name = a.getKey();
      Level l = MEMBER_LEVELS.get("android.R$attr#" + name);
      if (l == null) continue; // internal/private attribute
      out.append("A\t").append(name).append('\t').append(a.getValue()[0]).append('\t').append(a.getValue()[1])
          .append('\t').append(l.since).append(',').append(l.deprecated).append(',').append(l.removed).append('\n');
    }
    for (Map.Entry<String, List<String>> s : styleables.entrySet()) {
      StringBuilder names = new StringBuilder();
      for (String n : s.getValue()) {
        if (MEMBER_LEVELS.get("android.R$attr#" + n) == null) continue;
        if (names.length() > 0) names.append(',');
        names.append(n);
      }
      if (names.length() > 0) out.append("S\t").append(s.getKey()).append('\t').append(names).append('\n');
    }
    return out.toString();
  }

  static void defineAttr(Map<String, String[]> attrs, Element e) {
    String name = e.getAttribute("name");
    if (name.startsWith("android:")) name = name.substring(8);
    String format = e.getAttribute("format");
    StringBuilder values = new StringBuilder();
    for (Node v = e.getFirstChild(); v != null; v = v.getNextSibling()) {
      if (!(v instanceof Element)) continue;
      String tag = ((Element) v).getTagName();
      if (!tag.equals("enum") && !tag.equals("flag")) continue;
      if (values.length() > 0) values.append(',');
      values.append(((Element) v).getAttribute("name"));
      if (format.isEmpty()) format = tag;
      else if (!format.contains(tag)) format += "|" + tag;
    }
    String[] old = attrs.get(name);
    if (old == null || (old[0].isEmpty() && !format.isEmpty()) || (old[1].isEmpty() && values.length() > 0))
      attrs.put(name, new String[] {format.isEmpty() && old != null ? old[0] : format,
          values.length() == 0 && old != null ? old[1] : values.toString()});
  }

  static void writeGz(Path file, String text) throws IOException {
    try (OutputStream os = new GZIPOutputStream(Files.newOutputStream(file), 1 << 16)) {
      os.write(text.getBytes(StandardCharsets.UTF_8));
    }
    System.out.println(file.getFileName() + ": " + text.length() + " chars, " + Files.size(file) + " bytes gz");
  }
}
