package almlk;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.shima.demo.R;
import com.shima.demo.UiStrings;

/**
 * Error-count badge for the action bar (bug icon + number), built from {@code errorsview.xml}.
 *
 * <p>Visibility follows the reference: hidden when there are no errors, and hidden on narrow
 * screens (360dp wide or less) where the action bar has no room for it; tapping it opens the
 * errors page. The owner re-evaluates {@link #visibleFor} whenever the count or the screen width
 * changes and rebuilds the menu only when the visibility actually flips.
 */
public final class ErrorCountBadge {

  /** Narrowest screen (dp) on which the badge is shown; at or below it the bar stays uncluttered. */
  public static final int MIN_SCREEN_WIDTH_DP = 360;

  private final View root;
  private final TextView label;
  private int count;

  public ErrorCountBadge(Context context, View.OnClickListener onClick) {
    root = LayoutInflater.from(context).inflate(R.layout.errorsview, null, false);
    label = root.findViewById(R.id.errorsViewLabel);
    root.setClickable(true);
    root.setOnClickListener(onClick);
    setCount(0);
  }

  /** Whether the badge belongs on the bar for {@code errorCount} errors at this screen width. */
  public static boolean visibleFor(int errorCount, int screenWidthDp) {
    return errorCount > 0 && screenWidthDp > MIN_SCREEN_WIDTH_DP;
  }

  public View view() {
    return root;
  }

  public int count() {
    return count;
  }

  public void setCount(int value) {
    count = Math.max(0, value);
    label.setText(String.valueOf(count));
    Context context = root.getContext();
    root.setContentDescription(
        count == 1
            ? UiStrings.get(context, "ui_errors_one")
            : UiStrings.format(context, "ui_errors_count", count));
  }
}
