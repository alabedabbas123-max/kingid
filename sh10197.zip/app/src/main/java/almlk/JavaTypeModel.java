package almlk;

import static almlk.JavaSyntaxTree.*;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Type model of the analysis engine (E1): one view over the three class sources — project
 * sources ({@link SourceClass}, from the syntax tree), and platform and library classes ({@link
 * IndexedClass}, over {@link AndroidApiIndex}, which carries return and parameter types).
 *
 * <p>Member lookup walks the supertype graph with type-argument substitution, so {@code
 * List<String>.get(0)} is a {@code String} and inherited generic members resolve through their
 * declaring supertype. Every lookup reports whether the walked hierarchy was <em>complete</em> (all
 * supertypes known and reliable): absence of a member is only a finding when it was.
 */
public final class JavaTypeModel {

  private JavaTypeModel() {}

  // ───────────────────────────── types ─────────────────────────────

  public abstract static class Type {
    public abstract String display();

    @Override
    public String toString() {
      return display();
    }
  }

  public static final class Primitive extends Type {
    public final String name;

    Primitive(String name) {
      this.name = name;
    }

    @Override
    public String display() {
      return name;
    }

    public boolean isNumeric() {
      return this != BOOLEAN && this != VOID;
    }
  }

  public static final Primitive BOOLEAN = new Primitive("boolean");
  public static final Primitive BYTE = new Primitive("byte");
  public static final Primitive SHORT = new Primitive("short");
  public static final Primitive CHAR = new Primitive("char");
  public static final Primitive INT = new Primitive("int");
  public static final Primitive LONG = new Primitive("long");
  public static final Primitive FLOAT = new Primitive("float");
  public static final Primitive DOUBLE = new Primitive("double");
  public static final Primitive VOID = new Primitive("void");

  public static Primitive primitive(String name) {
    switch (name) {
      case "boolean":
        return BOOLEAN;
      case "byte":
        return BYTE;
      case "short":
        return SHORT;
      case "char":
        return CHAR;
      case "int":
        return INT;
      case "long":
        return LONG;
      case "float":
        return FLOAT;
      case "double":
        return DOUBLE;
      case "void":
        return VOID;
      default:
        return null;
    }
  }

  public static final class ArrayType extends Type {
    public final Type element;

    public ArrayType(Type element) {
      this.element = element;
    }

    @Override
    public String display() {
      return element.display() + "[]";
    }
  }

  public static final class ClassType extends Type {
    public final ClassSymbol symbol;
    public final List<Type> args;

    public ClassType(ClassSymbol symbol, List<Type> args) {
      this.symbol = symbol;
      this.args = args == null ? Collections.<Type>emptyList() : args;
    }

    @Override
    public String display() {
      if (args.isEmpty()) return symbol.simpleName();
      StringBuilder b = new StringBuilder(symbol.simpleName()).append('<');
      for (int i = 0; i < args.size(); i++) b.append(i == 0 ? "" : ",").append(args.get(i).display());
      return b.append('>').toString();
    }
  }

  public static final class TypeVar extends Type {
    public final String name;
    /** Upper bound; null = Object. */
    public Type bound;
    /** Declared by a method, or read from the index (bound unknown): never used as a receiver. */
    public final boolean opaque;

    public TypeVar(String name, boolean opaque) {
      this.name = name;
      this.opaque = opaque;
    }

    @Override
    public String display() {
      return name;
    }
  }

  public static final class WildcardType extends Type {
    public final int kind;
    public final Type bound;

    WildcardType(int kind, Type bound) {
      this.kind = kind;
      this.bound = bound;
    }

    @Override
    public String display() {
      return kind == 1 || bound == null ? "?" : (kind == 2 ? "? extends " : "? super ") + bound.display();
    }
  }

  private static final class Special extends Type {
    private final String name;

    Special(String name) {
      this.name = name;
    }

    @Override
    public String display() {
      return name;
    }
  }

  public static final Type NULL = new Special("null");
  public static final Type UNKNOWN = new Special("?");

  public static boolean isUnknown(Type t) {
    return t == null || t == UNKNOWN;
  }

  // ───────────────────────────── members ─────────────────────────────

  public static final class FieldSymbol {
    public final String name;
    public final boolean isStatic;
    public final ClassSymbol owner;
    public final Type type;

    FieldSymbol(String name, boolean isStatic, ClassSymbol owner, Type type) {
      this.name = name;
      this.isStatic = isStatic;
      this.owner = owner;
      this.type = type == null ? UNKNOWN : type;
    }
  }

  public static final class MethodSymbol {
    public final String name;
    public final ClassSymbol owner;
    public final boolean isStatic;
    /**
     * جولةُ ٤١: المستوى الذي دَخَلَ فيهِ هذا العُضوُ (‏0‏ = مَجهولٌ أو غيرُ منصَّةٍ)، والمستوى الذي
     * حُذِفَ فيهِ. تُحمَلُ من فَهرَسِ المنصَّةِ ههُنا لأنَّهُ المَوضِعُ الذي يَعلَمُ فيهِ صِنفٌ
     * مَنطِقِيُّ أنَّ أصْلَهُ أصْلٌ مُصَرَّحٌ في ‏`android-api.idx.gz`‏: صِنفُ مَجلِسٍ مَحَلِّيٍّ لا
     * يَحملُ «since» فيَيبسُ البابُ نَفِسُهُ، فلا وسمَ إصدارٍ على شيفرةِ المُستَخدِمِ إلّا ببَيانٍ
     * منصَّةِيٍّ. ولا مَعنى لهُ بلا ‏`minSdk`‏ مُصَرَّحًا (‏ProjectPlatform.gatesApi()‏).
     */
    int since;
    int removedIn;
    public final boolean varargs;
    public final List<String> paramTypes;
    public final List<String> typeParams;
    final TypeRef returnRef;
    final String returnText;
    final MethodDecl decl;
    private Type returnType;
    private boolean returnResolved;

    MethodSymbol(String name, ClassSymbol owner, boolean isStatic, boolean varargs,
        List<String> paramTypes, List<String> typeParams, TypeRef returnRef, String returnText,
        MethodDecl decl) {
      this.name = name;
      this.owner = owner;
      this.isStatic = isStatic;
      this.varargs = varargs;
      this.paramTypes = paramTypes;
      this.typeParams = typeParams == null ? Collections.<String>emptyList() : typeParams;
      this.returnRef = returnRef;
      this.returnText = returnText;
      this.decl = decl;
    }

    public int paramCount() {
      return paramTypes.size();
    }

    public boolean acceptsArity(int n) {
      int count = paramTypes.size();
      return varargs ? n >= count - 1 : n == count;
    }

    public synchronized Type returnType() {
      if (!returnResolved) {
        returnResolved = true;
        returnType = owner.resolveReturn(this);
      }
      return returnType;
    }

    public String signature() {
      StringBuilder b = new StringBuilder(name).append('(');
      for (int i = 0; i < paramTypes.size(); i++) b.append(i == 0 ? "" : ", ").append(paramTypes.get(i));
      return b.append(')').toString();
    }
  }

  // ───────────────────────────── class symbols ─────────────────────────────

  public abstract static class ClassSymbol {
    public abstract String qualifiedName();

    public abstract String simpleName();

    public abstract String packageName();

    /** {@link JavaSyntaxTree#CLASS} … {@link JavaSyntaxTree#ANNOTATION}. */
    public abstract int kind();

    public boolean isInterface() {
      int k = kind();
      return k == INTERFACE || k == ANNOTATION;
    }

    public abstract List<String> typeParams();

    /** Direct superclass; null for interfaces and {@code java.lang.Object}. */
    public abstract ClassType superclass();

    public abstract List<ClassType> interfaces();

    /** Every declared supertype was found. */
    public abstract boolean supertypesResolved();

    /** Members are fully known (no Lombok, no provisional R …). */
    public abstract boolean reliable();

    public abstract List<FieldSymbol> fields();

    public abstract List<MethodSymbol> methods();

    public abstract List<MethodSymbol> constructors();

    public abstract ClassSymbol memberType(String name);

    public abstract ClassSymbol outer();

    public abstract boolean isProject();

    public abstract boolean isStaticMember();

    abstract Type resolveReturn(MethodSymbol method);

    /** An error entity: a type name that resolved to nothing (reported once, where written). */
    public boolean isError() {
      return false;
    }

    private List<MethodSymbol> indexedMethods;
    private List<FieldSymbol> indexedFields;
    private HashMap<String, List<MethodSymbol>> methodIndex;
    private HashMap<String, FieldSymbol> fieldIndex;

    /** Declared methods named {@code name} (hash lookup, rebuilt when the members change). */
    public synchronized List<MethodSymbol> methodsNamed(String name) {
      List<MethodSymbol> all = methods();
      if (all != indexedMethods || methodIndex == null) {
        HashMap<String, List<MethodSymbol>> map = new HashMap<>();
        for (MethodSymbol m : all) {
          List<MethodSymbol> list = map.get(m.name);
          if (list == null) map.put(m.name, list = new ArrayList<>(2));
          list.add(m);
        }
        methodIndex = map;
        indexedMethods = all;
      }
      List<MethodSymbol> found = methodIndex.get(name);
      return found == null ? Collections.<MethodSymbol>emptyList() : found;
    }

    /** The declared field named {@code name}, or null. */
    public synchronized FieldSymbol fieldNamed(String name) {
      List<FieldSymbol> all = fields();
      if (all != indexedFields || fieldIndex == null) {
        HashMap<String, FieldSymbol> map = new HashMap<>();
        for (FieldSymbol f : all) if (!map.containsKey(f.name)) map.put(f.name, f);
        fieldIndex = map;
        indexedFields = all;
      }
      return fieldIndex.get(name);
    }

    /** The declaration as seen from inside: type parameters as type variables. */
    public ClassType thisType() {
      List<String> params = typeParams();
      if (params.isEmpty()) return new ClassType(this, null);
      ArrayList<Type> args = new ArrayList<>();
      for (String p : params) args.add(typeVar(p));
      return new ClassType(this, args);
    }

    Type typeVar(String name) {
      return new TypeVar(name, true);
    }

    @Override
    public String toString() {
      return qualifiedName();
    }
  }

  // ───────────────────────────── universe ─────────────────────────────

  /** Class lookup by qualified name: the analysed file first, then the project, then the index. */
  public static class Universe {
    final Map<String, ClassSymbol> overlay;

    public Universe(Map<String, ClassSymbol> overlay) {
      this.overlay = overlay;
    }

    public ClassSymbol byQualified(String qualified) {
      if (qualified == null || qualified.isEmpty()) return null;
      ClassSymbol c = overlay.get(qualified);
      if (c != null) return c;
      c = JavaProjectModel.classByQualifiedName(qualified);
      if (c != null) return c;
      AndroidApiIndex.ClassInfo info = AndroidApiIndex.classByQualifiedName(qualified);
      return info == null ? null : indexed(info);
    }
  }

  static final Universe GLOBAL = new Universe(Collections.<String, ClassSymbol>emptyMap());

  /** One lock for lazy source-class building: no lock-order cycles between analysis threads. */
  static final Object BUILD_LOCK = new Object();

  private static final WeakHashMap<AndroidApiIndex.ClassInfo, IndexedClass> INDEXED =
      new WeakHashMap<>();

  static IndexedClass indexed(AndroidApiIndex.ClassInfo info) {
    synchronized (INDEXED) {
      IndexedClass c = INDEXED.get(info);
      if (c == null) {
        c = new IndexedClass(info);
        INDEXED.put(info, c);
      }
      return c;
    }
  }

  /** Per-file naming context: package and imports. */
  public static final class FileContext {
    public final String packageName;
    public final List<Import> imports;
    public final boolean lombok;
    final HashMap<String, ClassSymbol> topLevel = new HashMap<>();

    public FileContext(Unit unit) {
      packageName = unit.packageName == null ? "" : unit.packageName;
      imports = unit.imports;
      boolean l = false;
      for (Import im : unit.imports) if (im.name.startsWith("lombok")) l = true;
      lombok = l;
    }
  }

  static String qualify(String pkg, String name) {
    return pkg == null || pkg.isEmpty() ? name : pkg + "." + name;
  }

  static String lastSegment(String name) {
    int dot = name.lastIndexOf('.');
    return dot < 0 ? name : name.substring(dot + 1);
  }

  /**
   * Resolves a simple type name at file level (JLS 6.4.1 order after the class scopes): single
   * import, the file's own top-level types, same package, on-demand imports, {@code java.lang}.
   */
  public static ClassSymbol resolveInFile(String name, FileContext file, Universe u) {
    for (Import im : file.imports) {
      if (im.onDemand) continue;
      if (lastSegment(im.name).equals(name)) {
        if (!im.isStatic) return u.byQualified(im.name);
        int dot = im.name.lastIndexOf('.');
        if (dot > 0) {
          ClassSymbol owner = u.byQualified(im.name.substring(0, dot));
          ClassSymbol member = owner == null ? null : memberTypeInherited(owner, name);
          if (member != null) return member;
        }
      }
    }
    ClassSymbol c = file.topLevel.get(name);
    if (c != null) return c;
    c = u.byQualified(qualify(file.packageName, name));
    if (c != null) return c;
    for (Import im : file.imports) {
      if (!im.onDemand) continue;
      if (!im.isStatic) {
        c = u.byQualified(im.name + "." + name);
        if (c != null) return c;
        ClassSymbol owner = u.byQualified(im.name);
        if (owner != null) {
          c = owner.memberType(name);
          if (c != null) return c;
        }
      } else {
        ClassSymbol owner = u.byQualified(im.name);
        c = owner == null ? null : memberTypeInherited(owner, name);
        if (c != null) return c;
      }
    }
    return u.byQualified("java.lang." + name);
  }

  /** A member type declared in {@code c} or inherited from its supertypes. */
  public static ClassSymbol memberTypeInherited(ClassSymbol c, String name) {
    ArrayDeque<ClassSymbol> queue = new ArrayDeque<>();
    HashSet<ClassSymbol> seen = new HashSet<>();
    queue.add(c);
    while (!queue.isEmpty()) {
      ClassSymbol x = queue.poll();
      if (!seen.add(x) || seen.size() > 64) continue;
      ClassSymbol m = x.memberType(name);
      if (m != null) return m;
      ClassType sup = x.superclass();
      if (sup != null) queue.add(sup.symbol);
      for (ClassType i : x.interfaces()) queue.add(i.symbol);
    }
    return null;
  }

  // ───────────────────────────── error entities ─────────────────────────────

  /**
   * Error entity of the reference model: every type name resolves to an entity, and one that is
   * not found becomes this placeholder carrying the name as written. It has no members and is not
   * reliable, so anything looked up through it stays silent; the name itself is reported once at
   * its own position by the caller.
   */
  public static final class ErrorClass extends ClassSymbol {
    private final String name;

    public ErrorClass(String writtenName) {
      String n = writtenName == null ? "" : writtenName.trim();
      int generic = n.indexOf('<');
      name = generic >= 0 ? n.substring(0, generic).trim() : n;
    }

    @Override public boolean isError() { return true; }
    @Override public String qualifiedName() { return name; }
    @Override public String simpleName() { return name.substring(name.lastIndexOf('.') + 1); }
    @Override public String packageName() {
      int dot = name.lastIndexOf('.');
      return dot < 0 ? "" : name.substring(0, dot);
    }
    @Override public int kind() { return CLASS; }
    @Override public List<String> typeParams() { return Collections.emptyList(); }
    @Override public ClassType superclass() { return null; }
    @Override public List<ClassType> interfaces() { return Collections.emptyList(); }
    @Override public boolean supertypesResolved() { return false; }
    @Override public boolean reliable() { return false; }
    @Override public List<FieldSymbol> fields() { return Collections.emptyList(); }
    @Override public List<MethodSymbol> methods() { return Collections.emptyList(); }
    @Override public List<MethodSymbol> constructors() { return Collections.emptyList(); }
    @Override public ClassSymbol memberType(String n) { return null; }
    @Override public ClassSymbol outer() { return null; }
    @Override public boolean isProject() { return false; }
    @Override public boolean isStaticMember() { return false; }
    @Override Type resolveReturn(MethodSymbol method) { return UNKNOWN; }
  }

  /** The error entity of an unresolved type name, as a class type. */
  public static ClassType errorType(String writtenName) {
    return new ClassType(new ErrorClass(writtenName), null);
  }

  // ───────────────────────────── substitution & lookup ─────────────────────────────

  public static Map<String, Type> envOf(ClassType t) {
    List<String> params = t.symbol.typeParams();
    if (params.isEmpty()) return Collections.emptyMap();
    HashMap<String, Type> env = new HashMap<>();
    boolean raw = t.args.size() != params.size();
    for (int i = 0; i < params.size(); i++) env.put(params.get(i), raw ? UNKNOWN : t.args.get(i));
    return env;
  }

  public static Type subst(Type t, Map<String, Type> env) {
    if (t == null || env.isEmpty()) return t;
    if (t instanceof TypeVar) {
      Type r = env.get(((TypeVar) t).name);
      return r != null ? r : t;
    }
    if (t instanceof ArrayType) {
      Type e = subst(((ArrayType) t).element, env);
      return e == ((ArrayType) t).element ? t : new ArrayType(e);
    }
    if (t instanceof WildcardType) {
      WildcardType w = (WildcardType) t;
      return w.bound == null ? t : new WildcardType(w.kind, subst(w.bound, env));
    }
    if (t instanceof ClassType) {
      ClassType c = (ClassType) t;
      if (c.args.isEmpty()) return t;
      ArrayList<Type> args = new ArrayList<>(c.args.size());
      boolean changed = false;
      for (Type a : c.args) {
        Type s = subst(a, env);
        changed |= s != a;
        args.add(s);
      }
      return changed ? new ClassType(c.symbol, args) : t;
    }
    return t;
  }

  /**
   * The type usable as a member receiver: wildcards and type variables are replaced by their
   * bound, opaque variables (method-level or index ones) become {@link #UNKNOWN}.
   */
  public static Type receiverOf(Type t, Universe u) {
    for (int guard = 0; guard < 8 && t != null; guard++) {
      if (t instanceof WildcardType) {
        WildcardType w = (WildcardType) t;
        t = w.kind == 2 ? w.bound : UNKNOWN;
      } else if (t instanceof TypeVar) {
        TypeVar v = (TypeVar) t;
        if (v.opaque) return UNKNOWN;
        if (v.bound == null) {
          ClassSymbol object = u.byQualified("java.lang.Object");
          return object == null ? UNKNOWN : new ClassType(object, null);
        }
        t = v.bound;
      } else {
        return t;
      }
    }
    return t == null ? UNKNOWN : t;
  }

  /** Result of a member lookup over a receiver's hierarchy. */
  public static final class Lookup {
    public final List<MethodSymbol> methods = new ArrayList<>();
    public final List<Map<String, Type>> methodEnvs = new ArrayList<>();
    public FieldSymbol field;
    public Map<String, Type> fieldEnv = Collections.emptyMap();
    public ClassSymbol memberType;
    /**
     * The absence of a member is a finding (the reference's always-judge policy): every <em>known</em>
     * class of the hierarchy is reliable. Error entities and unresolved supertypes do not block the
     * judgement; only generated members (Lombok, provisional R) and an unloadable Object do.
     */
    public boolean complete = true;
    /** The walk reached an error entity (an unresolved supertype). */
    public boolean errorEntity;
  }

  public static Lookup lookup(ClassType receiver, String name, Universe u) {
    Lookup result = new Lookup();
    if (receiver.symbol.isError()) {
      // The receiver is itself an error entity (reported where written): nothing to judge.
      result.errorEntity = true;
      result.complete = false;
      return result;
    }
    ArrayDeque<ClassType> queue = new ArrayDeque<>();
    HashSet<ClassSymbol> seen = new HashSet<>();
    queue.add(receiver);
    boolean sawInterface = false;
    boolean sawObject = false;
    while (!queue.isEmpty()) {
      ClassType t = queue.poll();
      ClassSymbol c = t.symbol;
      if (!seen.add(c)) continue;
      if (seen.size() > 96) {
        result.complete = false;
        break;
      }
      if ("java.lang.Object".equals(c.qualifiedName())) sawObject = true;
      if (c.isInterface()) sawInterface = true;
      if (c.isError()) result.errorEntity = true;
      else if (!c.reliable()) result.complete = false;
      Map<String, Type> env = envOf(t);
      if (result.field == null) {
        FieldSymbol f = c.fieldNamed(name);
        if (f != null) {
          result.field = f;
          result.fieldEnv = env;
        }
      }
      for (MethodSymbol m : c.methodsNamed(name)) {
        result.methods.add(m);
        result.methodEnvs.add(env);
      }
      if (result.memberType == null) result.memberType = c.memberType(name);
      ClassType sup = c.superclass();
      if (sup != null) queue.add((ClassType) subst(sup, env));
      for (ClassType i : c.interfaces()) queue.add((ClassType) subst(i, env));
    }
    // Interfaces, and classes whose superclass chain ends in an error entity, still have Object.
    if ((sawInterface || result.errorEntity) && !sawObject) {
      ClassSymbol object = u.byQualified("java.lang.Object");
      // W7: كان انقطاعُ السلسلة عند Object (منصّةٌ غير جاهزة) يُجهِل القرينةَ كلها، فتنحجب بلاغاتٌ
      // سببُها محليٌّ بحت. سطحُ Object مُعطًى لغويٌّ ثابت: إن لم يكن الاسمُ عليه فالحكمُ بغيابه قاطع
      // داخل هذه السلسلة، وإن كان عليه بقي الحكمُ محجوزًا كما كان — لا جزمَ على ما يُحتمل أنه موروثة.
      if (object == null) {
        if (almlk.JavaLangObjectSurface.mightBeInherited(name)) result.complete = false;
      }
      else if (seen.add(object)) {
        for (MethodSymbol m : object.methodsNamed(name)) {
          result.methods.add(m);
          result.methodEnvs.add(Collections.<String, Type>emptyMap());
        }
      }
    }
    return result;
  }

  /** Every known class of the hierarchy of {@code c} is reliable (error entities do not block). */
  public static boolean hierarchyComplete(ClassSymbol c) {
    ArrayDeque<ClassSymbol> queue = new ArrayDeque<>();
    HashSet<ClassSymbol> seen = new HashSet<>();
    queue.add(c);
    while (!queue.isEmpty()) {
      ClassSymbol x = queue.poll();
      if (!seen.add(x)) continue;
      if (seen.size() > 96) return false;
      if (!x.isError() && !x.reliable()) return false;
      ClassType sup = x.superclass();
      if (sup != null) queue.add(sup.symbol);
      for (ClassType i : x.interfaces()) queue.add(i.symbol);
    }
    return true;
  }

  /**
   * اكتمالُ السلسلةِ **وانغلاقُها**: كلُّ صنفٍ فيها موثوقٌ، ولا اسمَ علويٍّ كُتِبَ ثمَّ لم يُحَلَّ
   * ({@code supertypesResolved} كاذبةٌ أو كيانٌ خاطئٌ) يُقابَلُ بقطعِ السلسلةِ صمتًا ثمَّ حُكمٍ بأنَّ
   * «العضوَ ليسَ هنا». قرينةٌ أضيَقُ من hierarchyComplete لعِلمِنا أنَّ المرجعَ يَحكُمُ على الطرقِ
   * بلا انغلاقٍ (بوَّابةُ m4/R3 تُثبِتُ نصَّ «Unknown method …» معَ أبٍ غيرِ مَعهودٍ)؛ فاستعمالُها
   * مَحدودٌ بمسارِ الحقولِ والأسماءِ المجردةِ الذي أطلَقَ وهمَ «Unknown variable or field
   * 'DATABASE_NAME'» على ثابتٍ يَسكُنُ سلسلةً لم نَفهَرْسِها (ورقةُ W31 §٣٫١ و§٥).
   */
  public static boolean hierarchyCertain(ClassSymbol c) {
    ArrayDeque<ClassSymbol> queue = new ArrayDeque<>();
    HashSet<ClassSymbol> seen = new HashSet<>();
    queue.add(c);
    while (!queue.isEmpty()) {
      ClassSymbol x = queue.poll();
      if (!seen.add(x)) continue;
      if (seen.size() > 96) return false;
      if (!hierarchyComplete(x)) return false;
      if (x.isError() || !x.supertypesResolved()) return false;
      ClassType sup = x.superclass();
      if (sup != null) queue.add(sup.symbol);
      for (ClassType i : x.interfaces()) queue.add(i.symbol);
    }
    return true;
  }

  public static boolean isSubclass(ClassSymbol c, String qualified) {
    ArrayDeque<ClassSymbol> queue = new ArrayDeque<>();
    HashSet<ClassSymbol> seen = new HashSet<>();
    queue.add(c);
    while (!queue.isEmpty()) {
      ClassSymbol x = queue.poll();
      if (!seen.add(x) || seen.size() > 96) continue;
      if (x.qualifiedName().equals(qualified)) return true;
      ClassType sup = x.superclass();
      if (sup != null) queue.add(sup.symbol);
      for (ClassType i : x.interfaces()) queue.add(i.symbol);
    }
    return false;
  }

  /** Element type of an array or {@code Iterable<T>}; UNKNOWN when not provable. */
  public static Type elementTypeOf(Type t, Universe u) {
    if (t instanceof ArrayType) return ((ArrayType) t).element;
    t = receiverOf(t, u);
    if (!(t instanceof ClassType)) return UNKNOWN;
    ArrayDeque<ClassType> queue = new ArrayDeque<>();
    HashSet<ClassSymbol> seen = new HashSet<>();
    queue.add((ClassType) t);
    while (!queue.isEmpty()) {
      ClassType c = queue.poll();
      if (!seen.add(c.symbol) || seen.size() > 64) continue;
      if ("java.lang.Iterable".equals(c.symbol.qualifiedName()))
        return c.args.size() == 1 ? c.args.get(0) : UNKNOWN;
      Map<String, Type> env = envOf(c);
      ClassType sup = c.symbol.superclass();
      if (sup != null) queue.add((ClassType) subst(sup, env));
      for (ClassType i : c.symbol.interfaces()) queue.add((ClassType) subst(i, env));
    }
    return UNKNOWN;
  }

  // ───────────────────────────── indexed classes ─────────────────────────────

  /** A platform or library class read from {@link AndroidApiIndex}. */
  public static final class IndexedClass extends ClassSymbol {
    final AndroidApiIndex.ClassInfo info;
    private final List<String> typeParams;
    private boolean loaded;
    private ClassType superclass;
    private List<ClassType> interfaces;
    private boolean resolved;
    private List<FieldSymbol> fields;
    private List<MethodSymbol> methods;
    private List<MethodSymbol> constructors;

    IndexedClass(AndroidApiIndex.ClassInfo info) {
      this.info = info;
      ArrayList<String> params = new ArrayList<>();
      for (String p : info.typeParameters) {
        String name = p.trim();
        int space = name.indexOf(' ');
        if (space > 0) name = name.substring(0, space);
        if (!name.isEmpty()) params.add(name);
      }
      typeParams = params;
    }

    @Override
    public String qualifiedName() {
      return info.qualifiedName;
    }

    @Override
    public String simpleName() {
      return info.simpleName;
    }

    @Override
    public String packageName() {
      return info.packageName;
    }

    @Override
    public int kind() {
      switch (info.kind) {
        case "i":
          return INTERFACE;
        case "a":
          return ANNOTATION;
        case "e":
          return ENUM;
        default:
          return CLASS;
      }
    }

    @Override
    public List<String> typeParams() {
      return typeParams;
    }

    private synchronized void loadSupertypes() {
      if (loaded) return;
      loaded = true;
      boolean ok = true;
      String sup = info.superName == null ? "" : info.superName.trim();
      if (!sup.isEmpty() && !"java.lang.Object".equals(info.qualifiedName)) {
        Type t = parseType(sup);
        if (t instanceof ClassType) superclass = (ClassType) t;
        else {
          ok = false;
          superclass = errorType(sup);
        }
      } else if (sup.isEmpty() && !isInterface() && !"java.lang.Object".equals(info.qualifiedName)) {
        ClassSymbol object = GLOBAL.byQualified("java.lang.Object");
        if (object != null) superclass = new ClassType(object, null);
      }
      ArrayList<ClassType> list = new ArrayList<>();
      for (String i : info.interfaces) {
        Type t = parseType(i.trim());
        if (t instanceof ClassType) list.add((ClassType) t);
        else {
          ok = false;
          if (!i.trim().isEmpty()) list.add(errorType(i));
        }
      }
      interfaces = list;
      resolved = ok;
    }

    @Override
    public ClassType superclass() {
      loadSupertypes();
      return superclass;
    }

    @Override
    public List<ClassType> interfaces() {
      loadSupertypes();
      return interfaces;
    }

    @Override
    public boolean supertypesResolved() {
      loadSupertypes();
      return resolved;
    }

    @Override
    public boolean reliable() {
      return !info.provisional;
    }

    @Override
    public synchronized List<FieldSymbol> fields() {
      if (fields == null) {
        ArrayList<FieldSymbol> list = new ArrayList<>();
        for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(info)) {
          if (m.kind != AndroidApiIndex.Member.FIELD) continue;
          list.add(new FieldSymbol(m.name, m.isStatic || isInterface(), this, parseType(m.type)));
        }
        fields = list;
      }
      return fields;
    }

    @Override
    public synchronized List<MethodSymbol> methods() {
      if (methods == null) {
        ArrayList<MethodSymbol> list = new ArrayList<>();
        for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(info)) {
          if (m.kind != AndroidApiIndex.Member.METHOD) continue;
          List<String> params = parameterTypes(m.parameters);
          boolean varargs = !params.isEmpty() && params.get(params.size() - 1).endsWith("...");
          MethodSymbol symbol =
              new MethodSymbol(m.name, this, m.isStatic, varargs, params, null, null, m.type, null);
          symbol.since = m.since;
          symbol.removedIn = m.removed;
          list.add(symbol);
        }
        if (kind() == ENUM) {
          list.add(new MethodSymbol("values", this, true, false, Collections.<String>emptyList(),
              null, null, info.qualifiedName + "[]", null));
          list.add(new MethodSymbol("valueOf", this, true, false,
              Collections.singletonList("String"), null, null, info.qualifiedName, null));
        }
        methods = list;
      }
      return methods;
    }

    @Override
    public synchronized List<MethodSymbol> constructors() {
      if (constructors == null) {
        ArrayList<MethodSymbol> list = new ArrayList<>();
        for (AndroidApiIndex.Member m : AndroidApiIndex.constructors(info)) {
          List<String> params = parameterTypes(m.parameters);
          boolean varargs = !params.isEmpty() && params.get(params.size() - 1).endsWith("...");
          list.add(new MethodSymbol(info.simpleName, this, false, varargs, params, null, null,
              info.qualifiedName, null));
        }
        constructors = list;
      }
      return constructors;
    }

    @Override
    public ClassSymbol memberType(String name) {
      AndroidApiIndex.ClassInfo m = AndroidApiIndex.classByQualifiedName(info.qualifiedName + "." + name);
      return m == null ? null : indexed(m);
    }

    @Override
    public ClassSymbol outer() {
      if (!info.isNested()) return null;
      AndroidApiIndex.ClassInfo o = AndroidApiIndex.classByQualifiedName(info.container);
      return o == null ? null : indexed(o);
    }

    @Override
    public boolean isProject() {
      return false;
    }

    @Override
    public boolean isStaticMember() {
      return true;
    }

    @Override
    Type resolveReturn(MethodSymbol method) {
      return parseType(method.returnText);
    }

    /** Parses an index type text such as {@code java.util.List<E>} or {@code int[]}. */
    Type parseType(String text) {
      if (text == null) return UNKNOWN;
      String s = text.trim();
      if (s.isEmpty()) return UNKNOWN;
      int dims = 0;
      while (true) {
        if (s.endsWith("[]")) {
          s = s.substring(0, s.length() - 2).trim();
          dims++;
        } else if (s.endsWith("...")) {
          s = s.substring(0, s.length() - 3).trim();
          dims++;
        } else break;
      }
      Type base;
      if (s.startsWith("?")) {
        String rest = s.substring(1).trim();
        if (rest.startsWith("extends ")) base = new WildcardType(2, parseType(rest.substring(8)));
        else if (rest.startsWith("super ")) base = new WildcardType(3, parseType(rest.substring(6)));
        else base = new WildcardType(1, null);
      } else {
        int lt = s.indexOf('<');
        String name = lt < 0 ? s : s.substring(0, lt).trim();
        List<Type> args = null;
        if (lt >= 0) {
          int gt = s.lastIndexOf('>');
          args = new ArrayList<>();
          for (String a : splitTopLevel(gt > lt ? s.substring(lt + 1, gt) : s.substring(lt + 1)))
            args.add(parseType(a));
        }
        Primitive prim = primitive(name);
        if (prim != null) base = prim;
        else if (name.indexOf('.') > 0) {
          AndroidApiIndex.ClassInfo c = AndroidApiIndex.classByQualifiedName(name);
          ClassSymbol sym = c != null ? indexed(c) : GLOBAL.byQualified(name);
          base = sym == null ? UNKNOWN : new ClassType(sym, args);
        } else if (typeParams.contains(name)) {
          base = new TypeVar(name, true);
        } else {
          AndroidApiIndex.ClassInfo lang = AndroidApiIndex.classByQualifiedName("java.lang." + name);
          if (lang != null) base = new ClassType(indexed(lang), args);
          else {
            AndroidApiIndex.ClassInfo sibling =
                AndroidApiIndex.classByQualifiedName(qualify(info.packageName, name));
            base = sibling != null ? new ClassType(indexed(sibling), args) : new TypeVar(name, true);
          }
        }
      }
      if (base == UNKNOWN) return UNKNOWN;
      for (int i = 0; i < dims; i++) base = new ArrayType(base);
      return base;
    }
  }

  static List<String> splitTopLevel(String text) {
    ArrayList<String> parts = new ArrayList<>();
    int level = 0;
    int from = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '<') level++;
      else if (c == '>') level--;
      else if (c == ',' && level == 0) {
        parts.add(text.substring(from, i).trim());
        from = i + 1;
      }
    }
    String tail = text.substring(from).trim();
    if (!tail.isEmpty() || !parts.isEmpty()) parts.add(tail);
    return parts;
  }

  /** {@code "int index, E element"} → {@code [int, E]}; names are dropped. */
  static List<String> parameterTypes(String text) {
    if (text == null || text.trim().isEmpty()) return Collections.emptyList();
    ArrayList<String> types = new ArrayList<>();
    for (String part : splitTopLevel(text)) {
      int level = 0;
      int lastSpace = -1;
      for (int i = 0; i < part.length(); i++) {
        char c = part.charAt(i);
        if (c == '<') level++;
        else if (c == '>') level--;
        else if (c == ' ' && level == 0) lastSpace = i;
      }
      String type = part;
      if (lastSpace > 0) {
        String tail = part.substring(lastSpace + 1);
        if (!tail.isEmpty() && Character.isJavaIdentifierStart(tail.charAt(0))
            && !tail.endsWith("...") && !tail.endsWith("]")) type = part.substring(0, lastSpace).trim();
      }
      types.add(type);
    }
    return types;
  }

  // ───────────────────────────── source classes ─────────────────────────────

  /** Method-local names a local or anonymous class can see (supplied by the attributor). */
  public interface LocalNames {
    ClassSymbol localType(String name);

    Type typeVariable(String name);
  }

  private static final HashSet<String> LOMBOK = new HashSet<>(java.util.Arrays.asList(
      "Data", "Getter", "Setter", "Value", "Builder", "SuperBuilder", "AllArgsConstructor",
      "NoArgsConstructor", "RequiredArgsConstructor", "ToString", "EqualsAndHashCode", "Delegate",
      "With", "Wither", "Slf4j", "Log", "Log4j", "Log4j2", "CommonsLog", "Flogger", "JBossLog",
      "XSlf4j", "CustomLog", "Accessors", "FieldDefaults", "UtilityClass", "ExtensionMethod"));

  /** A class declared in project source (a project file, or the file being analysed). */
  public static final class SourceClass extends ClassSymbol {
    public final TypeDecl decl;
    public final FileContext file;
    public final ClassSymbol outerClass;
    final Universe universe;
    final LocalNames localNames;
    private final String qualified;
    private final HashMap<String, SourceClass> memberTypes = new HashMap<>();
    private final HashMap<String, TypeVar> typeVars = new HashMap<>();
    /** Anonymous class / enum constant body: the instantiated type. */
    ClassType anonymousBase;
    private int generation = Integer.MIN_VALUE;
    private boolean building;
    private ClassType superclass;
    private List<ClassType> interfaces = Collections.emptyList();
    private boolean resolved;
    private boolean reliable;
    private List<FieldSymbol> fields = Collections.emptyList();
    private List<MethodSymbol> methods = Collections.emptyList();
    private List<MethodSymbol> constructors = Collections.emptyList();

    public SourceClass(TypeDecl decl, FileContext file, ClassSymbol outerClass, Universe universe,
        LocalNames localNames) {
      this.decl = decl;
      this.file = file;
      this.outerClass = outerClass;
      this.universe = universe;
      this.localNames = localNames;
      if (decl.anonymous || decl.local) qualified = decl.name;
      else if (outerClass != null) qualified = outerClass.qualifiedName() + "." + decl.name;
      else qualified = qualify(file.packageName, decl.name);
      for (TypeParam tp : decl.typeParams) typeVars.put(tp.name, new TypeVar(tp.name, false));
      for (Member m : decl.members) {
        if (m instanceof TypeDecl) {
          TypeDecl nested = (TypeDecl) m;
          if (!nested.name.isEmpty())
            memberTypes.put(nested.name, new SourceClass(nested, file, this, universe, localNames));
        }
      }
    }

    public java.util.Collection<SourceClass> nestedClasses() {
      return memberTypes.values();
    }

    @Override
    public String qualifiedName() {
      return qualified;
    }

    @Override
    public String simpleName() {
      return decl.name;
    }

    @Override
    public String packageName() {
      return file.packageName;
    }

    @Override
    public int kind() {
      return decl.kind;
    }

    @Override
    public List<String> typeParams() {
      ArrayList<String> names = new ArrayList<>();
      for (TypeParam tp : decl.typeParams) names.add(tp.name);
      return names;
    }

    @Override
    Type typeVar(String name) {
      TypeVar v = typeVars.get(name);
      return v != null ? v : new TypeVar(name, true);
    }

    @Override
    public boolean isProject() {
      return true;
    }

    @Override
    public boolean isStaticMember() {
      if (outerClass == null) return true;
      return decl.mods.has(STATIC) || decl.kind != CLASS || outerClass.isInterface();
    }

    @Override
    public ClassSymbol outer() {
      return outerClass;
    }

    @Override
    public ClassSymbol memberType(String name) {
      return memberTypes.get(name);
    }

    private void ensure() {
      int current = universe == GLOBAL ? JavaProjectModel.generation() : 0;
      synchronized (BUILD_LOCK) {
        if (generation == current || building) return;
        building = true;
        try {
          build();
        } finally {
          building = false;
          generation = current;
        }
      }
    }

    private void build() {
      for (TypeParam tp : decl.typeParams) {
        TypeVar v = typeVars.get(tp.name);
        if (v != null) v.bound = tp.bounds.isEmpty() ? null : nonNull(resolve(tp.bounds.get(0), null));
      }
      boolean ok = true;
      ClassType sup = null;
      ArrayList<ClassType> ifaces = new ArrayList<>();
      String self = qualified;
      if (decl.anonymous) {
        if (anonymousBase == null) ok = false;
        else if (anonymousBase.symbol.isInterface()) {
          sup = objectType();
          ifaces.add(anonymousBase);
        } else sup = anonymousBase;
      } else if (decl.kind == CLASS) {
        if (decl.superclass != null) {
          Type t = resolveSupertype(decl.superclass);
          if (t instanceof ClassType) sup = (ClassType) t;
          else {
            ok = false;
            sup = errorType(writtenName(decl.superclass));
          }
        } else if (!"java.lang.Object".equals(self)) {
          sup = objectType();
          if (sup == null) ok = false;
        }
      } else if (decl.kind == ENUM) {
        ClassSymbol e = universe.byQualified("java.lang.Enum");
        if (e == null) ok = false;
        else sup = new ClassType(e, Collections.<Type>singletonList(new ClassType(this, null)));
      } else if (decl.kind == RECORD) {
        ClassSymbol r = universe.byQualified("java.lang.Record");
        sup = r != null ? new ClassType(r, null) : objectType();
        if (sup == null) ok = false;
      }
      for (TypeRef i : decl.interfaces) {
        Type t = resolveSupertype(i);
        if (t instanceof ClassType) ifaces.add((ClassType) t);
        else {
          ok = false;
          ifaces.add(errorType(writtenName(i)));
        }
      }
      if (decl.kind == ANNOTATION) {
        ClassSymbol a = universe.byQualified("java.lang.annotation.Annotation");
        if (a != null) ifaces.add(new ClassType(a, null));
        else ok = false;
      }
      superclass = sup;
      interfaces = ifaces;
      resolved = ok;
      reliable = !file.lombok && !hasLombok(decl.mods);

      ArrayList<FieldSymbol> fs = new ArrayList<>();
      ArrayList<MethodSymbol> ms = new ArrayList<>();
      ArrayList<MethodSymbol> cs = new ArrayList<>();
      boolean iface = isInterface();
      for (EnumConstant c : decl.constants)
        fs.add(new FieldSymbol(c.name, true, this, new ClassType(this, null)));
      for (VarDecl v : decl.recordComponents) {
        Type t = resolve(v.type, null);
        fs.add(new FieldSymbol(v.name, false, this, t));
      }
      HashSet<String> declaredNoArg = new HashSet<>();
      for (Member m : decl.members) {
        if (m instanceof FieldDecl) {
          FieldDecl f = (FieldDecl) m;
          if (hasLombok(f.mods)) reliable = false;
          boolean isStatic = f.mods.has(STATIC) || iface;
          for (VarDecl v : f.vars) {
            if (v.name.isEmpty()) continue;
            Type t = resolve(v.type, null);
            for (int i = 0; i < v.extraDims; i++) t = new ArrayType(t);
            fs.add(new FieldSymbol(v.name, isStatic, this, t));
          }
        } else if (m instanceof MethodDecl) {
          MethodDecl md = (MethodDecl) m;
          if (md.name.isEmpty()) continue;
          ArrayList<String> params = new ArrayList<>();
          for (VarDecl p : md.params) params.add(p.type == null ? "?" : p.type.display());
          ArrayList<String> tps = new ArrayList<>();
          for (TypeParam tp : md.typeParams) tps.add(tp.name);
          if (md.constructor) {
            if (decl.kind == RECORD && md.compact) continue; // canonical, added below
            cs.add(new MethodSymbol(decl.name, this, false, md.varargs(), params, tps, null, null, md));
          } else {
            if (md.params.isEmpty()) declaredNoArg.add(md.name);
            // نصُّ الإرجاعِ مَكتوبٌ كَما وُصِفَ: مَن يُولِّدُ تَنفِيذًا لا يَستَطيعُ أن يَدَعَ
            // «void» يَحِلَّ مَحَلَّ «int count()» — جِسمٌ لا يُترجَمُ، وقائِمَةٌ تَضحَكُ (ج٤٤).
            ms.add(new MethodSymbol(md.name, this, md.mods.has(STATIC), md.varargs(), params, tps,
                md.result, md.result == null ? null : md.result.display(), md));
          }
        }
      }
      if (decl.kind == ENUM) {
        ms.add(new MethodSymbol("values", this, true, false, Collections.<String>emptyList(), null,
            null, "[]", null));
        ms.add(new MethodSymbol("valueOf", this, true, false, Collections.singletonList("String"),
            null, null, "", null));
      }
      if (decl.kind == RECORD) {
        ArrayList<String> params = new ArrayList<>();
        for (VarDecl v : decl.recordComponents) {
          params.add(v.type == null ? "?" : v.type.display());
          if (!declaredNoArg.contains(v.name))
            ms.add(new MethodSymbol(v.name, this, false, false, Collections.<String>emptyList(),
                null, v.type, null, null));
        }
        boolean varargs = !decl.recordComponents.isEmpty()
            && decl.recordComponents.get(decl.recordComponents.size() - 1).type != null
            && decl.recordComponents.get(decl.recordComponents.size() - 1).type.varargs;
        boolean duplicate = false;
        for (MethodSymbol c : cs) if (c.paramCount() == params.size()) duplicate = true;
        if (!duplicate) cs.add(new MethodSymbol(decl.name, this, false, varargs, params, null, null, null, null));
      }
      if (cs.isEmpty() && decl.kind == CLASS && !decl.anonymous)
        cs.add(new MethodSymbol(decl.name, this, false, false, Collections.<String>emptyList(), null,
            null, null, null));
      fields = fs;
      methods = ms;
      constructors = cs;
    }

    private static boolean hasLombok(Modifiers mods) {
      for (Annotation a : mods.annotations) {
        String n = a.type == null ? "" : a.type.simpleName();
        if (LOMBOK.contains(n) || a.type != null && a.type.qualified().startsWith("lombok.")) return true;
      }
      return false;
    }

    private ClassType objectType() {
      ClassSymbol o = universe.byQualified("java.lang.Object");
      return o == null ? null : new ClassType(o, null);
    }

    private static Type nonNull(Type t) {
      return t == null ? UNKNOWN : t;
    }

    @Override
    public ClassType superclass() {
      ensure();
      return superclass;
    }

    @Override
    public List<ClassType> interfaces() {
      ensure();
      return interfaces;
    }

    @Override
    public boolean supertypesResolved() {
      ensure();
      return resolved;
    }

    @Override
    public boolean reliable() {
      ensure();
      return reliable;
    }

    @Override
    public List<FieldSymbol> fields() {
      ensure();
      return fields;
    }

    @Override
    public List<MethodSymbol> methods() {
      ensure();
      return methods;
    }

    @Override
    public List<MethodSymbol> constructors() {
      ensure();
      return constructors;
    }

    @Override
    Type resolveReturn(MethodSymbol method) {
      if (decl.kind == ENUM && method.decl == null && method.returnRef == null) {
        if ("[]".equals(method.returnText)) return new ArrayType(new ClassType(this, null));
        if ("".equals(method.returnText)) return new ClassType(this, null);
      }
      if (method.returnRef == null) return UNKNOWN;
      HashMap<String, TypeVar> methodVars = null;
      if (method.decl != null && !method.decl.typeParams.isEmpty()) {
        methodVars = new HashMap<>();
        for (TypeParam tp : method.decl.typeParams) methodVars.put(tp.name, new TypeVar(tp.name, true));
      }
      Type t = resolve(method.returnRef, methodVars);
      return t == null ? UNKNOWN : t;
    }

    /** Supertype names are resolved from the enclosing scope (not from this class's members). */
    private static String writtenName(TypeRef ref) {
      if (ref == null || ref.names.isEmpty()) return ref != null && ref.primitive != null ? ref.primitive : "?";
      StringBuilder b = new StringBuilder();
      for (String n : ref.names) {
        if (b.length() > 0) b.append('.');
        b.append(n);
      }
      return b.toString();
    }

    private Type resolveSupertype(TypeRef ref) {
      return resolveRef(ref, null, outerClass, true);
    }

    /** Resolves a type written inside this class; null when the class name is not found. */
    public Type resolve(TypeRef ref, Map<String, TypeVar> methodVars) {
      Type t = resolveRef(ref, methodVars, this, false);
      return t == null ? UNKNOWN : t;
    }

    private Type resolveRef(TypeRef ref, Map<String, TypeVar> methodVars, ClassSymbol scope,
        boolean supertype) {
      if (ref == null || ref.inferred) return UNKNOWN;
      Type base;
      if (ref.wildcard != 0) {
        Type b = ref.bound == null ? null : resolveRef(ref.bound, methodVars, scope, supertype);
        return new WildcardType(ref.wildcard, b == null ? UNKNOWN : b);
      }
      if (ref.primitive != null) {
        base = primitive(ref.primitive);
      } else {
        if (ref.names.isEmpty()) return null;
        String first = ref.names.get(0);
        Type var = ref.names.size() == 1 ? typeVariable(first, methodVars, supertype) : null;
        if (var != null) base = var;
        else {
          ClassSymbol c = resolveClassName(ref, scope);
          if (c == null) return null;
          List<Type> args = null;
          List<TypeRef> last = ref.args.get(ref.args.size() - 1);
          if (last != null && !last.isEmpty()) {
            args = new ArrayList<>();
            for (TypeRef a : last) {
              Type at = resolveRef(a, methodVars, scope, supertype);
              args.add(at == null ? UNKNOWN : at);
            }
          }
          base = new ClassType(c, args);
        }
      }
      for (int i = 0; i < ref.dims; i++) base = new ArrayType(base);
      if (ref.varargs) base = new ArrayType(base);
      return base;
    }

    private Type typeVariable(String name, Map<String, TypeVar> methodVars, boolean supertype) {
      if (methodVars != null) {
        TypeVar v = methodVars.get(name);
        if (v != null) return v;
      }
      TypeVar own = typeVars.get(name);
      if (own != null) return own;
      ClassSymbol o = outerClass;
      boolean instance = !isStaticMember();
      while (instance && o instanceof SourceClass) {
        SourceClass so = (SourceClass) o;
        TypeVar v = so.typeVars.get(name);
        if (v != null) return v;
        instance = !so.isStaticMember();
        o = so.outerClass;
      }
      if (localNames != null) return localNames.typeVariable(name);
      return null;
    }

    private ClassSymbol resolveClassName(TypeRef ref, ClassSymbol scope) {
      List<String> names = ref.names;
      ClassSymbol c = resolveSimple(names.get(0), scope);
      int i = 1;
      if (c == null) {
        for (i = 2; i <= names.size(); i++) {
          StringBuilder q = new StringBuilder(names.get(0));
          for (int j = 1; j < i; j++) q.append('.').append(names.get(j));
          c = universe.byQualified(q.toString());
          if (c != null) break;
        }
        if (c == null) return null;
      }
      for (; i < names.size(); i++) {
        c = memberTypeInherited(c, names.get(i));
        if (c == null) return null;
      }
      return c;
    }

    private ClassSymbol resolveSimple(String name, ClassSymbol scope) {
      if (localNames != null) {
        ClassSymbol local = localNames.localType(name);
        if (local != null) return local;
      }
      for (ClassSymbol c = scope; c != null; c = c.outer()) {
        if (c.simpleName().equals(name) && !(c instanceof SourceClass && ((SourceClass) c).decl.anonymous)) return c;
        ClassSymbol m = memberTypeInherited(c, name);
        if (m != null) return m;
      }
      return resolveInFile(name, file, universe);
    }
  }
}
