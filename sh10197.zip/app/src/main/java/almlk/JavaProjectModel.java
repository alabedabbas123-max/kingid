package almlk;

import almlk.JavaSyntaxTree.Unit;
import almlk.JavaTypeModel.FileContext;
import almlk.JavaTypeModel.SourceClass;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Declarations of every project source (E1): the classes the analysis engine resolves project
 * names against. Fed by {@code ProjectSymbolIndex.registerSource}; each file is parsed in skeleton
 * mode (bodies skipped) and re-parsed only when its content changes.
 */
public final class JavaProjectModel {

  private static final Object LOCK = new Object();
  private static final HashMap<String, Entry> FILES = new HashMap<>();
  private static final ConcurrentHashMap<String, SourceClass> CLASSES = new ConcurrentHashMap<>();
  private static final ConcurrentHashMap<String, Integer> PACKAGES = new ConcurrentHashMap<>();
  private static final ConcurrentHashMap<String, Integer> PACKAGE_PREFIXES = new ConcurrentHashMap<>();
  private static volatile int generation;
  private static volatile boolean foreignSources;
  private static volatile boolean passOpen;
  /**
   * آخرُ نبضةِ مسحٍ (الجولةُ ‏33): المُنبِضُ حيٌّ مهما طالَ عمرُ الممرِّ، والمتوقِّفُ عن النبضِ يُعَدُّ
   * مُجهَضًا. كانَ العمرُ يُقاسُ من {@code beginPass} وحدَهُ، فمسحةُ مشروعٍ كبيرٍ تتجاوزُ
   * {@code PASS_STALE_MS} وهي جاريةٌ حرفيًّا — فيُعادُ فتحُ بابِ الجزْمِ والنموذجُ نصفُ مَبنيٍّ،
   * وذلكَ كلُّ «مئاتِ الأخطاءِ» على الاستيراداتِ وأصنافِ المنصّةِ.
   */
  private static volatile long passBeatAt;
  private static volatile boolean passGaps;
  /** ساعةُ الممرِّ: millis الحقيقيةُ على الجهازِ، ومَزروعةٌ في مجموعةِ الانحدارِ (قياسُ {@code
   * PlatformMemberLookup.useClassLoader}) — فلا نَطرُّ ولا نَنامُ في الاختبارِ. */
  public interface PassClock {
    long now();
  }
  private static volatile PassClock passClock = new PassClock() {
    @Override public long now() { return System.currentTimeMillis(); }
  };

  /** مَزرَعُ البوابةِ ({@code null} = الساعةُ الحقيقيةُ). */
  public static void usePassClockForTests(PassClock clock) {
    passClock = clock == null ? new PassClock() {
      @Override public long now() { return System.currentTimeMillis(); }
    } : clock;
  }

  private static long passNow() {
    PassClock clock = passClock;
    return clock == null ? System.currentTimeMillis() : clock.now();
  }

  private static final class Entry {
    final int hash;
    final int length;
    final String packageName;
    final List<SourceClass> classes;

    Entry(int hash, int length, String packageName, List<SourceClass> classes) {
      this.hash = hash;
      this.length = length;
      this.packageName = packageName;
      this.classes = classes;
    }
  }

  private JavaProjectModel() {}

  static int generation() {
    return generation;
  }

  public static void clear() {
    synchronized (LOCK) {
      FILES.clear();
      CLASSES.clear();
      PACKAGES.clear();
      PACKAGE_PREFIXES.clear();
      foreignSources = false;
      passOpen = false;
      passGaps = false;
      generation++;
    }
  }

  /**
   * The project also has sources this model does not read (Kotlin): their classes are invisible
   * here, so a project-side type can never be proven absent.
   */
  public static void noteForeignSource() {
    foreignSources = true;
  }

  public static boolean hasForeignSources() {
    return foreignSources;
  }

  /**
   * Does this process's model already contain {@code reference}? A fresh on-disk class cache says a
   * file is unchanged since the last machine's scan — it says nothing about this process, so an
   * unchanged file still has to be read once per pass, or its classes look absent to the analysis.
   */
  public static boolean knows(String reference) {
    synchronized (LOCK) {
      return reference != null && FILES.containsKey(reference);
    }
  }

  /**
   * يبدأ مسحة بناء النموذج: أثناء المرور لا يجوز الجزم بغياب رمز، فالنموذج نصف مُعبَّأ بالضرورة
   * (هذا بالضبط ما كان يولّد «Unknown entity» كاذبة على أصناف المشروع عند كل فتح ثانٍ).
   */
  public static void beginPass() {
    synchronized (LOCK) {
      passOpen = true;
      passGaps = false;
      passBeatAt = passNow();
    }
  }

  /**
   * نبضةُ الماسحِ (الجولةُ ‏33، قـ١): تُنادَى كلَّ بضعِ عشراتِ الملفاتِ أثناءَ المسحِ. وظيفتُها أن
   * تُميِّزَ المسحَ الطويلَ الحيَّ من الممرِ المُجهَضِ: الأوّلُ لا يجوزُ الجزْمُ معهُ مطلقًا، والثاني
   * لا يُسكِتُ الفحصَ إلى الأبدِ. بلا هذهِ النبضةِ كانَ الطولُ نفسُهُ جنايةً على اليقينِ.
   */
  public static void notePassProgress() {
    if (passOpen) passBeatAt = passNow();
  }

  /** هل الممرُّ جاريٌّ الآنَ؟ (للتشخيصِ وللبواباتِ لا للحُكمِ على الجزْمِ). */
  public static boolean isPassOpen() {
    return passOpen;
  }

  /** عُمرُ آخرِ نبضةٍ بالميلي‌ثانية؛ سالبٌ إن لم يُفتَحْ ممرٌّ قطُّ. */
  public static long passAgeMs() {
    long beat = passBeatAt;
    return beat == 0L ? -1L : passNow() - beat;
  }

  /** مصدر تعذّر قراءته أو تخطّته المسحة (حدّ ملفات، استثناء إدخال، انقطاع): الجزم ممنوع بعدها. */
  public static void notePassGap() {
    passGaps = true;
  }

  /** ينهي المسحة؛ تُرفع المنعة عن الجزم إن لم تُبلَّغ فجوة فيها. */
  public static void endPass() {
    synchronized (LOCK) {
      passOpen = false;
    }
  }

  /**
   * هل غياب اسم عن النموذج <b>دليل</b> على عدم وجوده؟ لا، ما دامت المسحة جارية أو تركت فجوة أو كان
   * النموذج فارغًا. مسحة متوقفة (عملية أُجهضت ولم تصل {@code endPass}) لا تُسكِت الفحص إلى الأبد:
   * تُعدّ ميتة بعد {@code PASS_STALE_MS} <b>من آخرِ نبضةٍ</b> ({@link #notePassProgress}) فيعود الجزم
   * ممكنًا — فاليقينُ يُرَدُّ بانقطاعِ الخبرِ، لا بمرورِ الزمنِ على بدءٍ قد يكونُ مسحٌ حيٌّ بعدهُ.
   */
  public static boolean absenceProvablyComplete() {
    if (isEmpty()) return false;
    if (passGaps) return false;
    if (!passOpen) return true;
    return isPassAbandoned(passNow());
  }

  /** خالصةٌ: هل انقطَعَ خبرُ الممرِّ أطولَ من المِقدارِ المُسمَحِ؟ الوقتُ مُعطًى لا مقروءٌ. */
  public static boolean isPassAbandoned(long nowMs) {
    long beat = passBeatAt;
    return beat != 0L && nowMs - beat > PASS_STALE_MS;
  }

  /** مدةُ انقطاعِ النبضِ التي يُعدّ بعدها ممرٌّ مُجهَضًا لم يُغلق. */
  public static final long PASS_STALE_MS = 20_000;

  /** Registers (or refreshes) one project source identified by its stable {@code reference}. */
  public static void register(String reference, String source) {
    if (reference == null || source == null) return;
    synchronized (LOCK) {
      Entry old = FILES.get(reference);
      if (old != null && old.hash == source.hashCode() && old.length == source.length()) return;
      Unit unit = JavaParser.parseSkeleton(source);
      FileContext file = new FileContext(unit);
      ArrayList<SourceClass> classes = new ArrayList<>();
      for (JavaSyntaxTree.TypeDecl decl : unit.types) {
        if (decl.name.isEmpty()) continue;
        SourceClass c = new SourceClass(decl, file, null, JavaTypeModel.GLOBAL, null);
        file.topLevel.put(decl.name, c);
        collect(c, classes);
      }
      if (old != null) unregister(old);
      Entry entry = new Entry(source.hashCode(), source.length(), file.packageName, classes);
      FILES.put(reference, entry);
      for (SourceClass c : classes) CLASSES.put(c.qualifiedName(), c);
      PACKAGES.merge(file.packageName, 1, Integer::sum);
      for (String prefix : prefixes(file.packageName)) PACKAGE_PREFIXES.merge(prefix, 1, Integer::sum);
      generation++;
    }
  }

  private static void collect(SourceClass c, List<SourceClass> into) {
    into.add(c);
    for (SourceClass nested : c.nestedClasses()) collect(nested, into);
  }

  private static void unregister(Entry old) {
    for (SourceClass c : old.classes) CLASSES.remove(c.qualifiedName(), c);
    decrement(PACKAGES, old.packageName);
    for (String prefix : prefixes(old.packageName)) decrement(PACKAGE_PREFIXES, prefix);
  }

  private static void decrement(Map<String, Integer> map, String key) {
    Integer n = map.get(key);
    if (n == null) return;
    if (n <= 1) map.remove(key);
    else map.put(key, n - 1);
  }

  private static List<String> prefixes(String pkg) {
    if (pkg == null || pkg.isEmpty()) return Collections.emptyList();
    ArrayList<String> list = new ArrayList<>();
    int dot = pkg.indexOf('.');
    while (dot > 0) {
      list.add(pkg.substring(0, dot));
      dot = pkg.indexOf('.', dot + 1);
    }
    list.add(pkg);
    return list;
  }

  public static SourceClass classByQualifiedName(String qualified) {
    return qualified == null ? null : CLASSES.get(qualified);
  }

  /** A package that holds at least one project file. */
  public static boolean hasPackage(String pkg) {
    return pkg != null && PACKAGES.containsKey(pkg);
  }

  /** {@code name} is a project package or a prefix of one ({@code com}, {@code com.example}). */
  public static boolean isPackagePrefix(String name) {
    return name != null && PACKAGE_PREFIXES.containsKey(name);
  }

  public static boolean isEmpty() {
    return CLASSES.isEmpty();
  }

  public static List<SourceClass> classesNamed(String simpleName) {
    ArrayList<SourceClass> list = new ArrayList<>();
    for (SourceClass c : CLASSES.values()) if (c.simpleName().equals(simpleName)) list.add(c);
    return list;
  }
}
