package almlk;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * فهرس مكتبات المشروع (M4): يحوّل classpath المحقون من M3 إلى معرفة يستعملها الإكمال والتحقق.
 *
 * <ul>
 *   <li>كل JAR يُقرأ مرة واحدة بـ{@link ClassFileReader} وتُكتب كتلته بصيغة فهرس المنصة في ذاكرة
 *       مضغوطة بجانبه {@code *.shima-idx} (أو في مجلد الذاكرة المؤقتة إن كان المجلد للقراءة فقط).
 *   <li>كل AAR: الحزمة من AndroidManifest، وصنف {@code R} من R.txt، وخصائص {@code app:} وقيم
 *       enum/flag من {@code res/values/values.xml}، وأسماء الموارد — في ذاكرة {@code .shima-res}.
 *   <li>صنف {@code R} للتطبيق من موارد المشروع (ومن المكتبات إن كان R متعدّيًا) — مؤقت لا يُثبت غيابًا.
 * </ul>
 *
 * <p>يُدمج الناتج في {@link AndroidApiIndex} طبقةً واحدة تُستبدل ذرّيًا، فلا تتغيّر الواجهات العامة.
 * تشخيص «نوع/حزمة غير معروفة» لا يعمل إلا حين يكون الحلّ مكتملًا ({@link #importsCheckable}).
 */
public final class LibraryClassIndex {

  public static final String CACHE_SUFFIX = ".shima-idx";
  static final String RES_CACHE = ".shima-res";
  static final String INDEX_HEADER = "#shima-lib-idx 3";
  static final String RES_HEADER = "#shima-lib-res 3";

  /**
   * وحدةُ مشروعٍ مرتبطةٍ وموارِدُها المقروءةُ من قرصِها. صنفُ {@code R} يُبنى لكلِّ
   * وحدةٍ بحزمتِها — الاسمُ من {@code namespace} في ملفِّ بنائِها، وإلا من
   * {@code package=} في manifestِها، كما يصنعُ البناءُ الحقيقيُّ؛ ولا تقديرَ لآخرَ.
   */
  public static final class ModuleResources {
    public final File dir;
    public final String rPackage;
    public final ResourceSet resources;

    ModuleResources(File dir, String rPackage, ResourceSet resources) {
      this.dir = dir;
      this.rPackage = rPackage == null ? "" : rPackage;
      this.resources = resources == null ? new ResourceSet() : resources;
    }
  }

  /** ما يُفهرس: من نموذج البناء وحالة الحقن. */
  public static final class Request {
    public final File projectRoot, moduleDir, cacheDir;
    public final List<File> jars;
    public final List<File> aarDirs;
    /** الحلّ مكتمل وكل الاعتماديات قابلة للإثبات: يُسمح بتشخيص الاستيراد. */
    public final boolean complete;
    /** R التطبيق يضم موارد المكتبات (nonTransitiveRClass=false أو AGP أقدم من 8). */
    public final boolean transitiveR;
    public final String appPackage;
    /** مواردُ وحداتِ ‏{@code project(':x')} الموصولةِ — فارغةٌ في مشروعٍ بلا وصلٍ. */
    public final List<ModuleResources> modules;

    public Request(File projectRoot, File moduleDir, File cacheDir, List<File> jars, List<File> aarDirs,
        boolean complete, boolean transitiveR, String appPackage) {
      this(projectRoot, moduleDir, cacheDir, jars, aarDirs, complete, transitiveR, appPackage,
          Collections.<ModuleResources>emptyList());
    }

    public Request(File projectRoot, File moduleDir, File cacheDir, List<File> jars, List<File> aarDirs,
        boolean complete, boolean transitiveR, String appPackage, List<ModuleResources> modules) {
      this.projectRoot = projectRoot;
      this.moduleDir = moduleDir;
      this.cacheDir = cacheDir;
      this.jars = Collections.unmodifiableList(new ArrayList<>(jars));
      this.aarDirs = Collections.unmodifiableList(new ArrayList<>(aarDirs));
      this.complete = complete;
      this.transitiveR = transitiveR;
      this.appPackage = appPackage == null ? "" : appPackage;
      this.modules = Collections.unmodifiableList(new ArrayList<>(modules));
    }

    /** من نموذج الوحدة وحالة المكتبات المحقونة. */
    public static Request of(GradleBuildModel model, ProjectLibraries state, File cacheDir) {
      ArrayList<File> jars = new ArrayList<>(state.classpath());
      // W22/4ب: ما في `libs/` يُرصدُ هنا — على خيطٍ الفهرسة، ببصمةٍ القرص، بلا
      // شبكةٍ: فلا ينتظرُ المستخدمُ سطرَ `fileTree` ولا دورةَ تنزيلٍ لتدخُلَ أدواتُه.
      state.observeLocals(model.moduleDir, model.projectRoot, model.text);
      boolean provable = state.isComplete();
      // الوصلُ بعدَ كلِّ ما سبقَ: ما أعلنَهُ `fileTree`/`files(...)` قد يكونُ الملفَّ نفسَهُ الذي
      // رأتِهِ `libs/` — فلا يُفتَّحُ الأرشيفُ مرّتَيْنِ ولا يُكرَّرُ في classpathِ التحليلِ.
      java.util.Set<String> seenPaths = new java.util.HashSet<>();
      for (File jar : jars) seenPaths.add(jar.getAbsolutePath());
      for (File local : state.localClasspath()) {
        if (seenPaths.add(local.getAbsolutePath())) jars.add(local);
      }
      ArrayList<File> aarDirs = new ArrayList<>(state.libraryDirs());
      java.util.Set<String> seenNodes = new java.util.HashSet<>();
      for (File dir : aarDirs) seenNodes.add(dir.getAbsolutePath());
      for (File node : state.localAarNodes()) {
        if (seenNodes.add(node.getAbsolutePath())) aarDirs.add(node);
      }
      // W22/4ب٢‑ب: الوحدةُ المرتبطةُ ليست زخرفةً في الإعداداتِ: ملفّاتُها المعلَنةُ و{@code libs/}
      // فيها تدخلُ التحليلَ، و{@code project(':x')} لا يُنقِصُ الإثباتَ إذا كانَ مُدرَجًا ومعروفَ
      // المجلدِ. ما لم يُدرَجْ أو لم يُثبَتْ يبقَ مُعلَنَ النقصِ — يُخبَرُ عنهُ ولا يُختلَعُ.
      ArrayList<ModuleResources> modules = new ArrayList<>();
      for (GradleBuildModel source : model.modelsForAnalysis()) {
        boolean foreign = source != model;
        for (GradleBuildModel.Dependency d : source.dependencies) {
          if (!d.forAnalysis() && d.kind != GradleBuildModel.Kind.FILES) continue;
          switch (d.kind) {
            case FILES:
              if (d.scope == null || !d.forAnalysis()) break;
              List<File> files = fileDependencyJars(source.moduleDir, d.rawNotation);
              if (files == null) provable = false;
              else for (File jar : files) if (seenPaths.add(jar.getAbsolutePath())) jars.add(jar);
              break;
            case PROJECT:
              if (!model.resolvesProject(d.notation)) provable = false;
              break;
            case UNSUPPORTED:
            case UNRESOLVED_VARIABLE:
            case INVALID:
              provable = false;
              break;
            default:
              break;
          }
        }
        if (foreign) {
          almlk.LocalLibraries.Finding locals =
              almlk.LocalLibraries.discover(source.moduleDir, source.projectRoot, source.text, null);
          for (File jar : locals.classpath) {
            if (seenPaths.add(jar.getAbsolutePath())) jars.add(jar);
          }
          for (File node : locals.aarNodes) {
            if (seenNodes.add(node.getAbsolutePath())) aarDirs.add(node);
          }
          // W22/4ب٢‑ب٢: مخرجُ الوحدةِ نفسِها على القرصِ (بناؤُها السابقُ) إن وُجِدَ — فلا تُترَكُ
          // وحدةٌ بغيرِ أصنافٍ لمجرّدِ أنَّ مصادرَها خارجَ المتصفّحِ، ولا يُبنَ لهُ شيءٌ قسرًا.
          almlk.LocalLibraries.Finding built =
              almlk.LocalLibraries.discoverOutputs(source.moduleDir, null);
          for (File jar : built.classpath) {
            if (seenPaths.add(jar.getAbsolutePath())) jars.add(jar);
          }
          for (File node : built.aarNodes) {
            if (seenNodes.add(node.getAbsolutePath())) aarDirs.add(node);
          }
          // W22/4ب٢‑ب٣: ومواردُ الوحدةِ تدخلُ الفهرسَ لا البناءَ: تُقرأُ موارِدُها
          // بقارئِ مواردِ المشروعِ نفسِهِ، فتُصنعُ لها R بحزمتِها وتُرى أسماؤُها في
          // إكمالِ XML. لا ملفَّ تعريفٍ على القرصِ، ولا مخرجاتَ بناءٍ تُلْمَسُ، ولا أداةَ
          // مواردِ تُستَدْعى — قراءةٌ في الشجرةِ وتصنيعٌ في الذاكرةِ فقطَ.
          ResourceSet declared = projectResources(source.moduleDir);
          if (!declared.names.isEmpty() || !declared.attrs.isEmpty() || !declared.styleables.isEmpty()) {
            modules.add(new ModuleResources(source.moduleDir, appPackage(source), declared));
          }
        }
        if (source.text.contains("useLibrary") || hasSourcesOtherThanJava(source.moduleDir)) provable = false;
      }
      return new Request(model.projectRoot, model.moduleDir, cacheDir, jars, aarDirs, provable,
          transitiveR(model), appPackage(model), modules);
    }
  }

  // ═══════════════ الحالة ═══════════════

  /** موارد مكتبة أو المشروع: الخصائص المخصّصة، وstyleables، والأسماء لكل نوع. */
  static final class ResourceSet {
    final Map<String, AndroidApiIndex.AttrInfo> attrs = new LinkedHashMap<>();
    final Map<String, List<String>> styleables = new HashMap<>();
    final Map<String, TreeSet<String>> names = new HashMap<>();

    void name(String type, String name) {
      if (type == null || name == null || name.isEmpty()) return;
      names.computeIfAbsent(type, k -> new TreeSet<>()).add(name);
    }

    void addAll(ResourceSet other) {
      for (Map.Entry<String, AndroidApiIndex.AttrInfo> e : other.attrs.entrySet()) attrs.putIfAbsent(e.getKey(), e.getValue());
      for (Map.Entry<String, List<String>> e : other.styleables.entrySet()) styleables.putIfAbsent(e.getKey(), e.getValue());
      for (Map.Entry<String, TreeSet<String>> e : other.names.entrySet())
        names.computeIfAbsent(e.getKey(), k -> new TreeSet<>()).addAll(e.getValue());
      if (other.incomplete != null) incomplete(other.incomplete);
    }

    /**
     * سببٌ مُسمًّى يمنعُ عدَّ القائمةِ كاملةً (أولُّ سببٍ يُحفَظُ، ولا يَمحوهُ صمتٌ آخرُ). القاعدةُ:
     * لا «نصفُ قراءةٍ» بلا سببٍ — الصمتُ عن حكمٍ يَجِبُ أن يقعَ خطأً صامتًا لا يُعرَفُ، والسببُ
     * المكتوبُ هو ما يَجعلُ الحَذَرَ مُعلَنًا يُمكِنُ تضييقُهُ.
     */
    String incomplete;

    void incomplete(String reason) {
      if (incomplete == null) incomplete = reason;
    }

    /** قائمةٌ مُثبَتةٌ: كلُّ ما في الشجرةِ قُرِئَ، فلم نتجاوزْ مجلدًا ولا ملفًّا ولا نوعًا صمتًا. */
    boolean certain() {
      return incomplete == null;
    }

    String signature() {
      StringBuilder b = new StringBuilder();
      for (Map.Entry<String, TreeSet<String>> e : new TreeMap<>(names).entrySet())
        b.append(e.getKey()).append('=').append(e.getValue()).append(';');
      b.append(new TreeMap<>(styleables));
      b.append('|').append(incomplete == null ? "certain" : "uncertain");
      return b.toString();
    }
  }

  /** مكتبة AAR مقروءة. */
  static final class AarData {
    String packageName = "";
    final ResourceSet resources = new ResourceSet();
    /** حقول R.txt: النوع → (الاسم → int أو int[]). */
    final Map<String, Map<String, String>> rFields = new TreeMap<>();
    /** علَّةٌ مُسمَّاةٌ تُبطِلُ عدَّ ‏`rFields` قائمةً كاملةً؛ أو `null` إذا قُرِئَ كلُّ سطرٍ. */
    String problem;

    /** قائمةُ أصنافِ ‏R المُكتَمَلةُ تُثبَتُ: ‏`R.txt` فُهِمَ سطرًا سطرًا حتى آخرِهِ. */
    boolean certain() {
      return problem == null;
    }
  }

  private static final class Snapshot {
    static final Snapshot EMPTY = new Snapshot(null, Collections.<byte[]>emptyList(), new ResourceSet(),
        Collections.<String, Map<String, String>>emptyMap(), Collections.<String>emptyList(), true, 0);
    final Request request;
    final List<byte[]> blocks;
    /** مواردُ الأرففِ وحدَها (AAR): قاعدةُ الاتحادِ الذي يُعادُ عندَ كلِّ تحديثٍ. */
    final ResourceSet libraryResources;
    /** ما يسألُهُ المُكمِّلُ والسائلونَ: الأرففُ ثمَّ مواردُ الوحداتِ الموصولةِ. */
    volatile ResourceSet libraries;
    final Map<String, Map<String, String>> libraryRFields;
    /** ما رُفِضَ من مكتباتٍ بأسمائِها وأسبابِها — للخبرِ المرئيِّ، لا للحُكمِ على الأصنافِ. */
    final List<String> problems;
    /** لا صنفُ مكتبةٍ ناقصٌ ولا ‏`R.txt` مبتورٌ: عندها فقطَ يُثبَتُ غيابُ عضوٍ في ‏R مكتبةٍ أو التطبيقِ. */
    final boolean libraryCertain;
    final int generation;
    volatile ResourceSet project = new ResourceSet();
    volatile String projectSignature = "";
    /** موردُ كلِّ وحدةٍ موصولةٍ بترتيبِ ‏{@code request.modules}؛ {@code null} قبلَ أولِ قراءةٍ. */
    volatile List<ResourceSet> moduleResources = Collections.emptyList();
    volatile String modulesSignature;
    volatile long projectBuiltAt;

    Snapshot(Request request, List<byte[]> blocks, ResourceSet libraries,
        Map<String, Map<String, String>> libraryRFields, List<String> problems, boolean libraryCertain,
        int generation) {
      this.request = request;
      this.blocks = blocks;
      this.libraryResources = libraries;
      this.libraries = libraries;
      this.libraryRFields = libraryRFields;
      this.problems = problems;
      this.libraryCertain = libraryCertain;
      this.generation = generation;
    }
  }

  private static final Object LOCK = new Object();
  private static volatile Snapshot current = Snapshot.EMPTY;
  private static int generation;
  private static final long PROJECT_REFRESH_MS = 3000;

  private LibraryClassIndex() {}

  // ═══════════════ التثبيت ═══════════════

  /** يبني الفهرس على خيط عامل ثم ينفّذ {@code done} (على الخيط نفسه). */
  public static void installAsync(final Request request, final Runnable done) {
    final int run;
    synchronized (LOCK) {
      run = ++generation;
    }
    Thread worker = new Thread(() -> {
      try {
        install(request, run);
      } catch (Throwable ignored) {
        // فهرس ناقص لا يُسقط المحرر: يبقى السابق أو الفارغ.
      }
      if (done != null) done.run();
    }, "LibraryClassIndex");
    worker.setDaemon(true);
    worker.setPriority(Thread.MIN_PRIORITY);
    worker.start();
  }

  /**
   * كما {@link #installAsync(Request, Runnable)} لكنَّ الطلبَ نفسَهُ يُبنى داخل الخيطِ العاملِ:
   * رصدُ {@code libs/} — جردُ القرصِ وقراءةُ ترويساتِ الأرشيفاتِ وفكُّ AAR إن وُجِدَ — لا يمسُّ
   * خيطَ الواجهةِ قطُّ، وهو ما يطلبُهُ «فوريٌّ بلا تثقيلٍ»: الفتحُ يعودُ إلى المحرّرِ حالًا.
   */
  public static void installAsync(
      final GradleBuildModel model, final ProjectLibraries state, final File cacheDir, final Runnable done) {
    final int run;
    synchronized (LOCK) {
      run = ++generation;
    }
    Thread worker = new Thread(() -> {
      try {
        install(Request.of(model, state, cacheDir), run);
      } catch (Throwable ignored) {
        // فهرسٌ ناقصٌ لا يُسقِطُ المحرّرَ: يبقى السابقُ أو الفارغُ.
      }
      if (done != null) done.run();
    }, "LibraryClassIndex");
    worker.setDaemon(true);
    worker.setPriority(Thread.MIN_PRIORITY);
    worker.start();
  }

  /** بناء متزامن (للاختبارات وللخيط العامل). */
  public static void install(Request request) {
    int run;
    synchronized (LOCK) {
      run = ++generation;
    }
    install(request, run);
  }

  private static void install(Request request, int run) {
    if (request == null) {
      clear();
      return;
    }
    ArrayList<byte[]> blocks = new ArrayList<>();
    ArrayList<String> problems = new ArrayList<>();
    // W32: لا «تُتخطّى أصنافُهُ فقط». الأرشيفُ الذي لا يُقرَأُ كلُّهُ مَجهولٌ كلُّهُ: نُسمِّيهِ ونَرفُضُهُ
    // ونُبطِلُ إثباتَ الطبقةِ، فيَسكُتُ المُحلِّلُ حيثُ لم يَعلَمْ بدلَ أن يَحكُمَ على صنفٍ موجودٍ بأنَّهُ
    // «لا يُعرَفُ» (وهو وَهمُ ‏Context الذي وَعَدَت بِهِ خطةُ ‏W29 §٤/٤).
    boolean libraryCertain = true;
    for (File jar : request.jars) {
      if (stale(run)) return;
      try {
        byte[] block = jarIndex(jar, request.cacheDir);
        if (block != null) blocks.add(block);
      } catch (IOException broken) {
        problems.add(jar.getName() + " — " + messageOf(broken));
        libraryCertain = false;
      }
    }
    ResourceSet libraries = new ResourceSet();
    Map<String, Map<String, String>> allRFields = new TreeMap<>();
    for (File dir : request.aarDirs) {
      if (stale(run)) return;
      // العَقدُ تُفتَحُ على سببِها لا على «لا شيءَ»: بصمةُ العقدِ تُعلِنُ مُكوِّناتِها، فلو بُتِرَ
      // منها classes.jar أو مُنِيَ الفكُّ بنِقصٍ لَمَا جازَ أن تُنسَبَ العقدةُ إلى طبقةٍ مكتملةٍ.
      String why = AarExploder.nodeDamage(dir);
      AarData aar = why == null ? aarData(dir) : null;
      if (aar == null) {
        // عقدٌ لا يُعتَدُّ بهِ ليسَ «لا شيءَ»: اسمُهُ وسببُهُ خبرٌ يَجِبُ أن يَبلُغَ اللوحةَ.
        problems.add(nameOf(dir) + " — " + (why == null ? "no readable aar node" : why));
        libraryCertain = false;
        continue;
      }
      libraries.addAll(aar.resources);
      if (!aar.certain()) {
        problems.add(nameOf(dir) + " — " + aar.problem);
        libraryCertain = false;
      }
      if (!aar.packageName.isEmpty() && !aar.rFields.isEmpty())
        blocks.add(rClassBlock(aar.packageName, aar.rFields, !aar.certain()));
      for (Map.Entry<String, Map<String, String>> e : aar.rFields.entrySet())
        allRFields.computeIfAbsent(e.getKey(), k -> new TreeMap<>()).putAll(e.getValue());
    }
    // كتلُ R الوحداتِ وأسماءُها لا تُبنى هنا: تبنيها refreshProject (force) فورًا،
    // فتكونُ الدورةُ نفسُها عندَ الحفظِ وعندَ التثبيتِ — لا مسارَينِ يتفّقانِ بالصدفةِ.
    Snapshot next = new Snapshot(request, Collections.unmodifiableList(blocks), libraries, allRFields,
        Collections.unmodifiableList(problems), libraryCertain, run);
    synchronized (LOCK) {
      if (run != generation) return;
      refreshProject(next, true);
      current = next;
    }
  }

  private static boolean stale(int run) {
    synchronized (LOCK) {
      return run != generation;
    }
  }

  /** إغلاق المشروع أو تغيّره: لا مكتبات ولا تشخيص استيراد. */
  public static void clear() {
    synchronized (LOCK) {
      generation++;
      current = Snapshot.EMPTY;
      AndroidApiIndex.installLibraries(null);
    }
  }

  /** موارد المشروع تغيّرت (حفظ ملف): يُعاد R التطبيق والقوائم إن اختلفت الأسماء. */
  public static void refreshProjectResources() {
    synchronized (LOCK) {
      Snapshot snapshot = current;
      if (snapshot.request != null) refreshProject(snapshot, false);
    }
  }

  /** يعيد موارد المشروع؛ ويعيد بناء الطبقة (لـR التطبيق) عند تغيّر الأسماء أو عند التثبيت. */
  private static void refreshProject(Snapshot snapshot, boolean force) {
    ResourceSet project = projectResources(snapshot.request.moduleDir);
    String signature = project.signature();
    String modules = refreshModuleResources(snapshot);
    snapshot.project = project;
    snapshot.projectBuiltAt = System.currentTimeMillis();
    if (!force && signature.equals(snapshot.projectSignature) && modules.equals(snapshot.modulesSignature)) return;
    snapshot.projectSignature = signature;
    snapshot.modulesSignature = modules;
    ArrayList<byte[]> blocks = new ArrayList<>(snapshot.blocks);
    // W22/4ب٢‑ب٣: R كلِّ وحدةٍ موصولةٍ يُبنى بحزمتِها — لا في R التطبيقِ إلا إذا كانَ
    // R متعدّيًا عندَها (nonTransitiveRClass=false أو AGP أقدمُ من 8)، وكلاهما مُعلَنٌ.
    // وجديدُ W31: لم تَبقَ القائمةُ «مؤقَّتةً» بالحُكمِ العامِّ. المُحَكِّمُ شارةُ الاكتمالِ في
    // ResourceSet نفسِها (سببٌ مُسمًّى عندَ مجلدٍ لا يُدرَجُ، أو ملفٍّ لا يُقرَأُ، أو نوعِ مواردَ
    // لا نقرَأُهُ، أو values بلا بِنْيَةٍ مُكمَلةٍ): مَن قرَأَ كلَّ ما في شجرةٍ يَملِكُ أن يَحكُمَ
    // بغيابِ عضوٍ فيها، ومَن تَجاهَلَ صامتًا يَسكُتُ. هذا يَقبِضُ على سببِ الخطأِ الذي أصلحَهُ
    // المرجعُ بالإسكاتِ العامِّ، ويُعيدُ للمُحلِّلِ قولَ «لا مَوردَ بهذا الاسمِ» حيثُ ثِقَتُنا ثابتةٌ.
    List<ModuleResources> declared = snapshot.request.modules;
    List<ResourceSet> sets = snapshot.moduleResources;
    Map<String, Map<String, String>> moduleFields = new TreeMap<>();
    for (int i = 0; i < declared.size() && i < sets.size(); i++) {
      Map<String, Map<String, String>> fields = rFieldsOf(sets.get(i));
      if (fields.isEmpty()) continue;
      for (Map.Entry<String, Map<String, String>> e : fields.entrySet())
        moduleFields.computeIfAbsent(e.getKey(), k -> new TreeMap<>()).putAll(e.getValue());
      if (!declared.get(i).rPackage.isEmpty()) {
        blocks.add(rClassBlock(declared.get(i).rPackage, fields, !sets.get(i).certain()));
      }
    }
    String appPackage = snapshot.request.appPackage;
    if (!appPackage.isEmpty()) {
      Map<String, Map<String, String>> fields = rFieldsOf(project);
      // ثِقتُنا بقائمةِ التطبيقِ ثِقتُنا بكلِّ ما دَخَلَ فيها: أسماءُ المكتباتِ من ‏`R.txt` الذي
      // كَتبَهُ مُجمِّعُ المواردِ قائمةٌ مُغلَقةُ الصُّنعِ (كسِياسةِ أصنافِ ‏R المكتباتِ)، وأمَّا اكتمالُ
      // تفكيكِ ‏Aar نفسِهِ فصارَ مَوصولًا في ‏1.0.184: أرشيفٌ لا يُقرَأُ آخِرَهُ أو ‏R.txt مُحرَّفُ السطرِ
      // يُبطلانِ ‏libraryCertain، فلا يبقى اليقينُ ادعاءً يُعلَّقُ على بابٍ مُفتوحٍ.
      boolean certain = project.certain();
      if (snapshot.request.transitiveR) {
        certain = certain && snapshot.libraryCertain;
        for (ResourceSet set : sets) certain = certain && set.certain();
        for (Map.Entry<String, Map<String, String>> e : snapshot.libraryRFields.entrySet())
          fields.computeIfAbsent(e.getKey(), k -> new TreeMap<>()).putAll(e.getValue());
        for (Map.Entry<String, Map<String, String>> e : moduleFields.entrySet())
          fields.computeIfAbsent(e.getKey(), k -> new TreeMap<>()).putAll(e.getValue());
      }
      blocks.add(0, rClassBlock(appPackage, fields, !certain));
    }
    AndroidApiIndex.installLibraries(AndroidApiIndex.buildLayer(blocks, snapshot.generation));
  }

  /**
   * يعيدُ قراءةَ مواردِ الوحداتِ الموصولةِ ويحدّثُ اتحادَ ما تُسألُ منهُ المكتباتُ.
   * أولُ مرةٍ تكتفي بما قرأَهُ ‏{@code Request.of} فلا تُمسُّ الشجرةُ مرتينِ؛ وبعدَها
   * تمرُّ بقارئِ مواردِ المشروعِ نفسِهِ (لا قارئَ ثانٍ ولا استبعادًا مختلفًا). مشروعٌ
   * لم يُعلِنْ وحدةً لا يمشي قرصًا هنا ولا يُبدّلُ اتحادَهُ: ‏{@value #PROJECT_REFRESH_MS}
   * milli ثانيةٌ حدُّ الدورةِ كلِّها، مُطبَّقٌ في ‏{@code projectSet} قبلَ هذا الاستدعاءِ.
   */
  private static String refreshModuleResources(Snapshot snapshot) {
    List<ModuleResources> declared = snapshot.request.modules;
    if (declared.isEmpty()) {
      if (!snapshot.moduleResources.isEmpty()) {
        snapshot.moduleResources = Collections.<ResourceSet>emptyList();
        snapshot.libraries = snapshot.libraryResources;
      }
      return "";
    }
    boolean firstPass = snapshot.modulesSignature == null;
    ArrayList<ResourceSet> sets = new ArrayList<>(declared.size());
    StringBuilder signature = new StringBuilder();
    for (ModuleResources module : declared) {
      ResourceSet set = firstPass ? module.resources : projectResources(module.dir);
      sets.add(set);
      signature.append(module.rPackage).append('=').append(set.signature()).append(';');
    }
    snapshot.moduleResources = Collections.unmodifiableList(sets);
    snapshot.libraries = unionResources(snapshot.libraryResources, sets);
    return signature.toString();
  }

  /** الأرففُ ثمَّ الوحداتُ؛ الأسبقُ يفوزُ كما في ‏{@link ResourceSet#addAll} — لا خزانةَ. */
  private static ResourceSet unionResources(ResourceSet base, List<ResourceSet> extra) {
    if (extra.isEmpty()) return base;
    ResourceSet out = new ResourceSet();
    out.addAll(base);
    for (ResourceSet set : extra) out.addAll(set);
    return out;
  }

  // ═══════════════ الاستعلامات ═══════════════

  public static boolean isInstalled() {
    return current.request != null;
  }

  /** الحلّ مكتمل وقابل للإثبات، والفهرس مبني. */
  public static boolean isComplete() {
    Snapshot snapshot = current;
    //_request.complete_ قولُ المنادِي إنَّ كلَّ ما أُعلِنَ حُلَّ؛ و‏`libraryCertain` قولُ الفهرسِ إنَّهُ
    // قرَأَ ما حُلَّ كلَّهُ. الإثباتُ عندَ المُحلِّلِ يحتاجُ الاثنينِ — مِقبضٌ واحدٌ لا استثناءَ مفاتيحَ.
    return snapshot.request != null && snapshot.request.complete && snapshot.libraryCertain;
  }

  /** المكتباتُ المَرفوضةُ بأسمائِها وأسبابِها — تُعرَضُ، ولا تُستعمَلُ لحُكمٍ على صنفٍ. */
  public static List<String> problems() {
    return current.problems;
  }

  private static String messageOf(IOException error) {
    String text = error.getMessage();
    return text == null || text.isEmpty() ? error.getClass().getSimpleName() : text;
  }

  private static String nameOf(File file) {
    if (file == null) return "aar";
    File parent = file.getParentFile();
    // عقدةُ الفكِّ تحملُ اسمَ الأداةِ معَ اللاحقتَينِ: الخبرُ يُقالُ بالاسمِ الذي يَراهُ المستخدمُ.
    String name = file.getName();
    int dot = name.indexOf('.');
    return parent != null && name.endsWith(AarExploder.NODE_SUFFIX)
        ? name.substring(0, dot) + ".aar" : name;
  }

  public static String appPackage() {
    Snapshot snapshot = current;
    return snapshot.request == null ? "" : snapshot.request.appPackage;
  }

  /**
   * يُسمح بتشخيص استيرادات ملف حزمته {@code packageName} وصنفه الأول {@code primaryType}: الحلّ
   * مكتمل، وفهرس المنصة محمّل، والملف من مصادر الوحدة المحلولة الرئيسية (لا test ولا وحدة أخرى).
   */
  public static boolean importsCheckable(String packageName, String primaryType) {
    Snapshot snapshot = current;
    // «الحلُّ مكتملٌ» و«الفهرسُ قرَأَ ما حُلَّ كلَّهُ» شرطٌ واحدٌ هنا: مَرفوضٌ واحدٌ يَكفي لئلّا تُقالَ
    // «لا وجودَ لحزمةٍ» عن مكتبةٍ رُفِضَ أرشيفُها — فذاك حُكمُ غيابٍ كسائرِ أحكامِ الغيابِ (W32).
    if (snapshot.request == null || !snapshot.request.complete || !snapshot.libraryCertain
        || !AndroidApiIndex.isLoaded()) {
      return false;
    }
    if (primaryType == null || primaryType.isEmpty()) return false;
    String file = com.almlkid.kay.ui.ProjectSymbolIndex.fileOfClass(primaryType);
    if (file == null) return false;
    String pkg = com.almlkid.kay.ui.ProjectSymbolIndex.packageOf(primaryType);
    if (pkg == null || !pkg.equals(packageName == null ? "" : packageName)) return false;
    return isMainSource(new File(file), snapshot.request.moduleDir);
  }

  static boolean isMainSource(File file, File moduleDir) {
    String path = file.getAbsolutePath().replace('\\', '/');
    String module = moduleDir.getAbsolutePath().replace('\\', '/') + "/";
    if (!path.startsWith(module)) return false;
    String rest = path.substring(module.length());
    if (!rest.startsWith("src/")) return false;
    String set = rest.substring(4);
    int slash = set.indexOf('/');
    String sourceSet = slash < 0 ? set : set.substring(0, slash);
    String lower = sourceSet.toLowerCase(Locale.US);
    return !lower.startsWith("test") && !lower.startsWith("androidtest") && !lower.contains("test");
  }

  /** خاصية مخصّصة (app:) من المكتبات أو المشروع، أو null. */
  public static AndroidApiIndex.AttrInfo attr(String name) {
    Snapshot snapshot = current;
    if (name == null) return null;
    String bare = name.substring(name.indexOf(':') + 1);
    AndroidApiIndex.AttrInfo found = projectSet(snapshot).attrs.get(bare);
    return found != null ? found : snapshot.libraries.attrs.get(bare);
  }

  /** أسماء خصائص styleable (المخصّصة بلا بادئة، والمنصّية بـandroid:). */
  public static List<String> styleable(String name) {
    Snapshot snapshot = current;
    List<String> project = projectSet(snapshot).styleables.get(name);
    List<String> library = snapshot.libraries.styleables.get(name);
    if (project == null) return library == null ? Collections.<String>emptyList() : library;
    if (library == null) return project;
    ArrayList<String> out = new ArrayList<>(project);
    for (String attr : library) if (!out.contains(attr)) out.add(attr);
    return out;
  }

  /** كل الخصائص المخصّصة المعروفة (لـ?attr/). */
  public static Collection<String> attrNames() {
    Snapshot snapshot = current;
    TreeSet<String> out = new TreeSet<>(snapshot.libraries.attrs.keySet());
    out.addAll(projectSet(snapshot).attrs.keySet());
    TreeSet<String> declared = projectSet(snapshot).names.get("attr");
    if (declared != null) out.addAll(declared);
    TreeSet<String> library = snapshot.libraries.names.get("attr");
    if (library != null) out.addAll(library);
    return out;
  }

  /** أسماء موارد نوعٍ (string، style، drawable…) من المشروع ثم المكتبات، مرتّبة بلا تكرار. */
  public static Collection<String> resourceNames(String type) {
    Snapshot snapshot = current;
    TreeSet<String> out = new TreeSet<>();
    TreeSet<String> project = projectSet(snapshot).names.get(type);
    if (project != null) out.addAll(project);
    TreeSet<String> library = snapshot.libraries.names.get(type);
    if (library != null) out.addAll(library);
    return out;
  }

  /** موارد المشروع محدّثة (تُعاد إن مضى أكثر من 3 ثوانٍ)؛ فارغة بلا مشروع. */
  private static ResourceSet projectSet(Snapshot snapshot) {
    if (snapshot.request == null) return snapshot.project;
    if (System.currentTimeMillis() - snapshot.projectBuiltAt > PROJECT_REFRESH_MS) {
      synchronized (LOCK) {
        if (snapshot == current && System.currentTimeMillis() - snapshot.projectBuiltAt > PROJECT_REFRESH_MS)
          refreshProject(snapshot, false);
      }
    }
    return snapshot.project;
  }

  // ═══════════════ فهرسة JAR ═══════════════

  /** نص فهرس JAR (من الذاكرة إن طابقت الحجم والتاريخ، وإلا يُبنى ويُكتب). */
  static byte[] jarIndex(File jar, File cacheDir) throws IOException {
    if (jar == null || !jar.isFile()) return null;
    String stamp = INDEX_HEADER + "\t" + jar.length() + "\t" + jar.lastModified();
    File cache = cacheFile(jar, cacheDir);
    byte[] cached = readCache(cache, stamp);
    if (cached == null && cacheDir != null) {
      File fallback = fallbackCache(jar, cacheDir);
      if (!fallback.equals(cache)) cached = readCache(fallback, stamp);
    }
    if (cached != null) return cached;
    byte[] built = buildJarIndex(jar, stamp);
    if (!writeCache(cache, built) && cacheDir != null) writeCache(fallbackCache(jar, cacheDir), built);
    return built;
  }

  static byte[] buildJarIndex(File jar, String stamp) throws IOException {
    StringBuilder out = new StringBuilder(1 << 16);
    out.append(stamp).append('\n');
    try (ZipFile zip = new ZipFile(jar)) {
      ArrayList<ZipEntry> entries = new ArrayList<>();
      Enumeration<? extends ZipEntry> all = zip.entries();
      while (all.hasMoreElements()) {
        ZipEntry entry = all.nextElement();
        String name = entry.getName();
        if (entry.isDirectory() || !name.endsWith(".class") || name.startsWith("META-INF/")) continue;
        entries.add(entry);
      }
      entries.sort((a, b) -> a.getName().compareTo(b.getName()));
      int refused = 0;
      String first = null;
      for (ZipEntry entry : entries) {
        ClassFileReader.ClassFile parsed;
        try (InputStream in = zip.getInputStream(entry)) {
          byte[] data = readAll(in, entry.getSize());
          if (entry.getSize() >= 0 && data.length != entry.getSize()) {
            throw new IOException("shorter than its declared size");
          }
          parsed = ClassFileReader.read(data);
        } catch (IOException | RuntimeException badClass) {
          // صنفٌ لا يُقرَأُ إلى آخِرِهِ ليسَ «صنفًا زائدًا»: ما بَعْدَهُ من الدفقِ مَجهولٌ معَهُ،
          // فالنَّشْرُ على ما تَبقّى كذبٌ على السائلِ. نَعدُّهُ ونَذكُرُ اسمَهُ لا عددَهُ وحدَهُ.
          refused++;
          if (first == null) first = entry.getName();
          continue;
        }
        // أمَّا ما قرَأناَهُ ولم يُفهِمْنا شيئًا — صنفٌ غيرُ عامٍّ، أو ‏module-info، أو مُولَّدٌ بلا مصدرٍ
        // — فليسَ خسارةً: ‏indexBlock لا يَعِدُ إلّا بما يُعرَضُ في الإكمالِ. عَدُّهُ في الخسارةِ كانَ
        // سيَرفُضُ كلَّ jar فيه صنفٌ واحدٌ مُغلَقٌ على حزمَتِهِ، وذلكَ رَجْمٌ بالفألِ لا فحصٌ.
        String block = ClassFileReader.indexBlock(parsed);
        if (block != null) out.append(block);
      }
      // «فُهرِسَ ١٢٠ من ١٢١» معَ «مكتبةٌ كاملةٌ» في اللوحةِ أكذوبةٌ واحدةٌ: لا قائمةُ مُبتورةَ تُنشَرُ،
      // فيبقى «Context» على «لا يُعرَفُ» بدلَ «لا وجودَ لهُ»، ويُنطَقَ بالسببِ باسمِ الأداةِ.
      if (refused > 0) {
        throw new IOException("unreadable jar: " + refused + " of " + entries.size()
            + " class entries cannot be read to their end (first: " + first + ")");
      }
    } catch (IOException error) {
      throw error;
    } catch (RuntimeException error) {
      // الدليلُ المركزيُّ نفسُهُ لا يُقرَأُ (ذيلُهُ تَلِفَ): لا فهرسَ معَ عددٍ لا يُعرَفُ كم كانَ.
      throw new IOException("bad jar " + jar + ": " + error, error);
    }
    return out.toString().getBytes(StandardCharsets.UTF_8);
  }

  static File cacheFile(File jar, File cacheDir) {
    File parent = jar.getAbsoluteFile().getParentFile();
    if (parent != null && parent.canWrite()) return new File(jar.getAbsolutePath() + CACHE_SUFFIX);
    return fallbackCache(jar, cacheDir);
  }

  private static File fallbackCache(File jar, File cacheDir) {
    File dir = cacheDir == null ? jar.getAbsoluteFile().getParentFile() : new File(cacheDir, "library-index");
    return new File(dir, sha1(jar.getAbsolutePath()) + CACHE_SUFFIX);
  }

  private static byte[] readCache(File cache, String stamp) {
    if (cache == null || !cache.isFile()) return null;
    try (InputStream in = new GZIPInputStream(new FileInputStream(cache), 1 << 16)) {
      byte[] data = readAll(in, -1);
      byte[] expected = (stamp + "\n").getBytes(StandardCharsets.UTF_8);
      if (data.length < expected.length) return null;
      for (int i = 0; i < expected.length; i++) if (data[i] != expected[i]) return null;
      return data;
    } catch (IOException | RuntimeException error) {
      return null;
    }
  }

  private static boolean writeCache(File cache, byte[] data) {
    if (cache == null) return false;
    File dir = cache.getParentFile();
    if (dir != null && !dir.isDirectory() && !dir.mkdirs()) return false;
    File temp = new File(cache.getPath() + ".part");
    try (OutputStream out = new GZIPOutputStream(new FileOutputStream(temp), 1 << 16)) {
      out.write(data);
    } catch (IOException | RuntimeException error) {
      temp.delete();
      return false;
    }
    if (temp.renameTo(cache)) return true;
    cache.delete();
    boolean moved = temp.renameTo(cache);
    if (!moved) temp.delete();
    return moved;
  }

  static byte[] readAll(InputStream in, long sizeHint) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream(sizeHint > 0 && sizeHint < (1 << 24) ? (int) sizeHint : 8192);
    byte[] buffer = new byte[8192];
    int n;
    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
    return out.toByteArray();
  }

  private static String sha1(String text) {
    try {
      byte[] digest = MessageDigest.getInstance("SHA-1").digest(text.getBytes(StandardCharsets.UTF_8));
      StringBuilder b = new StringBuilder();
      for (int i = 0; i < 10; i++) b.append(String.format(Locale.US, "%02x", digest[i]));
      return b.toString();
    } catch (Exception error) {
      return Integer.toHexString(text.hashCode());
    }
  }

  // ═══════════════ AAR: الحزمة وR.txt والموارد ═══════════════

  /** بيانات AAR مفكوك (من ذاكرة .shima-res إن كانت أحدث من الفك). */
  static AarData aarData(File dir) {
    if (dir == null || !dir.isDirectory()) return null;
    // W22/4أ: بصمةُ العقدِ (حجمٌ + عدلةُ تعديلٍ + manifest) هي stampُ ذاكرةِ المواردِ، فلا تُعَدُّ
    // مواردُ أداةٍ مُبدَّلةٍ حديثةً لأنَّ علامةَ الزَّمنِ اتَّفقتْ؛ وبلا عقدٍ صالحٍ نمشي على القرصِ.
    almlk.AarExploder.Stamp node = almlk.AarExploder.readStamp(dir, "");
    String stamp = RES_HEADER + "\t" + (node == null ? dir.lastModified() : node.signature);
    File cache = new File(dir, RES_CACHE);
    byte[] cached = readCache(cache, stamp);
    if (cached != null) {
      AarData data = decodeAar(new String(cached, StandardCharsets.UTF_8));
      if (data != null) return data;
    }
    AarData data = readAar(dir);
    writeCache(cache, encodeAar(data, stamp).getBytes(StandardCharsets.UTF_8));
    return data;
  }

  static AarData readAar(File dir) {
    AarData data = new AarData();
    // الحزمةُ من وسمِ ‏`<manifest …>` بمسحٍ حرفيٍّ: اقتباسانِ ووسمٌ قد يتعدّدُ سطرُهُ
    data.packageName = AndroidManifestModel.packageOf(readText(new File(dir, "AndroidManifest.xml")));
    File rTxt = new File(dir, "R.txt");
    // أرشيفٌ لا ‏R.txt فيهِ حالَةٌ مَشروعةٌ لمكتبةٍ بلا مواردَ: لا سببٌ، ولا إدانةٌ، ولا يُبطِلُ شيئًا.
    if (rTxt.isFile()) data.problem = parseRTxt(readText(rTxt), data.rFields);
    // ملفٌّ باقٍ على القرصِ لا يُخرِجُ سطرًا ولا علَّةً = لم يُقرَأْ: يُقالُ، ولا يُترَكُ «فارغًا سَلِيماً».
    if (data.problem == null && rTxt.isFile() && rTxt.length() > 0 && readText(rTxt).isEmpty()) {
      data.problem = "R.txt could not be read";
    }
    indexResDir(new File(dir, "res"), data.resources);
    return data;
  }

  /** «int string app_name 0x7f…» و«int[] styleable Foo { … }». */
  /**
   * «‏int string app_name 0x7f…» و«‏int[] styleable Foo { … }». السطرُ الذي لا يُفهَمُ لا يَمُرُّ بلا
   * عَلامةٍ: سطرٌ قُطِعَ في وسطِ سِجلٍّ معطًى، أو سِجلٌّ ليسَ من هذا القالبِ، يُبطِلانِ أن تُعَدَّ
   * القائمةُ كاملةً — فلا يَحكُمَ أحدٌ على اسمٍ في ‏R مكتبةٍ أنَّهُ «لا وجودَ لهُ» لأنَّ سطرَهُ ضاعَ معَ
   * ذيلِ الملفِّ. تُعيدُ السببَ، أو `null` إذا فُهِمَ كلُّ ما وُجِدَ. وملفٌّ لا ‏R.txt فيهِ أصلًا
   * يُجابُ عنهُ في ‏readAar: أرشيفٌ لا مواردَ لهُ لا ذنبَ لهُ.
   */
  static String parseRTxt(String text, Map<String, Map<String, String>> out) {
    if (text == null) return "R.txt could not be read";
    int unread = 0;
    int records = 0;
    String first = null;
    for (String line : text.split("\n", -1)) {
      String trimmed = line.trim();
      if (trimmed.isEmpty()) continue;
      String[] f = trimmed.split("\\s+", 4);
      boolean shaped = f.length >= 3 && (f[0].equals("int") || f[0].equals("int[]"))
          && ClassFileReader.isJavaIdentifier(f[2]) && f[1].matches("[a-z][a-z_]*");
      if (shaped) {
        out.computeIfAbsent(f[1], k -> new TreeMap<>()).put(f[2], f[0]);
        records++;
        continue;
      }
      unread++;
      if (first == null) first = trimmed;
    }
    if (unread == 0) return null;
    return "R.txt is not a complete record list: " + unread + " line(s) unparsed (first: "
        + shorten(first) + ", parsed records: " + records + ")";
  }

  private static String shorten(String line) {
    if (line == null) return "-";
    return line.length() <= 48 ? line : line.substring(0, 48) + "…";
  }

  static String encodeAar(AarData data, String stamp) {
    StringBuilder b = new StringBuilder(stamp).append('\n');
    b.append("P\t").append(data.packageName).append('\n');
    // السببُ يُخزَّنُ معَ القائمةِ: لو ضاعَ عندَ أولِ إعادةِ فتحٍ لأطمَعَ السائلَ أنَّ الطبقةَ سَلِيمةٌ.
    if (data.problem != null) b.append("U\t").append(data.problem).append('\n');
    for (AndroidApiIndex.AttrInfo a : data.resources.attrs.values())
      b.append("A\t").append(a.name).append('\t').append(a.format).append('\t')
          .append(String.join(",", a.values)).append('\n');
    for (Map.Entry<String, List<String>> e : data.resources.styleables.entrySet())
      b.append("S\t").append(e.getKey()).append('\t').append(String.join(",", e.getValue())).append('\n');
    for (Map.Entry<String, TreeSet<String>> e : data.resources.names.entrySet())
      b.append("N\t").append(e.getKey()).append('\t').append(String.join(",", e.getValue())).append('\n');
    for (Map.Entry<String, Map<String, String>> e : data.rFields.entrySet())
      for (Map.Entry<String, String> f : e.getValue().entrySet())
        b.append("R\t").append(e.getKey()).append('\t').append(f.getKey()).append('\t').append(f.getValue()).append('\n');
    return b.toString();
  }

  static AarData decodeAar(String text) {
    AarData data = new AarData();
    for (String line : text.split("\n")) {
      if (line.isEmpty() || line.charAt(0) == '#') continue;
      String[] f = line.split("\t", -1);
      switch (f[0]) {
        case "P":
          data.packageName = f.length > 1 ? f[1] : "";
          break;
        case "U":
          data.problem = f.length > 1 ? f[1] : "";
          break;
        case "A":
          if (f.length >= 4) data.resources.attrs.put(f[1], attrInfo(f[1], f[2], f[3]));
          break;
        case "S":
          if (f.length >= 3) data.resources.styleables.put(f[1], list(f[2]));
          break;
        case "N":
          if (f.length >= 3) for (String name : list(f[2])) data.resources.name(f[1], name);
          break;
        case "R":
          if (f.length >= 4) data.rFields.computeIfAbsent(f[1], k -> new TreeMap<>()).put(f[2], f[3]);
          break;
        default:
          return null;
      }
    }
    return data;
  }

  private static List<String> list(String csv) {
    return csv.isEmpty() ? Collections.<String>emptyList()
        : Collections.unmodifiableList(Arrays.asList(csv.split(",")));
  }

  static AndroidApiIndex.AttrInfo attrInfo(String name, String format, String values) {
    return new AndroidApiIndex.AttrInfo(new String[] {"A", name, format, values, "1,0,0"});
  }

  // ═══════════════ موارد مجلد res ═══════════════

  /** موارد وحدة المشروع: كل src/<set>/res غير الاختبارية. */
  static ResourceSet projectResources(File moduleDir) {
    ResourceSet set = new ResourceSet();
    if (moduleDir == null) return set;
    File[] sourceSets = new File(moduleDir, "src").listFiles();
    if (sourceSets == null) return set;
    Arrays.sort(sourceSets);
    for (File sourceSet : sourceSets) {
      String lower = sourceSet.getName().toLowerCase(Locale.US);
      if (lower.contains("test")) continue;
      indexResDir(new File(sourceSet, "res"), set);
    }
    // ما أعلنَهُ ‏`sourceSets` من ‏`res.srcDirs` يُدمَجُ بعدَ العُرفِ: الأسبقُ يفوزُ، والإعلانُ لا يُهمَلُ
    for (File declared : GradleSourceSets.declaredResDirs(moduleDir)) indexResDir(declared, set);
    return set;
  }

  private static final List<String> FILE_TYPES = Arrays.asList(
      "anim", "animator", "color", "drawable", "font", "interpolator", "layout", "menu", "mipmap",
      "navigation", "raw", "transition", "xml");

  static void indexResDir(File res, ResourceSet set) {
    File[] folders = res.listFiles();
    if (folders == null) {
      // مجلدٌ موجودٌ لا يُدرَجُ: قراءةٌ تعذَّرَت لا شجرةٌ فارغةٌ، فلا تُعدَّ القائمةُ كاملةً.
      if (res.isDirectory()) set.incomplete("مجلدُ المواردِ لا يُدرَجُ: " + res.getPath());
      return;
    }
    Arrays.sort(folders);
    for (File folder : folders) {
      if (!folder.isDirectory()) continue;
      String name = folder.getName();
      int dash = name.indexOf('-');
      String type = dash < 0 ? name : name.substring(0, dash);
      File[] files = folder.listFiles();
      if (files == null) {
        set.incomplete("مجلدُ المواردِ لا يُدرَجُ: " + name);
        continue;
      }
      Arrays.sort(files);
      if (type.equals("values")) {
        for (File file : files) {
          if (file.getName().endsWith(".xml")) parseValues(readResText(file, set), set);
        }
      } else if (FILE_TYPES.contains(type)) {
        for (File file : files) {
          String fileName = file.getName();
          // ‏`.gitignore` وأمثالُها لا تُنشِئُ موردًا عندَ مُجمِّعِ المواردِ: تجاهُلُها ليسَ نُقصانًا.
          if (fileName.startsWith(".")) continue;
          int dot = fileName.indexOf('.');
          set.name(type, dot < 0 ? fileName : fileName.substring(0, dot));
          if (type.equals("layout") || type.equals("menu") || type.equals("navigation"))
            collectIds(readResText(file, set), set);
        }
      } else {
        // مجلدٌ لا نقرَأُهُ: ادعاءُ قائمةٍ كاملةٍ معَ تَجاوُزٍ صامتٍ كذبٌ على المُحلِّلِ.
        set.incomplete("نوعُ مواردَ لا يُقرَأُ: " + type);
      }
    }
  }

  /**
   * نصُّ ملفِّ مواردَ يَحمِلُ فشلَهُ سببًا: «فارغٌ لأنَّهُ فارغٌ» صوابٌ، و«فارغٌ لأنَّ القراءةَ
   * تعذَّرَت» نُقصانٌ — وreadText وحدَهُ لا يَفرِقُ بينَهُما.
   */
  private static String readResText(File file, ResourceSet set) {
    if (file == null || !file.isFile()) return "";
    try (InputStream in = new FileInputStream(file)) {
      return new String(readAll(in, file.length()), StandardCharsets.UTF_8);
    } catch (IOException | RuntimeException error) {
      set.incomplete("ملفُّ المواردِ لا يُقرَأُ: " + file.getName());
      return "";
    }
  }

  private static final Pattern NEW_ID = Pattern.compile("\"@\\+id/([\\w.]+)\"");

  private static void collectIds(String text, ResourceSet set) {
    Matcher m = NEW_ID.matcher(text);
    while (m.find()) set.name("id", m.group(1));
  }

  private static final Pattern COMMENT = Pattern.compile("<!--.*?-->", Pattern.DOTALL);
  private static final Pattern TAG = Pattern.compile("<(/?)([\\w:.-]+)((?:[^>\"']|\"[^\"]*\"|'[^']*')*?)(/?)>");
  private static final Pattern ATTRIBUTE = Pattern.compile("([\\w:.-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')");

  /**
   * values*.xml بمسح متسامح (بلا DOM): الأنواع وأسماؤها، والخصائص (format وenum/flag) داخل
   * declare-styleable وخارجه، وأعضاء كل styleable.
   */
  static void parseValues(String text, ResourceSet set) {
    String clean = COMMENT.matcher(text).replaceAll("");
    Matcher tags = TAG.matcher(clean);
    ArrayList<String> stack = new ArrayList<>();
    boolean sawRoot = false;
    String styleable = null;
    ArrayList<String> styleableAttrs = null;
    String attrName = null, attrFormat = "";
    ArrayList<String> attrValues = null;
    while (tags.find()) {
      boolean closing = !tags.group(1).isEmpty();
      boolean selfClosing = !tags.group(4).isEmpty();
      String tag = tags.group(2);
      if (tag.startsWith("?") || tag.startsWith("!")) continue;
      if (closing) {
        if (tag.equals("attr") && attrName != null) {
          finishAttr(set, attrName, attrFormat, attrValues);
          attrName = null;
        } else if (tag.equals("declare-styleable") && styleable != null) {
          set.styleables.put(styleable, Collections.unmodifiableList(styleableAttrs));
          styleable = null;
        }
        if (!stack.isEmpty()) stack.remove(stack.size() - 1);
        continue;
      }
      Map<String, String> attributes = attributes(tags.group(3));
      String name = attributes.get("name");
      int depth = stack.size();
      if (depth == 0 && tag.equals("resources")) sawRoot = true;
      if (depth == 1 && name != null) {
        // عنصر داخل <resources>
        switch (tag) {
          case "declare-styleable":
            set.name("styleable", name);
            if (selfClosing) {
              set.styleables.putIfAbsent(name, Collections.<String>emptyList());
            } else {
              styleable = name;
              styleableAttrs = new ArrayList<>();
            }
            break;
          case "attr":
            if (!name.startsWith("android:")) {
              set.name("attr", name);
              attrName = name;
              attrFormat = attributes.getOrDefault("format", "");
              attrValues = new ArrayList<>();
              if (selfClosing) {
                finishAttr(set, attrName, attrFormat, attrValues);
                attrName = null;
              }
            }
            break;
          case "item":
            String itemType = attributes.get("type");
            if (itemType != null) set.name(itemType, name);
            break;
          case "string-array":
          case "integer-array":
            set.name("array", name);
            break;
          case "eat-comment":
          case "public":
          case "skip":
            break;
          default:
            set.name(tag, name);
            break;
        }
      } else if (depth == 2 && tag.equals("attr") && styleable != null && name != null) {
        styleableAttrs.add(name);
        if (!name.startsWith("android:")) {
          set.name("attr", name);
          attrName = name;
          attrFormat = attributes.getOrDefault("format", "");
          attrValues = new ArrayList<>();
          if (selfClosing) {
            finishAttr(set, attrName, attrFormat, attrValues);
            attrName = null;
          }
        }
      } else if (attrName != null && (tag.equals("enum") || tag.equals("flag")) && name != null) {
        attrValues.add(name);
        if (!attrFormat.contains(tag)) attrFormat = attrFormat.isEmpty() ? tag : attrFormat + "|" + tag;
      }
      if (!selfClosing) stack.add(tag);
    }
    if (!sawRoot || !stack.isEmpty()) {
      // وسمٌ باقٍ بلا إغلاقٍ أو جذعٌ مفقودٌ: ما بعدَ القطعِ لم يُقرَأْ، فلا تُثبَتُ القائمةُ.
      set.incomplete("ملفُّ values بلا بِنْيَةٍ مُكمَلةٍ");
    }
  }

  /** خاصية مكتملة: أوّل تعريف ذي format/قيم يفوز (الإشارة المجرّدة داخل styleable لا تمحوه). */
  private static void finishAttr(ResourceSet set, String name, String format, List<String> values) {
    AndroidApiIndex.AttrInfo existing = set.attrs.get(name);
    if (existing != null && (!existing.format.isEmpty() || existing.values.length > 0)) return;
    if (existing != null && format.isEmpty() && (values == null || values.isEmpty())) return;
    set.attrs.put(name, attrInfo(name, format, values == null ? "" : String.join(",", values)));
  }

  private static Map<String, String> attributes(String text) {
    HashMap<String, String> out = new HashMap<>();
    Matcher m = ATTRIBUTE.matcher(text);
    while (m.find()) out.put(m.group(1), m.group(2) != null ? m.group(2) : m.group(3));
    return out;
  }

  // ═══════════════ صنف R ═══════════════

  /** حقول R من موارد المشروع: الأسماء بـ_ بدل النقطة، وstyleable كمصفوفة وفهارس. */
  static Map<String, Map<String, String>> rFieldsOf(ResourceSet set) {
    TreeMap<String, Map<String, String>> out = new TreeMap<>();
    for (Map.Entry<String, TreeSet<String>> e : set.names.entrySet()) {
      if (e.getKey().equals("styleable")) continue;
      Map<String, String> fields = out.computeIfAbsent(e.getKey(), k -> new TreeMap<>());
      for (String name : e.getValue()) {
        String field = name.replace('.', '_').replace('-', '_');
        if (ClassFileReader.isJavaIdentifier(field)) fields.put(field, "int");
      }
    }
    for (Map.Entry<String, List<String>> e : set.styleables.entrySet()) {
      String styleable = e.getKey().replace('.', '_');
      if (!ClassFileReader.isJavaIdentifier(styleable)) continue;
      Map<String, String> fields = out.computeIfAbsent("styleable", k -> new TreeMap<>());
      fields.put(styleable, "int[]");
      for (String attr : e.getValue()) fields.put(styleable + "_" + attr.replace(':', '_').replace('.', '_'), "int");
    }
    return out;
  }

  /** كتلة فهرس لصنف {@code pkg.R} وأصنافه الداخلية (v = مؤقت لـR التطبيق). */
  static byte[] rClassBlock(String pkg, Map<String, Map<String, String>> fields, boolean provisional) {
    // الحاوي ‏`pkg.R` مؤقَّتٌ (v) دائمًا: «قائمةُ الأنواعِ» ما لم نَدَّعِها كاملةً، فـ‏`R.raw` في
    // مشروعٍ بلا ‏`res/raw` يَجِبُ أن يَظَلَّ مُجرَّدَ مَجهولٍ لا خطأً. وأمَّا الأنواعُ المَقرُوءةُ
    // ‏`pkg.R.<type>` فتُثبَتُ متى مُنِحَتِ القائمةُ ثِقةً، فيَحكُمُ المُحلِّلُ على عضوٍ مفقودٍ منهُ
    // بحُكمِهِ على أيِّ حقلٍ — كما يَفعلُ المرجعُ بملفِّ قائمةِ المواردِ المُولَّدِ (ورقةُ §٢٫١).
    String flags = provisional ? "v" : "";
    StringBuilder b = new StringBuilder();
    b.append("C\t").append(pkg).append(".R\tc\t1\t0\t0\tjava.lang.Object\t\t\tv").append('\t').append(pkg).append('\n');
    for (Map.Entry<String, Map<String, String>> type : fields.entrySet()) {
      if (type.getValue().isEmpty()) continue;
      b.append("C\t").append(pkg).append(".R.").append(type.getKey())
          .append("\tc\t1\t0\t0\tjava.lang.Object\t\t\t").append(flags).append('\t').append(pkg).append('\n');
      for (Map.Entry<String, String> field : type.getValue().entrySet())
        b.append("F\t").append(field.getKey()).append("\ts\t").append(field.getValue()).append("\t\n");
    }
    return b.toString().getBytes(StandardCharsets.UTF_8);
  }

  // ═══════════════ إعدادات من نموذج البناء ═══════════════

  private static final Pattern NAMESPACE = Pattern.compile("\\bnamespace\\s*(?:=\\s*)?[\"']([\\w.]+)[\"']");

  /**
   * حزمةُ صنفِ ‏`R` لوحدةٍ: ‏`namespace` في ملفِّ البناءِ أولًا (هو المرجعُ في ‏`AGP`
   * الحديثةِ)، ثمَّ ‏`package=` في مانيفستِ الوحدةِ — بموضعَيْه: ‏`src/main/` في التخطيطِ
   * الحديثِ، وجذرُ الوحدةِ في تخطيطِ ADT القديمِ الذي تُنشئُهُ قوالبُنا أحيانًا.
   */
  static String appPackage(GradleBuildModel model) {
    Matcher m = NAMESPACE.matcher(model.text);
    if (m.find()) return m.group(1);
    File manifest = AndroidManifestModel.find(model.moduleDir, GradleSourceSets.of(model.text).manifestFile);
    return manifest == null ? "" : AndroidManifestModel.packageOf(readText(manifest));
  }

  private static final Pattern AGP_VERSION = Pattern.compile(
      "com\\.android\\.(?:application|library)['\"]\\s*\\)?\\s*version\\s*\\(?\\s*['\"](\\d+)\\."
          + "|com\\.android\\.tools\\.build:gradle:(\\d+)\\.");

  static boolean transitiveR(GradleBuildModel model) {
    String explicit = model.variables.get("android.nonTransitiveRClass");
    if (explicit != null) return explicit.trim().equalsIgnoreCase("false");
    String root = readText(new File(model.projectRoot, "build.gradle")) + readText(new File(model.projectRoot, "build.gradle.kts"))
        + readText(new File(model.projectRoot, "settings.gradle")) + readText(new File(model.projectRoot, "settings.gradle.kts"))
        + model.text;
    Matcher m = AGP_VERSION.matcher(root);
    if (!m.find()) return false;
    String major = m.group(1) != null ? m.group(1) : m.group(2);
    try {
      return Integer.parseInt(major) < 8;
    } catch (NumberFormatException error) {
      return false;
    }
  }

  private static final Pattern QUOTED = Pattern.compile("[\"']([^\"']+)[\"']");
  private static final Pattern FILE_TREE_DIR = Pattern.compile("\\bdir\\s*[:=]\\s*[\"']([^\"']+)[\"']|fileTree\\s*\\(\\s*[\"']([^\"']+)[\"']\\s*\\)");

  /**
   * ملفات fileTree/files القابلة للإثبات نصيًا: {@code fileTree(dir: 'libs', include: ['*.jar'])}
   * أو {@code files('libs/a.jar')}. null إن لم تُفهم الصيغة (فيصير الحلّ غير قابل للإثبات).
   */
  static List<File> fileDependencyJars(File moduleDir, String notation) {
    if (notation == null) return null;
    String text = notation.trim();
    ArrayList<File> out = new ArrayList<>();
    if (text.startsWith("fileTree")) {
      Matcher dir = FILE_TREE_DIR.matcher(text);
      if (!dir.find()) return null;
      String path = dir.group(1) != null ? dir.group(1) : dir.group(2);
      if (path.contains("$")) return null;
      boolean jars = !text.contains("include") || text.contains("*.jar");
      if (!jars) return null;
      File folder = new File(path).isAbsolute() ? new File(path) : new File(moduleDir, path);
      File[] files = folder.listFiles();
      if (files != null) {
        Arrays.sort(files);
        for (File file : files) if (file.getName().endsWith(".jar")) out.add(file);
      }
      return out;
    }
    if (text.startsWith("files")) {
      Matcher quoted = QUOTED.matcher(text);
      while (quoted.find()) {
        String path = quoted.group(1);
        if (path.contains("$") || !path.endsWith(".jar")) return null;
        out.add(new File(path).isAbsolute() ? new File(path) : new File(moduleDir, path));
      }
      return out.isEmpty() ? null : out;
    }
    return null;
  }

  /** مصادر Kotlin أو AIDL في الوحدة (أصناف لا يراها فهرس Java): لا تشخيص استيراد. */
  static boolean hasSourcesOtherThanJava(File moduleDir) {
    return containsSource(new File(moduleDir, "src"), 0);
  }

  private static boolean containsSource(File dir, int depth) {
    File[] files = dir.listFiles();
    if (files == null || depth > 24) return false;
    for (File file : files) {
      String name = file.getName();
      if (file.isDirectory()) {
        if (name.equals("res") || name.equals("assets") || name.equals("jniLibs") || name.startsWith(".")) continue;
        if (containsSource(file, depth + 1)) return true;
      } else if (name.endsWith(".kt") || name.endsWith(".aidl")) return true;
    }
    return false;
  }

  static String readText(File file) {
    if (file == null || !file.isFile()) return "";
    try (InputStream in = new FileInputStream(file)) {
      return new String(readAll(in, file.length()), StandardCharsets.UTF_8);
    } catch (IOException | RuntimeException error) {
      return "";
    }
  }
}
