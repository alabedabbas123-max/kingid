package almlk;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;

/**
 * Draws the zig-zag diagnostic underline from a small pre-rendered tile.
 *
 * <p>Instead of building a path for every range on every frame, one tile (a few periods of the
 * wave) is rendered per colour and size and repeated horizontally through a {@link BitmapShader};
 * each range is then a single {@code drawRect}. The tile is rebuilt only when the colour or the
 * band height changes (zoom / theme). The wave phase is anchored to the text origin, so it scrolls
 * with the code instead of shimmering.
 *
 * <p>Geometry follows the reference look: the band is centred one tenth of the font height below
 * the baseline, its height grows with the font, and the stroke is 40% of the band.
 */
public final class WavyUnderlinePainter {

  /** Pure geometry so it can be verified off-device. */
  public static float bandHeight(float fontHeightPx, float density) {
    float band = 10f * density * (fontHeightPx / 90f);
    float min = Math.max(3f, fontHeightPx * 0.16f);
    float max = Math.max(min, fontHeightPx * 0.42f);
    return Math.max(min, Math.min(band, max));
  }

  /** Vertical centre of the band for a line whose baseline is {@code baselineY}. */
  public static float centerY(float baselineY, float fontHeightPx) {
    return baselineY + fontHeightPx / 10f;
  }

  private static final int PERIODS_PER_TILE = 4;

  private final Slot error = new Slot();
  private final Slot warning = new Slot();
  /** بلاطةُ التلميحِ المستقلةُ: لونٌ غيرُ لونِ الإنذارِ، فلا تُهدَمُ بلاطةٌ لكلِّ سطرٍ يتناوبُ فيهِ اللونانِ. */
  private final Slot hint = new Slot();

  /** أسرةُ التَسطيرِ الثلاثةُ — أرقامُها كما في ‏`MarkTable.severityOf` و‏`DiagnosticSpanIndex.Span`. */
  public static final int FAMILY_ERROR = 0;
  public static final int FAMILY_WARNING = 1;
  public static final int FAMILY_HINT = 2;
  private final Matrix shaderMatrix = new Matrix();

  /** Paints one range; {@code phaseOriginX} is the x where column 0 of the text starts. */
  public void draw(
      Canvas canvas,
      float left,
      float right,
      float baselineY,
      float fontHeightPx,
      float density,
      float phaseOriginX,
      int color,
      boolean isWarning) {
    draw(canvas, left, right, baselineY, fontHeightPx, density, phaseOriginX, color,
        isWarning ? FAMILY_WARNING : FAMILY_ERROR);
  }

  /** الرسمُ بالأسرةِ رقمًا: تلميحٌ أصفرُ بلاطةً مستقلَّةً، لا مجاراةً للإنذارِ الكهرمانيِّ. */
  public void draw(
      Canvas canvas,
      float left,
      float right,
      float baselineY,
      float fontHeightPx,
      float density,
      float phaseOriginX,
      int color,
      int family) {
    if (right <= left) return;
    int band = Math.max(3, Math.round(bandHeight(fontHeightPx, density)));
    Slot slot = family == FAMILY_WARNING ? warning : family == FAMILY_HINT ? hint : error;
    Paint paint = slot.paint(color, band);
    float top = centerY(baselineY, fontHeightPx) - band / 2f;
    shaderMatrix.setTranslate(phaseOriginX, top);
    paint.getShader().setLocalMatrix(shaderMatrix);
    canvas.drawRect(left, top, right, top + band, paint);
  }

  /** Drops the cached tiles (e.g. when the view leaves the window). */
  public void release() {
    error.release();
    warning.release();
    hint.release();
  }

  private static final class Slot {
    private int color;
    private int band = -1;
    private Bitmap tile;
    private Paint paint;

    Paint paint(int wantedColor, int wantedBand) {
      if (paint != null && tile != null && !tile.isRecycled()
          && color == wantedColor && band == wantedBand) return paint;
      release();
      color = wantedColor;
      band = wantedBand;
      int period = wantedBand * 2;
      tile = Bitmap.createBitmap(period * PERIODS_PER_TILE, wantedBand, Bitmap.Config.ARGB_8888);
      Canvas tileCanvas = new Canvas(tile);
      Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
      stroke.setStyle(Paint.Style.STROKE);
      stroke.setColor(wantedColor);
      float strokeWidth = Math.max(1f, wantedBand * 0.4f);
      stroke.setStrokeWidth(strokeWidth);
      stroke.setStrokeJoin(Paint.Join.ROUND);
      stroke.setStrokeCap(Paint.Cap.BUTT);
      float high = strokeWidth / 2f;
      float low = wantedBand - strokeWidth / 2f;
      Path path = new Path();
      // Starts half a period before the tile and ends half after so seams join cleanly.
      float half = period / 2f;
      path.moveTo(-half, high);
      boolean down = true;
      for (float x = 0; x <= tile.getWidth() + half; x += half) {
        path.lineTo(x, down ? low : high);
        down = !down;
      }
      tileCanvas.drawPath(path, stroke);
      paint = new Paint(Paint.ANTI_ALIAS_FLAG);
      paint.setShader(new BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP));
      return paint;
    }

    void release() {
      if (tile != null && !tile.isRecycled()) tile.recycle();
      tile = null;
      paint = null;
      band = -1;
    }
  }
}
