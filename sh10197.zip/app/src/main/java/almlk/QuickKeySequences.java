package almlk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * سلاسلُ أدواتِ شريطِ المحرّر: لكلِّ نوعِ ملفٍ سلسلتُه، وأولُ رمزٍ فيها هو السهم.
 *
 * <p>العقدُ مُستخلَصٌ من المصدر ({@code QuickKey.getDefaultKey} و{@code AdvancedSetting.getEditorQuickKey} في
 * {@code abeed.zip → java.zip}) إعادةَ بناءٍ لا نسخَ سطر: القيمةُ المُخزَّنةُ نصٌّ تُفصَلُ أسطرًا (لا حروفًا)،
 * ومفتاحُها الامتدادُ نفسُه ({@code ".java"} و{@code ".xml"} و{@code ".c"})، وأولُ سطرٍ {@value #SPECIAL_TOKEN}
 — الرمزُ الخاصُّ الذي يُعرَضُ سهمًا ويعملُ {@code Tab} تنسيقًا. لأنَّه أولُ السلسلة كان أولَ زرٍّ في الشريط:
 * يتبدّلُ ترتيبُ ما بعدَهُ في الإعدادات ويبقى هو في رأسِهِ — بلا تثبيتٍ بكودٍ منفصل.
 *
 * <p>هذه الطبقةُ خالصةٌ بلا Android: تُقابَلُ في بواباتِ الانحدارِ سلوكيًّا، والشريطُ واللوحةُ كلاهما يقرؤون منها.
 */
public final class QuickKeySequences {

  /** الرمزُ الخاصُّ في السلاسل: يُعرَضُ سهمًا ويعملُ إزاحةً (Tab). */
  public static final String SPECIAL_TOKEN = "#sp";

  /** ما يُكتَبُ على الزرِّ بدل {@value #SPECIAL_TOKEN}. */
  public static final String ARROW_LABEL = "→";

  /** ما يُدرَجُ عند نقرِ السهم: مفتاحُ Tab في المحرّر، لا تحريكُ مؤشّر. */
  public static final String TAB_TOKEN = "\t";

  /** فاصلُ الرموزِ في السلسلة المُخزَّنة. */
  public static final String TOKEN_SEPARATOR = "\n";

  /** الأنواعُ التي تُعرَضُ في الإعدادات للتعديل — كما في مُختارِ المصدر. */
  public static final String[] EDITOR_TYPES = {".java", ".xml", ".c"};

  private static final String JAVA_SEQUENCE =
      SPECIAL_TOKEN
          + "\n{\n}\n(\n)\n;\n=\n\"\n|\n&\n!\n[\n]\n<\n>\n+\n-\n/\n*\n?\n:\n_";

  private static final String XML_SEQUENCE =
      SPECIAL_TOKEN
          + "\n<\n>\n/\n=\n\"\n:\n@\n+\n(\n)\n;\n,\n.\n?\n|\n\\\n&\n!\n[\n]\n{\n}\n_\n-";

  private QuickKeySequences() {}

  /** السلسلةُ الافتراضيةُ لنوعٍ: عائلةُ {@code xml} لها، وغيرُها لعائلةِ الجافا (كما في المصدر). */
  public static String defaultSequence(String type) {
    return isXmlFamily(type) ? XML_SEQUENCE : JAVA_SEQUENCE;
  }

  /** هل الامتدادُ من عائلةِ الوسوم؟ ({@code .xml/.htm/.html}) */
  public static boolean isXmlFamily(String type) {
    String normalized = normalizeType(type);
    return normalized.equals(".xml") || normalized.equals(".htm") || normalized.equals(".html");
  }

  /**
   * نوعُ الملفِ المفتوح، وهو مفتاحُ التفضيلِ في آنٍ واحد: {@code .htm/.html ← .xml} و{@code .cpp ← .c}
   * (تطبيعُ المصدر)، وبلا نقطةٍ أو بلا اسمٍ ⇒ {@code .java}.
   */
  public static String typeFor(String fileName) {
    if (fileName == null) return ".java";
    int dot = fileName.lastIndexOf('.');
    if (dot < 0 || dot == fileName.length() - 1) return ".java";
    return normalizeType(fileName.substring(dot));
  }

  /** صورةُ الامتدادِ المُستعمَلةُ مفتاحًا ومِقياسًا للافتراضي. */
  public static String normalizeType(String type) {
    if (type == null || type.isEmpty()) return ".java";
    String value = type.toLowerCase(Locale.US);
    if (value.charAt(0) != '.') value = "." + value;
    if (value.equals(".htm") || value.equals(".html")) return ".xml";
    if (value.equals(".cpp") || value.equals(".cc") || value.equals(".cxx")) return ".c";
    return value;
  }

  /**
   * رموزُ السلسلة بترتيبِها حرفيًّا: سطرٌ لكلِّ أداة، والسطرُ الفارغُ لا يولّدُ زرًّا (كما في حلقةِ المصدر).
   * يُرفَعُ {@code \r} من آخرِ السطرِ حتى لا تُفسِدَها لوحةٌ حسيةٌ تضيفُهُ عند الحفظ.
   */
  public static List<String> tokens(String sequence) {
    List<String> values = new ArrayList<>();
    if (sequence == null) return values;
    for (String line : sequence.split(TOKEN_SEPARATOR, -1)) {
      String token = line;
      if (token.endsWith("\r")) token = token.substring(0, token.length() - 1);
      if (!token.isEmpty()) values.add(token);
    }
    return values;
  }

  /** ما يُرسَمُ على الزرّ. */
  public static String labelFor(String token) {
    return SPECIAL_TOKEN.equals(token) ? ARROW_LABEL : token;
  }

  /** ما يُعمَلُ عند النقر: السهمُ إزاحة، وغيرُهُ رمزُهُ نفسُه فيدخلُ من مسارِ الكتابة. */
  public static String actionFor(String token) {
    return SPECIAL_TOKEN.equals(token) ? TAB_TOKEN : token;
  }

  /**
   * هجرةُ إعدادٍ قديمٍ كان يحفظُ الرموزَ حروفًا متّصلة: كلُّ حرفٍ يصيرُ سطرًا، والمسافاتُ تُهمَل.
   * تُستعمَلُ مرّةً واحدةً حتى لا يفقدَ مستخدمٌ ترتيبَهُ الذي عوّده.
   */
  public static String migrateLegacyCharacters(String legacyCharacters) {
    if (legacyCharacters == null || legacyCharacters.isEmpty()) return "";
    java.util.List<String> values = new ArrayList<>();
    for (int i = 0; i < legacyCharacters.length(); i++) {
      char value = legacyCharacters.charAt(i);
      if (value == '\n' || value == '\r' || Character.isWhitespace(value)) continue;
      // السهمُ كان يُخزَّنُ رسمتَه؛ والمهاجرةُ تُعيدُهُ رمزَها الخاصَّ حتى يبقى في رأسِ الشريط.
      values.add(String.valueOf(value).equals(ARROW_LABEL) ? SPECIAL_TOKEN : String.valueOf(value));
    }
    if (values.isEmpty()) return SPECIAL_TOKEN;
    if (!SPECIAL_TOKEN.equals(values.get(0))) values.add(0, SPECIAL_TOKEN);
    StringBuilder builder = new StringBuilder();
    for (String value : values) {
      if (builder.length() > 0) builder.append(TOKEN_SEPARATOR);
      builder.append(value);
    }
    return builder.toString();
  }
}
