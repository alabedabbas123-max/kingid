package almlk;

/**
 * ماسح بنيوي لـXML بمسار واحد — المرحلة السادسة.
 *
 * <p>يُنتج لكل سطر حالته عند البداية، وعمق التعشيش قبله، وحصيلته من الوسوم (مفتوحة/مغلقة/
 * ذاتية الإغلاق). هذا مصدر الحقيقة البنيوي المشترك بين تعليق XML الآمن والمنسق البنيوي، فلا
 * يُعاد تحليل النص بمحلل ثانٍ ولا بأي Regex.
 *
 * <p>الكلاس لا يُعدّل النص ولا يحتفظ به: كل دالة تمرّ مرة واحدة على المدخل، والحساب خطي
 * O(n) بزمن ومكان. حالاتLexer مطابقة لدلالات XML: تعليق لا يتداخل، CDATA حرفي، وسم يمتد
 * عبر الأسطر، وقيمة سمة بين اقتباسين مفرد/مزدوج تمتد عبر الأسطر.
 */
public final class XmlStructureScanner {

  /** خارج أي بنية. */
  public static final int NORMAL = 0;
  /** داخل {@code <!-- ... -->}. */
  public static final int COMMENT = 1;
  /** داخل {@code <![CDATA[ ... ]]>}. */
  public static final int CDATA = 2;
  /** داخل وسم بعد قراءة {@code <} واسمه. */
  public static final int TAG = 3;
  /** داخل قيمة سمة بين {@code "..."}. */
  public static final int ATTR_DQ = 4;
  /** داخل قيمة سمة بين {@code '...'}. */
  public static final int ATTR_SQ = 5;
  /** داخل {@code <? ... ?>}. */
  public static final int PI = 6;
  /** داخل {@code <!DOCTYPE ...>} وما شابه. */
  public static final int MARKUP = 7;

  /** هل الحالة تعني «داخل بنية حرفية لا يُعاد تنسيق أسطرها». */
  public static boolean isVerbatimState(int state) {
    return state == COMMENT || state == CDATA;
  }

  /** هل الحالة تعني «سطر استمرار لوسم مفتوح عبر الأسطر». */
  public static boolean isTagContinuation(int state) {
    return state == TAG || state == ATTR_DQ || state == ATTR_SQ;
  }

  /** نتيجة المسح: مصفوفات متوازية بفهرس السطر، بلا كائنات لكل سطر. */
  public static final class Layout {
    public final int lineCount;
    /** إزاحة بداية كل سطر. */
    public final int[] lineStart;
    /** إزاحة نهاية كل سطر دون {@code \n} (قد تشمل {@code \r} النهائية). */
    public final int[] lineEnd;
    /** حالة المحلل عند بداية السطر. */
    public final int[] startState;
    /** حالة المحلل عند نهاية السطر. */
    public final int[] endState;
    /** عمق التعشيش قبل معالجة السطر. */
    public final int[] depthBefore;
    /** حصيلة السطر: وسوم مفتوحة − مغلقة − ذاتية الإغلاق. */
    public final int[] depthDelta;
    /** أول محرف غير مسافة هو {@code </} والسطر يبدأ خارج أي بنية. */
    public final boolean[] startsWithClose;

    Layout(
        int lineCount,
        int[] lineStart,
        int[] lineEnd,
        int[] startState,
        int[] endState,
        int[] depthBefore,
        int[] depthDelta,
        boolean[] startsWithClose) {
      this.lineCount = lineCount;
      this.lineStart = lineStart;
      this.lineEnd = lineEnd;
      this.startState = startState;
      this.endState = endState;
      this.depthBefore = depthBefore;
      this.depthDelta = depthDelta;
      this.startsWithClose = startsWithClose;
    }

    /** رقم السطر الحاوي للإزاحة، ببحث ثنائي على بدايات الأسطر. */
    public int lineAt(int offset) {
      int low = 0;
      int high = lineCount - 1;
      while (low < high) {
        int mid = (low + high + 1) >>> 1;
        if (lineStart[mid] <= offset) low = mid;
        else high = mid - 1;
      }
      return low;
    }
  }

  private XmlStructureScanner() {}

  /** مسح كامل للنص مرة واحدة. */
  public static Layout scan(String text) {
    int length = text.length();
    int lineCount = 1;
    for (int i = 0; i < length; i++) if (text.charAt(i) == '\n') lineCount++;

    int[] lineStart = new int[lineCount];
    int[] lineEnd = new int[lineCount];
    int index = 0;
    for (int i = 0; i < length; i++) {
      if (text.charAt(i) == '\n') {
        lineEnd[index] = i;
        index++;
        if (index < lineCount) lineStart[index] = i + 1;
      }
    }
    lineEnd[lineCount - 1] = length;

    int[] startState = new int[lineCount];
    int[] endState = new int[lineCount];
    int[] depthBefore = new int[lineCount];
    int[] depthDelta = new int[lineCount];
    boolean[] startsWithClose = new boolean[lineCount];

    int state = NORMAL;
    boolean tagClosing = false;
    boolean tagSelfClose = false;
    int depth = 0;

    for (int line = 0; line < lineCount; line++) {
      int from = lineStart[line];
      int to = lineEnd[line];
      startState[line] = state;
      depthBefore[line] = depth;

      int probe = from;
      while (probe < to && isSpace(text.charAt(probe))) probe++;
      startsWithClose[line] =
          state == NORMAL && probe + 1 < to && text.charAt(probe) == '<' && text.charAt(probe + 1) == '/';

      int opened = 0;
      int closed = 0;
      int selfClosed = 0;

      int i = from;
      while (i < to) {
        char c = text.charAt(i);
        switch (state) {
          case NORMAL:
            if (c == '<' && regionMatches(text, i, "<!--")) {
              state = COMMENT;
              i += 4;
            } else if (c == '<' && regionMatches(text, i, "<![CDATA[")) {
              state = CDATA;
              i += 9;
            } else if (c == '<' && regionMatches(text, i, "<?")) {
              state = PI;
              i += 2;
            } else if (c == '<' && regionMatches(text, i, "<!")) {
              state = MARKUP;
              i += 2;
            } else if (c == '<' && i + 1 < to && text.charAt(i + 1) == '/') {
              state = TAG;
              tagClosing = true;
              tagSelfClose = false;
              i += 2;
            } else if (c == '<') {
              state = TAG;
              tagClosing = false;
              tagSelfClose = false;
              opened++;
              i++;
            } else {
              i++;
            }
            break;

          case TAG:
            if (c == '"') {
              state = ATTR_DQ;
              i++;
            } else if (c == '\'') {
              state = ATTR_SQ;
              i++;
            } else if (c == '>') {
              if (tagClosing) closed++;
              else if (tagSelfClose) selfClosed++;
              state = NORMAL;
              tagClosing = false;
              tagSelfClose = false;
              i++;
            } else {
              if (c == '/') tagSelfClose = true;
              else if (!isSpace(c)) tagSelfClose = false;
              i++;
            }
            break;

          case ATTR_DQ:
            if (c == '"') state = TAG;
            i++;
            break;

          case ATTR_SQ:
            if (c == '\'') state = TAG;
            i++;
            break;

          case COMMENT:
            if (regionMatches(text, i, "-->")) {
              state = NORMAL;
              i += 3;
            } else {
              i++;
            }
            break;

          case CDATA:
            if (regionMatches(text, i, "]]>")) {
              state = NORMAL;
              i += 3;
            } else {
              i++;
            }
            break;

          case PI:
            if (regionMatches(text, i, "?>")) {
              state = NORMAL;
              i += 2;
            } else {
              i++;
            }
            break;

          default: // MARKUP
            if (c == '>') state = NORMAL;
            i++;
            break;
        }
      }

      endState[line] = state;
      int delta = opened - closed - selfClosed;
      depthDelta[line] = delta;
      depth += delta;
      if (depth < 0) depth = 0;
    }

    return new Layout(
        lineCount, lineStart, lineEnd, startState, endState, depthBefore, depthDelta, startsWithClose);
  }

  /** حالة المحلل عند إزاحة معينة — لمسار واحد بلا تخزين. */
  public static int stateAt(String text, int offset) {
    return walkTo(text, clamp(offset, text.length()), -1, -1, NORMAL);
  }

  /**
   * هل يمرّ المدى {@code [from, to)} على أي موضع حالته {@code state}؟
   *
   * <p>ضروري لأن حالة بداية السطر وحدها لا تكفي: بنية مثل {@code <![CDATA[…]]>} قد تفتح وتغلق
   * داخل السطر نفسه فتبقى حالته عند البداية والنهاية {@link #NORMAL}.
   */
  public static boolean rangeTouchesState(String text, int from, int to, int state) {
    int probeFrom = clamp(from, text.length());
    int probeTo = clamp(to, text.length());
    return walkTo(text, probeTo, probeFrom, probeTo, state) == FOUND;
  }

  private static final int FOUND = -2;

  private static int clamp(int value, int length) {
    return value < 0 ? 0 : Math.min(value, length);
  }

  /**
   * مسار واحد على النص حتى {@code limit}.
   *
   * <p>إن كان {@code probeFrom < 0} يرجع الحالة النهائية؛ وإلا يرجع {@link #FOUND} عند أول موضع
   * حالته {@code probeState} داخل {@code [probeFrom, probeTo)}.
   */
  private static int walkTo(String text, int limit, int probeFrom, int probeTo, int probeState) {
    boolean probing = probeFrom >= 0;
    int state = NORMAL;
    int i = 0;
    while (i < limit) {
      if (probing && i >= probeFrom && i < probeTo && state == probeState) return FOUND;
      char c = text.charAt(i);
      switch (state) {
        case NORMAL:
          if (c == '<' && regionMatches(text, i, "<!--")) {
            state = COMMENT;
            i += 4;
          } else if (c == '<' && regionMatches(text, i, "<![CDATA[")) {
            state = CDATA;
            i += 9;
          } else if (c == '<' && regionMatches(text, i, "<?")) {
            state = PI;
            i += 2;
          } else if (c == '<' && regionMatches(text, i, "<!")) {
            state = MARKUP;
            i += 2;
          } else if (c == '<' && i + 1 < text.length() && text.charAt(i + 1) == '/') {
            state = TAG;
            i += 2;
          } else if (c == '<') {
            state = TAG;
            i++;
          } else {
            i++;
          }
          break;
        case TAG:
          if (c == '"') state = ATTR_DQ;
          else if (c == '\'') state = ATTR_SQ;
          else if (c == '>') state = NORMAL;
          i++;
          break;
        case ATTR_DQ:
          if (c == '"') state = TAG;
          i++;
          break;
        case ATTR_SQ:
          if (c == '\'') state = TAG;
          i++;
          break;
        case COMMENT:
          if (regionMatches(text, i, "-->")) {
            state = NORMAL;
            i += 3;
          } else {
            i++;
          }
          break;
        case CDATA:
          if (regionMatches(text, i, "]]>")) {
            state = NORMAL;
            i += 3;
          } else {
            i++;
          }
          break;
        case PI:
          if (regionMatches(text, i, "?>")) {
            state = NORMAL;
            i += 2;
          } else {
            i++;
          }
          break;
        default:
          if (c == '>') state = NORMAL;
          i++;
          break;
      }
    }
    // لم يُعثر على الحالة داخل النافذة؛ الحالة النهائية قيمة صالحة (0..7) فلا تُلبس بـFOUND.
    return state;
  }

  /**
   * مدى التعليق المحيط بالإزاحة: {@code {بداية "<!--"، ما بعد "-->"}} أو {@code null}.
   *
   * <p>الحد الأعلى شامل لشارة {@code -->} نفسها: فوقوف المؤشر على الشارة يُعدّ داخل التعليق،
   * بينما الموضع بعدها مباشرة خارجَه.
   */
  public static int[] commentSpanContaining(String text, int offset) {
    if (offset < 0 || offset > text.length()) return null;
    int i = 0;
    while (i < text.length()) {
      if (!regionMatches(text, i, "<!--")) {
        i++;
        continue;
      }
      int close = indexOf(text, "-->", i + 4);
      if (close < 0) return null; // تعليق غير مغلق: لا مدى آمن
      if (offset >= i && offset < close + 3) return new int[] {i, close + 3};
      i = close + 3;
    }
    return null;
  }

  /** أول تعليق مكتمل يبدأ داخل المدى {@code [from, to)}: {@code {بداية، ما بعد النهاية}} أو {@code null}. */
  public static int[] firstCommentSpanInRange(String text, int from, int to) {
    int start = Math.max(0, from);
    int limit = Math.min(text.length(), to);
    for (int i = start; i < limit; i++) {
      if (!regionMatches(text, i, "<!--")) continue;
      int close = indexOf(text, "-->", i + 4);
      if (close < 0) return null;
      return new int[] {i, close + 3};
    }
    return null;
  }

  /** أول إزاحة لـ{@code target} عند أو بعد {@code from}، أو ‎-1. */
  public static int indexOf(String text, String target, int from) {
    int last = text.length() - target.length();
    for (int i = Math.max(0, from); i <= last; i++) {
      if (regionMatches(text, i, target)) return i;
    }
    return -1;
  }

  /** مطابقة literal بلا تخصيص String — مقارنة محارف مباشرة. */
  public static boolean regionMatches(String text, int offset, String literal) {
    if (offset < 0 || offset + literal.length() > text.length()) return false;
    for (int i = 0; i < literal.length(); i++) {
      if (text.charAt(offset + i) != literal.charAt(i)) return false;
    }
    return true;
  }

  public static boolean isSpace(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\f';
  }
}
