package almlk;

/**
 * محلّل بيانات مسار SVG (السمة d): M L H V C S Q T A Z بصيغتيها المطلقة والنسبية، مع الأرقام
 * المضغوطة («1.5.5» و«1-2» و«1e-3») وأعلام القوس الملتصقة. القوس يتحوّل إلى منحنيات بيزييه
 * تكعيبية، فيكفي المستهلك أربعة أوامر رسم (android.graphics.Path أو غيره).
 */
public final class SvgPathParser {

  /** مستهلك أوامر المسار بإحداثيات مطلقة. */
  public interface Sink {
    void moveTo(float x, float y);

    void lineTo(float x, float y);

    void quadTo(float x1, float y1, float x, float y);

    void cubicTo(float x1, float y1, float x2, float y2, float x, float y);

    void close();
  }

  /** بيانات مسار تالفة. */
  public static final class PathError extends Exception {
    public final int offset;

    PathError(String message, int offset) {
      super(message + " at " + offset);
      this.offset = offset;
    }
  }

  private final String d;
  private int at;
  private float x, y, startX, startY, ctrlX, ctrlY;
  private char previous;

  private SvgPathParser(String d) {
    this.d = d;
  }

  public static void parse(String d, Sink sink) throws PathError {
    if (d == null) throw new PathError("Empty path", 0);
    new SvgPathParser(d).run(sink);
  }

  private void run(Sink sink) throws PathError {
    char command = 0;
    skipSeparators();
    while (at < d.length()) {
      char c = d.charAt(at);
      if (isCommand(c)) {
        command = c;
        at++;
      } else if (command == 0 || !startsNumber(c)) {
        throw new PathError("Unexpected '" + c + "'", at);
      } else if (command == 'M') {
        command = 'L'; // الأزواج اللاحقة لـ M خطوط ضمنية.
      } else if (command == 'm') {
        command = 'l';
      } else if (command == 'Z' || command == 'z') {
        throw new PathError("Number after close", at);
      }
      execute(command, sink);
      skipSeparators();
    }
  }

  private void execute(char command, Sink sink) throws PathError {
    boolean relative = Character.isLowerCase(command);
    float ox = relative ? x : 0, oy = relative ? y : 0;
    switch (Character.toUpperCase(command)) {
      case 'M':
        x = ox + number();
        y = oy + number();
        startX = x;
        startY = y;
        sink.moveTo(x, y);
        ctrlX = x;
        ctrlY = y;
        break;
      case 'L':
        x = ox + number();
        y = oy + number();
        sink.lineTo(x, y);
        ctrlX = x;
        ctrlY = y;
        break;
      case 'H':
        x = ox + number();
        sink.lineTo(x, y);
        ctrlX = x;
        ctrlY = y;
        break;
      case 'V':
        y = oy + number();
        sink.lineTo(x, y);
        ctrlX = x;
        ctrlY = y;
        break;
      case 'C': {
        float x1 = ox + number(), y1 = oy + number();
        float x2 = ox + number(), y2 = oy + number();
        x = ox + number();
        y = oy + number();
        sink.cubicTo(x1, y1, x2, y2, x, y);
        ctrlX = x2;
        ctrlY = y2;
        break;
      }
      case 'S': {
        boolean smooth = "CcSs".indexOf(previous) >= 0;
        float x1 = smooth ? 2 * x - ctrlX : x, y1 = smooth ? 2 * y - ctrlY : y;
        float x2 = ox + number(), y2 = oy + number();
        x = ox + number();
        y = oy + number();
        sink.cubicTo(x1, y1, x2, y2, x, y);
        ctrlX = x2;
        ctrlY = y2;
        break;
      }
      case 'Q': {
        float x1 = ox + number(), y1 = oy + number();
        x = ox + number();
        y = oy + number();
        sink.quadTo(x1, y1, x, y);
        ctrlX = x1;
        ctrlY = y1;
        break;
      }
      case 'T': {
        boolean smooth = "QqTt".indexOf(previous) >= 0;
        float x1 = smooth ? 2 * x - ctrlX : x, y1 = smooth ? 2 * y - ctrlY : y;
        x = ox + number();
        y = oy + number();
        sink.quadTo(x1, y1, x, y);
        ctrlX = x1;
        ctrlY = y1;
        break;
      }
      case 'A': {
        float rx = Math.abs(number()), ry = Math.abs(number()), rotation = number();
        boolean large = flag(), sweep = flag();
        float ex = ox + number(), ey = oy + number();
        arc(sink, x, y, ex, ey, rx, ry, rotation, large, sweep);
        x = ex;
        y = ey;
        ctrlX = x;
        ctrlY = y;
        break;
      }
      case 'Z':
        sink.close();
        x = startX;
        y = startY;
        ctrlX = x;
        ctrlY = y;
        break;
      default:
        throw new PathError("Unknown command '" + command + "'", at);
    }
    previous = command;
  }

  /** قوس إهليجي بين نقطتين ← منحنيات تكعيبية (تحويل SVG من صيغة الطرفين إلى المركز). */
  static void arc(Sink sink, float x0, float y0, float x1, float y1, float rx, float ry, float angle,
      boolean large, boolean sweep) {
    if (x0 == x1 && y0 == y1) return;
    if (rx == 0 || ry == 0) {
      sink.lineTo(x1, y1);
      return;
    }
    double phi = Math.toRadians(angle % 360);
    double cos = Math.cos(phi), sin = Math.sin(phi);
    double dx = (x0 - x1) / 2.0, dy = (y0 - y1) / 2.0;
    double x1p = cos * dx + sin * dy, y1p = -sin * dx + cos * dy;
    double rxs = (double) rx * rx, rys = (double) ry * ry;
    double lambda = (x1p * x1p) / rxs + (y1p * y1p) / rys;
    double radiusX = rx, radiusY = ry;
    if (lambda > 1) {
      double scale = Math.sqrt(lambda);
      radiusX *= scale;
      radiusY *= scale;
      rxs = radiusX * radiusX;
      rys = radiusY * radiusY;
    }
    double num = rxs * rys - rxs * y1p * y1p - rys * x1p * x1p;
    double den = rxs * y1p * y1p + rys * x1p * x1p;
    double coef = den == 0 ? 0 : Math.sqrt(Math.max(0, num / den));
    if (large == sweep) coef = -coef;
    double cxp = coef * radiusX * y1p / radiusY, cyp = -coef * radiusY * x1p / radiusX;
    double cx = cos * cxp - sin * cyp + (x0 + x1) / 2.0;
    double cy = sin * cxp + cos * cyp + (y0 + y1) / 2.0;
    double theta = angleBetween(1, 0, (x1p - cxp) / radiusX, (y1p - cyp) / radiusY);
    double delta = angleBetween((x1p - cxp) / radiusX, (y1p - cyp) / radiusY,
        (-x1p - cxp) / radiusX, (-y1p - cyp) / radiusY);
    if (!sweep && delta > 0) delta -= 2 * Math.PI;
    else if (sweep && delta < 0) delta += 2 * Math.PI;
    int segments = (int) Math.ceil(Math.abs(delta) / (Math.PI / 2) - 1e-7);
    if (segments < 1) segments = 1;
    double step = delta / segments;
    double k = 4.0 / 3.0 * Math.tan(step / 4);
    double t = theta;
    for (int i = 0; i < segments; i++) {
      double c1 = Math.cos(t), s1 = Math.sin(t);
      double t2 = t + step;
      double c2 = Math.cos(t2), s2 = Math.sin(t2);
      double ax = c1 - k * s1, ay = s1 + k * c1;
      double bx = c2 + k * s2, by = s2 - k * c2;
      float px = (float) (cx + radiusX * (cos * ax) - radiusY * (sin * ay));
      float py = (float) (cy + radiusX * (sin * ax) + radiusY * (cos * ay));
      float qx = (float) (cx + radiusX * (cos * bx) - radiusY * (sin * by));
      float qy = (float) (cy + radiusX * (sin * bx) + radiusY * (cos * by));
      float ex, ey;
      if (i == segments - 1) {
        ex = x1;
        ey = y1;
      } else {
        ex = (float) (cx + radiusX * cos * c2 - radiusY * sin * s2);
        ey = (float) (cy + radiusX * sin * c2 + radiusY * cos * s2);
      }
      sink.cubicTo(px, py, qx, qy, ex, ey);
      t = t2;
    }
  }

  private static double angleBetween(double ux, double uy, double vx, double vy) {
    double dot = ux * vx + uy * vy;
    double len = Math.sqrt((ux * ux + uy * uy) * (vx * vx + vy * vy));
    double a = Math.acos(Math.max(-1, Math.min(1, len == 0 ? 1 : dot / len)));
    return (ux * vy - uy * vx) < 0 ? -a : a;
  }

  private static boolean isCommand(char c) {
    return "MmLlHhVvCcSsQqTtAaZz".indexOf(c) >= 0;
  }

  private static boolean startsNumber(char c) {
    return (c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.';
  }

  private void skipSeparators() {
    while (at < d.length()) {
      char c = d.charAt(at);
      if (c == ' ' || c == ',' || c == '\t' || c == '\n' || c == '\r' || c == '\f') at++;
      else break;
    }
  }

  private boolean flag() throws PathError {
    skipSeparators();
    if (at < d.length()) {
      char c = d.charAt(at);
      if (c == '0' || c == '1') {
        at++;
        return c == '1';
      }
    }
    throw new PathError("Expected arc flag", at);
  }

  private float number() throws PathError {
    skipSeparators();
    int start = at;
    if (at < d.length() && (d.charAt(at) == '-' || d.charAt(at) == '+')) at++;
    boolean digits = false, dot = false;
    while (at < d.length()) {
      char c = d.charAt(at);
      if (c >= '0' && c <= '9') {
        digits = true;
        at++;
      } else if (c == '.' && !dot) {
        dot = true;
        at++;
      } else {
        break;
      }
    }
    if (!digits) {
      at = start;
      throw new PathError("Expected number", start);
    }
    if (at < d.length() && (d.charAt(at) == 'e' || d.charAt(at) == 'E')) {
      int mark = at++;
      if (at < d.length() && (d.charAt(at) == '-' || d.charAt(at) == '+')) at++;
      int expStart = at;
      while (at < d.length() && d.charAt(at) >= '0' && d.charAt(at) <= '9') at++;
      if (at == expStart) at = mark;
    }
    try {
      float value = Float.parseFloat(d.substring(start, at));
      if (Float.isNaN(value) || Float.isInfinite(value)) throw new PathError("Invalid number", start);
      return value;
    } catch (NumberFormatException e) {
      throw new PathError("Invalid number", start);
    }
  }
}
