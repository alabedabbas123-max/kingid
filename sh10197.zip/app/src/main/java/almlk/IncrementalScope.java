package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * نُسخُ الملفاتِ ونطاقاتُها الحاضنةُ — طبقةٌ صافيةٌ للجولةِ ‏24/2 («الفحصُ التدريجيُّ» في ورقةِ الدراسةِ
 * ‏W23 §ب و§ج).
 *
 * <p>ما أخذناهُ من المرجعِ: {@code abcd.Nk} يُصدِرُ للمُحرِّكِ <b>نسخةً</b> لكلِّ ملفٍّ
 * ({@code u7(String)J}) وسؤالَ «أأُعيدُ تحليلَه؟» ({@code tp}/{@code gn})، فلا يُعادُ تغذيةُ ما لم يتغيَرْ؛
 * والمِدادُ يقرأُ نصَّهُ نفسَهُ عبرَ قناةٍ عكسيّةٍ صفحةً صفحةً. عندَنا لا قناةَ عكسيّةً (الحِملُ نصٌّ مُرسَلٌ
 * رأسًا)، فَبُقيَتِ الفكرةُ الحاسِمةُ وحدَها: <b>لا طلبَ بلا تغيّرٍ، ولا مسحَ أوسعَ من الحاجةِ</b>.
 *
 * <p>وهنا سببُ بقاءِ هذا في الصافيِ: قرارُ «أَتُرسِلُ أم لا» وقرارُ «أيُّ نطاقٍ» حسابٌ على سِلسلةٍ وارقينِ،
 * لا يَمسُّ {@code Context} ولا {@code Handler} ولا القرصَ؛ فيُختبَرُ على {@code JVM} كما يُختبَرُ على
 * الجهازِ، وهو أخطرُ موضعٍ لسقوطٍ صامتٍ (نطاقٌ ضيِّقٌ = تشخيصاتٌ ناقصةٌ، ونطاقٌ واسعٌ = جُمودٌ).
 *
 * <p>الأسقافُ معلَنةٌ والزيادةُ معدودةٌ لا مطرودةٌ صمتًا (بندُ «الحالاتُ المسمّاةُ» في شروطِ المشروعِ):
 * {@link #MAX_TRACKED} ملفًّا، و{@link #MAX_PROBLEMS} سِجلًّا.
 */
public final class IncrementalScope {

  /** كم ملفًّا يُتذكَرُ؟ ما زادَ يُخرَجُ من الحسابِ بأقدمِ نسخةٍ (الملفُّ المفتوحُ الآنَ لا يَخسَرُ). */
  public static final int MAX_TRACKED = 512;
  /** كم سِجلًّا يُحفَظُ للطرفينِ؟ (نفسُ سقفِ {@code AnalyzerProtocol.MAX_PROBLEMS}). */
  public static final int MAX_PROBLEMS = 4;
  /** تحتَ هذا الحجمِ لا فائدةَ من التقييدِ بالنطاقِ: الفحصُ الكاملُ أرخصُ من حسابِ الحدودِ. */
  public static final int WHOLE_FILE_CHARS = 4096;

  /** ما يَحمِلُهُ الطلبُ من قرارٍ تدريجيٍّ: نسخةٌ، ونطاقٌ (أو فراغٌ = الملفُّ كلُّهُ). */
  public static final class Plan {
    public final String file;
    public final long revision;
    /** ‏true عندَ الحاجةِ إلى الفحصِ كلِّهِ (ملفٌّ جديدٌ، أو تغيّرٌ خارجَ أيِّ نطاقٍ مَعْروفٍ). */
    public final boolean wholeFile;
    public final int from;
    public final int to;
    public final List<String> problems;

    Plan(String file, long revision, boolean wholeFile, int from, int to, List<String> problems) {
      this.file = file == null ? "" : file;
      this.revision = revision;
      this.wholeFile = wholeFile;
      this.from = Math.max(0, from);
      this.to = Math.max(this.from, to);
      this.problems =
          problems == null
              ? Collections.<String>emptyList()
              : Collections.unmodifiableList(new ArrayList<>(problems));
    }
  }

  /** بترتيبِ الإدخالِ: «أقدمُ نسخةٍ» هي الأقدمُ طلبًا لا الأصغرُ بصمةً (البصمةُ لا تَر تيبُ لها). */
  private final Map<String, Long> revisions =
      new java.util.LinkedHashMap<String, Long>(64, 0.75f, false);
  private final ArrayList<String> problems = new ArrayList<>(MAX_PROBLEMS + 1);
  private int skipped;
  private int requested;
  private int evicted;

  /** نسخةُ الملفِّ كما هي مُسجَّلةٌ؛ صِفرٌ لمن لا نُسخةَ لهُ (وهو سؤالٌ مشروعٌ عندَ أولِ فتحٍ). */
  public long revisionOf(String file) {
    Long seen = file == null ? null : revisions.get(file);
    return seen == null ? 0L : seen;
  }

  public synchronized int trackedCount() {
    return revisions.size();
  }

  public synchronized int skippedCount() {
    return skipped;
  }

  public synchronized int requestedCount() {
    return requested;
  }

  public synchronized int evictedCount() {
    return evicted;
  }

  public synchronized List<String> problems() {
    return Collections.unmodifiableList(new ArrayList<>(problems));
  }

  public synchronized void clear() {
    revisions.clear();
    problems.clear();
    skipped = 0;
    requested = 0;
    evicted = 0;
  }

  /**
   * القرارُ كلُّهُ في نداءٍ واحدٍ: إن لم تتغيّرِ النسخةُ فلا طلبَ ({@code null})؛ وإلا فخُطّةٌ تحملُ
   * النطاقَ الحاضنَ للتعديلِ أو الملفَّ كلَّهُ إن كان صغيرًا/تعذَّرَ حصرُ النطاقِ.
   *
   * @param previous نصُّ آخرِ فحصٍ مُطبَّقٍ (أو {@code null} عندَ أولِ مرةٍ)
   * @param current نصُّ اللحظةِ
   */
  public synchronized Plan plan(String file, String previous, String current) {
    if (file == null || file.isEmpty() || current == null) return null;
    long revision = fingerprint(current);
    Long known = revisions.get(file);
    if (known != null && known.longValue() == revision) {
      skipped++;
      return null;
    }
    requested++;
    List<String> notes = new ArrayList<>(2);
    int[] region = previous == null || previous.isEmpty() || current.length() <= WHOLE_FILE_CHARS
        ? null
        : enclosingRegion(previous, current);
    boolean whole = region == null;
    revisions.put(file, revision);
    while (revisions.size() > MAX_TRACKED) {
      // الإخراجُ من أولِ مُدخَلٍ لا من آخرِ طلبٍ: ما يُفتَحُ الآنَ يجبُ ألّا يفقدَ ذاكرتَهُ؛ وحلقةٌ لا
      //if (eldest != null && !eldest.equals(file)) {
      java.util.Iterator<String> it = revisions.keySet().iterator();
      String eldest = null;
      while (it.hasNext()) {
        String candidate = it.next();
        if (!candidate.equals(file)) {
          eldest = candidate;
          break;
        }
      }
      if (eldest == null) break; // الملفُّ الحاليُّ هو كلُّ ما نَتتبَّعُهُ: لا إخراجَ يُجدي
      revisions.remove(eldest);
      evicted++;
      note("tracked files capped at " + MAX_TRACKED + " (least recently requested dropped)", notes);
    }
    return new Plan(
        file, revision, whole, whole ? 0 : region[0], whole ? current.length() : region[1], notes);
  }

  /** بعدَ ردٍّ مَرفوضٍ أو بائتٍ: تُلغى النسخةُ المُسجَّلةُ فيُعادُ الطلبُ ولا يَسقُطُ بينَ نسختينِ. */
  public synchronized void forget(String file) {
    if (file != null) revisions.remove(file);
  }

  /** يثبَّتُ بعدَ التطبيقِ الناجحِ (المسارُ كلُّهُ: النسخةُ التي رُئِيَت على الشاشةِ لا التي أرسِلَتْ). */
  public synchronized void noteApplied(String file, long revision) {
    if (file == null || file.isEmpty()) return;
    revisions.put(file, revision);
    if (revision == 0L) forget(file);
  }

  /**
   * بصمةٌ لا {@code hashCode} السلسلةِ (الاصطدامُ فيها شائعٌ بما يكفي لإسقاطِ فحصٍ حقيقيٍّ): طولٌ ثمَّ
   * FNV-1a على كلِّ محرفٍ، فكلُّ تعديلٍ ولو بحرفٍ واحدٍ يَفصِمُ النسخةَ — التخطّي الخاطئُ أثمنُ من مسحٍ زائدٍ.
   */
  public static long fingerprint(String text) {
    if (text == null || text.isEmpty()) return 0L;
    long h = 1469598103934665603L; // FNV-1a
    int n = text.length();
    h = h * 1099511628211L ^ n;
    // كلُّ محرفٍ يَدخُلُ الحسابَ: عيّنةٌ متباعدةٌ اصطدمَتْ في البوابةِ بتعديلٍ حرفًا واحدًا في وسطِ
    // سطرٍ قصيرٍ — وهو بالضبطِ الحالةُ التي يجبُ ألّا تُسقِطَ فحصًا. الكلفةُ مرورٌ واحدٌ على النصِّ
    // (أرخصُ من نسخةِ المستندِ نفسِها وأرخصُ بكثيرٍ من جولةِ تحليلٍ)، والصوابُ هنا أوثقُ من السرعةِ.
    for (int i = 0; i < n; i++) h = (h ^ text.charAt(i)) * 1099511628211L;
    return h == 0L ? 1L : h;
  }

  /**
   * النطاقُ الحاضنُ للتعديلِ: بَدايةٌ مشتركةٌ ونهايةٌ مشتركةٌ بينَ النسختينِ، ثمَّ توسيعٌ إلى حدودِ
   * الإعلانِ الذي يحويهِ التعديلُ (أقواسُ الصنفِ/الدالةِ لا الأسطرُ) — كما يَفعَلُ المرجعُ حينَ يسألُ
   * المحرِّكَ عن «نطاقِ الإعلانِ الحاضنِ» بدلَ إعادةِ الملفِّ كلِّهِ.
   *
   * @return {@code {from, to}} أو {@code null} إذا تعذَّرَ الحصرُ (فليُفرَضِ الفحصُ الكاملُ)
   */
  public static int[] enclosingRegion(String previous, String current) {
    if (previous == null || current == null) return null;
    int common = 0;
    int limit = Math.min(previous.length(), current.length());
    while (common < limit && previous.charAt(common) == current.charAt(common)) common++;
    if (common == 0) return null; // تعديلٌ في أولِ الملفِّ أو إعادةُ كتابةٍ كلِّيًّا
    int tail = 0;
    while (
        tail < limit - common
            && previous.charAt(previous.length() - 1 - tail) == current.charAt(current.length() - 1 - tail)) {
      tail++;
    }
    int from = Math.max(0, common - 1);
    int to = Math.min(current.length(), current.length() - tail + 1);
    return braceEnclosed(current, from, to);
  }

  /**
   * توسيعٌ إلى كتلةِ الإعلانِ الحاضنةِ: نَصعَدُ من {@code from} إلى القوسِ المفتوحِ الذي يَفتَحُ المستوى
   * الذي نَقرؤُهُ، ثمَّ نَهبطُ إلى قوسِهِ المُطابِقِ. ولا نَدخُلُ نصًّا ولا تعليقًا (هما قوسانِ مثلُ غيرِهِما
   * إن لم نَتجنَّبه، فتتوهَّمَ الحدودُ).
   */
  public static int[] braceEnclosed(String text, int from, int to) {
    if (text == null || text.isEmpty()) return null;
    int start = Math.max(0, Math.min(from, text.length() - 1));
    int end = Math.max(start, Math.min(to, text.length()));
    int depth = 0;
    int open = -1;
    for (int i = start; i >= 0; i--) {
      char c = text.charAt(i);
      if (skipInside(text, i)) continue;
      if (c == '}') depth++;
      else if (c == '{') {
        if (depth == 0) {
          open = i;
          break;
        }
        depth--;
      }
    }
    if (open < 0) return new int[] {0, text.length()}; // لا كتلةٌ حاضنةٌ: فحصٌ كاملٌ، لا حدسٌ
    int close = -1;
    depth = 0;
    for (int i = open; i < text.length(); i++) {
      char c = text.charAt(i);
      if (skipInside(text, i)) continue;
      if (c == '{') depth++;
      else if (c == '}') {
        depth--;
        if (depth == 0) {
          close = i + 1;
          break;
        }
      }
    }
    if (close < 0) return new int[] {0, text.length()};
    if (end > close) close = end; // النطاقُ يَسَعُ التعديلَ دائمًا، لا الإعلانَ وحدَهُ
    // رأسُ الإعلانِ (التعديلاتُ والمُعتَدِلُ اسمُها) يسبقُ القوسَ: نَضُمُّهُ حتى يُقارَنَ التوقيعُ.
    int head = open;
    while (head > 0 && text.charAt(head - 1) != '}' && text.charAt(head - 1) != ';' && text.charAt(head - 1) != '{') {
      head--;
    }
    return new int[] {Math.min(head, start), Math.min(text.length(), Math.max(close, end))};
  }

  /** هل هذا المحرفُ داخلَ نصٍّ حرفيٍّ أو تعليقٍ؟ (مسحٌ محليٌّ إلى أولِ السطرِ، لا إعادةَ تحليلٍ). */
  private static boolean skipInside(String text, int at) {
    int lineStart = at;
    while (lineStart > 0 && text.charAt(lineStart - 1) != '\n') lineStart--;
    boolean inString = false;
    boolean inChar = false;
    for (int i = lineStart; i < at; i++) {
      char c = text.charAt(i);
      if (c == '\\' && (inString || inChar)) {
        i++;
        continue;
      }
      if (c == '"' && !inChar) inString = !inString;
      else if (c == '\'' && !inString) inChar = !inChar;
    }
    if (inString || inChar) return true;
    String line = text.substring(lineStart, Math.min(at == text.length() ? at : at + 1, text.length()));
    return line.trim().startsWith("//") || line.contains("//");
  }

  private void note(String text, List<String> also) {
    if (!problems.contains(text)) {
      if (problems.size() < MAX_PROBLEMS) problems.add(text);
    }
    if (also != null && !also.contains(text) && also.size() < MAX_PROBLEMS) also.add(text);
  }

  /** حالةٌ مُسمّاةٌ للقياسِ والسجلِّ: بلا عدّاداتٍ لا يُثبَتُ أنَّ التدريجَ يَعمَلُ. */
  public synchronized String state() {
    if (requested == 0 && skipped == 0) return "idle";
    if (!problems.isEmpty()) return "capped";
    return "tracking";
  }
}
