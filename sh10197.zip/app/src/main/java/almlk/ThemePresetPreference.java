package almlk;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.preference.Preference;

/**
 * سطرُ ثيمٍ في قسمِ الثيماتِ من شاشةِ الإعداداتِ — مثلُهُ مثلُ سطرِ الإعداداتِ تمامًا، لأنَّهُ **هو** سطرُ الإعدادات:
 * {@code android.preference.Preference} بـ{@code widgetLayout} فيه شريطُ المعاينة، فيرثُ العنوانَ
 * والوصفَ والفاصلَ والخطَّ والحشوُ كلَّها من ثيمِ الإعداداتِ نفسِه، بلا ListView يدويٍّ يُقلّدُ الشكل.
 *
 * <p>لا تعرفُ هذه الطبقةُ أسماءَ المواردِ ولا ألوانًا: الشاشةُ تمُرُّ عليهِ ما حلَّتْهُ من لوحةِ الأدوارِ
 * ({@link EditorThemePresets}) وحالتِهِ (مُطبَّقٌ/لا)، فهو قابلٌ للقياسِ وحدَهُ.
 */
public class ThemePresetPreference extends Preference {

  private int[] previewColors = new int[0];
  private boolean active;

  public ThemePresetPreference(Context context) {
    this(context, null);
  }

  public ThemePresetPreference(Context context, AttributeSet attrs) {
    super(context, attrs);
    setWidgetLayoutResource(com.shima.demo.R.layout.theme_gallery_swatch);
    setSelectable(true);
  }

  /** معاينةُ الثيمِ وحالتُهُ — تُحدَّثُ عندَ كلِّ اختيارٍ فلا يجمدُ ✓ على سطرٍ قديم. */
  public void setPreview(int[] colors, boolean active) {
    this.previewColors = colors == null ? new int[0] : colors;
    this.active = active;
    notifyChanged();
  }

  public boolean isActive() {
    return active;
  }

  /**
   * {@code android.preference.PreferenceViewHolder} غيرُ موجودٍ في {@code android.jar} الذي نُترجِمُ لهُ،
   * فالرباطُ من مسارِ العرضِ القديمِ عندَ كلِّ ربطِ سطر: النتيجةُ نفسُها (شريطُ معاينةٍ حيٌّ) بلا طبقةٍ ثانية.
   */
  @Override
  @SuppressWarnings("deprecation")
  public View getView(View convertView, ViewGroup parent) {
    View row = super.getView(convertView, parent);
    View strip = row.findViewById(com.shima.demo.R.id.themeGallerySwatch);
    if (strip instanceof ThemeSwatchStrip) {
      ThemeSwatchStrip view = (ThemeSwatchStrip) strip;
      view.setColors(previewColors);
      view.setActive(active);
    }
    return row;
  }
}
