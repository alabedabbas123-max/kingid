package almlk;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * محرك إعادة البناء النقي (بلا أندرويد): Inline / Introduce / Extract Method كتحويلات نصية
 * آمنة قابلة للاختبار خارج الجهاز (بند 2/3). يعيد null عند تعذّر العملية ليُعرض سبب ظاهر.
 */
public final class Refactor {
  private Refactor() {}

  /**
   * تضمين متغير (Inline): يحذف إعلان {@code Type var = init;} ويستبدل كل استخداماته بـ«(init)».
   * يعيد null إن لم يُعثر على الإعلان أو لا استخدامات له.
   */
  public static String inlineVariable(String source, String var) {
    if (source == null || var == null || var.isEmpty()) return null;
    Pattern decl =
        Pattern.compile(
            "(?m)^[ \\t]*(?:final\\s+)?[A-Za-z_][\\w.]*(?:<[^\\n>]*>)?(?:\\[\\])?\\s+"
                + Pattern.quote(var) + "\\s*=\\s*([^;\\n]+);[ \\t]*\\n?");
    Matcher m = decl.matcher(source);
    if (!m.find()) return null;
    String init = m.group(1).trim();
    String withoutDecl = source.substring(0, m.start()) + source.substring(m.end());
    if (Renamer.countOccurrences(withoutDecl, var) == 0) return null;
    return Renamer.renameAll(withoutDecl, var, "(" + init + ")");
  }

  /**
   * استخلاص متغير (Introduce): يستبدل التعبير المحدد [start,end) باسم جديد ويضيف
   * {@code var name = expr;} قبل السطر الحاوي. يعيد null لمدى غير صالح.
   */
  public static String introduceVariable(String source, int start, int end, String name) {
    if (source == null || start < 0 || end > source.length() || start >= end) return null;
    if (!Renamer.isValidJavaIdentifier(name) || Renamer.isKeyword(name)) return null;
    String expr = source.substring(start, end).trim();
    if (expr.isEmpty()) return null;
    int lineStart = source.lastIndexOf('\n', start - 1) + 1;
    int i = lineStart;
    while (i < source.length() && (source.charAt(i) == ' ' || source.charAt(i) == '\t')) i++;
    String indent = source.substring(lineStart, i);
    String decl = indent + "var " + name + " = " + expr + ";\n";
    return source.substring(0, lineStart)
        + decl
        + source.substring(lineStart, start)
        + name
        + source.substring(end);
  }

  /**
   * استخلاص دالة (Extract Method): يلفّ العبارات المحددة [start,end) بدالة {@code private void
   * name()} تُضاف قبل آخر «}»، ويستبدل التحديد بنداء الدالة. يعيد null لمدى غير صالح.
   */
  public static String extractMethod(String source, int start, int end, String name) {
    if (source == null || start < 0 || end > source.length() || start >= end) return null;
    if (!Renamer.isValidJavaIdentifier(name) || Renamer.isKeyword(name)) return null;
    int lastBrace = source.lastIndexOf('}');
    if (lastBrace < 0) return null;
    String body = source.substring(start, end).trim();
    if (body.isEmpty()) return null;
    StringBuilder method = new StringBuilder("\n  private void " + name + "() {\n");
    for (String line : body.split("\n")) method.append("    ").append(line.trim()).append('\n');
    method.append("  }\n");
    String call = name + "();";
    String s2 = source.substring(0, start) + call + source.substring(end);
    int insertAt = s2.lastIndexOf('}');
    return s2.substring(0, insertAt) + method + s2.substring(insertAt);
  }
}
