package almlk;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * ملف POM واحد كما كُتب (M2): الإحداثيات، والأب، والخصائص، وdependencyManagement، والاعتماديات،
 * وإعادة التوجيه. النموذج الفعّال (وراثة الأب والاستبدال والاستيراد) يبنيه {@link MavenResolver}.
 * جافا خالصة (javax.xml متاح في Android).
 */
public final class MavenPom {

  /** اعتماد داخل POM (قبل الاستبدال). */
  public static final class Dependency {
    public final String groupId, artifactId, version, scope, type, classifier;
    public final boolean optional;
    /** group:artifact، ويُقبل * في أي جزء. */
    public final List<String> exclusions;

    public Dependency(String groupId, String artifactId, String version, String scope, String type,
        String classifier, boolean optional, List<String> exclusions) {
      this.groupId = groupId;
      this.artifactId = artifactId;
      this.version = version;
      this.scope = scope;
      this.type = type;
      this.classifier = classifier;
      this.optional = optional;
      this.exclusions = exclusions == null ? Collections.<String>emptyList() : exclusions;
    }

    public String key() {
      return groupId + ":" + artifactId;
    }

    /** نسخة بعد استبدال ${…} وبإصدار/نطاق من dependencyManagement إن غاب. */
    Dependency with(String newGroup, String newArtifact, String newVersion, String newScope, String newType,
        String newClassifier, List<String> newExclusions) {
      return new Dependency(newGroup, newArtifact, newVersion, newScope, newType, newClassifier, optional, newExclusions);
    }
  }

  public String groupId, artifactId, version, packaging;
  public String parentGroupId, parentArtifactId, parentVersion;
  public String relocationGroupId, relocationArtifactId, relocationVersion;
  public final Map<String, String> properties = new LinkedHashMap<>();
  public final List<Dependency> dependencyManagement = new ArrayList<>();
  public final List<Dependency> dependencies = new ArrayList<>();

  /** يحلّل النص؛ يرمي استثناء عند XML فاسد أو جذر ليس project. */
  public static MavenPom parse(byte[] xml) throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    factory.setNamespaceAware(false);
    factory.setExpandEntityReferences(false);
    trySetFeature(factory, "http://apache.org/xml/features/disallow-doctype-decl", true);
    trySetFeature(factory, "http://xml.org/sax/features/external-general-entities", false);
    trySetFeature(factory, "http://xml.org/sax/features/external-parameter-entities", false);
    DocumentBuilder builder = factory.newDocumentBuilder();
    builder.setErrorHandler(SILENT);
    Document document = builder.parse(new ByteArrayInputStream(xml));
    Element project = document.getDocumentElement();
    if (project == null || !"project".equals(localName(project))) throw new java.io.IOException("not a POM");
    MavenPom pom = new MavenPom();
    pom.groupId = text(project, "groupId");
    pom.artifactId = text(project, "artifactId");
    pom.version = text(project, "version");
    pom.packaging = text(project, "packaging");
    Element parent = child(project, "parent");
    if (parent != null) {
      pom.parentGroupId = text(parent, "groupId");
      pom.parentArtifactId = text(parent, "artifactId");
      pom.parentVersion = text(parent, "version");
    }
    Element distribution = child(project, "distributionManagement");
    Element relocation = distribution == null ? null : child(distribution, "relocation");
    if (relocation != null) {
      pom.relocationGroupId = text(relocation, "groupId");
      pom.relocationArtifactId = text(relocation, "artifactId");
      pom.relocationVersion = text(relocation, "version");
    }
    Element properties = child(project, "properties");
    if (properties != null) {
      NodeList list = properties.getChildNodes();
      for (int i = 0; i < list.getLength(); i++) {
        Node node = list.item(i);
        if (node instanceof Element) pom.properties.put(localName((Element) node), node.getTextContent().trim());
      }
    }
    Element management = child(project, "dependencyManagement");
    Element managed = management == null ? null : child(management, "dependencies");
    if (managed != null) readDependencies(managed, pom.dependencyManagement);
    Element deps = child(project, "dependencies");
    if (deps != null) readDependencies(deps, pom.dependencies);
    return pom;
  }

  public boolean hasParent() {
    return parentGroupId != null && parentArtifactId != null && parentVersion != null;
  }

  public boolean isRelocated() {
    return relocationGroupId != null || relocationArtifactId != null || relocationVersion != null;
  }

  private static void readDependencies(Element container, List<Dependency> out) {
    NodeList list = container.getChildNodes();
    for (int i = 0; i < list.getLength(); i++) {
      Node node = list.item(i);
      if (!(node instanceof Element) || !"dependency".equals(localName((Element) node))) continue;
      Element d = (Element) node;
      List<String> exclusions = new ArrayList<>();
      Element ex = child(d, "exclusions");
      if (ex != null) {
        NodeList items = ex.getChildNodes();
        for (int j = 0; j < items.getLength(); j++) {
          Node item = items.item(j);
          if (!(item instanceof Element)) continue;
          String g = text((Element) item, "groupId");
          String a = text((Element) item, "artifactId");
          exclusions.add((g == null ? "*" : g) + ":" + (a == null ? "*" : a));
        }
      }
      String groupId = text(d, "groupId");
      String artifactId = text(d, "artifactId");
      if (groupId == null || artifactId == null) continue;
      out.add(new Dependency(groupId, artifactId, text(d, "version"), text(d, "scope"), text(d, "type"),
          text(d, "classifier"), "true".equalsIgnoreCase(text(d, "optional")), exclusions));
    }
  }

  // ═══════════════ الاستبدال ═══════════════

  private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^}]+)\\}");

  /**
   * يستبدل {@code ${name}} من الخصائص المعطاة (مع project.* وpom.* وparent.*) تكراريًا حتى عمق 10؛
   * ما لا يُعرف يبقى كما هو.
   */
  public static String interpolate(String value, Map<String, String> properties) {
    if (value == null || value.indexOf("${") < 0) return value;
    String current = value;
    for (int round = 0; round < 10 && current.indexOf("${") >= 0; round++) {
      Matcher matcher = PLACEHOLDER.matcher(current);
      StringBuffer out = new StringBuffer();
      boolean changed = false;
      while (matcher.find()) {
        String key = matcher.group(1).trim();
        String replacement = properties.get(key);
        if (replacement == null && key.startsWith("pom.")) replacement = properties.get("project." + key.substring(4));
        if (replacement == null) {
          matcher.appendReplacement(out, Matcher.quoteReplacement(matcher.group()));
        } else {
          matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
          changed = true;
        }
      }
      matcher.appendTail(out);
      current = out.toString();
      if (!changed) break;
    }
    return current;
  }

  // ═══════════════ أدوات DOM ═══════════════

  /** بلا طباعة «[Fatal Error]» في stderr/logcat: الخطأ يصل استثناءً فقط. */
  private static final org.xml.sax.ErrorHandler SILENT = new org.xml.sax.ErrorHandler() {
    @Override
    public void warning(org.xml.sax.SAXParseException e) {}

    @Override
    public void error(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException {
      throw e;
    }

    @Override
    public void fatalError(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException {
      throw e;
    }
  };

  private static void trySetFeature(DocumentBuilderFactory factory, String feature, boolean value) {
    try {
      factory.setFeature(feature, value);
    } catch (Throwable ignored) {
      // بعض محللات Android لا تدعم كل الخصائص؛ الكيانات الخارجية معطّلة بـsetExpandEntityReferences.
    }
  }

  private static String localName(Element element) {
    String name = element.getNodeName();
    int colon = name.indexOf(':');
    return colon < 0 ? name : name.substring(colon + 1);
  }

  /** أول ابن مباشر بالاسم (لا الأحفاد — كي لا يُقرأ groupId من parent بدل المشروع). */
  static Element child(Element parent, String name) {
    NodeList list = parent.getChildNodes();
    for (int i = 0; i < list.getLength(); i++) {
      Node node = list.item(i);
      if (node instanceof Element && name.equals(localName((Element) node))) return (Element) node;
    }
    return null;
  }

  static String text(Element parent, String name) {
    Element element = child(parent, name);
    if (element == null) return null;
    String value = element.getTextContent();
    if (value == null) return null;
    value = value.trim();
    return value.isEmpty() ? null : value;
  }
}
