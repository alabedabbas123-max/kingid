package almlk;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * هل يحمِلُ الملفُّ الموجودُ في المخزنِ المكتبةَ فعلًا، أم اسمَها فقطْ؟
 *
 * <p>اسمٌ يطابقُ لا يعني تثبيتًا: تنزيلٌ مقطوعٌ عندَ آخرِ مِئراتِ البايتاتِ، ومرآةٌ تجيبُ صفحةَ خطأٍ
 * برمزِ 200، وفكٌّ لأرشيفٍ قُطِعَ فخلَّفَ `classes.jar` فارغًا — كلُّ ذلكَ كانَ يُعَدُّ «المكتباتُ
 * جاهزةٌ»، فيبقى المشروعُ يُلومُ رموزًا ناقصةً في ملفٍّ بأسطُرٍ معدودةٍ ولا سبيلَ إلى معرفةِ أنَّ
 * الأداةَ لم تُنزَّلْ قطُّ. هنا يُفتَتَحُ الأرشيفُ وتُعَدُّ مضامينُهُ:
 *
 * <ul>
 *   <li>{@link #READY} — أرشيفٌ يُقرَأُ وفيهِ أصنافٌ (وللـAAR يكفي أن يكونَ manifestٌ: مكتباتُ
 *       المواردِ حقٌّ ولا أصنافَ فيها عمدًا)؛
 *   <li>{@link #EMPTY} — أرشيفٌ يُقرَأُ ولا أصنافَ فيهِ: مُثبَّتةٌ لكنْ لا شيءَ يُحَلُّ منهُ، فتُبلَّغُ
 *       ولا تُعَدُّ «جاهزةً»؛
 *   <li>{@link #UNUSABLE} — ليس أرشيفًا أصلًا (مقطوعٌ، أو صفرُ بايتٍ، أو صفحةُ خطأٍ): <em>ليس
 *       تثبيتًا</em>، ونسخةُنا الخاصةُ منهُ تُحذَفُ حتى يُجَلَّبَ غيرُها في المرورِ القادمِ؛
 *   <li>{@link #MISSING} — لا ملفَّ بهذا الاسمِ.
 * </ul>
 *
 * <p>الحُكمُ محفوظٌ بمسارِ الملفِ وحجمِهِ وعدَّلةِ تعديلِهِ لأنَّ المحلَّلَ يسألُ عن الملفِّ نفسِهِ
 * مرَّاتٍ في الدورةِ الواحدةِ، وقِراءةُ جدولِ الوسطِ عملُ قرصٍ. جافا خالصةٌ: تُترجِمُها `qa.sh`
 * وتُقِيسُ عليها البوّاباتُ بملفاتَ حقيقيّةٍ.
 */
public final class LibraryInstallState {

  public static final int READY = 0;
  public static final int EMPTY = 1;
  public static final int UNUSABLE = 2;
  public static final int MISSING = 3;

  /** نتيجةُ فحصِ ملفٍّ واحدٍ: الحالةُ، حجمُهُ، عددُ مداخلِ الأرشيفِ وأصنافِهِ، وسببٌ للقارئِ. */
  public static final class Verdict {
    public final int state;
    public final long bytes;
    public final int entries;
    public final int classEntries;
    /** الأرشيفُ يذكرُ `classes.jar` (لأرشيفِ AAR: إن غابَ بعدَ الفكِّ كانَ الفكُّ ناقصًا). */
    public final boolean listsClassesJar;
    /** `AndroidManifest.xml` — علامةُ أرشيفِ أندرويدَ الصحيحِ. */
    public final boolean hasManifest;
    public final String reason;

    Verdict(int state, long bytes, int entries, int classEntries, boolean listsClassesJar,
        boolean hasManifest, String reason) {
      this.state = state;
      this.bytes = bytes;
      this.entries = entries;
      this.classEntries = classEntries;
      this.listsClassesJar = listsClassesJar;
      this.hasManifest = hasManifest;
      this.reason = reason == null ? "" : reason;
    }

    /** مُثبَّتةٌ بحقٍّ: تُعَدُّ في «جاهزةٍ» وتُحمَلُ إلى classpath. */
    public boolean installed() {
      return state == READY;
    }

    /** اسمٌ بلا مضمونٍ: خطأٌ صريحٌ على سطرِ الاعتمادِ، ونسخةُ المخزنِ تُستبدَلُ. */
    public boolean broken() {
      return state == UNUSABLE;
    }

    /** مُثبَّتةٌ لكنْ لا تُحِلُّ شيئًا: تُبلَّغُ ولا تُعَدُّ خطأَ تنزيلٍ. */
    public boolean silent() {
      return state == EMPTY;
    }

    @Override
    public String toString() {
      return state + "/" + bytes + "B/" + entries + "e/" + classEntries + "c " + reason;
    }
  }

  private static final int MAX_MEMO = 512;
  private static final LinkedHashMap<String, Verdict> MEMO =
      new LinkedHashMap<String, Verdict>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Verdict> eldest) {
          return size() > MAX_MEMO;
        }
      };

  private LibraryInstallState() {}

  /** الامتداداتُ التي تُفتَّتَحُ كأرشيفٍ؛ ما عداها (pom/module/metadata) يُكتَفى بأن لا يكونَ فارغًا. */
  public static boolean isArchiveExtension(String extension) {
    if (extension == null) return false;
    String e = extension.toLowerCase(java.util.Locale.US);
    return e.equals("jar") || e.equals("aar") || e.equals("zip");
  }

  /** فحصٌ بامتدادِ الاسمِ نفسِهِ (`x.aar` ← aar). */
  public static Verdict inspect(File file) {
    return inspect(file, extensionOf(file == null ? null : file.getName()));
  }

  public static Verdict inspect(File file, String extension) {
    if (file == null) return new Verdict(MISSING, 0, 0, 0, false, false, "no file");
    long length = file.isFile() ? file.length() : -1L;
    if (length < 0) {
      // مجلدٌ (classes.jar بعدَ فكٍّ ناقصٍ) أو لا شيءَ: ليس تثبيتًا
      return new Verdict(file.isDirectory() ? READY : MISSING, 0, 0, 0, false, false,
          file.isDirectory() ? "" : "not in the store");
    }
    String key = file.getAbsolutePath() + "|" + length + "|" + file.lastModified();
    synchronized (MEMO) {
      Verdict known = MEMO.get(key);
      if (known != null) return known;
    }
    // القراءةُ خارجَ القفلِ (فتحُ أرشيفٍ عملُ قرصٍ)، والمرورُ المتوازيُ للتنزيلِ يسألُ تزامنيًّا —
    // فالحفظُ وحدَهُ محميٌّ، وتكرارُ القراءةِ لملفٍّ واحدٍ ثمنُهُ فتحٌ زائدٌ لا أكثرُ.
    Verdict verdict = read(file, length, extension);
    synchronized (MEMO) {
      MEMO.put(key, verdict);
    }
    return verdict;
  }

  private static Verdict read(File file, long length, String extension) {
    if (!isArchiveExtension(extension)) {
      if (length == 0) return new Verdict(UNUSABLE, 0, 0, 0, false, false, "empty file");
      return new Verdict(READY, length, 0, 0, false, false, "");
    }
    if (length < 22)
      return new Verdict(UNUSABLE, length, 0, 0, false, false,
          length == 0 ? "empty file" : "too small to be an archive (" + length + " bytes)");
    ZipFile zip = null;
    try {
      zip = new ZipFile(file);
    } catch (IOException notAnArchive) {
      String message = notAnArchive.getMessage();
      return new Verdict(UNUSABLE, length, 0, 0, false, false,
          "not a readable archive (" + (message == null || message.isEmpty()
              ? "truncated or an error page" : message) + ")");
    }
    try {
      int entries = 0, classes = 0;
      boolean listsClasses = false, manifest = false;
      Enumeration<? extends ZipEntry> all = zip.entries();
      while (all.hasMoreElements()) {
        ZipEntry entry = all.nextElement();
        entries++;
        String name = entry.getName();
        if (name.endsWith(".class")) classes++;
        else if (name.equals("classes.jar")) listsClasses = true;
        else if (name.equals("AndroidManifest.xml")) manifest = true;
      }
      if (entries == 0)
        return new Verdict(UNUSABLE, length, 0, 0, listsClasses, manifest, "archive holds no entries");
      if (classes > 0) return new Verdict(READY, length, entries, classes, listsClasses, manifest, "");
      if (manifest) return new Verdict(READY, length, entries, 0, listsClasses, manifest, "");
      return new Verdict(EMPTY, length, entries, 0, listsClasses, manifest,
          "no classes in it (" + entries + " entries)");
    } finally {
      try {
        if (zip != null) zip.close();
      } catch (IOException ignored) {
        // إغلاقٌ لا يغيّرُ الحكمَ
      }
    }
  }

  /** سطرٌ واحدٌ للقارئِ: ما وُجِدَ ولماذا لا يُعَدُّ مكتبةً. */
  public static String describe(Verdict verdict, String what) {
    if (verdict == null) return what == null ? "" : what;
    if (verdict.state == READY) return what == null ? "" : what;
    String detail = verdict.reason.isEmpty() ? "" : ": " + verdict.reason;
    switch (verdict.state) {
      case MISSING:
        return what + " is not in the store" + detail;
      case EMPTY:
        return what + " is installed but carries no classes" + detail;
      default:
        return what + " is not an installed library — its file (" + verdict.bytes
            + " bytes) is not usable" + detail;
    }
  }

  /** الملفُّ في مخزنِنا خاصَّتُنا: النسخةُ الفاسدةُ تُحذَفُ ليُجَلَّبَ بدلَها؛ ولا نَمَسُّ مستودعًا محليًّا غيرَنا. */
  public static boolean heal(File ownDir, File file, Verdict verdict) {
    if (verdict == null || !verdict.broken()) return false;
    if (ownDir == null || file == null) return false;
    try {
      if (!file.getCanonicalPath().startsWith(ownDir.getCanonicalPath() + File.separator)) return false;
    } catch (IOException unknown) {
      return false;
    }
    boolean deleted = file.delete();
    if (deleted) forget(file);
    return deleted;
  }

  /** يُنسى محفوظُ ملفٍّ حذفَتْهُ الدورةُ أو استبدَلَتْهُ تنزيلٌ جديدٌ. */
  public static void forget(File file) {
    if (file == null) return;
    String path = file.getAbsolutePath();
    synchronized (MEMO) {
      java.util.Iterator<String> keys = MEMO.keySet().iterator();
      while (keys.hasNext()) if (keys.next().startsWith(path + "|")) keys.remove();
    }
  }

  /** الحالةُ كلُّها (للاختبارِ ولإعادةِ التجهيزِ). */
  public static void clearMemo() {
    synchronized (MEMO) {
      MEMO.clear();
    }
  }

  private static String extensionOf(String name) {
    if (name == null) return null;
    int dot = name.lastIndexOf('.');
    return dot < 0 || dot == name.length() - 1 ? null : name.substring(dot + 1);
  }
}
