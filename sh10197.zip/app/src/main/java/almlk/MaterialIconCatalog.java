package almlk;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * فهرس أيقونات Material Design (Templarian) من أرشيف المستودع: meta.json للأسماء والأسماء
 * البديلة والفئات، وsvg/&lt;name&gt;.svg لبيانات المسار (مسار واحد على شبكة 24×24). يقرأ المسارات
 * عند الطلب، ويولّد Vector XML وSVG.
 */
public final class MaterialIconCatalog implements Closeable {

  /** أرشيف المستودع الرسمي الخفيف (الأيقونات نفسها وmeta.json نفسه). */
  public static final String ARCHIVE_URL =
      "https://codeload.github.com/Templarian/MaterialDesign-SVG/zip/refs/heads/master";
  public static final String ALL = "";
  public static final String OTHER = "\u0000other";

  public static final class Icon {
    public final String name;
    public final List<String> aliases;
    public final List<String> tags;

    Icon(String name, List<String> aliases, List<String> tags) {
      this.name = name;
      this.aliases = aliases;
      this.tags = tags;
    }
  }

  /** موضع تطابق البحث: في الاسم (alias = -1) أو في اسم بديل بفهرسه. */
  public static final class Match {
    public final int alias, start, end;

    Match(int alias, int start, int end) {
      this.alias = alias;
      this.start = start;
      this.end = end;
    }
  }

  private static final Pattern PATH_DATA = Pattern.compile("<path[^>]*?\\sd=\"([^\"]*)\"");

  private final ZipFile zip;
  private final String prefix;
  private final List<Icon> icons;
  private final List<String> categories;

  private MaterialIconCatalog(ZipFile zip, String prefix, List<Icon> icons, List<String> categories) {
    this.zip = zip;
    this.prefix = prefix;
    this.icons = icons;
    this.categories = categories;
  }

  public static MaterialIconCatalog open(File archive) throws IOException {
    ZipFile zip = new ZipFile(archive);
    try {
      ZipEntry meta = null;
      Enumeration<? extends ZipEntry> entries = zip.entries();
      while (entries.hasMoreElements()) {
        ZipEntry e = entries.nextElement();
        String n = e.getName();
        if (n.endsWith("meta.json") && (n.equals("meta.json") || n.endsWith("/meta.json"))
            && n.indexOf('/') == n.lastIndexOf('/')) {
          meta = e;
          break;
        }
      }
      if (meta == null) throw new IOException("meta.json not found in icon archive");
      String prefix = meta.getName().substring(0, meta.getName().length() - "meta.json".length());
      Object root;
      try {
        root = JsonText.parse(new String(read(zip, meta), StandardCharsets.UTF_8));
      } catch (JsonText.SyntaxError e) {
        throw new IOException("Invalid meta.json: " + e.getMessage());
      }
      if (!(root instanceof List)) throw new IOException("Invalid meta.json");
      ArrayList<Icon> icons = new ArrayList<>();
      TreeSet<String> tags = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
      for (Object item : (List<?>) root) {
        if (!(item instanceof Map)) continue;
        Map<?, ?> m = (Map<?, ?>) item;
        Object name = m.get("name");
        if (!(name instanceof String)) continue;
        if (zip.getEntry(prefix + "svg/" + name + ".svg") == null) continue;
        Icon icon = new Icon((String) name, strings(m.get("aliases")), strings(m.get("tags")));
        tags.addAll(icon.tags);
        icons.add(icon);
      }
      ArrayList<String> categories = new ArrayList<>();
      categories.add(ALL);
      categories.addAll(tags);
      categories.add(OTHER);
      return new MaterialIconCatalog(zip, prefix, Collections.unmodifiableList(icons),
          Collections.unmodifiableList(categories));
    } catch (IOException | RuntimeException e) {
      zip.close();
      throw e;
    }
  }

  private static List<String> strings(Object value) {
    ArrayList<String> out = new ArrayList<>();
    if (value instanceof List) for (Object o : (List<?>) value) if (o instanceof String) out.add((String) o);
    return Collections.unmodifiableList(out);
  }

  private static byte[] read(ZipFile zip, ZipEntry entry) throws IOException {
    try (InputStream in = zip.getInputStream(entry)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.max(256, entry.getSize()));
      byte[] buffer = new byte[16384];
      for (int n; (n = in.read(buffer)) > 0; ) out.write(buffer, 0, n);
      return out.toByteArray();
    }
  }

  public List<Icon> icons() {
    return icons;
  }

  /** ALL أولًا، ثم الفئات أبجديًا، ثم OTHER (أيقونات بلا فئة). */
  public List<String> categories() {
    return categories;
  }

  /** أيقونات الفئة المطابقة للبحث (بالاسم ثم الأسماء البديلة، بلا حساسية لحالة الأحرف). */
  public List<Icon> filter(String category, String query) {
    ArrayList<Icon> out = new ArrayList<>();
    for (Icon icon : icons) {
      if (!inCategory(icon, category)) continue;
      if (query == null || query.trim().isEmpty() || match(icon, query) != null) out.add(icon);
    }
    return out;
  }

  public static boolean inCategory(Icon icon, String category) {
    if (category == null || ALL.equals(category)) return true;
    if (OTHER.equals(category)) return icon.tags.isEmpty();
    for (String t : icon.tags) if (t.equalsIgnoreCase(category)) return true;
    return false;
  }

  public static Match match(Icon icon, String query) {
    String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT).replace(' ', '-');
    if (q.isEmpty()) return null;
    int at = icon.name.toLowerCase(Locale.ROOT).indexOf(q);
    if (at >= 0) return new Match(-1, at, at + q.length());
    for (int i = 0; i < icon.aliases.size(); i++) {
      at = icon.aliases.get(i).toLowerCase(Locale.ROOT).indexOf(q);
      if (at >= 0) return new Match(i, at, at + q.length());
    }
    return null;
  }

  /** بيانات مسار الأيقونة (d) من ملف SVG داخل الأرشيف. */
  public String pathData(Icon icon) throws IOException {
    ZipEntry entry = zip.getEntry(prefix + "svg/" + icon.name + ".svg");
    if (entry == null) throw new IOException("Missing icon " + icon.name);
    return extractPathData(new String(read(zip, entry), StandardCharsets.UTF_8));
  }

  static String extractPathData(String svg) throws IOException {
    Matcher m = PATH_DATA.matcher(svg);
    StringBuilder d = new StringBuilder();
    while (m.find()) {
      if (d.length() > 0) d.append(' ');
      d.append(m.group(1));
    }
    if (d.length() == 0) throw new IOException("No path data");
    return d.toString();
  }

  /** «ab-testing» ← «ic_ab_testing» (اسم مورد صالح). */
  public static String resourceName(String iconName) {
    StringBuilder out = new StringBuilder("ic_");
    for (char c : iconName.toLowerCase(Locale.ROOT).toCharArray()) {
      out.append((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ? c : '_');
    }
    return out.toString();
  }

  public static String svg(String pathData) {
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\n"
        + "    <path d=\"" + CodeEscaper.escapeXml(pathData) + "\" />\n</svg>\n";
  }

  /** VectorDrawable بلون #AARRGGBB وأبعاد sizeDp. */
  public static String vectorXml(String pathData, int argb, int sizeDp) {
    return "<vector xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
        + "    android:width=\"" + sizeDp + "dp\"\n"
        + "    android:height=\"" + sizeDp + "dp\"\n"
        + "    android:viewportWidth=\"24\"\n"
        + "    android:viewportHeight=\"24\">\n"
        + "    <path\n"
        + "        android:fillColor=\"" + String.format("#%08X", argb) + "\"\n"
        + "        android:pathData=\"" + CodeEscaper.escapeXml(pathData) + "\" />\n"
        + "</vector>\n";
  }

  @Override
  public void close() throws IOException {
    zip.close();
  }
}
