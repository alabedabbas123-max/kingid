package almlk;

import java.util.Locale;

/**
 * اسمُ الحزمةِ الافتراضيُّ للمشروعِ الجديدِ — صافٍ ليُقاسَ في العدّةِ لا بالعينِ.
 *
 * <p>المرجعُ (`preferences_advanced_setting.xml` عندَهُ): «Package name prefix … If left blank, the
 * default will be used» بقيمةٍ افتراضيةٍ {@code com.mycompany.}؛ أيْ أنَّ الحزمةَ = البادئةُ +
 * مُعرِّفُ اسمِ المشروعِ. وسابقًا كانَ مشروعُنا يكتبُ {@code com.my.<name>} ثابتًا: صفُّ الإعداداتِ
 * لا يُقرأُ من أحدٍ. هذا الصنفُ هو الموضعُ الواحدُ للقاعدةِ، ويُسقِطُ البادئةَ الخبيثةَ إلى
 * {@code com.my.} بدلَ إنتاجِ حزمةٍ لا تُترجَمُ.
 */
public final class ProjectNaming {

  /** البادئةُ المستخدمةُ حينَ يغيبُ الإعدادُ أو يكونُ غيرَ صالحٍ. */
  public static final String FALLBACK_PREFIX = "com.my.";

  private ProjectNaming() {}

  /**
   * حزمةٌ صالحةٍ من بادئةٍ واسمِ مشروعٍ: {@code ("com.mycompany.", "My App")} →
   * {@code com.mycompany.myapp}. البادئةُ الفارغةُ أو غيرُ الصالحةِ ← {@value #FALLBACK_PREFIX}؛
   * ولا يُترَكُ جزءٌ يبدأُ برقمٍ أو خالٍ.
   */
  public static String packageFor(String prefix, String projectName) {
    String slug = slug(projectName);
    String head = normalizePrefix(prefix);
    return slug.isEmpty() ? trimDot(head) : head + slug;
  }

  /** جزءٌ واحدٌ صالحٌ من اسمِ حزمةٍ: حروفٌ صغيرةٌ وأرقامٌ وشرطاتٌ سفلى فقطْ، بلا رقمٍ أولٍ. */
  public static String slug(String raw) {
    if (raw == null) return "";
    StringBuilder out = new StringBuilder();
    boolean lastUnderscore = true; // يمنعُ _ أوليًّا ومُتكرّرًا
    for (char c : raw.trim().toLowerCase(Locale.US).toCharArray()) {
      if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
        out.append(c);
        lastUnderscore = false;
      } else if (!lastUnderscore) {
        out.append('_');
        lastUnderscore = true;
      }
    }
    while (out.length() > 0 && out.charAt(out.length() - 1) == '_') out.setLength(out.length() - 1);
    while (out.length() > 0 && Character.isDigit(out.charAt(0))) out.deleteCharAt(0);
    return out.toString();
  }

  /** بادئةٌ مضمونةُ الصلاحيةِ تنتهي بنقطةٍ واحدةٍ؛ ما لا يصلحُ جزءَ حزمةٍ يسقطُ إلى الافتراضيِّ. */
  public static String normalizePrefix(String prefix) {
    String value = prefix == null ? "" : prefix.trim();
    if (value.isEmpty()) return FALLBACK_PREFIX;
    if (!value.endsWith(".")) value = value + ".";
    if (!isPackage(value.substring(0, value.length() - 1))) return FALLBACK_PREFIX;
    return value;
  }

  /** حزمةٌ صالحةٌ: أجزاءٌ مفصولةٌ بنقاطٍ، كلُّ جزءٍ معرِّفٌ جافا لا يبدأُ برقمٍ. */
  public static boolean isPackage(String value) {
    if (value == null || value.isEmpty()) return false;
    int start = 0;
    for (int i = 0; i <= value.length(); i++) {
      if (i != value.length() && value.charAt(i) != '.') continue;
      String part = value.substring(start, i);
      if (!isIdentifier(part)) return false;
      start = i + 1;
    }
    return true;
  }

  /**
   * حزمةُ تطبيقٍ تصلُحُ للمانيفستِ ولسمةِ namespace: جزآنِ فأكثرُ، كلُّ جزءٍ معرِّفٌ **صغيرٌ**، ولا
   * كبيرةٌ ولا مفردةٌ — لأنَّ `isPackage` وحدها تُجيزُ {@code Single} و{@code com}، وهما يُنتجانِ
   * مانيفستًا لا يبني: اسمُ نشاطٍ نسبيٌّ (.MainActivity) بلا حزمةٍ كاملةٍ. المعالجُ يستعملُ نفسَ
   * القاعدةِ في تحقُّقِ الحقلِ، فلا لسانَينِ للصلاحيةِ في التطبيقِ.
   */
  public static boolean isApplicationPackage(String value) {
    if (value == null) return false;
    String v = value.trim();
    if (v.indexOf('.') < 0) return false;
    if (!isPackage(v)) return false;
    for (int i = 0; i < v.length(); i++) if (Character.isUpperCase(v.charAt(i))) return false;
    return true;
  }

  private static boolean isIdentifier(String part) {
    if (part.isEmpty()) return false;
    if (!Character.isJavaIdentifierStart(part.charAt(0))) return false;
    for (int i = 1; i < part.length(); i++) if (!Character.isJavaIdentifierPart(part.charAt(i))) return false;
    return !part.equals("class") && !part.equals("package") && !part.equals("int") && !part.equals("new");
  }

  /**
   * اسمُ مجلدِ الاستنساخِ من رابطِ مستودعٍ: {@code https://host/team/repo.git} → {@code repo}.
   * يقطَعُ الاستعلامَ والبصرَةَ والوسمَ، ويسقطُ ما ليس حرفًا/رقمًا/{@code ._-}، ويرجعُ «clone»
   * إن لم يبقَ شيءٌ — لأنَّ مجلدًا باسمٍ فارغٍ يعني كتابةً في والدِهِ، وهو أخطرُ من اسمٍ قبيحٍ.
   */
  public static String repoName(String url) {
    String value = url == null ? "" : url.trim();
    int stop = value.length();
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      if (c == '?' || c == '#' || c == '&') {
        stop = i;
        break;
      }
    }
    value = trimGit(value.substring(0, stop));
    int scheme = value.indexOf("://");
    if (scheme >= 0) {
      int pathStart = value.indexOf('/', scheme + 3);
      if (pathStart < 0) return "clone"; // مضيفٌ بلا مسارٍ: لا مستودعَ مسمًّى، فلا اسمَ يُختَرَعُ
      value = trimGit(value.substring(pathStart + 1));
    } else {
      int colon = value.lastIndexOf(':');
      if (colon >= 0) value = trimGit(value.substring(colon + 1));
    }
    int slash = value.lastIndexOf('/');
    String name = slash >= 0 ? value.substring(slash + 1) : value;
    StringBuilder out = new StringBuilder(name.length());
    for (int i = 0; i < name.length(); i++) {
      char c = name.charAt(i);
      boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
          || c == '.' || c == '_' || c == '-';
      out.append(ok ? c : '_');
    }
    String trimmed = out.toString();
    while (trimmed.startsWith(".") || trimmed.startsWith("_")) trimmed = trimmed.substring(1);
    return trimmed.isEmpty() || trimmed.equals(".") || trimmed.equals("..") ? "clone" : trimmed;
  }

  /** تجريدُ الشرطةِ الأخيرةِ ولواحقِ {@code .git} معًا (قد تتكررُ: «repo.git/»). */
  private static String trimGit(String value) {
    String out = value;
    boolean changed = true;
    while (changed) {
      changed = false;
      while (out.endsWith("/")) {
        out = out.substring(0, out.length() - 1);
        changed = true;
      }
      if (out.endsWith(".git")) {
        out = out.substring(0, out.length() - 4);
        changed = true;
      }
    }
    return out;
  }

  private static String trimDot(String head) {
    return head.endsWith(".") ? head.substring(0, head.length() - 1) : head;
  }
}
