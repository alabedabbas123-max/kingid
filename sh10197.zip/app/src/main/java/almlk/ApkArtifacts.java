package almlk;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * ما ترَكَ البناءُ على القرصِ: مُخرَجٌ لكلِّ نمطٍ، بحجمِهِ وزمنِهِ ومرحلتِهِ وموقِّعِهِ.
 *
 * <p><b>المنهجُ منقولٌ عن المرجعِ لا الشيفرةُ.</b> {@code GradleProject} في المرجعِ لا يَمشي على
 * الشجرةِ ولا يَسألُ نظامَ بناءٍ شيئًا: يبني أربعةَ مساراتٍ عُرفيَّةٍ ({@code build/outputs/apk}
 * ثمَّ {@code debug} و{@code release} تحتَهُ)، ويَقرَأُ {@code output.json} الذي يَكتُبُهُ غِرلافُ
 * أندرويدَ نفسُهُ، ويأخذُ <b>أولَ</b> سجلٍّ منهُ، ثمَّ يَخرُجُ بملفٍّ واحدٍ. و{@code ResourceApkBuilder}
 * هنالِكَ يُسَمِّي مُخرَجَهُ بسلاسلَ صارمةٍ ({@code _unsigned.apk}، {@code _aligned_unsigned.apk}،
 * {@code _7zip_aligned_signed.apk}…) — فمرحلةُ المُخرَجِ عندَهُ <b>في الاسمِ</b> لا في فحصِ الحزمةِ.
 * {@code AppUtils.getApkInfo(File)} يَحرِسُ بثلاثَةٍ ({@code != null}، {@code isFile()}، {@code exists()})
 * ثمَّ يَقرَأُ ما في الحزمةِ من اسمٍ وإصدارٍ وموقِّعٍ. هذا كلُّهُ منقولٌ هنا؛ وأمَّا {@code Gson}
 * و{@code FileIOUtils} و{@code StringUtils} و{@code AlertDialog} فبدائلُها صفيَّةٌ صغيرةٌ عندَنا.
 *
 * <p><b>ما لا يَفْعَلُهُ هذا الصنفُ قطُّ:</b> لا {@code aapt} ولا {@code zipalign} ولا {@code jarsigner}
 * ولا {@code gradle} (لا {@code ProcessBuilder} في هذهِ الطبقةِ)، ولا كتابةَ على القرصِ ولا حذفَ ولا
 * إعادةَ تسميةٍ، ولا {@code android.} (فلا {@code getPackageArchiveInfo} مباشرًا)، ولا {@code java.net}،
 * ولا مشيَ أعمقَ من مجلَّدِ نمطٍ واحدٍ. قراءةُ الموقِّعِ تُحقَنُ من الغلافِ الأندرويديِّ عبرَ
 * {@link SignerReader} — كما يُحقَنُ {@code MavenResolver.Fetcher} للشبكةِ — فتبقى الآليّةُ صفيّةً
 * مَقيسةً في {@code qa.sh}، والمنادِي الأندرويديُّ سطرًا واحدًا عندَ صاحبِ الحزمةِ.
 *
 * <p><b>العجزُ علامةٌ لا استثناءٌ:</b> مُخرَجٌ لا يَعرِفُهُ القرصُ، أو ملفٌّ فارغٌ، أو
 * {@code output.json} لا يُدَقُّ، أو موقِّعٌ لا يُقرَأُ — كلُّهُ سطرٌ في {@link Result#problems()}،
 * ولا واحدَ منهُ {@code isError()} في اللوحةِ، لأنَّ مشروعًا لم يَبْنِهِ صاحبُهُ بعدُ ليس مشروعًا
 * مكسورًا.
 *
 * <p><b>خِفَّةٌ وسقوفٌ.</b> {@value #MAX_JSON_BYTES} بايتًا حدُّ {@code output.json}،
 * و{@value #MAX_VARIANTS} مُخرَجًا يُعرَضُ لكلِّ وحدةٍ (الزِّيادةُ مَعدودةٌ لا مَكتومةٌ)،
 * و{@value #MAX_ISSUES} علاماتٍ، و{@value #MAX_CACHE} بطاقةً محفوظةً ببصمةِ القرصِ.
 */
public final class ApkArtifacts {

  /** حدُّ ما يُقرَأُ من {@code output.json} بايتًا؛ فوقَهُ لا تدقيقَ ولا ادِّعاءَ. */
  public static final long MAX_JSON_BYTES = 256L * 1024;
  /** كم مُخرَجًا يُعرَضُ للوحدةِ الواحدةِ (النمطانِ، وما تحتَ {@code bin/} من قديمٍ). */
  public static final int MAX_VARIANTS = 8;
  /** كم ملفًّا يُمسَحُ في مجلَّدٍ واحدٍ قبلَ الوقوفِ (لا ترتيبَ كاملَ لآلافِ المُخرَجاتِ). */
  public static final int MAX_SCAN = 16;
  /** كم علامةٍ تَخرُجُ للوحدةِ الواحدةِ، فلا تُغرَقُ اللوحةُ. */
  public static final int MAX_ISSUES = 4;
  /** كم بطاقةٍ محفوظةٍ في {@link #inspectCached(File)}. */
  public static final int MAX_CACHE = 8;
  /** عُمقُ الكتلِ في {@code output.json}؛ وما بعدَهُ يُقطَعُ لا يُخمَّنُ. */
  public static final int MAX_DEPTH = 12;
  /** كم عُقدةً يَبني المُدقِّقُ؛ فوقَهُ يَتوقَّفُ ويُبَلِّغُ. */
  public static final int MAX_NODES = 8192;

  /** قراءةُ ما في الحزمةِ من اسمٍ وإصدارٍ وموقِّعٍ — يُمِدُّ بها الغلافُ الأندرويديُّ. */
  public interface SignerReader {
    /** سطرٌ واحدٌ (اسمُ الحزمةِ + الإصدارُ + بصمةُ الموقِّعِ)، أو {@code null} عندَ العجزِ. */
    String describe(File apk);
  }

  private static final Map<String, Result> CACHE =
      new LinkedHashMap<String, Result>(8, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Result> eldest) {
          return size() > MAX_CACHE;
        }
      };

  private ApkArtifacts() {
  }

  /** مُخرَجٌ واحدٌ لنمطٍ واحدٍ، كما قالَتهُ {@code output.json} أو كما وجدَهُ القرصُ. */
  public static final class Artifact {
    /** {@code debug} أو {@code release} (من {@code filters}، أو من الاسمِ، أو من المجلَّدِ). */
    public final String variant;
    /** اسمُ الملفِّ كما على القرصِ (أو كما سُمِّيَ في {@code output.json}). */
    public final String fileName;
    /** ما قالَتهُ الوثيقةُ من مسارٍ؛ {@code ""} حيثُ لا وثيقةَ (مشيُ {@code bin/} القديمُ). */
    public final String declaredPath;
    /** هل الملفُّ موجودٌ على القرصِ فعلًا؟ {@code output.json} قد يَكذِبُ بعدَ {@code clean}. */
    public final boolean onDisk;
    /** عددُ البايتاتِ، أو {@code -1} حيثُ لا ملفَّ. */
    public final long bytes;
    /** زمنُ التماسِ بصيغةِ {@code yyyy-MM-dd HH:mm}، أو {@code ""}. */
    public final String stamp;
    /** {@code unsigned} / {@code aligned} / {@code signed} / {@code aligned+signed} / {@code unknown}. */
    public final String stage;
    /** {@code versionName} من الوثيقةِ، أو {@code ""}. */
    public final String versionName;
    /** {@code versionCode} من الوثيقةِ، أو {@code -1}. */
    public final int versionCode;
    /** {@code minSdkVersion}/{@code targetSdkVersion} كما كُتِبا، أو {@code ""}. */
    public final String minSdk;
    public final String targetSdk;
    /** {@code outputType.type} (عادةً {@code APK})، أو {@code ""}. */
    public final String outputType;
    /** ما قالَهُ مُقرِئُ الحزمةِ؛ {@code null} قبلَ أن يُحِقَّ الغلافُ قارئًا. */
    public String signer;
    /** أينَ وُجِدَ الملفُّ فعلًا؛ {@code null} حيثُ لا شيءَ على القرصِ. */
    final File locatedAt;

    Artifact(String variant, String fileName, String declaredPath, boolean onDisk, long bytes,
        String stamp, String stage, String versionName, int versionCode, String minSdk,
        String targetSdk, String outputType, File locatedAt) {
      this.variant = variant;
      this.locatedAt = locatedAt;
      this.fileName = fileName;
      this.declaredPath = declaredPath;
      this.onDisk = onDisk;
      this.bytes = bytes;
      this.stamp = stamp;
      this.stage = stage;
      this.versionName = versionName;
      this.versionCode = versionCode;
      this.minSdk = minSdk;
      this.targetSdk = targetSdk;
      this.outputType = outputType;
      this.signer = null;
    }

    /** سطرٌ واحدٌ للوحةِ: لا مسارًا مُطلَقًا، ولا ادِّعاءَ بما لم يُقرَأْ. */
    public String describe() {
      StringBuilder out = new StringBuilder();
      out.append(variant).append('/').append(fileName);
      out.append(onDisk ? " (" + bytes + " B" : " (missing");
      if (onDisk && !stamp.isEmpty()) out.append(", ").append(stamp);
      if (!stage.isEmpty()) out.append(", ").append(stage);
      if (!versionName.isEmpty()) out.append(", v").append(versionName);
      if (versionCode >= 0) out.append('#').append(versionCode);
      if (signer != null && !signer.isEmpty()) out.append(", ").append(signer);
      out.append(')');
      return out.toString();
    }
  }

  /** ما جُمِعَ لوحدةٍ واحدةٍ. */
  public static final class Result {
    public final File moduleDir;
    /** هل وُجِدَت {@code output.json} عندَ نمطٍ من الأنماطِ؟ */
    public final boolean jsonSeen;
    /** المُخرَجاتُ المعروضةُ (حتى {@value #MAX_VARIANTS}). */
    public final List<Artifact> artifacts;
    /** كم سجلًّا في الوثائقِ كلِّها (بما جاوَزَ المعروضَ). */
    public final int counted;
    /** هل جَاوَزَ العددُ {@value #MAX_VARIANTS}؟ */
    public final boolean overflow;
    /** هل بَلَغَ حجمُ الوثيقةِ الحدَّ فلم تُدَقَّ؟ */
    public final boolean jsonTooLarge;
    /** هل عُرضَ قارئُ الموقِّعِ (فإن لم يُعْرَضْ سَكَتَتِ الطبقةُ عنهُ لا شَكَتْ)? */
    public final boolean readerOffered;
    public final List<String> failures;
    /** بصمةُ القرصِ عندَ القراءةِ (فارغةٌ حيثُ لا حِفْظَ). */
    public final String stamp;

    Result(File moduleDir, boolean jsonSeen, List<Artifact> artifacts, int counted, boolean overflow,
        boolean jsonTooLarge, boolean readerOffered, List<String> failures, String stamp) {
      this.moduleDir = moduleDir;
      this.jsonSeen = jsonSeen;
      this.artifacts = artifacts;
      this.counted = counted;
      this.overflow = overflow;
      this.jsonTooLarge = jsonTooLarge;
      this.readerOffered = readerOffered;
      this.failures = failures;
      this.stamp = stamp;
    }

    /** هل المُخرَجاتُ التي جُمِعَت صفرًا؟ (لا علاقةَ لهُ بالعلاماتِ). */
    public boolean isEmpty() {
      return artifacts.isEmpty();
    }

    /** هل على القرصِ مُخرَجُ ‏{@code release} كاملٌ؟ */
    public boolean hasReleaseApk() {
      return find("release", true) != null;
    }

    /** هل ذَكَرَتِ الوثائقُ نمطَ ‏{@code release} أصلًا (مَوْجودًا كانَ أم لا)؟ */
    public boolean hasReleaseRecord() {
      return find("release", false) != null;
    }

    private Artifact find(String variant, boolean onDiskOnly) {
      for (Artifact a : artifacts) {
        if (a == null || !variant.equals(a.variant)) continue;
        if (!onDiskOnly || a.onDisk) return a;
      }
      return null;
    }

    /** المُجلَّدانِ اللذانِ نُقِيسُ عليهِما — للسطرِ الذي يَعِدُ صاحِبَهُ بمَعرِفَةِ أينَ نَظرْنا. */
    public static String describeDirs() {
      return "build/outputs/apk/debug, build/outputs/apk/release, bin/debug, bin/release";
    }

    /** ما يَنبَغي أن يَرَاهُ صاحبُ المشروعِ في اللوحةِ؛ علامةٌ لا خطأُ بناءٍ. */
    public List<String> problems() {
      List<String> out = new ArrayList<>();
      if (moduleDir == null) return out;
      if (jsonTooLarge) {
        out.add("output.json is over " + (MAX_JSON_BYTES / 1024) + " KiB — not parsed");
      }
      if (!failures.isEmpty()) {
        out.add("output.json could not be read: " + failures.get(0));
      }
      for (Artifact a : artifacts) {
        if (out.size() >= MAX_ISSUES) break;
        if (a == null) continue;
        if (!a.onDisk && !a.declaredPath.isEmpty()) {
          out.add("output.json of " + a.variant + " names " + a.declaredPath
              + ", which is not on disk (the build was cleaned?)");
        } else if (a.onDisk && a.bytes == 0L) {
          out.add(a.variant + " output " + a.fileName + " is empty (0 B) — the build never finished");
        } else if (a.onDisk && readerOffered && (a.signer == null || a.signer.isEmpty())) {
          out.add(a.variant + " output " + a.fileName + " has no signer applied to it");
        }
      }
      if (overflow && out.size() < MAX_ISSUES) {
        out.add("outputs list " + counted + " records; only the first " + MAX_VARIANTS
            + " are read");
      }
      return out;
    }

    /** بطاقةُ اللوحةِ: عددٌ وأسماءٌ وأحجامٌ، بلا مسارٍ مُطلَقٍ. */
    public String describe() {
      StringBuilder out = new StringBuilder();
      out.append("outputs of ").append(moduleDir == null ? "«none»" : moduleDir.getName());
      if (isEmpty()) return out.append(": nothing on disk yet").toString();
      out.append(" [").append(counted).append(jsonSeen ? " record(s), output.json read]"
          : " file(s), no output.json]");
      String sep = ": ";
      for (Artifact a : artifacts) {
        if (a == null) continue;
        out.append(sep).append(a.describe());
        sep = "; ";
      }
      return out.toString();
    }
  }

  /** الأنماطُ المُعَرَّفةُ عُرفًا عندَ غِرلافِ أندرويدَ، بالترتيبِ الذي يَعرضُها المرجعُ. */
  public static List<String> variantDirs() {
    List<String> out = new ArrayList<>();
    out.add("debug");
    out.add("release");
    return out;
  }

  /** قراءةُ وحدةٍ بلا مُقرِئِ حزمةٍ: لا شيءَ يُقالُ عن الموقِّعِ. */
  public static Result of(File moduleDir) {
    return of(moduleDir, null);
  }

  /**
   * ما على القرصِ من مُخرَجاتِ {@code moduleDir}: وثائقُ {@code build/outputs/apk/<نمطٍ>/output.json}
   * أوَّلًا (كالمرجعِ تمامًا)، ثمَّ ما في {@code bin/<نمطٍ>} من {@code *.apk} للمسارِ القديمِ.
   */
  public static Result of(File moduleDir, SignerReader reader) {
    if (moduleDir == null) return new Result(null, false, new ArrayList<Artifact>(), 0, false,
        false, reader != null, new ArrayList<String>(), "");
    List<Artifact> artifacts = new ArrayList<>();
    List<String> failures = new ArrayList<>();
    boolean jsonSeen = false;
    boolean tooLarge = false;
    int counted = 0;
    for (String variant : variantDirs()) {
      File dir = new File(new File(moduleDir, "build/outputs/apk"), variant);
      File json = new File(dir, "output.json");
      if (!json.isFile()) continue;
      jsonSeen = true;
      String text = read(json, failures);
      if (text == null) {
        tooLarge = true;
        continue;
      }
      List<Object> records = records(text, failures);
      counted += records.size();
      for (Object record : records) {
        Artifact a = read(dir, variant, record, failures);
        if (artifacts.size() < MAX_VARIANTS) artifacts.add(a);
      }
    }
    for (String variant : variantDirs()) {
      File dir = new File(moduleDir, "bin/" + variant);
      if (!dir.isDirectory()) continue;
      for (File apk : newestApks(dir)) {
        counted++;
        Artifact a = new Artifact(variant, apk.getName(), "", apk.isFile(), apk.length(),
            when(apk), stageOf(apk.getName()), "", -1, "", "", "APK", apk);
        if (artifacts.size() < MAX_VARIANTS) artifacts.add(a);
      }
    }
    if (reader != null) {
      for (Artifact a : artifacts) {
        if (a == null || a.locatedAt == null) continue;
        try {
          a.signer = reader.describe(a.locatedAt);
        } catch (Exception failure) {
          a.signer = null; // قارئٌ يَرمي لا يُبطِلُ الخبرَ كلَّهُ
        }
      }
    }
    return new Result(moduleDir, jsonSeen, artifacts, counted, counted > MAX_VARIANTS, tooLarge,
        reader != null, failures, "");
  }

  /**
   * يحكُمُ على القرصِ مرةً واحدةً لكلِّ وحدةٍ (اللوحةُ تُعادُ ملؤها كثيرًا): مفتاحُ الحفظِ مسارُ
   * الوحدةِ نفسِها، والبصمةُ ما في مجلدَيِ النمطينِ — فوحدةٌ واحدةٌ بطاقةٌ واحدةٌ، ولا أرشيفَ
   * لتواريخِ القراءةِ. أمَّا {@link #of(File, SignerReader)} فلا يَمُرُّ بالحفظِ: قراءةُ موقِّعٍ
   * بمُنادٍ مُعيَّنٍ لا تُمَثِّلُ قراءةً بدونِهِ.
   */
  public static Result inspectCached(File moduleDir) {
    if (moduleDir == null) return of((File) null);
    String key = moduleDir.getAbsolutePath();
    String stamp = fingerprint(moduleDir);
    Result cached = lookup(key);
    if (cached != null && stamp.equals(cached.stamp)) return cached;
    Result fresh = of(moduleDir);
    Result held = new Result(fresh.moduleDir, fresh.jsonSeen, fresh.artifacts, fresh.counted,
        fresh.overflow, fresh.jsonTooLarge, fresh.readerOffered, fresh.failures, stamp);
    remember(key, held);
    return held;
  }

  /** بصمةُ القرصِ: المسارُ + ما في مجلدَيِ النمطينِ من عددٍ وأحدثِ تماسٍ. */
  public static String fingerprint(File moduleDir) {
    if (moduleDir == null) return "";
    StringBuilder out = new StringBuilder(moduleDir.getAbsolutePath());
    for (String variant : variantDirs()) {
      File json = new File(new File(new File(moduleDir, "build/outputs/apk"), variant), "output.json");
      out.append('|').append(json.isFile() ? json.length() : -1L)
          .append(':').append(json.isFile() ? json.lastModified() : 0L);
      File legacy = new File(moduleDir, "bin/" + variant);
      File[] apks = legacy.isDirectory() ? legacy.listFiles() : null;
      out.append('|').append(apks == null ? -1 : apks.length);
    }
    return out.toString();
  }

  /** تَفريغُ الحفظِ (عندَ إعادةِ الربطِ، وفي الاختباراتِ). */
  public static void clearCache() {
    synchronized (CACHE) {
      CACHE.clear();
    }
  }

  /** كم بطاقةً في الحفظِ الآنَ. */
  public static int cacheSize() {
    synchronized (CACHE) {
      return CACHE.size();
    }
  }

  /**
   * مرحلةُ المُخرَجِ من الاسمِ وحدَهُ، على وَفقِ سلاسلِ {@code insureFileNameV2} في المرجعِ:
   * {@code _unsigned}، {@code _7zip_unsigned}، {@code _aligned_unsigned}، {@code _7zip_aligned_unsigned}،
   * {@code _aligned_signed}، {@code _7zip_aligned_signed}. واسمُ غِرلافِ أندرويدَ العاديُّ
   * ({@code app-release.apk}) لا يَقولُ شيئًا ⇒ {@code unknown}.
   */
  public static String stageOf(String fileName) {
    String n = fileName == null ? "" : fileName.toLowerCase(Locale.US);
    boolean unsigned = n.contains("unsigned");
    boolean aligned = n.contains("aligned");
    boolean signed = n.contains("signed") && !unsigned;
    if (signed && aligned) return "aligned+signed";
    if (signed) return "signed";
    if (unsigned && aligned) return "aligned";
    if (unsigned) return "unsigned";
    if (n.contains("aligned")) return "aligned";
    return "unknown";
  }

  // ───────────────────────────────────── ما تحتَ السطرِ ─────────────────────────────────────

  private static Result lookup(String stamp) {
    if (stamp == null || stamp.isEmpty()) return null;
    synchronized (CACHE) {
      return CACHE.get(stamp);
    }
  }

  private static void remember(String stamp, Result result) {
    if (stamp == null || stamp.isEmpty()) return;
    synchronized (CACHE) {
      CACHE.put(stamp, result);
      while (CACHE.size() > MAX_CACHE) {
        Iterator<String> oldest = CACHE.keySet().iterator();
        if (!oldest.hasNext()) return;
        oldest.next();
        oldest.remove();
      }
    }
  }

  /** نصُّ الوثيقةِ، أو {@code null} إن جَاوَزَتِ الحدَّ؛ والعجزُ في {@code failures}. */
  private static String read(File json, List<String> failures) {
    if (json.length() > MAX_JSON_BYTES) return null;
    StringBuilder out = new StringBuilder(4096);
    java.io.Reader in = null;
    try {
      in = new java.io.InputStreamReader(new java.io.FileInputStream(json), "UTF-8");
      char[] buf = new char[4096];
      long got = 0L;
      int n;
      while ((n = in.read(buf)) >= 0) {
        got += n;
        if (got > MAX_JSON_BYTES) return null;
        out.append(buf, 0, n);
      }
    } catch (Exception failure) {
      if (failures.size() < MAX_ISSUES) failures.add("unreadable: " + note(failure));
      return null;
    } finally {
      if (in != null) {
        try {
          in.close();
        } catch (Exception ignored) {
          // إغلاقُ تيارِ قراءةٍ لا يَنقُصُ من الخبرِ شيئًا
        }
      }
    }
    return out.toString();
  }

  /** سجلاتُ الوثيقةِ: قائمةُ كُتلٍ؛ وما خلا ذلكَ ففارغةٌ مع سطرِ عجزٍ. */
  private static List<Object> records(String text, List<String> failures) {
    List<Object> out = new ArrayList<>();
    if (text == null || text.trim().isEmpty()) {
      if (failures.size() < MAX_ISSUES) failures.add("empty document");
      return out;
    }
    int[] at = new int[] {0};
    int[] nodes = new int[] {0};
    Object parsed = value(text, at, nodes, 0);
    skipSpace(text, at);
    if (parsed == null) {
      if (failures.size() < MAX_ISSUES) {
        failures.add("not readable as JSON at offset " + Math.min(at[0], text.length()));
      }
      return out;
    }
    if (parsed instanceof List) {
      out.addAll((List<?>) parsed);
    } else if (parsed instanceof Map) {
      out.add(parsed);
    } else if (failures.size() < MAX_ISSUES) {
      failures.add("expected a list of records");
    }
    return out;
  }

  private static Artifact read(File dir, String variant, Object record, List<String> failures) {
    if (!(record instanceof Map)) {
      return new Artifact(variant, "«record unreadable»", "", false, -1L, "", "unknown", "", -1, "",
          "", "", null);
    }
    Map<?, ?> map = (Map<?, ?>) record;
    String declared = textAt(pick(map, "path"));
    if (declared.isEmpty()) declared = textAt(pick(map, "outputFile"));
    Object apkData = pick(map, "apkData");
    String name = declared.indexOf('/') >= 0 ? declared.substring(declared.lastIndexOf('/') + 1)
        : declared;
    String versionName = textAt(pick(apkData, "versionName"));
    if (versionName.isEmpty()) versionName = textAt(pick(map, "versionName"));
    int versionCode = numberAt(pick(apkData, "versionCode"));
    if (versionCode < 0) versionCode = numberAt(pick(map, "versionCode"));
    String minSdk = textAt(pick(apkData, "minSdkVersion"));
    String targetSdk = textAt(pick(apkData, "targetSdkVersion"));
    String outputType = textAt(pick(pick(map, "outputType"), "type"));
    String declaredVariant = variantFrom(pick(apkData, "filters"));
    String variantName = declaredVariant.isEmpty() ? variant : declaredVariant;
    String fileName = name.isEmpty() ? "«no name»" : name;
    boolean onDisk = false;
    long bytes = -1L;
    String when = "";
    File located = null;
    if (!name.isEmpty()) {
      File found = new File(dir, declared);
      if (found.isFile()) {
        onDisk = true;
        bytes = found.length();
        when = when(found);
        located = found;
      }
    }
    return new Artifact(variantName, fileName, declared, onDisk, bytes, when, stageOf(fileName),
        versionName, versionCode, minSdk, targetSdk, outputType, located);
  }

  /** {@code filters:[{filterType:'BuildType',name:'debug'}]} ⇒ اسمُ النمطِ. */
  private static String variantFrom(Object filters) {
    if (!(filters instanceof List)) return "";
    for (Object item : (List<?>) filters) {
      String n = textAt(pick(item, "name"));
      if ("debug".equals(n) || "release".equals(n)) return n;
    }
    return "";
  }

  /** أحدثُ {@code *.apk} في مجلَّدٍ واحدٍ، بلا نُزولٍ أعمقَ ولا ترتيبٍ كاملٍ. */
  private static List<File> newestApks(File dir) {
    List<File> out = new ArrayList<>();
    File[] all = dir.listFiles();
    if (all == null) return out;
    int scanned = 0;
    for (File f : all) {
      if (f == null || !f.isFile()) continue;
      if (!f.getName().toLowerCase(Locale.US).endsWith(".apk")) continue;
      if (scanned++ >= MAX_SCAN) break;
      int at = out.size();
      while (at > 0 && out.get(at - 1).lastModified() < f.lastModified()) at--;
      if (out.size() < MAX_SCAN) out.add(at, f);
    }
    return out;
  }

  private static String when(File f) {
    try {
      return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(f.lastModified()));
    } catch (Exception failure) {
      return "";
    }
  }

  private static Object pick(Object holder, String key) {
    if (!(holder instanceof Map)) return null;
    return ((Map<?, ?>) holder).get(key);
  }

  /** نصُّ قيمةٍ رقمًا كانتْ أو نصًّا أو كتلةً فيها {@code value} (كما يَكتُبُها الغِرلافُ). */
  private static String textAt(Object v) {
    if (v == null) return "";
    if (v instanceof String) return (String) v;
    if (v instanceof Number) {
      double d = ((Number) v).doubleValue();
      if (d == Math.rint(d) && !Double.isInfinite(d)) return String.valueOf((long) d);
      return String.valueOf(v);
    }
    if (v instanceof Boolean) return v.toString();
    if (v instanceof Map) {
      Object inner = ((Map<?, ?>) v).get("value");
      return inner == null ? "" : textAt(inner);
    }
    return "";
  }

  private static int numberAt(Object v) {
    String s = textAt(v);
    if (s.isEmpty()) return -1;
    try {
      return Integer.parseInt(s.trim());
    } catch (NumberFormatException failure) {
      return -1;
    }
  }

  private static String note(Throwable t) {
    String m = t == null ? null : t.getMessage();
    if (m == null || m.isEmpty()) return t == null ? "«؟»" : t.getClass().getSimpleName();
    int cut = m.indexOf('\n');
    return cut > 0 ? m.substring(0, cut) : (m.length() > 120 ? m.substring(0, 120) : m);
  }

  // ─────────────────────────── مُدقِّقُ JSON صغيرٌ (بلا ‏`org.json`) ───────────────────────────

  private static void skipSpace(String s, int[] at) {
    while (at[0] < s.length() && Character.isWhitespace(s.charAt(at[0]))) at[0]++;
  }

  /** قيمةٌ واحدةٌ، أو {@code null} عندَ القطعِ أو تجاوزِ السقوفِ. */
  private static Object value(String s, int[] at, int[] nodes, int depth) {
    skipSpace(s, at);
    if (at[0] >= s.length() || depth > MAX_DEPTH || ++nodes[0] > MAX_NODES) return null;
    char c = s.charAt(at[0]);
    if (c == '{') return object(s, at, nodes, depth);
    if (c == '[') return array(s, at, nodes, depth);
    if (c == '"') return string(s, at);
    if (s.startsWith("true", at[0])) {
      at[0] += 4;
      return Boolean.TRUE;
    }
    if (s.startsWith("false", at[0])) {
      at[0] += 5;
      return Boolean.FALSE;
    }
    if (s.startsWith("null", at[0])) {
      at[0] += 4;
      return null;
    }
    return number(s, at);
  }

  private static Object object(String s, int[] at, int[] nodes, int depth) {
    LinkedHashMap<String, Object> out = new LinkedHashMap<>();
    at[0]++;
    skipSpace(s, at);
    if (at[0] < s.length() && s.charAt(at[0]) == '}') {
      at[0]++;
      return out;
    }
    while (at[0] < s.length()) {
      if (++nodes[0] > MAX_NODES) return null;
      skipSpace(s, at);
      if (s.charAt(at[0]) != '"') return null;
      String key = string(s, at);
      if (key == null) return null;
      skipSpace(s, at);
      if (at[0] >= s.length() || s.charAt(at[0]) != ':') return null;
      at[0]++;
      Object v = value(s, at, nodes, depth + 1);
      out.put(key, v);
      skipSpace(s, at);
      if (at[0] >= s.length()) return null;
      char c = s.charAt(at[0]);
      at[0]++;
      if (c == '}') return out;
      if (c != ',') return null;
    }
    return null;
  }

  private static Object array(String s, int[] at, int[] nodes, int depth) {
    ArrayList<Object> out = new ArrayList<>();
    at[0]++;
    skipSpace(s, at);
    if (at[0] < s.length() && s.charAt(at[0]) == ']') {
      at[0]++;
      return out;
    }
    while (at[0] < s.length()) {
      if (++nodes[0] > MAX_NODES) return null;
      Object v = value(s, at, nodes, depth + 1);
      out.add(v);
      skipSpace(s, at);
      if (at[0] >= s.length()) return null;
      char c = s.charAt(at[0]);
      at[0]++;
      if (c == ']') return out;
      if (c != ',') return null;
    }
    return null;
  }

  private static String string(String s, int[] at) {
    StringBuilder out = new StringBuilder();
    at[0]++;
    while (at[0] < s.length()) {
      char c = s.charAt(at[0]++);
      if (c == '"') return out.toString();
      if (c != '\\') {
        out.append(c);
        continue;
      }
      if (at[0] >= s.length()) return null;
      char e = s.charAt(at[0]++);
      switch (e) {
        case 'n': out.append('\n'); break;
        case 't': out.append('\t'); break;
        case 'r': out.append('\r'); break;
        case 'b': out.append('\b'); break;
        case 'f': out.append('\f'); break;
        case 'u':
          if (at[0] + 4 > s.length()) return null;
          try {
            out.append((char) Integer.parseInt(s.substring(at[0], at[0] + 4), 16));
          } catch (NumberFormatException failure) {
            return null;
          }
          at[0] += 4;
          break;
        default: out.append(e);
      }
    }
    return null;
  }

  private static Object number(String s, int[] at) {
    int start = at[0];
    while (at[0] < s.length() && "+-.eE0123456789".indexOf(s.charAt(at[0])) >= 0) at[0]++;
    String token = s.substring(start, at[0]);
    if (token.isEmpty()) return null;
    try {
      if (token.indexOf('.') < 0 && token.indexOf('e') < 0 && token.indexOf('E') < 0) {
        return Long.valueOf(Long.parseLong(token));
      }
      return Double.valueOf(token);
    } catch (NumberFormatException failure) {
      return null;
    }
  }
}
