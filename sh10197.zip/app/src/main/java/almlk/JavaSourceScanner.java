package almlk;

/** Small Java lexical helpers shared by source-only editor transformations. */
final class JavaSourceScanner {
  private JavaSourceScanner() {}

  /** Returns same-length source with comments and literal contents blanked out. */
  static String maskNonCode(String source) {
    if (source == null || source.isEmpty()) return source == null ? "" : source;
    char[] masked = source.toCharArray();
    int state = 0; // 0=code, 1=line comment, 2=block comment, 3=string, 4=char, 5=text block
    boolean escaped = false;
    for (int i = 0; i < masked.length; i++) {
      char ch = source.charAt(i);
      char next = i + 1 < source.length() ? source.charAt(i + 1) : 0;
      if (state == 0) {
        if (ch == '/' && next == '/') {
          masked[i] = masked[i + 1] = ' ';
          i++;
          state = 1;
        } else if (ch == '/' && next == '*') {
          masked[i] = masked[i + 1] = ' ';
          i++;
          state = 2;
        } else if (ch == '"' && i + 2 < source.length()
            && source.charAt(i + 1) == '"' && source.charAt(i + 2) == '"') {
          masked[i] = masked[i + 1] = masked[i + 2] = ' ';
          i += 2;
          state = 5;
        } else if (ch == '"') {
          masked[i] = ' ';
          state = 3;
          escaped = false;
        } else if (ch == '\'') {
          masked[i] = ' ';
          state = 4;
          escaped = false;
        }
      } else if (state == 1) {
        if (ch == '\n' || ch == '\r') {
          state = 0;
        } else {
          masked[i] = ' ';
        }
      } else if (state == 2) {
        if (ch == '*' && next == '/') {
          masked[i] = masked[i + 1] = ' ';
          i++;
          state = 0;
        } else if (ch != '\n' && ch != '\r') {
          masked[i] = ' ';
        }
      } else if (state == 3 || state == 4) {
        if (ch != '\n' && ch != '\r') masked[i] = ' ';
        if (escaped) {
          escaped = false;
        } else if (ch == '\\') {
          escaped = true;
        } else if ((state == 3 && ch == '"') || (state == 4 && ch == '\'')) {
          state = 0;
        }
      } else { // text block
        if (ch == '"' && i + 2 < source.length()
            && source.charAt(i + 1) == '"' && source.charAt(i + 2) == '"') {
          masked[i] = masked[i + 1] = masked[i + 2] = ' ';
          i += 2;
          state = 0;
        } else if (ch != '\n' && ch != '\r') {
          masked[i] = ' ';
        }
      }
    }
    return new String(masked);
  }

  static int matching(String source, int open, char opening, char closing) {
    if (source == null || open < 0 || open >= source.length() || source.charAt(open) != opening)
      return -1;
    int depth = 0;
    for (int i = open; i < source.length(); i++) {
      char value = source.charAt(i);
      if (value == opening) depth++;
      else if (value == closing && --depth == 0) return i;
    }
    return -1;
  }

  static boolean identifierStart(char value) {
    return Character.isJavaIdentifierStart(value);
  }

  static boolean identifierPart(char value) {
    return Character.isJavaIdentifierPart(value);
  }

  static int skipWhitespace(String value, int offset) {
    int i = Math.max(0, offset);
    while (i < value.length() && Character.isWhitespace(value.charAt(i))) i++;
    return i;
  }
}
