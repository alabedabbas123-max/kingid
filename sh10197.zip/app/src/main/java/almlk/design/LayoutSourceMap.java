package almlk.design;

import java.util.ArrayList;

/**
 * خريطة مصدر تخطيط XML للمصمم: عناصر بترتيب الوثيقة (نفس ترتيب بناء المعاينة)
 * مع إزاحات نصية دقيقة — فتعديل الخصائص والإضافة والحذف والإحاطة تُكتب في النص
 * الحقيقي نفسه الذي يعود للمحرر، لا في نموذج شكلي.
 */
public final class LayoutSourceMap {

  public static final class Element {
    public String tag;
    public int start; // موضع '<'
    public int startTagEnd; // بعد '>' لوسم البداية
    public int end; // بعد نهاية العنصر كاملًا ('/>' أو '</tag>')
    public boolean selfClosing;
    public int depth;
    public int parentIndex = -1;
    final ArrayList<int[]> attrSpans = new ArrayList<>(); // {nameStart,nameEnd,valueStart,valueEnd}
  }

  private final String text;
  private final ArrayList<Element> elements = new ArrayList<>();

  public LayoutSourceMap(String xml) {
    text = xml == null ? "" : xml;
    parse();
  }

  public int count() {
    return elements.size();
  }

  public Element element(int index) {
    return index >= 0 && index < elements.size() ? elements.get(index) : null;
  }

  private void parse() {
    ArrayList<Integer> openStack = new ArrayList<>();
    int i = 0;
    while (i < text.length()) {
      int lt = text.indexOf('<', i);
      if (lt < 0) break;
      if (text.startsWith("<!--", lt)) {
        int close = text.indexOf("-->", lt);
        i = close < 0 ? text.length() : close + 3;
        continue;
      }
      if (text.startsWith("<![CDATA[", lt)) {
        int close = text.indexOf("]]>", lt);
        i = close < 0 ? text.length() : close + 3;
        continue;
      }
      if (lt + 1 < text.length() && (text.charAt(lt + 1) == '?' || text.charAt(lt + 1) == '!')) {
        int close = skipTag(lt + 1);
        i = close;
        continue;
      }
      if (lt + 1 < text.length() && text.charAt(lt + 1) == '/') {
        int close = skipTag(lt + 1);
        if (!openStack.isEmpty()) {
          Element open = elements.get(openStack.remove(openStack.size() - 1));
          open.end = close;
        }
        i = close;
        continue;
      }
      // وسم بداية عنصر.
      Element element = new Element();
      element.start = lt;
      element.depth = openStack.size();
      element.parentIndex = openStack.isEmpty() ? -1 : openStack.get(openStack.size() - 1);
      int p = lt + 1;
      int nameStart = p;
      while (p < text.length() && !Character.isWhitespace(text.charAt(p))
          && text.charAt(p) != '>' && text.charAt(p) != '/') p++;
      element.tag = text.substring(nameStart, p);
      // السمات حتى نهاية الوسم مع تجاوز القيم المقتبسة.
      while (p < text.length()) {
        char c = text.charAt(p);
        if (c == '"' || c == '\'') {
          p = skipQuoted(p);
          continue;
        }
        if (c == '>') {
          p++;
          break;
        }
        if (c == '/' && p + 1 < text.length() && text.charAt(p + 1) == '>') {
          element.selfClosing = true;
          p += 2;
          break;
        }
        if (Character.isLetter(c) || c == '_') {
          int ns = p;
          while (p < text.length()
              && (Character.isLetterOrDigit(text.charAt(p))
                  || text.charAt(p) == ':' || text.charAt(p) == '_' || text.charAt(p) == '-'
                  || text.charAt(p) == '.')) p++;
          int ne = p;
          while (p < text.length() && Character.isWhitespace(text.charAt(p))) p++;
          if (p < text.length() && text.charAt(p) == '=') {
            p++;
            while (p < text.length() && Character.isWhitespace(text.charAt(p))) p++;
            if (p < text.length() && (text.charAt(p) == '"' || text.charAt(p) == '\'')) {
              int vs = p + 1;
              int after = skipQuoted(p);
              element.attrSpans.add(new int[] {ns, ne, vs, after - 1});
              p = after;
            }
          }
          continue;
        }
        p++;
      }
      element.startTagEnd = p;
      element.end = p; // يُمدد عند وسم الإغلاق.
      elements.add(element);
      if (!element.selfClosing) openStack.add(elements.size() - 1);
      i = p;
    }
    // وسوم لم تُغلق: مداها حتى نهاية النص.
    for (int open : openStack) elements.get(open).end = text.length();
  }

  private int skipQuoted(int quoteAt) {
    char quote = text.charAt(quoteAt);
    int p = quoteAt + 1;
    while (p < text.length() && text.charAt(p) != quote) p++;
    return Math.min(p + 1, text.length());
  }

  private int skipTag(int from) {
    int p = from;
    while (p < text.length()) {
      char c = text.charAt(p);
      if (c == '"' || c == '\'') {
        p = skipQuoted(p);
        continue;
      }
      if (c == '>') return p + 1;
      p++;
    }
    return text.length();
  }

  // ===== قراءة =====

  /** قيمة سمة (بالاسم المؤهل كاملًا مثل android:background) أو null. */
  public String attribute(int index, String qualifiedName) {
    Element e = element(index);
    if (e == null) return null;
    for (int[] span : e.attrSpans)
      if (qualifiedName.equals(text.substring(span[0], span[1])))
        return text.substring(span[2], span[3]);
    return null;
  }

  // ===== كتابة: كل عملية تعيد نص XML الجديد كاملًا =====

  public String setAttribute(int index, String qualifiedName, String value) {
    Element e = element(index);
    if (e == null) return text;
    for (int[] span : e.attrSpans)
      if (qualifiedName.equals(text.substring(span[0], span[1]))) {
        if (value == null || value.isEmpty()) {
          // حذف السمة بكاملها مع الفراغ السابق لها.
          int from = span[0];
          while (from > e.start + 1 && Character.isWhitespace(text.charAt(from - 1))) from--;
          return text.substring(0, from) + text.substring(span[3] + 1);
        }
        return text.substring(0, span[2]) + value + text.substring(span[3]);
      }
    if (value == null || value.isEmpty()) return text;
    // إدراج سمة جديدة قبل نهاية وسم البداية — بسطر جديد محاذى إن كان الوسم متعدد الأسطر.
    int closeAt = e.selfClosing ? e.startTagEnd - 2 : e.startTagEnd - 1;
    int insertAt = closeAt;
    while (insertAt > e.start && Character.isWhitespace(text.charAt(insertAt - 1))) insertAt--;
    String separator = " ";
    if (text.lastIndexOf('\n', closeAt) > e.start) {
      // وسم متعدد الأسطر: بادئة بمحاذاة آخر سمة.
      int lastLineStart = text.lastIndexOf('\n', insertAt - 1) + 1;
      int indentEnd = lastLineStart;
      while (indentEnd < text.length()
          && (text.charAt(indentEnd) == ' ' || text.charAt(indentEnd) == '\t')) indentEnd++;
      separator = "\n" + text.substring(lastLineStart, indentEnd);
    }
    return text.substring(0, insertAt)
        + separator + qualifiedName + "=\"" + value + "\""
        + text.substring(insertAt);
  }

  public String deleteElement(int index) {
    Element e = element(index);
    if (e == null) return text;
    int from = lineStartIfAlone(e.start);
    int to = e.end;
    if (from < e.start && to < text.length() && text.charAt(to) == '\n') to++;
    return text.substring(0, from) + text.substring(to);
  }

  public String insertBefore(int index, String snippet) {
    Element e = element(index);
    if (e == null) return text;
    String indent = indentOf(e.start);
    return text.substring(0, lineStartIfAlone(e.start))
        + indent + snippet.replace("\n", "\n" + indent) + "\n"
        + text.substring(lineStartIfAlone(e.start));
  }

  public String insertAfter(int index, String snippet) {
    Element e = element(index);
    if (e == null) return text;
    String indent = indentOf(e.start);
    return text.substring(0, e.end)
        + "\n" + indent + snippet.replace("\n", "\n" + indent)
        + text.substring(e.end);
  }

  /** إدراج داخل حاوية (قبل وسم إغلاقها، أو تحويل الذاتية الإغلاق إلى زوج). */
  public String insertInside(int index, String snippet) {
    Element e = element(index);
    if (e == null) return text;
    String childIndent = indentOf(e.start) + "    ";
    String block = childIndent + snippet.replace("\n", "\n" + childIndent);
    if (e.selfClosing) {
      String open = text.substring(e.start, e.startTagEnd - 2).trim() + ">";
      return text.substring(0, e.start)
          + open + "\n" + block + "\n" + indentOf(e.start) + "</" + e.tag + ">"
          + text.substring(e.end);
    }
    int closeStart = text.lastIndexOf("</", e.end);
    if (closeStart <= e.startTagEnd) closeStart = e.end;
    int lineStart = lineStartIfAlone(closeStart);
    return text.substring(0, lineStart) + block + "\n" + text.substring(lineStart);
  }

  /** إحاطة العنصر بحاوية: يزاح العنصر سطرًا ببادئة إضافية داخل وسمي الحاوية. */
  public String surround(int index, String openTag, String closeTag) {
    Element e = element(index);
    if (e == null) return text;
    String indent = indentOf(e.start);
    String body = text.substring(lineStartIfAlone(e.start), e.end);
    String indented = "    " + body.replace("\n", "\n    ");
    return text.substring(0, lineStartIfAlone(e.start))
        + indent + openTag + "\n"
        + indented + "\n"
        + indent + closeTag
        + text.substring(e.end);
  }

  private String indentOf(int offset) {
    int lineStart = text.lastIndexOf('\n', offset - 1) + 1;
    int p = lineStart;
    while (p < text.length() && (text.charAt(p) == ' ' || text.charAt(p) == '\t')) p++;
    return text.substring(lineStart, p);
  }

  private int lineStartIfAlone(int offset) {
    int lineStart = text.lastIndexOf('\n', offset - 1) + 1;
    for (int p = lineStart; p < offset; p++)
      if (text.charAt(p) != ' ' && text.charAt(p) != '\t') return offset;
    return lineStart;
  }
}
