package almlk.design;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

/**
 * محرك عرض تخطيطات XML للمصمم — بأسلوبنا بالكامل (محرك المرجع مشفر):
 * يبني شجرة Views حقيقية بمواقع وأبعاد مطابقة: قواعد RelativeLayout، الجاذبيات،
 * الأوزان، وحل موارد المشروع الفعلية (@dimen/@color/@string) عبر ResourceResolver.
 */
public final class XmlLayoutRenderer {

  public static final class Node {
    public final String name;
    public final int depth;
    public final View view;

    Node(String name, int depth, View view) {
      this.name = name;
      this.depth = depth;
      this.view = view;
    }
  }

  public static final class Result {
    public View root;
    public final ArrayList<Node> nodes = new ArrayList<>();
    public String error;
  }

  private final Context context;
  private final ResourceResolver resolver;
  private final boolean dark;
  private final HashMap<String, Integer> idsByName = new HashMap<>();
  private int nextViewId = 0x7f9A0001;

  private XmlLayoutRenderer(Context context, ResourceResolver resolver, boolean dark) {
    this.context = context;
    this.resolver = resolver == null ? new ResourceResolver() : resolver;
    this.dark = dark;
  }

  public static Result render(
      Context context, String xml, boolean darkTheme, ResourceResolver resolver) {
    XmlLayoutRenderer engine = new XmlLayoutRenderer(context, resolver, darkTheme);
    Result result = new Result();
    try {
      XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
      parser.setInput(new StringReader(xml == null ? "" : xml));
      ArrayList<ViewGroup> stack = new ArrayList<>();
      ArrayList<String> tagStack = new ArrayList<>();
      for (int event = parser.getEventType();
          event != XmlPullParser.END_DOCUMENT;
          event = parser.next()) {
        if (event == XmlPullParser.START_TAG) {
          HashMap<String, String> attrs = new HashMap<>();
          for (int i = 0; i < parser.getAttributeCount(); i++) {
            // المحلل غير namespace-aware: الاسم يصل بالبادئة (android:/app:) — تُقص
            // حتى تقرأ السمات بأسمائها المجردة، وقيود ConstraintLayout تُقرأ بالمفتاح نفسه.
            String name = parser.getAttributeName(i);
            int colon = name.indexOf(':');
            attrs.put(colon >= 0 ? name.substring(colon + 1) : name, parser.getAttributeValue(i));
          }
          View view = engine.build(parser.getName(), attrs);
          result.nodes.add(new Node(shortName(parser.getName()), stack.size(), view));
          if (result.root == null) result.root = view;
          else if (!stack.isEmpty()) {
            ViewGroup parent = stack.get(stack.size() - 1);
            parent.addView(view, engine.layoutParamsFor(parent, attrs));
          }
          boolean container = view instanceof ViewGroup && isContainer(parser.getName());
          if (container) {
            stack.add((ViewGroup) view);
            tagStack.add(parser.getName());
          }
          if (parser.isEmptyElementTag() && container) {
            stack.remove(stack.size() - 1);
            tagStack.remove(tagStack.size() - 1);
          }
        } else if (event == XmlPullParser.END_TAG) {
          if (!tagStack.isEmpty() && tagStack.get(tagStack.size() - 1).equals(parser.getName())) {
            stack.remove(stack.size() - 1);
            tagStack.remove(tagStack.size() - 1);
          }
        }
      }
    } catch (Throwable failure) {
      result.error = failure.getMessage() == null ? failure.toString() : failure.getMessage();
    }
    return result;
  }

  private static String shortName(String tag) {
    int dot = tag.lastIndexOf('.');
    return dot >= 0 ? tag.substring(dot + 1) : tag;
  }

  private static boolean isContainer(String tag) {
    switch (shortName(tag)) {
      case "LinearLayout":
      case "FrameLayout":
      case "RelativeLayout":
      case "ScrollView":
      case "HorizontalScrollView":
      case "RadioGroup":
      case "TableLayout":
      case "TableRow":
      case "CardView":
      case "ConstraintLayout":
      case "CoordinatorLayout":
      case "DrawerLayout":
        return true;
      default:
        return false;
    }
  }

  private String attr(HashMap<String, String> a, String name) {
    String raw = a.get(name);
    return raw == null ? null : resolver.resolve(raw);
  }

  private View build(String tag, HashMap<String, String> a) {
    String name = shortName(tag);
    View view;
    switch (name) {
      case "LinearLayout":
      case "RadioGroup":
      case "TableLayout":
      case "TableRow":
        LinearLayout linear = new LinearLayout(context);
        linear.setOrientation(
            "horizontal".equals(attr(a, "orientation"))
                ? LinearLayout.HORIZONTAL
                : "vertical".equals(attr(a, "orientation"))
                    ? LinearLayout.VERTICAL
                    : name.equals("TableRow") ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        String weightSum = attr(a, "weightSum");
        if (weightSum != null) {
          try {
            linear.setWeightSum(Float.parseFloat(weightSum));
          } catch (NumberFormatException ignored) {
          }
        }
        view = linear;
        break;
      case "RelativeLayout":
      case "ConstraintLayout":
      case "CoordinatorLayout":
        view = new RelativeLayout(context);
        break;
      case "ScrollView":
        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport("true".equals(attr(a, "fillViewport")));
        view = scroll;
        break;
      case "HorizontalScrollView":
        view = new HorizontalScrollView(context);
        break;
      case "TextView":
      case "AppCompatTextView":
      case "MaterialTextView":
        view = applyText(new TextView(context), a);
        break;
      case "EditText":
      case "AppCompatEditText":
      case "TextInputEditText":
        view = applyText(new EditText(context), a);
        break;
      case "Button":
      case "AppCompatButton":
      case "MaterialButton":
        view = applyText(new Button(context), a);
        break;
      case "CheckBox":
        view = applyText(new CheckBox(context), a);
        break;
      case "RadioButton":
        view = applyText(new RadioButton(context), a);
        break;
      case "Switch":
      case "SwitchCompat":
      case "SwitchMaterial":
        view = applyText(new Switch(context), a);
        break;
      case "SeekBar":
        view = new SeekBar(context);
        break;
      case "ProgressBar":
        view = new ProgressBar(context);
        break;
      case "Spinner":
        view = new Spinner(context);
        break;
      case "ImageView":
      case "AppCompatImageView":
        view = applyImage(new ImageView(context), a);
        break;
      case "ImageButton":
      case "AppCompatImageButton":
        view = applyImage(new ImageButton(context), a);
        break;
      case "FloatingActionButton":
      case "ExtendedFloatingActionButton":
        ImageButton fab = new ImageButton(context);
        applyImage(fab, a);
        android.graphics.drawable.GradientDrawable circle =
            new android.graphics.drawable.GradientDrawable();
        circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        Integer fabTint = resolver.color(a.get("backgroundTint"));
        circle.setColor(fabTint != null ? fabTint : 0xFF2196F3);
        fab.setBackground(circle);
        fab.setColorFilter(Color.WHITE);
        fab.setMinimumWidth(dp(56));
        fab.setMinimumHeight(dp(56));
        fab.setElevation(dp(6));
        view = fab;
        break;
      case "View":
        view = new View(context);
        break;
      case "CardView":
      case "MaterialCardView":
        FrameLayout card = new FrameLayout(context);
        android.graphics.drawable.GradientDrawable surface =
            new android.graphics.drawable.GradientDrawable();
        surface.setColor(dark ? 0xFF2B2B2B : Color.WHITE);
        String radius = attr(a, "cardCornerRadius");
        surface.setCornerRadius(radius != null ? sizeOf(radius, dp(4)) : dp(4));
        card.setBackground(surface);
        card.setElevation(dp(3));
        view = card;
        break;
      case "FrameLayout":
      case "DrawerLayout":
        view = new FrameLayout(context);
        break;
      default:
        TextView placeholder = new TextView(context);
        placeholder.setText(name);
        placeholder.setGravity(Gravity.CENTER);
        placeholder.setTextColor(dark ? Color.LTGRAY : Color.DKGRAY);
        placeholder.setMinHeight(dp(40));
        view = placeholder;
        break;
    }
    applyCommon(view, a);
    return view;
  }

  private TextView applyText(TextView view, HashMap<String, String> a) {
    String text = attr(a, "text");
    if (text != null) view.setText(stripReference(text));
    String hint = attr(a, "hint");
    if (hint != null) view.setHint(stripReference(hint));
    String size = attr(a, "textSize");
    if (size != null) {
      try {
        float value = Float.parseFloat(size.replaceAll("[a-z]+$", ""));
        view.setTextSize(
            size.endsWith("dp") || size.endsWith("dip")
                ? TypedValue.COMPLEX_UNIT_DIP
                : TypedValue.COMPLEX_UNIT_SP,
            value);
      } catch (NumberFormatException ignored) {
      }
    }
    Integer color = resolver.color(a.get("textColor"));
    if (color != null) view.setTextColor(color);
    else view.setTextColor(dark ? Color.WHITE : 0xFF212121);
    Integer hintColor = resolver.color(a.get("textColorHint"));
    if (hintColor != null) view.setHintTextColor(hintColor);
    String style = attr(a, "textStyle");
    if (style != null)
      view.setTypeface(
          null,
          style.contains("bold") && style.contains("italic")
              ? Typeface.BOLD_ITALIC
              : style.contains("bold") ? Typeface.BOLD
              : style.contains("italic") ? Typeface.ITALIC : Typeface.NORMAL);
    if ("true".equals(attr(a, "singleLine")) || "1".equals(attr(a, "maxLines")))
      view.setSingleLine(true);
    String maxLines = attr(a, "maxLines");
    if (maxLines != null) {
      try {
        view.setMaxLines(Integer.parseInt(maxLines));
      } catch (NumberFormatException ignored) {
      }
    }
    String ellipsize = attr(a, "ellipsize");
    if (ellipsize != null) {
      switch (ellipsize) {
        case "start":
          view.setEllipsize(TextUtils.TruncateAt.START);
          break;
        case "middle":
          view.setEllipsize(TextUtils.TruncateAt.MIDDLE);
          break;
        case "marquee":
          view.setEllipsize(TextUtils.TruncateAt.MARQUEE);
          break;
        default:
          view.setEllipsize(TextUtils.TruncateAt.END);
          break;
      }
    }
    Integer gravity = gravityOf(attr(a, "gravity"));
    if (gravity != null) view.setGravity(gravity);
    return view;
  }

  private ImageView applyImage(ImageView view, HashMap<String, String> a) {
    // ‎@drawable مشروعي لا يُركّب بلا مترجم موارد — رمز صورة بديل كما يفعل المرجع.
    view.setImageResource(android.R.drawable.ic_menu_gallery);
    String scaleType = attr(a, "scaleType");
    if (scaleType != null) {
      switch (scaleType) {
        case "centerCrop":
          view.setScaleType(ImageView.ScaleType.CENTER_CROP);
          break;
        case "centerInside":
          view.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
          break;
        case "fitXY":
          view.setScaleType(ImageView.ScaleType.FIT_XY);
          break;
        case "center":
          view.setScaleType(ImageView.ScaleType.CENTER);
          break;
        default:
          view.setScaleType(ImageView.ScaleType.FIT_CENTER);
          break;
      }
    }
    return view;
  }

  private static String stripReference(String raw) {
    if (raw.startsWith("@")) {
      int slash = raw.indexOf('/');
      return slash >= 0 ? raw.substring(slash + 1) : raw;
    }
    return raw;
  }

  private void applyCommon(View view, HashMap<String, String> a) {
    String id = a.get("id");
    if (id != null) view.setId(idFor(id));
    Integer background = resolver.color(a.get("background"));
    if (background != null) view.setBackgroundColor(background);
    int all = sizeOf(attr(a, "padding"), -1);
    int left = sizeOf(attr(a, "paddingLeft"), all >= 0 ? all : view.getPaddingLeft());
    int top = sizeOf(attr(a, "paddingTop"), all >= 0 ? all : view.getPaddingTop());
    int right = sizeOf(attr(a, "paddingRight"), all >= 0 ? all : view.getPaddingRight());
    int bottom = sizeOf(attr(a, "paddingBottom"), all >= 0 ? all : view.getPaddingBottom());
    String start = attr(a, "paddingStart");
    String end = attr(a, "paddingEnd");
    if (start != null) left = sizeOf(start, left);
    if (end != null) right = sizeOf(end, right);
    view.setPadding(left, top, right, bottom);
    String minHeight = attr(a, "minHeight");
    if (minHeight != null) view.setMinimumHeight(sizeOf(minHeight, 0));
    String minWidth = attr(a, "minWidth");
    if (minWidth != null) view.setMinimumWidth(sizeOf(minWidth, 0));
    String alpha = attr(a, "alpha");
    if (alpha != null) {
      try {
        view.setAlpha(Float.parseFloat(alpha));
      } catch (NumberFormatException ignored) {
      }
    }
    String visibility = attr(a, "visibility");
    if ("gone".equals(visibility) || "invisible".equals(visibility)) view.setAlpha(0.35f);
  }

  private int idFor(String reference) {
    String name = reference.substring(reference.indexOf('/') + 1);
    Integer existing = idsByName.get(name);
    if (existing != null) return existing;
    int id = nextViewId++;
    idsByName.put(name, id);
    return id;
  }

  private ViewGroup.LayoutParams layoutParamsFor(ViewGroup parent, HashMap<String, String> a) {
    int width = dimensionOf(attr(a, "layout_width"), ViewGroup.LayoutParams.WRAP_CONTENT);
    int height = dimensionOf(attr(a, "layout_height"), ViewGroup.LayoutParams.WRAP_CONTENT);
    ViewGroup.MarginLayoutParams params;
    if (parent instanceof LinearLayout) {
      LinearLayout.LayoutParams linear = new LinearLayout.LayoutParams(width, height);
      String weight = attr(a, "layout_weight");
      if (weight != null) {
        try {
          linear.weight = Float.parseFloat(weight);
        } catch (NumberFormatException ignored) {
        }
      }
      Integer gravity = gravityOf(attr(a, "layout_gravity"));
      if (gravity != null) linear.gravity = gravity;
      params = linear;
    } else if (parent instanceof FrameLayout) {
      FrameLayout.LayoutParams frame = new FrameLayout.LayoutParams(width, height);
      Integer gravity = gravityOf(attr(a, "layout_gravity"));
      if (gravity != null) frame.gravity = gravity;
      params = frame;
    } else if (parent instanceof RelativeLayout) {
      boolean constrained = a.containsKey("layout_constraintTop_toTopOf")
          || a.containsKey("layout_constraintBottom_toBottomOf")
          || a.containsKey("layout_constraintStart_toStartOf")
          || a.containsKey("layout_constraintEnd_toEndOf")
          || a.containsKey("layout_constraintLeft_toLeftOf")
          || a.containsKey("layout_constraintRight_toRightOf");
      if (constrained) {
        width = constraintDimensionOf(attr(a, "layout_width"), width);
        height = constraintDimensionOf(attr(a, "layout_height"), height);
      }
      RelativeLayout.LayoutParams relative = new RelativeLayout.LayoutParams(width, height);
      applyRelativeRules(relative, a);
      params = relative;
    } else {
      params = new ViewGroup.MarginLayoutParams(width, height);
    }
    int margin = sizeOf(attr(a, "layout_margin"), 0);
    params.leftMargin = sizeOf(attr(a, "layout_marginLeft"), margin);
    params.topMargin = sizeOf(attr(a, "layout_marginTop"), margin);
    params.rightMargin = sizeOf(attr(a, "layout_marginRight"), margin);
    params.bottomMargin = sizeOf(attr(a, "layout_marginBottom"), margin);
    String start = attr(a, "layout_marginStart");
    String end = attr(a, "layout_marginEnd");
    if (start != null) params.leftMargin = sizeOf(start, params.leftMargin);
    if (end != null) params.rightMargin = sizeOf(end, params.rightMargin);
    return params;
  }

  /** قواعد RelativeLayout المرجعية — مواقع العناصر النسبية تُحترم كما ستُرسم فعليًا. */
  private void applyRelativeRules(RelativeLayout.LayoutParams p, HashMap<String, String> a) {
    if ("true".equals(attr(a, "layout_alignParentTop")))
      p.addRule(RelativeLayout.ALIGN_PARENT_TOP);
    if ("true".equals(attr(a, "layout_alignParentBottom")))
      p.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
    if ("true".equals(attr(a, "layout_alignParentLeft"))
        || "true".equals(attr(a, "layout_alignParentStart")))
      p.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
    if ("true".equals(attr(a, "layout_alignParentRight"))
        || "true".equals(attr(a, "layout_alignParentEnd")))
      p.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
    if ("true".equals(attr(a, "layout_centerInParent"))) p.addRule(RelativeLayout.CENTER_IN_PARENT);
    if ("true".equals(attr(a, "layout_centerHorizontal")))
      p.addRule(RelativeLayout.CENTER_HORIZONTAL);
    if ("true".equals(attr(a, "layout_centerVertical"))) p.addRule(RelativeLayout.CENTER_VERTICAL);
    anchorRule(p, a, "layout_below", RelativeLayout.BELOW);
    anchorRule(p, a, "layout_above", RelativeLayout.ABOVE);
    anchorRule(p, a, "layout_toRightOf", RelativeLayout.RIGHT_OF);
    anchorRule(p, a, "layout_toEndOf", RelativeLayout.RIGHT_OF);
    anchorRule(p, a, "layout_toLeftOf", RelativeLayout.LEFT_OF);
    anchorRule(p, a, "layout_toStartOf", RelativeLayout.LEFT_OF);
    anchorRule(p, a, "layout_alignTop", RelativeLayout.ALIGN_TOP);
    anchorRule(p, a, "layout_alignBottom", RelativeLayout.ALIGN_BOTTOM);
    anchorRule(p, a, "layout_alignLeft", RelativeLayout.ALIGN_LEFT);
    anchorRule(p, a, "layout_alignRight", RelativeLayout.ALIGN_RIGHT);
    // قيود ConstraintLayout الشائعة → قواعد RelativeLayout المكافئة (دقة مواقع المعاينة).
    boolean topParent = "parent".equals(a.get("layout_constraintTop_toTopOf"));
    boolean bottomParent = "parent".equals(a.get("layout_constraintBottom_toBottomOf"));
    boolean startParent =
        "parent".equals(a.get("layout_constraintStart_toStartOf"))
            || "parent".equals(a.get("layout_constraintLeft_toLeftOf"));
    boolean endParent =
        "parent".equals(a.get("layout_constraintEnd_toEndOf"))
            || "parent".equals(a.get("layout_constraintRight_toRightOf"));
    if (topParent && bottomParent) p.addRule(RelativeLayout.CENTER_VERTICAL);
    else if (topParent) p.addRule(RelativeLayout.ALIGN_PARENT_TOP);
    else if (bottomParent) p.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
    if (startParent && endParent) p.addRule(RelativeLayout.CENTER_HORIZONTAL);
    else if (startParent) p.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
    else if (endParent) p.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
    anchorRule(p, a, "layout_constraintTop_toBottomOf", RelativeLayout.BELOW);
    anchorRule(p, a, "layout_constraintBottom_toTopOf", RelativeLayout.ABOVE);
    anchorRule(p, a, "layout_constraintStart_toEndOf", RelativeLayout.RIGHT_OF);
    anchorRule(p, a, "layout_constraintLeft_toRightOf", RelativeLayout.RIGHT_OF);
    anchorRule(p, a, "layout_constraintEnd_toStartOf", RelativeLayout.LEFT_OF);
    anchorRule(p, a, "layout_constraintRight_toLeftOf", RelativeLayout.LEFT_OF);
    anchorRule(p, a, "layout_constraintTop_toTopOf", RelativeLayout.ALIGN_TOP);
    anchorRule(p, a, "layout_constraintBottom_toBottomOf", RelativeLayout.ALIGN_BOTTOM);
    anchorRule(p, a, "layout_constraintStart_toStartOf", RelativeLayout.ALIGN_LEFT);
    anchorRule(p, a, "layout_constraintEnd_toEndOf", RelativeLayout.ALIGN_RIGHT);
  }

  private void anchorRule(
      RelativeLayout.LayoutParams p, HashMap<String, String> a, String name, int rule) {
    String target = a.get(name);
    if (target != null && target.startsWith("@")) p.addRule(rule, idFor(target));
  }

  private int dimensionOf(String value, int fallback) {
    if (value == null) return fallback;
    if ("match_parent".equals(value) || "fill_parent".equals(value))
      return ViewGroup.LayoutParams.MATCH_PARENT;
    if ("wrap_content".equals(value)) return ViewGroup.LayoutParams.WRAP_CONTENT;
    return sizeOf(value, fallback);
  }

  /** بُعد ابن ConstraintLayout: ‎0dp = امتداد للقيود — يُعرض كامتداد للأب. */
  private int constraintDimensionOf(String value, int fallback) {
    if ("0dp".equals(value) || "0.0dip".equals(value) || "0dip".equals(value))
      return ViewGroup.LayoutParams.MATCH_PARENT;
    return dimensionOf(value, fallback);
  }

  private int sizeOf(String value, int fallback) {
    if (value == null) return fallback;
    try {
      float number = Float.parseFloat(value.replaceAll("(dip|dp|sp|px)$", ""));
      if (value.endsWith("px")) return (int) number;
      return dp(number);
    } catch (NumberFormatException wrong) {
      return fallback;
    }
  }

  private static Integer gravityOf(String value) {
    if (value == null) return null;
    int gravity = 0;
    for (String part : value.split("\\|")) {
      switch (part.trim()) {
        case "center":
          gravity |= Gravity.CENTER;
          break;
        case "center_vertical":
          gravity |= Gravity.CENTER_VERTICAL;
          break;
        case "center_horizontal":
          gravity |= Gravity.CENTER_HORIZONTAL;
          break;
        case "left":
        case "start":
          gravity |= Gravity.LEFT;
          break;
        case "right":
        case "end":
          gravity |= Gravity.RIGHT;
          break;
        case "top":
          gravity |= Gravity.TOP;
          break;
        case "bottom":
          gravity |= Gravity.BOTTOM;
          break;
        case "fill":
          gravity |= Gravity.FILL;
          break;
        default:
          break;
      }
    }
    return gravity == 0 ? null : gravity;
  }

  private int dp(float n) {
    return (int) (n * context.getResources().getDisplayMetrics().density + 0.5f);
  }

  /** إطار المصمم المتقطع حول العناصر (وضع التحرير) وإطار التحديد الأزرق المصمت. */
  public static final class BorderOverlay extends FrameLayout {
    private final Paint dashed = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selected = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Node> nodes;
    private boolean bordersVisible = true;
    private View selectedView;

    public BorderOverlay(Context context, List<Node> nodes) {
      super(context);
      this.nodes = nodes;
      dashed.setStyle(Paint.Style.STROKE);
      dashed.setStrokeWidth(dpi(context, 1));
      dashed.setColor(0xFF9E9E9E);
      dashed.setPathEffect(
          new DashPathEffect(new float[] {dpi(context, 4), dpi(context, 3)}, 0));
      selected.setStyle(Paint.Style.STROKE);
      selected.setStrokeWidth(dpi(context, 2));
      selected.setColor(0xFF2196F3);
      setWillNotDraw(false);
    }

    public void setBordersVisible(boolean visible) {
      bordersVisible = visible;
      invalidate();
    }

    public boolean bordersVisible() {
      return bordersVisible;
    }

    public void select(View view) {
      selectedView = view;
      invalidate();
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
      super.dispatchDraw(canvas);
      int[] mine = new int[2];
      getLocationInWindow(mine);
      if (bordersVisible) for (Node node : nodes) drawFrame(canvas, node.view, mine, dashed);
      if (selectedView != null) drawFrame(canvas, selectedView, mine, selected);
    }

    private void drawFrame(Canvas canvas, View view, int[] mine, Paint paint) {
      if (view == null || !view.isAttachedToWindow()) return;
      int[] at = new int[2];
      view.getLocationInWindow(at);
      float left = at[0] - mine[0];
      float top = at[1] - mine[1];
      canvas.drawRect(left, top, left + view.getWidth(), top + view.getHeight(), paint);
    }

    private static int dpi(Context c, float n) {
      return (int) (n * c.getResources().getDisplayMetrics().density + 0.5f);
    }
  }
}
