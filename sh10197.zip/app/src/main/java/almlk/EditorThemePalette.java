package almlk;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * لوحةُ ألوانِ المحرّر: ثلاثةَ عشرَ دورًا، لكلِّ دورٍ قيمةٌ فاتحةٌ وأخرى داكنة، والقيمةُ **نصٌّ سداسيٌّ**
 * لا رقمٌ — كما في المصدر ({@code ColorDefault} + {@code HighlightUtils}).
 *
 * <p>العقدُ المنقولُ من {@code com/factorialovich/aide/highlight}: ترتيبُ الأدوارِ وقيمُها الافتراضيةُ
 * حرفيًّا، ومفتاحُ التخزينِ مشتقٌّ من اسمِ الدورِ بترشيحِ الحروفِ غيرِ الأبجديةِ إلى {@code _} ثم إلحاقِ
 * {@code _light} أو {@code _dark}، وترميزُ نسخِ اللوحةِ {@code themeCode;light,dark;…} بعدَ {@code gzip}
 * و{@code base64} مع تصغيرِ {@code #ffRRGGBB} إلى {@code RRGGBB}. ولا لونَ خامسَ عشرَ: ما كان عندَنا
 * «دوالاً» و«متغيّرات» صار دورَ {@code Identifier} الواحدَ كما عندَهم، وألوانُ المستخدمِ تنتقلُ إليهِ بهجرةٍ
 * مُعلَنةٍ لا بصمت.
 *
 * <p>هذه الطبقةُ خالصةٌ: تُقابَلُ في بواباتِ الانحدارِ سلوكيًّا (الجدولُ، المرشِّحُ، التحليلُ، الترميزُ،
 * الهجرةُ)، والشاشةُ والمحرّرُ يقرآنِ منها ولا تكرّرُ شيئًا من أرقامِها.
 */
public final class EditorThemePalette {

  /** الأدوارُ بأسماءِها كما هي مفاتيحَ تخزينٍ في المصدر (الاسمُ نفسُهُ، لا ترجمةٌ له). */
  public static final String BACKGROUND = "background";
  public static final String PLAIN = "Plain";
  public static final String KEYWORD = "Keyword";
  public static final String IDENTIFIER = "Identifier";
  public static final String LITERAL = "Literal";
  public static final String OPERATOR = "Operator";
  public static final String TYPE_IDENTIFIER = "Type Identifier";
  public static final String NAMESPACE_IDENTIFIER = "Namespace/Package Identifier";
  public static final String SEPARATOR = "Separator/Punctuator";
  public static final String COMMENT = "Comment";
  public static final String LINE_NUMBER = "line number";
  public static final String LINE_BACKGROUND = "line background";
  public static final String SELECTED_BACKGROUND = "selected background";

  /** الترتيبُ الذي تُعرَضُ به السطورُ في اللوحتين — ترتيبُ المصدر، لا ترتيبٌ لغويٌّ عندنا. */
  public static final String[] ROLE_ORDER = {
    BACKGROUND, PLAIN, KEYWORD, IDENTIFIER, LITERAL, OPERATOR, TYPE_IDENTIFIER,
    NAMESPACE_IDENTIFIER, SEPARATOR, COMMENT, LINE_NUMBER, LINE_BACKGROUND, SELECTED_BACKGROUND
  };

  private static final String[] LIGHT_HEX = {
    "#00FFFFFF", "#FF000000", "#FF569CD6", "#FFFFFF00", "#FF569CD6", "#FFD4D4D4", "#FF00B7EB",
    "#FFC58600", "#FF00CED1", "#FF008000", "#FFB0B0B0", "#10000000", "#FF7869F0"
  };

  // «كاي أسود» (Kay Dark) — اللوحةُ الافتراضيةُ السوداءُ كما أملى المستخدمُ حرفيًّا، بترتيبِ
  // ROLE_ORDER نفسِهِ: خلفيةٌ سوداءُ صِرْفةٌ، نصٌّ أبيض، مفتاحٌ أحمر، معرِّفٌ أصفر، عليقةٌ خضراء،
  // عاملٌ ورديّ، نوعٌ وأرقامُ أسطرٍ سماويّانِ (#23BBFF)، باقةٌ صفراء، فاصلٌ فيروزيّ، تعليقٌ أخضرُ
  // فسفوريّ، ظلُّ السطرِ النشِطِ بشبكةٍ زرقاءَ **ألفاها صفرٌ** (لا تُجعَلُ opaque)، وخلفيةُ التحديدِ زرقاء.
  // الفاتحةُ بقيتْ قيمَ المرجعِ كما هي: طلبُكَ مسَّ الأسودَ وحدَهُ.
  private static final String[] DARK_HEX = {
    "#FF000000", "#FFFFFFFF", "#FFFF5252", "#FFFFD740", "#FF8BC34A", "#FFEC407A", "#FF23BBFF",
    "#FFFFD740", "#FF4DD0E1", "#FF04DA2B", "#FF23BBFF", "#002908FA", "#FF2E94C2"
  };

  /** رمزُ اللوحةِ في ترميزِ النسخِ/الاستيراد، كما يفتحُ المصدرُ سلسلتَهُ. */
  public static final String DEFAULT_THEME_CODE = "default";

  /**
   * أدوارُ المواردِ عندَ المصدر: {@code DOC_COMMENT} لا صَفَّ له في {@code ColorDefault} (الثلاثةَ عشرَ
   * فقط) ⇒ مفتاحُهُ في التفضيلاتِ لا يُزرَعُ إطلاقًا، {@code HighlightUtils.getHighLightColor} يرمي
   * الاستثناءَ ويرجعُ إلى **موردِ النظامِ مباشرةً**: {@code editor_syntax_comment(_light)} من
   * {@code res/values/colors.xml} — لا لونَ صَفٍّ يُحرِّرُهُ المستخدمُ ولا لوحةَ ثيمٍ تُبدِّلُهُ. لذلك
   * يُطرَدُ من {@link #ROLE_ORDER} ومن التخزينِ والتصديرِ طردًا، وتُحمَلُ قيمتُهُ الحرفيةُ هنا.
   * ولا دورَ {@code DELEGATE_IDENTIFIER} عندَنا: كانت «المرجعُ المفوَّضُ» صَفًّا ثانويًّا بلونِ الموردِ
   * {@code editor_syntax_type} وميْلانٍ زائد، واللقطاتُ الأربعُ من المصدرِ (تقريرُ ١.٠.١٤٢) تُريهِ
   * سادةً كاسمِ الدالةِ الذي يَلي النقطة، فزالتِ الحاجةُ إليهِ وزالَ ممرُّهُ.
   */
  public static final String DOCUMENTATION_COMMENT = "Documentation Comment";

  private static final String[] RESOURCE_ROLES = {DOCUMENTATION_COMMENT};
  /** {@code editor_syntax_comment_light}. */
  private static final int[] RESOURCE_LIGHT = {0xFF009B00};
  /** {@code editor_syntax_comment}. */
  private static final int[] RESOURCE_DARK = {0xFF50BB50};

  public static boolean isResourceRole(String role) {
    return resourceIndexOf(role) >= 0;
  }

  private static int resourceIndexOf(String role) {
    for (int i = 0; i < RESOURCE_ROLES.length; i++) if (RESOURCE_ROLES[i].equals(role)) return i;
    return -1;
  }

  /** لونُ دورِ موردٍ؛ لا يقرأُ ثيمًا ولا تفضيلًا، والدورُ غيرُ الموردِ خطأُ برنامجٍ لا حالةُ تشغيل. */
  public static int resourceColor(String role, boolean light) {
    int index = resourceIndexOf(role);
    if (index < 0) {
      throw new IllegalStateException("not a resource role: " + role);
    }
    return (light ? RESOURCE_LIGHT[index] : RESOURCE_DARK[index]) | 0xFF000000;
  }

  public static String resourceHex(String role, boolean light) {
    return formatArgb(resourceColor(role, light));
  }

  private EditorThemePalette() {}

  public static int roleCount() {
    return ROLE_ORDER.length;
  }

  /** {@code true} تعني اللوحةَ الفاتحة — وهو نفسُ المعنى الذي تحمِلُهُ {@code z} في المصدر. */
  public static String defaultHex(String role, boolean light) {
    int index = indexOf(role);
    if (index < 0) return light ? LIGHT_HEX[1] : DARK_HEX[1];
    return light ? LIGHT_HEX[index] : DARK_HEX[index];
  }

  public static int defaultColor(String role, boolean light) {
    return parseHex(defaultHex(role, light), 0);
  }

  public static int indexOf(String role) {
    for (int i = 0; i < ROLE_ORDER.length; i++) if (ROLE_ORDER[i].equals(role)) return i;
    return -1;
  }

  public static boolean isRole(String role) {
    return indexOf(role) >= 0;
  }

  /**
   * مفتاحُ التخزينِ كما يشتقّهُ المصدر: {@code name.replaceAll("[^a-z|A-Z]", "_").toLowerCase()} ثم
   * {@code _light} أو {@code _dark} — فـ{@code "Namespace/Package Identifier"} يصيرُ
   * {@code namespace__package__identifier_light}.
   */
  public static String spKey(String role, boolean light) {
    String safe = role == null ? "" : role;
    StringBuilder builder = new StringBuilder(safe.length() + 6);
    for (int i = 0; i < safe.length(); i++) {
      char value = safe.charAt(i);
      boolean letter = (value >= 'a' && value <= 'z') || (value >= 'A' && value <= 'Z');
      builder.append(letter ? Character.toLowerCase(value) : '_');
    }
    builder.append(light ? "_light" : "_dark");
    return builder.toString();
  }

  /** مفاتيحُ اللوحةِ كلِّها بترتيبِها — تُستعمَلُ للذرءِ ولمسحِ لوحةٍ بعينِها دونِ الأخرى. */
  public static String[] spKeys(boolean light) {
    String[] keys = new String[ROLE_ORDER.length];
    for (int i = 0; i < keys.length; i++) keys[i] = spKey(ROLE_ORDER[i], light);
    return keys;
  }

  /**
   * تحليلٌ بلا انهيارٍ للعليل: {@code #AARRGGBB} و{@code #RRGGBB} و{@code RRGGBB} المصغَّرةُ (من ترميزِ
   * النسخ) مقبولة؛ وغيرُها يُرجِعُ {@code fallback}.
   */
  /**
   * قاعدةُ تلوينِ الواجهةِ الواحدة: الفاتحُ ⇒ أسودُ صريحٌ على بياضٍ لأيقوناتِ الشريطِ وقسمِ القائمةِ
   * والخيارات، والداكنُ ⇒ عناصرُ بيضاءُ على سواد. تُبنى الأيقوناتُ على هذا اللونِ لا على لونِ الدور،
   * فلا يتركُ وضعُ الليلِ أيقونةً بيضاءَ على شريطٍ أبيض.
   */
  public static int foregroundFor(boolean dark) {
    return dark ? 0xFFFFFFFF : 0xFF000000;
  }

  public static int backgroundFor(boolean dark) {
    return dark ? 0xFF191919 : 0xFFFFFFFF;
  }

  public static int chromeFor(boolean dark) {
    return dark ? 0xFF232323 : 0xFFFFFFFF;
  }

  public static int parseHex(String text, int fallback) {
    Integer value = parseHexOrNull(text);
    return value == null ? fallback : value.intValue();
  }

  public static Integer parseHexOrNull(String text) {
    if (text == null) return null;
    String value = text.trim();
    if (value.isEmpty()) return null;
    if (value.charAt(0) == '#') value = value.substring(1);
    if (value.length() == 6) value = "FF" + value;
    if (value.length() != 8) return null;
    long parsed;
    try {
      parsed = Long.parseLong(value, 16);
    } catch (NumberFormatException e) {
      return null;
    }
    return Integer.valueOf((int) parsed);
  }

  /** القيمةُ كما تُحفَظُ وتُعرَضُ: {@code #AARRGGBB} بأحرفٍ كبيرة، كما يُلحِقُ المصدرُ {@code toUpperCase}. */
  public static String formatArgb(int color) {
    return String.format(Locale.US, "#%08X", color);
  }

  /** تصغيرُ المصدر: {@code #ffRRGGBB} ⇒ {@code RRGGBB} — لا يُختصَرُ إلا ما كان تسعةَ أحرفَ بهذا البادئة. */
  public static String compressHex(String hex) {
    if (hex == null) return "";
    String value = hex.trim();
    if (value.length() == 9 && value.toLowerCase(Locale.US).startsWith("#ff")) {
      return value.substring(3);
    }
    return value;
  }

  public static String expandHex(String hex) {
    Integer value = parseHexOrNull(hex);
    return value == null ? null : formatArgb(value.intValue());
  }

  /**
   * ترميزُ اللوحةِ للنسخ: {@code themeCode;فاتح،داكن;فاتح،داكن;…} بترتيبِ الأدوار، الألوانُ مصغَّرة،
   * والنصُّ كلُّهُ {@code gzip} ثم {@code base64} — قالبُ المصدرِ حرفيًّا ليصيرَ ما يُنسخُ عندَنا
   * مقروءًا عندَهُم وبالعكس.
   */
  public static String encodeTheme(String themeCode, Map<String, int[]> roleToLightDark) {
    StringBuilder text = new StringBuilder(themeCode == null ? DEFAULT_THEME_CODE : themeCode);
    for (String role : ROLE_ORDER) {
      int[] pair = roleToLightDark == null ? null : roleToLightDark.get(role);
      int light = pair == null ? defaultColor(role, true) : pair[0];
      int dark = pair == null ? defaultColor(role, false) : pair[1];
      text.append(';').append(compressHex(formatArgb(light))).append(',')
          .append(compressHex(formatArgb(dark)));
    }
    try {
      ByteArrayOutputStream bytes = new ByteArrayOutputStream();
      try (GZIPOutputStream gzip = new GZIPOutputStream(bytes)) {
        gzip.write(text.toString().getBytes(StandardCharsets.UTF_8));
      }
      return Base64.getEncoder().encodeToString(bytes.toByteArray());
    } catch (IOException impossible) {
      throw new IllegalStateException(impossible);
    }
  }

  /** لوحةٌ مفكوكة: رمزُ الثيمِ وقيمُ الأدوارِ بترتيبِها. {@link #UNKNOWN_THEME_CODE} عند غيابِ الرمز. */
  public static final String UNKNOWN_THEME_CODE = "";

  public static final class DecodedTheme {
    public final String themeCode;
    /** دورٌ ← {@code {فاتح، داكن}}؛ لا يدخلُهُ إلا دورٌ معروفٌ من اللوحة. */
    public final LinkedHashMap<String, int[]> roles;

    DecodedTheme(String themeCode, LinkedHashMap<String, int[]> roles) {
      this.themeCode = themeCode;
      this.roles = roles;
    }
  }

  /**
   * فكُّ الترميزِ بمسامحةِ المصدر: سطرٌ لكلِّ دورٍ بترتيبِهِ، وكلُّ خطأٍ في سطرٍ يُسقِطُ ذلك السطرَ وحدَهُ
   * ولا يُفسِدُ اللوحةَ كلَّها؛ و{@code IOException} للنصِّ غيرِ القابلِ للفكِّ أصلًا.
   */
  public static DecodedTheme decodeTheme(String config) throws IOException {
    if (config == null || config.trim().isEmpty()) throw new IOException("Empty config");
    byte[] packed;
    try {
      packed = Base64.getMimeDecoder().decode(config.trim());
    } catch (IllegalArgumentException e) {
      throw new IOException("Invalid config");
    }
    String text;
    try (InputStream in = new GZIPInputStream(new ByteArrayInputStream(packed))) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buffer = new byte[4096];
      for (int n; (n = in.read(buffer)) > 0; ) {
        out.write(buffer, 0, n);
        if (out.size() > 64 * 1024) throw new IOException("Config too large");
      }
      text = new String(out.toByteArray(), StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new IOException("Invalid config");
    }
    String[] parts = text.split(";", -1);
    LinkedHashMap<String, int[]> roles = new LinkedHashMap<>();
    String themeCode = UNKNOWN_THEME_CODE;
    for (int i = 0; i < parts.length; i++) {
      String part = parts[i];
      if (i == 0) {
        themeCode = part.trim().isEmpty() ? UNKNOWN_THEME_CODE : part.trim();
        continue;
      }
      int roleIndex = i - 1;
      if (roleIndex >= ROLE_ORDER.length) break;
      int comma = part.indexOf(',');
      if (comma <= 0) continue;
      Integer light = parseHexOrNull(part.substring(0, comma));
      Integer dark = parseHexOrNull(part.substring(comma + 1));
      if (light == null || dark == null) continue;
      roles.put(ROLE_ORDER[roleIndex], new int[] {light.intValue(), dark.intValue()});
    }
    if (roles.isEmpty()) throw new IOException("No known colors");
    return new DecodedTheme(themeCode, roles);
  }

  /**
   * دورُ اللوحةِ الذي يحلُّ محلَّ مفتاحٍ من لوحتِنا القديمةِ خمسةَ عشرَ: {@code type} إلى نوعِ الصنف،
   * {@code selected_line}/{@code selected_text} إلى لوحتَي السطرِ والتحديد، و{@code function}/{@code variable}
   * إلى {@code Identifier} (بأولويّةٍ تُطبَّقُ في {@code ThemeConfig})، وسواهُ بالاسم. {@code null} للمجهول.
   */
  public static String roleForLegacyKey(String legacyKey) {
    if (legacyKey == null) return null;
    switch (legacyKey) {
      case "background": return BACKGROUND;
      case "plain": return PLAIN;
      case "keyword": return KEYWORD;
      case "identifier": return IDENTIFIER;
      case "literal": return LITERAL;
      case "operator": return OPERATOR;
      case "type": return TYPE_IDENTIFIER;
      case "namespace": return NAMESPACE_IDENTIFIER;
      case "separator": return SEPARATOR;
      case "comment": return COMMENT;
      case "line_number": return LINE_NUMBER;
      case "selected_line": return LINE_BACKGROUND;
      case "selected_text": return SELECTED_BACKGROUND;
      case "function": return IDENTIFIER;
      case "variable": return IDENTIFIER;
      default: return null;
    }
  }

  /** الأدوارُ التي كانت لوحاتَنا القديمةُ تفردُ لها لونًا ثم صارت دورًا واحدًا — بترتيبِ الأولوية. */
  /**
   * اسمُ المفتاحِ القديمِ الذي كان يستعملُهُ دورٌ من لوحتِنا خمسةَ عشرَ — للاجتثاثِ والهجرةِ لا
   * للاستعمال: {@code selected_line} كان اسمَ خلفيةِ السطر، و{@code line_number} بخطّةٍ سفلى.
   */
  public static String legacyKeyForRole(String role) {
    if (role == null) return "";
    if (TYPE_IDENTIFIER.equals(role)) return "type";
    if (NAMESPACE_IDENTIFIER.equals(role)) return "namespace";
    if (SEPARATOR.equals(role)) return "separator";
    if (LINE_NUMBER.equals(role)) return "line_number";
    if (LINE_BACKGROUND.equals(role)) return "selected_line";
    if (SELECTED_BACKGROUND.equals(role)) return "selected_text";
    return role.toLowerCase(Locale.US);
  }

  public static final String[] LEGACY_IDENTIFIERS = {"function", "variable"};

  public static boolean isLegacyFold(String legacyKey) {
    for (String value : LEGACY_IDENTIFIERS) if (value.equals(legacyKey)) return true;
    return false;
  }
}
