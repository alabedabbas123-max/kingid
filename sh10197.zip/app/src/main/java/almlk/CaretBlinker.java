package almlk;

import android.os.SystemClock;
import android.view.View;

/**
 * بند almlk ← دور نبض المؤشر في OConsole (الحقل Runnable «f546lg»): ظهور/اختفاء كل
 * نصف ثانية بإعادة رسم محلية، مع تجميد النبض عند عدم عنية المضيف، ومطابقة لسلوك
 * دقات مؤشر النظام (500ms).
 */
public final class CaretBlinker implements Runnable {

  private static final long BLINK_MS = 500L;

  private final View host;
  private boolean blinking;
  private boolean visible = true;
  private long lastStep;

  public CaretBlinker(View host) {
    this.host = host;
  }

  /** تشغيل النبض (يُستدعى عندما يحصل المضيف على التركيز/الظهور). */
  public void start() {
    if (blinking) return;
    blinking = true;
    visible = true;
    host.removeCallbacks(this);
    lastStep = SystemClock.uptimeMillis();
    host.postDelayed(this, BLINK_MS);
  }

  /** إيقاف النبض نهائيًا مع إبقاء المؤشر مرئيًا (كما يحدث عند ترك التركيز). */
  public void stop() {
    blinking = false;
    visible = true;
    host.removeCallbacks(this);
  }

  /** وهلة المؤشر حاليًا — يرسم المؤشر فقط إذا true. */
  public boolean visible() {
    return visible || !blinking;
  }

  /** يقفل النبض مع المؤشر الظاهر (يُسخدم عند الكتابة المتواصلة تفاديًا لومضان مزعج). */
  public void holdVisible() {
    visible = true;
    if (blinking) {
      host.removeCallbacks(this);
      host.postDelayed(this, BLINK_MS);
    }
  }

  @Override
  public void run() {
    if (!blinking) return;
    long now = SystemClock.uptimeMillis();
    if (now - lastStep >= BLINK_MS) {
      visible = !visible;
      lastStep = now;
      host.postInvalidate();
    }
    host.postDelayed(this, BLINK_MS);
  }
}
