package almlk;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * نموذج بناء Gradle لوحدة واحدة (M1): الاعتماديات ومواضع أسطرها، والمستودعات، والمتغيرات.
 *
 * <p>يقرأ ملف الوحدة (Groovy أو KTS) ومعه:
 * <ul>
 *   <li>الملف الجذري وsettings.gradle ({@code dependencyResolutionManagement}).
 *   <li>gradle.properties، وكتل {@code ext}، و{@code apply from}.
 *   <li>كتالوج الإصدارات {@code gradle/libs.versions.toml}.
 * </ul>
 * تحليل نصّي ثابت بلا تنفيذ Groovy: ما لا يُثبت بالنص يُعلَّم {@link Kind#UNSUPPORTED} ولا يُعدّ
 * خطأ (مبدأ الإثبات المتّبع في الفاحص). جافا خالصة بلا Android.
 */
public final class GradleBuildModel {

  public static final String GOOGLE_URL = "https://dl.google.com/dl/android/maven2/";
  public static final String CENTRAL_URL = "https://repo.maven.apache.org/maven2/";
  public static final String PLUGIN_PORTAL_URL = "https://plugins.gradle.org/m2/";
  /** JCenter مجمَّد للقراءة فقط وما زال يخدم؛ Central مرآته الاحتياطية (يُلحقها المحرك). */
  public static final String JCENTER_URL = "https://jcenter.bintray.com/";
  public static final String JITPACK_URL = "https://jitpack.io/";
  /** بادئة «متغير لا يُثبت نصيًا» في missing[0] (تعبير أو ثابت صنف). */
  public static final String UNPROVABLE = "\u0000";

  /** نوع إعلان الاعتماد. */
  public enum Kind {
    /** إحداثيات Maven كاملة قابلة للحلّ. */
    MAVEN,
    /** group:artifact بلا إصدار — يُنتظر من platform/BOM. */
    MISSING_VERSION,
    /** fileTree(...) أو files(...): ملفات من القرص. */
    FILES,
    /** project(':lib'): وحدة من المشروع نفسه. */
    PROJECT,
    /** متغير غير معرّف، أو $ داخل نص أحادي الاقتباس في Groovy (لا يُستبدل). */
    UNRESOLVED_VARIABLE,
    /** نص ليس إحداثيات صالحة. */
    INVALID,
    /** صيغة لا يمكن إثباتها نصيًا (تعبير برمجي) — لا تُعدّ خطأ. */
    UNSUPPORTED
  }

  /** نطاق الإعداد: ما يدخل التحليل والإكمال وما لا يدخل. */
  public enum Scope {
    /** implementation / api / compile (ومتغيّراتها debug/release/flavor). */
    COMPILE,
    /** compileOnly / provided: للتحليل فقط، لا يُحزَّم. */
    COMPILE_ONLY,
    RUNTIME_ONLY,
    /** annotationProcessor / kapt / ksp. */
    PROCESSOR,
    /** test* / androidTest*. */
    TEST,
    /** coreLibraryDesugaring / lintChecks وغيرها. */
    OTHER
  }

  /** إعلان اعتماد واحد بموضعه في ملف الوحدة. */
  public static final class Dependency {
    public final String configuration;
    public final Scope scope;
    public final Kind kind;
    /** النص كما كُتب (بلا اقتباس). */
    public final String rawNotation;
    /** النص بعد استبدال المتغيرات (أو الخام إن تعذّر). */
    public final String notation;
    /** للإحداثيات الكاملة فقط، وإلا null. */
    public final MavenStore.Coordinate coordinate;
    /** اسم المتغير غير المحلول (UNRESOLVED_VARIABLE)، وإلا null. */
    public final String unresolvedVariable;
    /** platform(...)/enforcedPlatform(...): BOM يُقرأ منه dependencyManagement. */
    public final boolean platform;
    /** إزاحة بداية الإعلان (اسم الإعداد) ونهايته في نص الملف. */
    public final int start, end;
    /** رقم سطر البداية (يبدأ من 0). */
    public final int line;
    /** خطأ «$ في نص أحادي الاقتباس» — مؤكد دائمًا ولو تعذّر إثبات غيره (buildSrc). */
    public final boolean literalDollar;

    Dependency(String configuration, Kind kind, String rawNotation, String notation,
        MavenStore.Coordinate coordinate, String unresolvedVariable, boolean platform,
        int start, int end, int line) {
      this(configuration, kind, rawNotation, notation, coordinate, unresolvedVariable, platform, start, end, line, false);
    }

    Dependency(String configuration, Kind kind, String rawNotation, String notation,
        MavenStore.Coordinate coordinate, String unresolvedVariable, boolean platform,
        int start, int end, int line, boolean literalDollar) {
      this.configuration = configuration;
      this.scope = scopeOf(configuration);
      this.kind = kind;
      this.rawNotation = rawNotation;
      this.notation = notation;
      this.coordinate = coordinate;
      this.unresolvedVariable = unresolvedVariable;
      this.platform = platform;
      this.start = start;
      this.end = end;
      this.line = line;
      this.literalDollar = literalDollar;
    }

    Dependency unprovable() {
      return new Dependency(configuration, Kind.UNSUPPORTED, rawNotation, notation, null, null, platform, start, end, line);
    }

    /** يدخل فهرس التحليل والإكمال (لا الاختبارات ولا المعالجات ولا وقت التشغيل). */
    public boolean forAnalysis() {
      return scope == Scope.COMPILE || scope == Scope.COMPILE_ONLY;
    }

    /** خطأ مؤكد يُعلَّم على سطره. */
    public boolean isError() {
      return kind == Kind.UNRESOLVED_VARIABLE || kind == Kind.INVALID;
    }

    @Override
    public String toString() {
      return configuration + " " + kind + " " + notation + " @" + line;
    }
  }

  /** مستودع Maven بعنوان URL (أو مجلد لـflatDir/mavenLocal). */
  public static final class Repository {
    public static final int REMOTE = 0, LOCAL = 1, FLAT_DIR = 2;
    public final int type;
    public final String name;
    /** عنوان ينتهي بـ/ للبعيد؛ مسار مجلد لـFLAT_DIR؛ null لـmavenLocal (يحدّده المحرك). */
    public final String url;

    Repository(int type, String name, String url) {
      this.type = type;
      this.name = name;
      this.url = url;
    }

    String identity() {
      return type + "|" + (url == null ? name : url);
    }

    @Override
    public String toString() {
      return name + (url == null ? "" : " " + url);
    }
  }

  // ═══════════════ النموذج المحمَّل ═══════════════

  public final File buildFile;
  public final File moduleDir;
  public final File projectRoot;
  public final boolean kts;
  public final String text;
  public final Map<String, String> variables;
  public final List<Dependency> dependencies;
  public final List<Repository> repositories;
  /** المستودعات لم تُعلَن في أي ملف فاستُعمل الافتراضي (Google ثم Central). */
  public final boolean defaultRepositories;
  /**
   * مستودعات buildscript/pluginManagement: للإضافات في Gradle، لكنها تلميح صادق لمكان مكتبات المشروع
   * القديم (google() فيها غالبًا)، فيستعملها المحرك احتياطًا بعد المعلنة.
   */
  public List<Repository> buildscriptRepositories = Collections.emptyList();
  /**
   * وحداتُ المشروعِ المعلَنةُ في {@code settings.gradle} وما يبلغُها هذا المنادِي. تُحسَبُ على
   * خيطِ دورةِ الاعتماداتِ مرةً لكلِّ دورةٍ (لا في خيطِ الواجهةِ)، و{@code null} معناها لم تُدرَس
   * بعدُ — فلا حلَّ ولا فهرسةَ تعتبرُ شيئًا ممّا لم يُعلَنْ.
   */
  public almlk.GradleProjectModules projectModules;
  /** إصدار إضافة Kotlin إن طُبّقت (تضيف kotlin-stdlib ضمنيًا)، وإلا null. */
  public final String kotlinPluginVersion;
  public final boolean kotlinPluginApplied;
  /** لإعادة تحليل النص الحي (reparse): الكتالوج وbuildSrc كما حُمّلا. */
  private Map<String, String> catalogLibraries = Collections.emptyMap();
  private Map<String, List<String>> catalogBundles = Collections.emptyMap();
  private boolean hasBuildSrc;

  private GradleBuildModel(File buildFile, File projectRoot, String text, Map<String, String> variables,
      List<Dependency> dependencies, List<Repository> repositories, boolean defaultRepositories,
      boolean kotlinPluginApplied, String kotlinPluginVersion) {
    this.buildFile = buildFile;
    this.moduleDir = buildFile.getAbsoluteFile().getParentFile();
    this.projectRoot = projectRoot;
    this.kts = buildFile.getName().endsWith(".kts");
    this.text = text;
    this.variables = Collections.unmodifiableMap(variables);
    this.dependencies = Collections.unmodifiableList(dependencies);
    this.repositories = Collections.unmodifiableList(repositories);
    this.defaultRepositories = defaultRepositories;
    this.kotlinPluginApplied = kotlinPluginApplied;
    this.kotlinPluginVersion = kotlinPluginVersion;
  }

  /** إحداثيات Maven الكاملة التي تدخل التحليل، بلا تكرار وبترتيب الإعلان. */
  public List<MavenStore.Coordinate> analysisCoordinates() {
    Set<MavenStore.Coordinate> out = new LinkedHashSet<>();
    collectAnalysis(this, out);
    // W22/4ب٢‑ب: ما تُعلِنُهُ الوحداتُ المرتبطةُ اعتماداتٌ للمشروعِ نفسِهِ: تُضافُ كما هي، ولا
    // يُختلَعُ سطرٌ لم تكتبْهُ شيفرةٌ، ولا تُحمَلْ مكتبةٌ لم تُدرِجْها settings.gradle.
    if (projectModules != null) {
      for (GradleBuildModel module : projectModules.models()) collectAnalysis(module, out);
    }
    return new ArrayList<>(out);
  }

  private static void collectAnalysis(GradleBuildModel model, Set<MavenStore.Coordinate> out) {
    for (Dependency dependency : model.dependencies) {
      if (dependency.kind == Kind.MAVEN && dependency.forAnalysis()) out.add(dependency.coordinate);
    }
  }

  /** النموذجُ ثمَّ ما تبلُغُهُ إدراجَاتُ الإعداداتِ: منهُ تُقرَأُ الاعتماداتُ في حلٍّ وفهرسةٍ. */
  public List<GradleBuildModel> modelsForAnalysis() {
    return projectModules == null || projectModules.isEmpty()
        ? Collections.singletonList(this)
        : projectModules.modelsWithCaller(this);
  }

  /** هل {@code project(':x')} مُدرَجٌ ولهُ ملفُّ بناءٍ؟ لا «نعم» بلا قرصٍ يثبتُ ذلكَ. */
  public boolean resolvesProject(String projectPath) {
    return projectModules != null && projectModules.resolves(projectPath);
  }

  /** الإعلانات الخاطئة مؤكدًا (للتموّج الأحمر في M3). */
  public List<Dependency> errors() {
    List<Dependency> out = new ArrayList<>();
    for (Dependency dependency : dependencies) if (dependency.isError()) out.add(dependency);
    return out;
  }

  /**
   * يحمّل نموذج الوحدة: {@code target} ملف بناء أو مجلد وحدة (يُختار build.gradle ثم .kts، ومجلد
   * app إن كان المجلد جذر مشروع). يعيد null إن لم يوجد ملف بناء.
   */
  public static GradleBuildModel load(File target) {
    if (target == null) return null;
    File buildFile = target.isFile() ? target : GradleDependencyEditor.moduleBuildFile(target);
    if (buildFile == null || !buildFile.isFile()) return null;
    buildFile = buildFile.getAbsoluteFile();
    File moduleDir = buildFile.getParentFile();
    File root = findProjectRoot(moduleDir);

    Map<String, String> vars = new LinkedHashMap<>();
    vars.put("rootDir", root.getAbsolutePath());
    vars.put("projectDir", moduleDir.getAbsolutePath());
    vars.putAll(parseProperties(readText(new File(root, "gradle.properties"))));
    if (!moduleDir.equals(root)) vars.putAll(parseProperties(readText(new File(moduleDir, "gradle.properties"))));

    File rootBuild = GradleDependencyEditor.buildFileIn(root);
    File settings = settingsFileIn(root);
    String settingsText = settings == null ? "" : readText(settings);
    String rootText = rootBuild == null || rootBuild.equals(buildFile) ? "" : readText(rootBuild);
    String text = readText(buildFile);

    Set<String> applied = new HashSet<>();
    if (rootBuild != null && !rootBuild.equals(buildFile)) collectVariables(rootBuild, rootText, vars, applied, 0);
    collectVariables(buildFile, text, vars, applied, 0);

    Map<String, String> libraries = new LinkedHashMap<>();
    Map<String, List<String>> bundles = new LinkedHashMap<>();
    Map<String, String> catalogVersions = new LinkedHashMap<>();
    File[] catalogs = new File(root, "gradle").listFiles();
    if (catalogs != null) {
      Arrays.sort(catalogs);
      for (File catalog : catalogs) {
        String name = catalog.getName();
        if (!name.endsWith(".versions.toml")) continue;
        String alias = name.substring(0, name.length() - ".versions.toml".length());
        parseVersionCatalog(readText(catalog), alias, libraries, bundles, catalogVersions);
      }
    }

    String kotlinVersion = detectKotlinVersion(rootText + "\n" + text + "\n" + settingsText, vars, catalogVersions);
    boolean kotlinApplied = kotlinPluginApplied(text);
    List<Dependency> dependencies =
        parseDependencies(text, buildFile.getName().endsWith(".kts"), vars, libraries, bundles, kotlinVersion);
    if (new File(root, "buildSrc").isDirectory()) {
      // buildSrc يعرّف متغيرات لا تُرى نصيًا: لا خطأ إلا المؤكد ($ في نص أحادي الاقتباس).
      for (int i = 0; i < dependencies.size(); i++) {
        Dependency d = dependencies.get(i);
        if (d.kind == Kind.UNRESOLVED_VARIABLE && !d.literalDollar) dependencies.set(i, d.unprovable());
      }
    }

    List<Repository> repos = new ArrayList<>();
    Set<String> seen = new HashSet<>();
    addAll(repos, seen, parseRepositories(settingsText, vars));
    addAll(repos, seen, parseRepositories(rootText, vars));
    addAll(repos, seen, parseRepositories(text, vars));
    boolean defaults = repos.isEmpty();
    if (defaults) {
      repos.add(new Repository(Repository.REMOTE, "google", GOOGLE_URL));
      repos.add(new Repository(Repository.REMOTE, "mavenCentral", CENTRAL_URL));
    }
    GradleBuildModel model =
        new GradleBuildModel(buildFile, root, text, vars, dependencies, repos, defaults, kotlinApplied, kotlinVersion);
    model.catalogLibraries = libraries;
    model.catalogBundles = bundles;
    model.hasBuildSrc = new File(root, "buildSrc").isDirectory();
    List<Repository> hints = new ArrayList<>();
    Set<String> hintSeen = new HashSet<>();
    addAll(hints, hintSeen, parseBuildscriptRepositories(settingsText, vars));
    addAll(hints, hintSeen, parseBuildscriptRepositories(rootText, vars));
    addAll(hints, hintSeen, parseBuildscriptRepositories(text, vars));
    model.buildscriptRepositories = Collections.unmodifiableList(hints);
    return model;
  }

  /**
   * اعتماديات نص ملف الوحدة الحي (غير المحفوظ) بمتغيرات النموذج وكتالوجه، فتتبع العلامات الأسطر أثناء
   * التحرير. المتغيرات المعرّفة في النص نفسه (ext) تُقرأ منه.
   */
  public List<Dependency> reparse(String liveText) {
    String source = liveText == null ? "" : liveText;
    Map<String, String> vars = new LinkedHashMap<>(variables);
    collectVariables(buildFile, source, vars, new HashSet<String>(), 0);
    List<Dependency> out = parseDependencies(source, kts, vars, catalogLibraries, catalogBundles, kotlinPluginVersion);
    if (hasBuildSrc) {
      for (int i = 0; i < out.size(); i++) {
        Dependency d = out.get(i);
        if (d.kind == Kind.UNRESOLVED_VARIABLE && !d.literalDollar) out.set(i, d.unprovable());
      }
    }
    return out;
  }

  /** جذر المشروع: أقرب مجلد (حتى ثلاثة مستويات) يحوي settings.gradle(.kts)، وإلا مجلد الوحدة. */
  public static File findProjectRoot(File moduleDir) {
    File dir = moduleDir.getAbsoluteFile();
    for (int depth = 0; dir != null && depth < 4; depth++, dir = dir.getParentFile()) {
      if (settingsFileIn(dir) != null) return dir;
    }
    return moduleDir.getAbsoluteFile();
  }

  public static File settingsFileIn(File dir) {
    File groovy = new File(dir, "settings.gradle");
    if (groovy.isFile()) return groovy;
    File kts = new File(dir, "settings.gradle.kts");
    return kts.isFile() ? kts : null;
  }

  private static void addAll(List<Repository> out, Set<String> seen, List<Repository> found) {
    for (Repository repository : found) if (seen.add(repository.identity())) out.add(repository);
  }

  // ═══════════════ إعدادات الاعتماد ═══════════════

  private static final Set<String> NOT_CONFIGURATIONS =
      new HashSet<>(Arrays.asList(
          "def", "val", "var", "if", "else", "for", "while", "return", "constraints", "components",
          "modules", "attributesSchema", "println", "configurations", "apply", "ext", "extra", "String",
          "final", "static", "import", "try", "catch", "when", "fun", "class", "object", "plugins",
          "android", "repositories", "dependencies", "buildscript", "allprojects", "subprojects",
          "tasks", "task", "group", "version", "logger"));

  static Scope scopeOf(String configuration) {
    String c = configuration.toLowerCase(Locale.US);
    if (c.startsWith("test") || c.startsWith("androidtest") || c.contains("unittest")) return Scope.TEST;
    if (c.endsWith("compileonly") || c.endsWith("provided") || c.endsWith("compileonlyapi")) return Scope.COMPILE_ONLY;
    if (c.endsWith("runtimeonly") || c.equals("runtime") || c.endsWith("apk")) return Scope.RUNTIME_ONLY;
    if (c.endsWith("annotationprocessor") || c.equals("kapt") || c.startsWith("kapt") || c.equals("ksp")
        || c.startsWith("ksp")) return Scope.PROCESSOR;
    if (c.endsWith("implementation") || c.endsWith("api") || c.endsWith("compile")) return Scope.COMPILE;
    return Scope.OTHER;
  }

  /** هل يبدو الاسم إعداد اعتماد معروفًا (لتمييزه عن أي استدعاء آخر داخل الكتلة)؟ */
  static boolean looksLikeConfiguration(String name) {
    if (NOT_CONFIGURATIONS.contains(name)) return false;
    String c = name.toLowerCase(Locale.US);
    return c.endsWith("implementation") || c.endsWith("api") || c.endsWith("compile")
        || c.endsWith("compileonly") || c.endsWith("provided") || c.endsWith("runtimeonly")
        || c.equals("runtime") || c.endsWith("annotationprocessor") || c.startsWith("kapt")
        || c.startsWith("ksp") || c.endsWith("apk") || c.equals("coreLibraryDesugaring".toLowerCase(Locale.US))
        || c.equals("lintchecks") || c.equals("lintpublish") || c.equals("wearapp")
        || c.equals("detektplugins") || c.equals("classpath");
  }

  // ═══════════════ تحليل الاعتماديات ═══════════════

  /** تحليل كتل dependencies العليا (لا داخل buildscript/allprojects/subprojects). */
  public static List<Dependency> parseDependencies(String text, boolean kts, Map<String, String> vars,
      Map<String, String> libraries, Map<String, List<String>> bundles, String kotlinVersion) {
    List<Dependency> out = new ArrayList<>();
    if (text == null || text.isEmpty()) return out;
    String masked = maskComments(text);
    for (Block block : blocks(masked)) {
      if (!block.name.equals("dependencies") || block.insideAny("buildscript", "allprojects", "subprojects",
          "constraints", "pluginManagement")) continue;
      int pos = block.open + 1;
      while (pos < block.close) {
        pos = skipSpace(masked, pos, block.close);
        if (pos >= block.close) break;
        int end = statementEnd(masked, pos, block.close);
        parseStatement(text, masked, pos, end, kts, vars, libraries, bundles, kotlinVersion, out);
        pos = Math.max(end, pos + 1);
      }
    }
    return out;
  }

  private static final Pattern STATEMENT_HEAD = Pattern.compile("([A-Za-z_][A-Za-z0-9_]*)");

  private static void parseStatement(String text, String masked, int start, int end, boolean kts,
      Map<String, String> vars, Map<String, String> libraries, Map<String, List<String>> bundles,
      String kotlinVersion, List<Dependency> out) {
    String statement = masked.substring(start, end);
    Matcher head = STATEMENT_HEAD.matcher(statement);
    if (!head.lookingAt()) return;
    String configuration = head.group(1);
    // KTS: "implementation"(…) نادر؛ والإعدادات المقتبسة تُعامل كاسمها.
    if (!looksLikeConfiguration(configuration)) return;
    String rest = statement.substring(head.end()).trim();
    if (rest.isEmpty() || rest.startsWith("=") || rest.startsWith(".")) return;
    rest = stripTrailingClosure(rest);
    if (rest.startsWith("(")) {
      int close = matchClose(rest, 0);
      if (close == rest.length() - 1) rest = rest.substring(1, close).trim();
    }
    if (rest.isEmpty()) return;
    int line = lineOf(text, start);
    int trimmedEnd = start + statement.replaceAll("\\s+$", "").length();
    List<String> args = splitTopLevel(rest, ',');
    if (isNamedMap(args)) {
      out.add(fromNamedMap(configuration, args, vars, start, trimmedEnd, line));
      return;
    }
    for (String arg : args) {
      // ('g:a:v', { exclude … }): الإغلاق وسيطًا داخل القوسين إعداد للاعتماد، لا اعتماد.
      if (arg.trim().startsWith("{")) continue;
      notation(configuration, arg.trim(), kts, vars, libraries, bundles, kotlinVersion, false, start, trimmedEnd, line, out);
    }
  }

  private static void notation(String configuration, String arg, boolean kts, Map<String, String> vars,
      Map<String, String> libraries, Map<String, List<String>> bundles, String kotlinVersion, boolean platform,
      int start, int end, int line, List<Dependency> out) {
    if (arg.isEmpty()) return;
    Matcher call = Pattern.compile("^([A-Za-z_][A-Za-z0-9_]*)\\s*\\((.*)\\)$", Pattern.DOTALL).matcher(arg);
    if (call.matches() && matchClose(arg, arg.indexOf('(')) == arg.length() - 1) {
      String function = call.group(1);
      String inner = call.group(2).trim();
      switch (function) {
        case "platform":
        case "enforcedPlatform":
          notation(configuration, inner, kts, vars, libraries, bundles, kotlinVersion, true, start, end, line, out);
          return;
        case "fileTree":
        case "files":
          out.add(new Dependency(configuration, Kind.FILES, arg, arg, null, null, platform, start, end, line));
          return;
        case "project":
          out.add(new Dependency(configuration, Kind.PROJECT, arg, projectPath(inner), null, null, platform, start, end, line));
          return;
        case "kotlin":
          out.add(kotlinModule(configuration, inner, vars, kotlinVersion, platform, start, end, line));
          return;
        default:
          out.add(new Dependency(configuration, Kind.UNSUPPORTED, arg, arg, null, null, platform, start, end, line));
          return;
      }
    }
    if (isStringLiteral(arg)) {
      out.add(fromString(configuration, arg, kts, vars, platform, start, end, line));
      return;
    }
    // libs.androidx.core.ktx أو libs.bundles.x (كتالوج الإصدارات)
    String accessor = arg.replaceAll("\\s+", "");
    if (accessor.matches("[A-Za-z_][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)+")) {
      String catalog = accessor.substring(0, accessor.indexOf('.'));
      String path = accessor.substring(catalog.length() + 1);
      if (catalogExists(catalog, libraries, bundles)) {
        if (path.startsWith("bundles.")) {
          List<String> members = bundles.get(catalog + ":" + normalizeAlias(path.substring(8)));
          if (members == null) {
            out.add(new Dependency(configuration, Kind.UNRESOLVED_VARIABLE, accessor, accessor, null, accessor, platform, start, end, line));
            return;
          }
          for (String member : members) out.add(fromValue(configuration, accessor, member, platform, start, end, line));
          return;
        }
        String value = libraries.get(catalog + ":" + normalizeAlias(path));
        if (value == null) {
          out.add(new Dependency(configuration, Kind.UNRESOLVED_VARIABLE, accessor, accessor, null, accessor, platform, start, end, line));
          return;
        }
        out.add(fromValue(configuration, accessor, value, platform, start, end, line));
        return;
      }
    }
    // مرجع متغير يحمل نص الإحداثيات (ext.appcompat = '…' ثم implementation appcompat)
    String key = normalizeVariable(accessor);
    if (vars.containsKey(key)) {
      out.add(fromValue(configuration, accessor, vars.get(key), platform, start, end, line));
      return;
    }
    out.add(new Dependency(configuration, Kind.UNSUPPORTED, arg, arg, null, null, platform, start, end, line));
  }

  private static boolean catalogExists(String catalog, Map<String, String> libraries, Map<String, List<String>> bundles) {
    String prefix = catalog + ":";
    for (String key : libraries.keySet()) if (key.startsWith(prefix)) return true;
    for (String key : bundles.keySet()) if (key.startsWith(prefix)) return true;
    return false;
  }

  private static Dependency fromString(String configuration, String literal, boolean kts, Map<String, String> vars,
      boolean platform, int start, int end, int line) {
    char quote = literal.charAt(0);
    String raw = unquote(literal);
    boolean interpolates = kts || quote == '"';
    if (!interpolates && raw.indexOf('$') >= 0) {
      // Groovy: '…$x' لا يُستبدل أبدًا فيُطلب حرفيًا ويفشل — خطأ مؤكد كما في المرجع.
      Matcher name = Pattern.compile("\\$\\{?\\s*([A-Za-z_][\\w.]*)").matcher(raw);
      String variable = name.find() ? name.group(1) : "$";
      return new Dependency(configuration, Kind.UNRESOLVED_VARIABLE, raw, raw, null, variable, platform, start, end, line, true);
    }
    String[] missing = new String[1];
    String value = interpolate(raw, vars, missing);
    if (missing[0] != null) {
      return unresolved(configuration, raw, missing[0], platform, start, end, line);
    }
    return fromValue(configuration, raw, value, platform, start, end, line);
  }

  /** نص إحداثيات نهائي (بعد الاستبدال) → MAVEN أو MISSING_VERSION أو INVALID. */
  private static Dependency fromValue(String configuration, String raw, String value, boolean platform,
      int start, int end, int line) {
    String trimmed = value.trim();
    MavenStore.Coordinate coordinate = MavenStore.Coordinate.parse(trimmed);
    if (coordinate != null) {
      return new Dependency(configuration, Kind.MAVEN, raw, trimmed, coordinate, null, platform, start, end, line);
    }
    if (trimmed.matches("[A-Za-z0-9_.\\-]+:[A-Za-z0-9_.\\-]+")) {
      return new Dependency(configuration, Kind.MISSING_VERSION, raw, trimmed, null, null, platform, start, end, line);
    }
    return new Dependency(configuration, Kind.INVALID, raw, trimmed, null, null, platform, start, end, line);
  }

  /** متغير مفقود: خطأ إن كان اسمًا بسيطًا، وغير قابل للإثبات إن كان تعبيرًا أو ثابت صنف. */
  private static Dependency unresolved(String configuration, String raw, String missing, boolean platform,
      int start, int end, int line) {
    if (missing.startsWith(UNPROVABLE)) {
      return new Dependency(configuration, Kind.UNSUPPORTED, raw, raw, null, null, platform, start, end, line);
    }
    return new Dependency(configuration, Kind.UNRESOLVED_VARIABLE, raw, raw, null, missing, platform, start, end, line);
  }

  private static boolean isNamedMap(List<String> args) {
    for (String arg : args) {
      if (arg.trim().matches("(?s)(group|name|version|classifier|ext)\\s*[:=].*")) return true;
    }
    return false;
  }

  private static Dependency fromNamedMap(String configuration, List<String> args, Map<String, String> vars,
      int start, int end, int line) {
    Map<String, String> map = new LinkedHashMap<>();
    String raw = String.join(", ", args).trim();
    for (String arg : args) {
      Matcher entry = Pattern.compile("(?s)\\s*(\\w+)\\s*[:=]\\s*(.+?)\\s*").matcher(arg);
      if (!entry.matches()) continue;
      String valueText = entry.group(2);
      String value;
      if (isStringLiteral(valueText)) {
        boolean interpolates = valueText.charAt(0) == '"';
        String inner = unquote(valueText);
        if (!interpolates && inner.indexOf('$') >= 0) {
          return new Dependency(configuration, Kind.UNRESOLVED_VARIABLE, raw, raw, null, inner, false, start, end, line, true);
        }
        String[] missing = new String[1];
        value = interpolate(inner, vars, missing);
        if (missing[0] != null) {
          return unresolved(configuration, raw, missing[0], false, start, end, line);
        }
      } else {
        String key = normalizeVariable(valueText.replaceAll("\\s+", ""));
        value = vars.get(key);
        if (value == null) {
          return new Dependency(configuration, Kind.UNSUPPORTED, raw, raw, null, null, false, start, end, line);
        }
      }
      map.put(entry.group(1), value);
    }
    String group = map.get("group"), name = map.get("name"), version = map.get("version");
    if (group == null && name != null) {
      // implementation(name: 'lib', ext: 'aar') — مرجع flatDir وليس إحداثيات Maven.
      return new Dependency(configuration, Kind.FILES, raw, name + (map.get("ext") == null ? "" : "." + map.get("ext")), null, null, false, start, end, line);
    }
    if (group == null || name == null) {
      return new Dependency(configuration, Kind.INVALID, raw, raw, null, null, false, start, end, line);
    }
    StringBuilder value = new StringBuilder(group).append(':').append(name);
    if (version != null) value.append(':').append(version);
    if (version != null && map.get("classifier") != null) value.append(':').append(map.get("classifier"));
    if (version != null && map.get("ext") != null) value.append('@').append(map.get("ext"));
    return fromValue(configuration, raw, value.toString(), false, start, end, line);
  }

  private static Dependency kotlinModule(String configuration, String inner, Map<String, String> vars,
      String kotlinVersion, boolean platform, int start, int end, int line) {
    List<String> args = splitTopLevel(inner, ',');
    String raw = "kotlin(" + inner + ")";
    if (args.isEmpty() || !isStringLiteral(args.get(0).trim())) {
      return new Dependency(configuration, Kind.UNSUPPORTED, raw, raw, null, null, platform, start, end, line);
    }
    String module = unquote(args.get(0).trim());
    String version = null;
    if (args.size() > 1) {
      String second = args.get(1).trim().replaceFirst("^version\\s*=\\s*", "");
      if (isStringLiteral(second)) {
        String[] missing = new String[1];
        version = interpolate(unquote(second), vars, missing);
        if (missing[0] != null) {
          return unresolved(configuration, raw, missing[0], platform, start, end, line);
        }
      }
    }
    if (version == null) version = kotlinVersion;
    if (version == null) {
      return new Dependency(configuration, Kind.MISSING_VERSION, raw, "org.jetbrains.kotlin:kotlin-" + module, null, null, platform, start, end, line);
    }
    return fromValue(configuration, raw, "org.jetbrains.kotlin:kotlin-" + module + ":" + version, platform, start, end, line);
  }

  private static String projectPath(String inner) {
    Matcher path = Pattern.compile("['\"]([^'\"]+)['\"]").matcher(inner);
    return path.find() ? path.group(1) : inner;
  }

  /** يقطع إغلاق {@code { exclude … }} اللاحق على المستوى الأعلى. */
  static String stripTrailingClosure(String rest) {
    int depth = 0;
    for (int i = 0; i < rest.length(); i++) {
      char c = rest.charAt(i);
      if (c == '"' || c == '\'') {
        i = skipString(rest, i) - 1;
        continue;
      }
      if (c == '(' || c == '[') depth++;
      else if (c == ')' || c == ']') depth--;
      else if (c == '{' && depth == 0) return rest.substring(0, i).trim();
    }
    return rest;
  }

  // ═══════════════ المتغيرات ═══════════════

  private static final Pattern EXT_ASSIGN =
      Pattern.compile("(?:\\b(?:project|rootProject)\\s*\\.\\s*)?\\bext\\s*\\.\\s*([A-Za-z_]\\w*)\\s*=(?!=)\\s*");
  private static final Pattern EXT_SET =
      Pattern.compile("\\b(?:ext|extra)\\s*\\.\\s*set\\s*\\(\\s*['\"]([A-Za-z_]\\w*)['\"]\\s*,\\s*");
  private static final Pattern EXT_INDEX =
      Pattern.compile("\\b(?:ext|extra)\\s*\\[\\s*['\"]([A-Za-z_]\\w*)['\"]\\s*\\]\\s*=(?!=)\\s*");
  private static final Pattern LOCAL_DECLARATION =
      Pattern.compile("\\b(?:def|val|var|String)\\s+([A-Za-z_]\\w*)\\s*(?::\\s*String\\s*)?=(?!=)\\s*");
  private static final Pattern BY_EXTRA =
      Pattern.compile("\\bval\\s+([A-Za-z_]\\w*)\\s*(?::\\s*String\\s*)?by\\s+extra\\s*\\(\\s*");
  private static final Pattern APPLY_FROM =
      Pattern.compile("\\bapply\\s*\\(?\\s*from\\s*[:=]\\s*(['\"][^'\"]+['\"])");

  /** يجمع المتغيرات بترتيب ظهورها في الملف، ويتبع {@code apply from} (حتى عمق 3). */
  static void collectVariables(File file, String text, Map<String, String> vars, Set<String> applied, int depth) {
    if (text == null || text.isEmpty() || depth > 3) return;
    String masked = maskComments(text);
    List<int[]> hits = new ArrayList<>();
    List<String> names = new ArrayList<>();
    collect(EXT_ASSIGN, masked, hits, names);
    collect(EXT_SET, masked, hits, names);
    collect(EXT_INDEX, masked, hits, names);
    collect(LOCAL_DECLARATION, masked, hits, names);
    collect(BY_EXTRA, masked, hits, names);
    // داخل كتل ext { name = value } و{ set('name', value) }
    for (Block block : blocks(masked)) {
      if (!block.name.equals("ext")) continue;
      Matcher assign = Pattern.compile("(?m)(?:^|;)\\s*([A-Za-z_]\\w*)\\s*=(?!=)\\s*").matcher(masked);
      assign.region(block.open + 1, block.close);
      while (assign.find()) {
        if (depthWithin(masked, block.open + 1, assign.start()) != 0) continue;
        hits.add(new int[] {assign.start(), assign.end()});
        names.add(assign.group(1));
      }
      Matcher set = Pattern.compile("\\bset\\s*\\(\\s*['\"]([A-Za-z_]\\w*)['\"]\\s*,\\s*").matcher(masked);
      set.region(block.open + 1, block.close);
      while (set.find()) {
        hits.add(new int[] {set.start(), set.end()});
        names.add(set.group(1));
      }
    }
    Matcher apply = APPLY_FROM.matcher(masked);
    while (apply.find()) {
      hits.add(new int[] {apply.start(), -1});
      names.add(apply.group(1));
    }
    Integer[] order = new Integer[hits.size()];
    for (int i = 0; i < order.length; i++) order[i] = i;
    Arrays.sort(order, (a, b) -> Integer.compare(hits.get(a)[0], hits.get(b)[0]));
    for (Integer index : order) {
      int[] hit = hits.get(index);
      String name = names.get(index);
      if (hit[1] < 0) {
        String[] missing = new String[1];
        String path = interpolate(unquote(name), vars, missing);
        if (missing[0] != null || path.startsWith("http")) continue;
        File script = new File(path);
        if (!script.isAbsolute()) script = new File(file.getAbsoluteFile().getParentFile(), path);
        String key = script.getAbsolutePath();
        if (script.isFile() && applied.add(key)) collectVariables(script, readText(script), vars, applied, depth + 1);
        continue;
      }
      readValue(masked, hit[1], name, vars);
    }
  }

  private static void collect(Pattern pattern, String masked, List<int[]> hits, List<String> names) {
    Matcher matcher = pattern.matcher(masked);
    while (matcher.find()) {
      hits.add(new int[] {matcher.start(), matcher.end()});
      names.add(matcher.group(1));
    }
  }

  /** يقرأ قيمة عند الموضع: نص، رقم، خريطة {@code [k: v]} أو {@code mapOf("k" to v)}، أو مرجع متغير. */
  private static void readValue(String masked, int pos, String name, Map<String, String> vars) {
    pos = skipSpace(masked, pos, masked.length());
    if (pos >= masked.length()) return;
    char c = masked.charAt(pos);
    if (c == '"' || c == '\'') {
      int end = skipString(masked, pos);
      String literal = masked.substring(pos, end);
      String inner = unquote(literal);
      if (c == '\'' && !literal.startsWith("'''")) {
        vars.put(name, inner);
        return;
      }
      String[] missing = new String[1];
      String value = interpolate(inner, vars, missing);
      if (missing[0] == null) vars.put(name, value);
      return;
    }
    if (c == '[') {
      int close = matchClose(masked, pos);
      if (close < 0) return;
      readMap(masked.substring(pos + 1, close), name, vars);
      return;
    }
    if (masked.startsWith("mapOf", pos)) {
      int open = masked.indexOf('(', pos);
      int close = open < 0 ? -1 : matchClose(masked, open);
      if (close < 0) return;
      for (String entry : splitTopLevel(masked.substring(open + 1, close), ',')) {
        Matcher pair = Pattern.compile("(?s)\\s*\"([A-Za-z_][\\w]*)\"\\s+to\\s+(.+?)\\s*").matcher(entry);
        if (pair.matches()) storeScalar(name + "." + pair.group(1), pair.group(2), vars);
      }
      return;
    }
    Matcher token = Pattern.compile("[A-Za-z0-9_.+\\-]+").matcher(masked);
    token.region(pos, masked.length());
    if (token.lookingAt()) storeScalar(name, token.group(), vars);
  }

  private static void readMap(String body, String prefix, Map<String, String> vars) {
    for (String entry : splitTopLevel(body, ',')) {
      Matcher pair = Pattern.compile("(?s)\\s*['\"]?([A-Za-z_][\\w\\-]*)['\"]?\\s*:\\s*(.+?)\\s*").matcher(entry);
      if (!pair.matches()) continue;
      String key = prefix + "." + pair.group(1);
      String value = pair.group(2);
      if (value.startsWith("[")) {
        int close = matchClose(value, 0);
        if (close > 0) readMap(value.substring(1, close), key, vars);
      } else {
        storeScalar(key, value, vars);
      }
    }
  }

  private static void storeScalar(String name, String valueText, Map<String, String> vars) {
    String value = valueText.trim();
    if (isStringLiteral(value)) {
      String inner = unquote(value);
      if (value.charAt(0) == '\'') {
        vars.put(name, inner);
        return;
      }
      String[] missing = new String[1];
      String resolved = interpolate(inner, vars, missing);
      if (missing[0] == null) vars.put(name, resolved);
      return;
    }
    if (value.matches("-?\\d+(\\.\\d+)*[A-Za-z]?")) {
      vars.put(name, value.replaceAll("[LlFfDd]$", ""));
      return;
    }
    String reference = normalizeVariable(value.replaceAll("\\s+", ""));
    if (vars.containsKey(reference)) vars.put(name, vars.get(reference));
  }

  /** يزيل بادئات الوصول: rootProject.ext.x، project.x، ext.x، extra["x"] → x. */
  static String normalizeVariable(String reference) {
    String key = reference.trim();
    Matcher extra = Pattern.compile("(?:rootProject\\.|project\\.)?extra\\[\"([^\"]+)\"\\](?:\\s+as\\s+\\w+)?").matcher(key);
    if (extra.matches()) return extra.group(1);
    key = key.replaceFirst("^rootProject\\.ext\\.", "").replaceFirst("^project\\.ext\\.", "")
        .replaceFirst("^rootProject\\.", "").replaceFirst("^project\\.", "").replaceFirst("^ext\\.", "");
    return key;
  }

  /**
   * استبدال {@code $x} و{@code ${x}} و{@code ${rootProject.ext.x}}. أول متغير مفقود يُكتب في
   * {@code missing[0]} ويُعاد النص كما هو.
   */
  public static String interpolate(String text, Map<String, String> vars, String[] missing) {
    if (text == null || text.indexOf('$') < 0) return text;
    StringBuilder out = new StringBuilder();
    int i = 0;
    while (i < text.length()) {
      char c = text.charAt(i);
      if (c == '\\' && i + 1 < text.length() && text.charAt(i + 1) == '$') {
        out.append('$');
        i += 2;
        continue;
      }
      if (c != '$') {
        out.append(c);
        i++;
        continue;
      }
      String expression;
      int next;
      if (i + 1 < text.length() && text.charAt(i + 1) == '{') {
        int close = text.indexOf('}', i + 2);
        if (close < 0) {
          missing[0] = text.substring(i + 2);
          return text;
        }
        expression = text.substring(i + 2, close).trim();
        next = close + 1;
      } else {
        Matcher name = Pattern.compile("[A-Za-z_][\\w]*(?:\\.[A-Za-z_][\\w]*)*").matcher(text);
        name.region(i + 1, text.length());
        if (!name.lookingAt()) {
          out.append(c);
          i++;
          continue;
        }
        expression = name.group();
        next = name.end();
      }
      if (!expression.matches("[A-Za-z_]\\w*(?:\\.[A-Za-z_]\\w*)*")
          && !expression.matches("(?:rootProject\\.|project\\.)?extra\\[\"[^\"]+\"\\](?:\\s+as\\s+\\w+)?")) {
        missing[0] = UNPROVABLE + expression;
        return text;
      }
      String key = normalizeVariable(expression);
      String value = vars.get(key);
      String tail = "";
      if (value == null && key.contains(".") && !expression.startsWith("{")) {
        // "$name.suffix": المتغير name ثم نص حرفي (مثل "$v.0" نادرًا)
        String first = key.substring(0, key.indexOf('.'));
        if (vars.containsKey(first) && !text.startsWith("${", i)) {
          value = vars.get(first);
          tail = key.substring(first.length());
        }
      }
      if (value == null) {
        // Versions.core وما شابه: ثابت صنف (buildSrc/إضافة) لا يُرى نصيًا.
        boolean classConstant = key.contains(".") && Character.isUpperCase(key.charAt(0));
        missing[0] = classConstant ? UNPROVABLE + expression : expression;
        return text;
      }
      out.append(value).append(tail);
      i = next;
    }
    return out.toString();
  }

  /** gradle.properties: key=value، key: value، key value؛ # و! تعليقات. */
  public static Map<String, String> parseProperties(String text) {
    Map<String, String> out = new LinkedHashMap<>();
    if (text == null) return out;
    for (String rawLine : text.split("\r?\n")) {
      String line = rawLine.trim();
      if (line.isEmpty() || line.startsWith("#") || line.startsWith("!")) continue;
      Matcher pair = Pattern.compile("([^=:\\s]+)\\s*[=:\\s]\\s*(.*)").matcher(line);
      if (pair.matches()) out.put(pair.group(1), pair.group(2).trim());
    }
    return out;
  }

  // ═══════════════ كتالوج الإصدارات ═══════════════

  /**
   * يقرأ {@code [versions]} و{@code [libraries]} و{@code [bundles]}. المفاتيح تُخزَّن
   * {@code catalog:alias.normalized} والقيمة إحداثيات (بإصدار أو بدونه).
   */
  public static void parseVersionCatalog(String text, String catalog, Map<String, String> libraries,
      Map<String, List<String>> bundles, Map<String, String> versions) {
    if (text == null) return;
    String section = "";
    Map<String, String> rawLibraries = new LinkedHashMap<>();
    Map<String, String> rawBundles = new LinkedHashMap<>();
    String[] lines = text.split("\r?\n");
    for (int i = 0; i < lines.length; i++) {
      String line = stripTomlComment(lines[i]).trim();
      if (line.isEmpty()) continue;
      if (line.startsWith("[") && line.endsWith("]") && !line.contains("=")) {
        section = line.substring(1, line.length() - 1).trim();
        continue;
      }
      int eq = line.indexOf('=');
      if (eq < 0) continue;
      String key = unquote(line.substring(0, eq).trim());
      String value = line.substring(eq + 1).trim();
      // مصفوفات متعددة الأسطر في [bundles]
      while (value.startsWith("[") && depthOf(value, '[', ']') > 0 && i + 1 < lines.length) {
        value += " " + stripTomlComment(lines[++i]).trim();
      }
      if (section.equals("versions")) {
        if (isStringLiteral(value)) versions.put(key, unquote(value));
        else if (value.startsWith("{")) {
          String strict = tomlField(value, "strictly", "require", "prefer");
          if (strict != null) versions.put(key, strict);
        }
      } else if (section.equals("libraries")) {
        rawLibraries.put(key, value);
      } else if (section.equals("bundles")) {
        rawBundles.put(key, value);
      }
    }
    for (Map.Entry<String, String> entry : rawLibraries.entrySet()) {
      String value = entry.getValue();
      String coordinate = null;
      if (isStringLiteral(value)) {
        coordinate = unquote(value);
      } else if (value.startsWith("{")) {
        String module = tomlField(value, "module");
        String group = tomlField(value, "group");
        String name = tomlField(value, "name");
        String base = module != null ? module : group != null && name != null ? group + ":" + name : null;
        if (base == null) continue;
        String version = tomlField(value, "version");
        String ref = tomlField(value, "version.ref");
        if (ref == null) {
          Matcher nested = Pattern.compile("version\\s*=\\s*\\{([^}]*)\\}").matcher(value);
          if (nested.find()) {
            ref = tomlField("{" + nested.group(1) + "}", "ref");
            if (ref == null) version = tomlField("{" + nested.group(1) + "}", "strictly", "require", "prefer");
          }
        }
        if (ref != null) version = versions.get(ref);
        coordinate = version == null ? base : base + ":" + version;
      }
      if (coordinate != null) libraries.put(catalog + ":" + normalizeAlias(entry.getKey()), coordinate);
    }
    for (Map.Entry<String, String> entry : rawBundles.entrySet()) {
      List<String> members = new ArrayList<>();
      Matcher alias = Pattern.compile("\"([^\"]+)\"").matcher(entry.getValue());
      while (alias.find()) {
        String coordinate = libraries.get(catalog + ":" + normalizeAlias(alias.group(1)));
        if (coordinate != null) members.add(coordinate);
      }
      bundles.put(catalog + ":" + normalizeAlias(entry.getKey()), members);
    }
  }

  /** Gradle يوحّد - و_ و. في الاسم المستعار إلى نقطة الوصول. */
  static String normalizeAlias(String alias) {
    return alias.replace('-', '.').replace('_', '.').toLowerCase(Locale.US);
  }

  private static String tomlField(String table, String... keys) {
    for (String key : keys) {
      Matcher field = Pattern.compile("(?:^|[{,\\s])" + Pattern.quote(key) + "\\s*=\\s*\"([^\"]*)\"").matcher(table);
      if (field.find()) return field.group(1);
    }
    return null;
  }

  private static String stripTomlComment(String line) {
    boolean inString = false;
    for (int i = 0; i < line.length(); i++) {
      char c = line.charAt(i);
      if (c == '"') inString = !inString;
      else if (c == '#' && !inString) return line.substring(0, i);
    }
    return line;
  }

  // ═══════════════ Kotlin ═══════════════

  private static boolean kotlinPluginApplied(String text) {
    String masked = maskComments(text);
    return Pattern.compile("['\"](?:kotlin-android|org\\.jetbrains\\.kotlin\\.(?:android|jvm|multiplatform))['\"]"
        + "|\\bkotlin\\s*\\(\\s*\"(?:android|jvm|multiplatform)\"\\s*\\)"
        + "|\\balias\\s*\\(\\s*libs\\.plugins\\.kotlin").matcher(masked).find();
  }

  private static String detectKotlinVersion(String text, Map<String, String> vars, Map<String, String> catalogVersions) {
    String masked = maskComments(text);
    Matcher plugin = Pattern.compile(
            "(?:id\\s*\\(?\\s*['\"]org\\.jetbrains\\.kotlin\\.[\\w.]+['\"]\\s*\\)?|kotlin\\s*\\(\\s*\"[\\w.]+\"\\s*\\))"
                + "\\s*version\\s*['\"]([^'\"]+)['\"]")
        .matcher(masked);
    if (plugin.find()) {
      String[] missing = new String[1];
      String value = interpolate(plugin.group(1), vars, missing);
      if (missing[0] == null) return value;
    }
    Matcher classpath = Pattern.compile("['\"]org\\.jetbrains\\.kotlin:kotlin-gradle-plugin:([^'\"]+)['\"]").matcher(masked);
    if (classpath.find()) {
      String[] missing = new String[1];
      String value = interpolate(classpath.group(1), vars, missing);
      if (missing[0] == null && value.indexOf('$') < 0) return value;
    }
    if (vars.containsKey("kotlin_version")) return vars.get("kotlin_version");
    if (catalogVersions.containsKey("kotlin")) return catalogVersions.get("kotlin");
    return null;
  }

  // ═══════════════ المستودعات ═══════════════

  /**
   * كتل {@code repositories} التي تحلّ اعتماديات المشروع: العليا، و{@code allprojects}، و
   * {@code subprojects}، و{@code dependencyResolutionManagement} — لا {@code buildscript} ولا
   * {@code pluginManagement} (تلك للإضافات).
   */
  public static List<Repository> parseRepositories(String text, Map<String, String> vars) {
    return repositoriesIn(text, vars, false);
  }

  /** مستودعات كتل repositories داخل buildscript أو pluginManagement فقط. */
  public static List<Repository> parseBuildscriptRepositories(String text, Map<String, String> vars) {
    return repositoriesIn(text, vars, true);
  }

  private static List<Repository> repositoriesIn(String text, Map<String, String> vars, boolean buildscript) {
    List<Repository> out = new ArrayList<>();
    if (text == null || text.isEmpty()) return out;
    String masked = maskComments(text);
    List<Block> all = blocks(masked);
    for (Block block : all) {
      if (!block.name.equals("repositories")
          || block.insideAny("buildscript", "pluginManagement") != buildscript) continue;
      String body = masked.substring(block.open + 1, block.close);
      int pos = 0;
      while (pos < body.length()) {
        pos = skipSpace(body, pos, body.length());
        if (pos >= body.length()) break;
        int end = closureStatementEnd(body, pos, statementEnd(body, pos, body.length()));
        Repository repository = repositoryOf(body.substring(pos, end).trim(), vars);
        if (repository != null) out.add(repository);
        pos = Math.max(end, pos + 1);
      }
    }
    return out;
  }

  private static Repository repositoryOf(String statement, Map<String, String> vars) {
    String compact = statement.replaceAll("\\s+", "");
    if (compact.startsWith("google(")) return new Repository(Repository.REMOTE, "google", GOOGLE_URL);
    if (compact.startsWith("mavenCentral(")) return new Repository(Repository.REMOTE, "mavenCentral", CENTRAL_URL);
    // jcenter مجمَّد للقراءة فقط: نخدمه من عنوانه أولًا، والمحرك يلحق Central مرآةً احتياطية.
    if (compact.startsWith("jcenter(")) return new Repository(Repository.REMOTE, "jcenter", JCENTER_URL);
    if (compact.startsWith("gradlePluginPortal(")) return new Repository(Repository.REMOTE, "gradlePluginPortal", PLUGIN_PORTAL_URL);
    if (compact.startsWith("mavenLocal(")) return new Repository(Repository.LOCAL, "mavenLocal", null);
    if (compact.startsWith("flatDir")) {
      Matcher dir = Pattern.compile("dirs?\\s*[(=]?\\s*['\"]([^'\"]+)['\"]").matcher(statement);
      if (!dir.find()) return null;
      String[] missing = new String[1];
      String path = interpolate(dir.group(1), vars, missing);
      return missing[0] == null ? new Repository(Repository.FLAT_DIR, "flatDir", path) : null;
    }
    if (compact.startsWith("maven")) {
      Matcher url = Pattern.compile(
              "(?:\\burl\\s*[=(]?\\s*(?:uri\\s*\\(\\s*)?|setUrl\\s*\\(\\s*|^maven\\s*\\(\\s*(?:url\\s*=\\s*)?(?:uri\\s*\\(\\s*)?)"
                  + "(['\"])(.+?)\\1")
          .matcher(statement);
      if (!url.find()) return null;
      String[] missing = new String[1];
      String value = interpolate(url.group(2), vars, missing);
      if (missing[0] != null) return null;
      if (value.startsWith("file:")) value = value.replaceFirst("^file:(//)?", "");
      if (!value.startsWith("http")) {
        return new Repository(Repository.LOCAL, "maven", value);
      }
      if (!value.endsWith("/")) value += "/";
      return new Repository(Repository.REMOTE, "maven", value);
    }
    return null;
  }

  // ═══════════════ أدوات المسح النصّي ═══════════════

  /** كتلة مسمّاة {@code name { … }} بمؤشر أبيها. */
  static final class Block {
    final String name;
    final int open;
    int close = -1;
    final Block parent;

    Block(String name, int open, Block parent) {
      this.name = name;
      this.open = open;
      this.parent = parent;
    }

    boolean insideAny(String... names) {
      for (Block b = parent; b != null; b = b.parent) {
        for (String n : names) if (b.name.equals(n)) return true;
      }
      return false;
    }
  }

  /** كل الكتل المسمّاة بمرور واحد مرتبةً بموضع الفتح (النصوص تُتخطّى؛ النص مُقنَّع التعليقات). */
  static List<Block> blocks(String masked) {
    List<Block> out = new ArrayList<>();
    List<Block> stack = new ArrayList<>();
    for (int i = 0; i < masked.length(); i++) {
      char c = masked.charAt(i);
      if (c == '"' || c == '\'') {
        i = skipString(masked, i) - 1;
        continue;
      }
      if (c == '{') {
        Block block = new Block(nameBefore(masked, i), i, stack.isEmpty() ? null : stack.get(stack.size() - 1));
        stack.add(block);
        out.add(block);
      } else if (c == '}' && !stack.isEmpty()) {
        stack.remove(stack.size() - 1).close = i;
      }
    }
    for (Block unclosed : stack) unclosed.close = masked.length();
    return out;
  }

  /** اسم المعرّف قبل {@code {}} مع تخطّي وسائط {@code (…)}: «maven(…) {» → maven. */
  private static String nameBefore(String s, int brace) {
    int i = brace - 1;
    while (i >= 0 && Character.isWhitespace(s.charAt(i))) i--;
    if (i >= 0 && s.charAt(i) == ')') {
      int depth = 0;
      for (; i >= 0; i--) {
        char c = s.charAt(i);
        if (c == ')') depth++;
        else if (c == '(' && --depth == 0) break;
      }
      if (i < 0) return ""; // ) بلا ( مطابق قبله
      i--;
      while (i >= 0 && Character.isWhitespace(s.charAt(i))) i--;
    }
    if (i < 0) return "";
    int end = i + 1;
    while (i >= 0 && (Character.isJavaIdentifierPart(s.charAt(i)))) i--;
    return s.substring(i + 1, end);
  }

  /** يستبدل التعليقات بمسافات (الأسطر محفوظة) مع احترام النصوص — الإزاحات لا تتغير. */
  public static String maskComments(String text) {
    char[] out = text.toCharArray();
    int i = 0;
    while (i < out.length) {
      char c = out[i];
      if (c == '"' || c == '\'') {
        i = skipString(text, i);
        continue;
      }
      if (c == '/' && i + 1 < out.length && out[i + 1] == '/') {
        while (i < out.length && out[i] != '\n') out[i++] = ' ';
        continue;
      }
      if (c == '/' && i + 1 < out.length && out[i + 1] == '*') {
        int end = text.indexOf("*/", i + 2);
        end = end < 0 ? out.length : end + 2;
        for (; i < end; i++) if (out[i] != '\n') out[i] = ' ';
        continue;
      }
      i++;
    }
    return new String(out);
  }

  /** موضع ما بعد نهاية النص الذي يبدأ عند {@code i} (يدعم الاقتباس الثلاثي والهروب). */
  static int skipString(String s, int i) {
    char quote = s.charAt(i);
    if (s.startsWith(String.valueOf(new char[] {quote, quote, quote}), i)) {
      int end = s.indexOf(new String(new char[] {quote, quote, quote}), i + 3);
      return end < 0 ? s.length() : end + 3;
    }
    for (int j = i + 1; j < s.length(); j++) {
      char c = s.charAt(j);
      if (c == '\\') {
        j++;
        continue;
      }
      if (c == quote) return j + 1;
      if (c == '\n') return j;
    }
    return s.length();
  }

  /** الإغلاق المطابق لـ{@code ( [ {} عند {@code open}، أو -1. */
  static int matchClose(String s, int open) {
    if (open < 0 || open >= s.length()) return -1;
    int depth = 0;
    for (int i = open; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '"' || c == '\'') {
        i = skipString(s, i) - 1;
        continue;
      }
      if (c == '(' || c == '[' || c == '{') depth++;
      else if (c == ')' || c == ']' || c == '}') {
        if (--depth == 0) return i;
      }
    }
    return -1;
  }

  /**
   * نهاية الجملة: سطر جديد على العمق صفر (ما لم ينتهِ السطر بفاصلة/عامل أو يبدأ التالي بنقطة)، أو
   * {@code ;}.
   */
  /**
   * داخل كتلة repositories: {@code maven { … } jcenter()} على سطر واحد عبارتان، فتنتهي الأولى بعد
   * إغلاقها إن تبعه اسم على السطر نفسه.
   */
  static int closureStatementEnd(String s, int start, int end) {
    int depth = 0;
    for (int i = start; i < end; i++) {
      char c = s.charAt(i);
      if (c == '"' || c == '\'') {
        i = Math.min(end, skipString(s, i)) - 1;
        continue;
      }
      if (c == '(' || c == '[' || c == '{') depth++;
      else if (c == ')' || c == ']' || c == '}') {
        depth--;
        if (depth == 0 && c == '}') {
          int next = i + 1;
          while (next < end && (s.charAt(next) == ' ' || s.charAt(next) == '\t')) next++;
          if (next < end && Character.isLetter(s.charAt(next))) return i + 1;
        }
      }
    }
    return end;
  }

  static int statementEnd(String s, int start, int limit) {
    int depth = 0;
    for (int i = start; i < limit; i++) {
      char c = s.charAt(i);
      if (c == '"' || c == '\'') {
        i = Math.min(limit, skipString(s, i)) - 1;
        continue;
      }
      if (c == '(' || c == '[' || c == '{') depth++;
      else if (c == ')' || c == ']' || c == '}') {
        if (depth == 0) return i;
        depth--;
      } else if (depth == 0 && c == ';') return i;
      else if (depth == 0 && c == '\n') {
        int back = i - 1;
        while (back >= start && (s.charAt(back) == ' ' || s.charAt(back) == '\t' || s.charAt(back) == '\r')) back--;
        char last = back >= start ? s.charAt(back) : '\n';
        int ahead = skipSpace(s, i, limit);
        char next = ahead < limit ? s.charAt(ahead) : '\n';
        if (last == ',' || last == '+' || last == '(' || last == '=' || next == '.') continue;
        return i;
      }
    }
    return limit;
  }

  private static int skipSpace(String s, int pos, int limit) {
    while (pos < limit && (Character.isWhitespace(s.charAt(pos)) || s.charAt(pos) == ';')) pos++;
    return pos;
  }

  private static int depthWithin(String s, int from, int to) {
    int depth = 0;
    for (int i = from; i < to; i++) {
      char c = s.charAt(i);
      if (c == '"' || c == '\'') {
        i = skipString(s, i) - 1;
        continue;
      }
      if (c == '(' || c == '[' || c == '{') depth++;
      else if (c == ')' || c == ']' || c == '}') depth--;
    }
    return depth;
  }

  private static int depthOf(String s, char open, char close) {
    int depth = 0;
    boolean inString = false;
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '"') inString = !inString;
      else if (!inString && c == open) depth++;
      else if (!inString && c == close) depth--;
    }
    return depth;
  }

  /** تقسيم على الفاصل في المستوى الأعلى فقط (خارج الأقواس والنصوص). */
  static List<String> splitTopLevel(String s, char separator) {
    List<String> out = new ArrayList<>();
    int depth = 0, last = 0;
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '"' || c == '\'') {
        i = skipString(s, i) - 1;
        continue;
      }
      if (c == '(' || c == '[' || c == '{') depth++;
      else if (c == ')' || c == ']' || c == '}') depth--;
      else if (c == separator && depth == 0) {
        out.add(s.substring(last, i));
        last = i + 1;
      }
    }
    String tail = s.substring(last);
    if (!tail.trim().isEmpty() || !out.isEmpty()) out.add(tail);
    return out;
  }

  static boolean isStringLiteral(String s) {
    if (s.length() < 2) return false;
    char q = s.charAt(0);
    if (q != '"' && q != '\'') return false;
    return skipString(s, 0) == s.length() && s.charAt(s.length() - 1) == q;
  }

  static String unquote(String s) {
    String t = s.trim();
    if (t.length() >= 6 && (t.startsWith("\"\"\"") || t.startsWith("'''"))) return t.substring(3, t.length() - 3);
    if (t.length() >= 2 && (t.charAt(0) == '"' || t.charAt(0) == '\'') && t.charAt(t.length() - 1) == t.charAt(0)) {
      return t.substring(1, t.length() - 1);
    }
    return t;
  }

  static int lineOf(String text, int offset) {
    int line = 0;
    for (int i = 0; i < offset && i < text.length(); i++) if (text.charAt(i) == '\n') line++;
    return line;
  }

  static String readText(File file) {
    if (file == null || !file.isFile()) return "";
    try (InputStream in = new FileInputStream(file)) {
      ByteArrayOutputStream bytes = new ByteArrayOutputStream();
      byte[] buffer = new byte[8192];
      int n;
      while ((n = in.read(buffer)) > 0) bytes.write(buffer, 0, n);
      return bytes.toString("UTF-8");
    } catch (Exception error) {
      return "";
    }
  }
}
