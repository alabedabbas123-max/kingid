package almlk;

/**
 * قرارُ **كيفَ تُرسَمُ العلامةُ** (غامقٌ/مائلٌ) على خطِّ المحرِّرِ الواحد — النقلُ الحرفيُّ لآليّةِ
 * المصدر في {@code com/aide/p000ui/views/editor/C0034x}: هُناك يُبنى الخطُّ بـ{@code
 * Typeface.create(typeface, style)} ويُترَكُ الغمقُ المصطنعُ إلا بشرطٍ واحد:
 * <pre>{@code fakeBold = (style & BOLD) == 0 ? false : !typeface.isBold();}</pre>
 * أي أنّهم **يُفعِّلونَ الغامقَ الحقيقيَّ للعائلةِ أولًا**، ولا يلجؤونَ إلى الغمقِ المصطنعِ إلا إذا لم
 * يكنْ في العائلةِ غامقٌ أصلًا؛ ومقياسُهُم على ذلكَ قياسُ {@code m183j6}: عرضُ «public» بخطٍّ غامقٍ
 * مقابلَ عرضِهِ سادةً — فإنْ تساوى العرضانِ فلا معنى لغامقٍ حقيقيٍّ في هذه العائلة.
 *
 * <p>الفرقُ عن سلوكِنا السابقِ جوهريٌّ لا تجميليٌّ: {@code setFakeBoldText(true)} الدائمُ كانَ يزيدُ
 * عرضَ المحارفِ في العائلاتِ التي تملِكُ غامقًا حقيقيًّا فيصطدمَ المحرِّرُ ذا العرضِ الثابتِ بانزياحِ
 * الأعمدة، والميلُ الدائمُ {@code setTextSkewX} كانَ يشوهُ العائلاتِ التي تملِكُ مائلًا حقيقيًّا.
 * السياسةُ إذن: <b>النمطُ الحقيقيُّ إن وُجِد، والمصطنعُ عندَ الضرورةِ فقط</b> — وهي مُنفَّذةٌ هنا دوالَّ
 * خالصةً حتى تُختبَرَ بلا Android، ويُطبِّقَها {@link StylePaintCache} على الدهّانِ نفسِهِ.
 */
public final class EditorEmphasisPolicy {

  /** أنماطُ {@code Typeface} بأرقامِها Android: لا ترجمةً وسيطةً بينَ العلامةِ والنمط. */
  public static final int TYPEFACE_NORMAL = 0;
  public static final int TYPEFACE_BOLD = 1;
  public static final int TYPEFACE_ITALIC = 2;
  public static final int TYPEFACE_BOLD_ITALIC = 3;

  /** ميلُ المصدرِ للمائلِ المصطنع (AIDE: {@code -0.22f}) — قدرٌ يُقرَأُ ولا يُتلفَضُ. */
  public static final float ITALIC_SKEW = -0.22f;

  private EditorEmphasisPolicy() {}

  /**
   * نمطُ الخطِّ المطلوبُ لعلامةِ نمطٍ لغويّ. أرقامُ علاماتِنا ({@code 1} غامق، {@code 2} مائل) مطابقةٌ
   * لأرقامِ {@code Typeface.Style} عمدًا — فالتحويلُ قناعٌ، لا جدول.
   */
  public static int typefaceStyleFor(int flags) {
    int bold = (flags & EditorSyntaxRoles.FLAG_BOLD) != 0 ? TYPEFACE_BOLD : 0;
    int italic = (flags & EditorSyntaxRoles.FLAG_ITALIC) != 0 ? TYPEFACE_ITALIC : 0;
    return bold | italic;
  }

  /** الغمقُ المصطنعُ فقط حين طُلِبَ غامقٌ ولم تُوفِّرِ العائلةُ غامقًا حقيقيًّا (شرطُ {@code C0034x}). */
  public static boolean useFakeBold(int flags, boolean familyHasRealBold) {
    return (flags & EditorSyntaxRoles.FLAG_BOLD) != 0 && !familyHasRealBold;
  }

  /** الميلُ المصطنعُ فقط حين طُلِبَ مائلٌ ولم تُوفِّرِ العائلةُ مائلًا حقيقيًّا — قياسُ الشرطِ نفسِهِ. */
  public static boolean useSyntheticItalic(int flags, boolean familyHasRealItalic) {
    return (flags & EditorSyntaxRoles.FLAG_ITALIC) != 0 && !familyHasRealItalic;
  }

  /** انحناءُ الدهّانِ الفعليّ: صفرٌ حين يكفي {@code Typeface.create} وحده. */
  public static float skewFor(int flags, boolean familyHasRealItalic) {
    return useSyntheticItalic(flags, familyHasRealItalic) ? ITALIC_SKEW : 0f;
  }

  /**
   * ترجمةُ قياسِ {@code C0034x.m183j6}: الغامقُ «مرئيٌّ» في هذه العائلةِ إذا غيّرَ عرضَ المحارف.
   * يُستعمَلُ حيثُ يهمُّ ثباتُ الشبكةِ (محرِّرُ عرضٍ ثابت): لا غامقَ مصطنعًا يزيحُ العمودَ ما دامَ
   * الغامقُ الحقيقيُّ موجودًا.
   */
  public static boolean boldChangesAdvance(float widthWithBold, float widthPlain) {
    return Float.compare(widthWithBold, widthPlain) != 0;
  }
}
