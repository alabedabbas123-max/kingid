package almlk;

import java.io.File;
import java.util.HashMap;

/**
 * فهرس موارد مشروع XML — المرحلة السابعة.
 *
 * <p>يمسح {@code res/} مرة واحدة ويبني خريطة {@code type/name → إعلان}، فالحل **بحث O(1)**
 * لا إعادة مسح — وهو منهج المرجع الذي يحلّ {@code @id/x} و{@code @+id/x} من الخريطة نفسها.
 *
 * <p>يُبنى على خيط خلفي (لا I/O على خيط الواجهة)، بمسح محارف مباشر بلا Regex، وبحدود
 * صريحة تمنع انفلات المسح على مشروع ضخم.
 */
public final class XmlResourceIndex {

  /** سقف يمنع فهرسة ملف قيم شاذ الحجم. */
  private static final int MAX_FILE_BYTES = 512 * 1024;
  /** سقف إجمالي للإعلانات. */
  private static final int MAX_DECLARATIONS = 20000;
  /** عمق أقصى لنزول شجرة المشروع بحثًا عن {@code res}. */
  private static final int MAX_DEPTH = 8;

  /** أنواع الموارد الملفّية: الإعلان هو الملف نفسه. */
  private static final String[] FILE_TYPES = {
    "drawable", "layout", "mipmap", "anim", "animator", "menu", "xml", "raw", "color", "font",
    "interpolator", "transition"
  };

  /** إعلان مورد: أين عُرّف. */
  public static final class Declaration {
    public final String type;
    public final String name;
    /** قيمة المورد لنصوص {@code values}، أو {@code null} للموارد الملفّية. */
    public final String value;
    /** المسار المطلق للملف المُعرِّف. */
    public final String file;
    /** رقم السطر (0 إن كان الإعلان هو الملف كله). */
    public final int line;
    /** إزاحة بداية الإعلان داخل الملف. */
    public final int offset;
    /** {@code true} للموارد الملفّية (الإعلان = الملف). */
    public final boolean fileBased;

    Declaration(
        String type, String name, String value, String file, int line, int offset, boolean fileBased) {
      this.type = type;
      this.name = name;
      this.value = value;
      this.file = file;
      this.line = line;
      this.offset = offset;
      this.fileBased = fileBased;
    }
  }

  private final HashMap<String, Declaration> byKey;
  private final File root;

  private XmlResourceIndex(File root, HashMap<String, Declaration> byKey) {
    this.root = root;
    this.byKey = byKey;
  }

  /** فهرس فارغ آمن — لا {@code null} ولا استثناء عند غياب الجذر. */
  public static XmlResourceIndex empty() {
    return new XmlResourceIndex(null, new HashMap<String, Declaration>());
  }

  public boolean isEmpty() {
    return byKey.isEmpty();
  }

  public int size() {
    return byKey.size();
  }

  public File root() {
    return root;
  }

  /** بحث O(1) بالمفتاح الموحّد {@code type/name}. */
  public Declaration lookup(String type, String name) {
    if (type == null || name == null) return null;
    return byKey.get(type + "/" + name);
  }

  /** بحث O(1) بمرجع محلول — الإعلان {@code @+id/x} والمرجع {@code @id/x} سواء. */
  public Declaration lookup(XmlResourceReference reference) {
    return reference == null ? null : byKey.get(reference.key());
  }

  /**
   * بناء الفهرس بمسح واحد. **يُستدعى على خيط خلفي حصرًا** لأنه يقرأ من القرص.
   *
   * @param projectRoot جذر المشروع المفتوح؛ {@code null} أو مسار غير موجود يعيد فهرسًا فارغًا.
   */
  public static XmlResourceIndex build(File projectRoot) {
    return build(projectRoot, null);
  }

  /**
   * بناءٌ بجذورٍ زائدةِ: مجلداتُ وحداتٍ مرتبطةٍ خارجَ الجذرِ تُمشى بنفسِ الماشي
   * وبعمقٍ يبدأُ من 1، فحدودُ {@code MAX_DEPTH} و{@code MAX_DECLARATIONS} ومجلداتُ
   * {@code build} و{@code .gradle} الممنوعةُ هي هي — لا ماكينةُ مسحٍ ثانيةَ.
   *
   * <p>الأسبقُ يفوزُ ({@link #put}): ما في المشروعِ المفتوحِ مقدّمٌ على ما في وحداتِ
   * ‏{@code include}، كما يفعلُ aapt بالوحدةِ الحاليةِ. وجذرٌ تحتَ المشروعِ يُتخطّى
   * لأنّ المسحَ الأولَ يراهُ فعلًا؛ والقائمةُ قد تكونُ {@code null} (وحدةٌ غيرُ معلَنةٍ)
   * فيعودُ السلوكُ كما كانَ قبلَ هذهِ المرحلةِ تمامًا.
   */
  public static XmlResourceIndex build(File projectRoot, java.util.List<File> extraRoots) {
    if (projectRoot == null || !projectRoot.isDirectory()) return empty();
    HashMap<String, Declaration> map = new HashMap<>();
    collectResDirs(projectRoot, 0, map);
    if (extraRoots != null) {
      String inside = absolute(projectRoot);
      for (File extra : extraRoots) {
        if (map.size() >= MAX_DECLARATIONS) break;
        if (extra == null || !extra.isDirectory()) continue;
        if (isSameOrInside(inside, extra)) continue;
        collectResDirs(extra, 1, map);
      }
    }
    return new XmlResourceIndex(projectRoot, map);
  }

  private static boolean isSameOrInside(String rootPath, File dir) {
    String candidate = absolute(dir);
    return candidate.equals(rootPath) || candidate.startsWith(rootPath + java.io.File.separator);
  }

  private static void collectResDirs(File dir, int depth, HashMap<String, Declaration> map) {
    if (depth > MAX_DEPTH || map.size() >= MAX_DECLARATIONS) return;
    File[] children = dir.listFiles();
    if (children == null) return;
    // جذرٌ مُصرَّحٌ بهِ قد يكونُ مجلدَ مواردَ نفسَهُ (‏`res.srcDirs = ['shared-res']`):
    // لا بحثَ عنِ الاسمِ ‏`res` حينَ يقولُ المشروعُ إنَّ هنا مواردَ.
    if (depth > 0 && looksLikeResDir(children)) {
      indexResFolder(dir, map);
      return;
    }
    for (File child : children) {
      if (map.size() >= MAX_DECLARATIONS) return;
      String name = child.getName();
      if (child.isDirectory()) {
        if (isSkippedDir(name)) continue;
        if ("res".equals(name)) indexResFolder(child, map);
        else collectResDirs(child, depth + 1, map);
      }
    }
  }

  /** ابنٌ واحدٌ باسمِ نوعِ مواردَ يكفي: ‏`values/`، ‏`drawable-night/`، ‏`layout/`… */
  private static boolean looksLikeResDir(File[] children) {
    for (File child : children) {
      if (child.isDirectory() && folderType(child.getName()) != null) return true;
    }
    return false;
  }

  private static boolean isSkippedDir(String name) {
    return "build".equals(name)
        || ".gradle".equals(name)
        || ".git".equals(name)
        || ".idea".equals(name)
        || "node_modules".equals(name)
        || ".cxx".equals(name);
  }

  /** يفهرس مجلد {@code res} واحدًا: موارد {@code values} ثم الموارد الملفّية. */
  private static void indexResFolder(File res, HashMap<String, Declaration> map) {
    File[] children = res.listFiles();
    if (children == null) return;
    for (File child : children) {
      if (!child.isDirectory()) continue;
      String folder = child.getName();
      String type = folderType(folder);
      if (type == null) continue;
      if ("values".equals(type)) {
        indexValuesFolder(child, map);
      } else if (isFileType(type)) {
        indexFileFolder(child, type, map);
      }
    }
  }

  /** اسم المجلد قبل الواصف: {@code drawable-hdpi} ← {@code drawable}، {@code values-ar} ← {@code values}. */
  private static String folderType(String folder) {
    int dash = folder.indexOf('-');
    String base = dash < 0 ? folder : folder.substring(0, dash);
    if (base.isEmpty()) return null;
    if ("values".equals(base)) return "values";
    return isFileType(base) ? base : null;
  }

  private static boolean isFileType(String type) {
    for (String candidate : FILE_TYPES) if (candidate.equals(type)) return true;
    return false;
  }

  /** المورد الملفّي: الإعلان هو الملف نفسه عند السطر 0. */
  private static void indexFileFolder(File folder, String type, HashMap<String, Declaration> map) {
    File[] files = folder.listFiles();
    if (files == null) return;
    for (File file : files) {
      if (map.size() >= MAX_DECLARATIONS || !file.isFile()) continue;
      String name = stripExtension(file.getName());
      if (name.isEmpty()) continue;
      put(map, new Declaration(type, name, null, absolute(file), 0, 0, true));
      indexInlineDeclarations(file, map);
    }
  }

  /**
   * يلتقط الإعلانات المكتوبة **داخل** ملف XML بصيغة {@code @+type/name}.
   *
   * <p>{@code @+id/root} في ملف layout هو الإعلان الفعلي لذلك المعرّف، وكان الفهرس يتجاهله لأنه
   * يفهرس أسماء الملفات وحدها — فيفشل «الانتقال إلى» على {@code @id/root} صامتًا رغم أن توثيق
   * {@link #lookup(XmlResourceReference)} يَعِد بأن الإعلان والمرجع «سواء». المرحلة التاسعة:
   * أغلقت الفجوة بين العقد والتنفيذ بدل تعديل العقد.
   *
   * <p>التعليقات وCDATA تُتخطى عبر ماسح البنية نفسه فلا يُفهرس اسم داخل تعليق، والحدود القائمة
   * ({@code MAX_FILE_BYTES} و{@code MAX_DECLARATIONS}) تُحترم كما في بقية المسارات.
   */
  private static void indexInlineDeclarations(File file, HashMap<String, Declaration> map) {
    if (map.size() >= MAX_DECLARATIONS) return;
    if (!file.getName().toLowerCase(java.util.Locale.US).endsWith(".xml")) return;
    if (file.length() > MAX_FILE_BYTES) return;
    String text = read(file);
    if (text == null) return;
    String path = absolute(file);
    int line = 0;
    int scanned = 0;
    int at = text.indexOf("@+");
    while (at >= 0 && map.size() < MAX_DECLARATIONS) {
      while (scanned <= at && scanned < text.length()) {
        if (text.charAt(scanned) == '\n') line++;
        scanned++;
      }
      int state = XmlStructureScanner.stateAt(text, at);
      if (state != XmlStructureScanner.COMMENT && state != XmlStructureScanner.CDATA) {
        XmlResourceReference reference = XmlResourceReference.at(text, at);
        if (reference != null && reference.declaration) {
          put(map, new Declaration(reference.type, reference.name, null, path, line, at, false));
          at = text.indexOf("@+", reference.end);
          continue;
        }
      }
      at = text.indexOf("@+", at + 2);
    }
  }

  private static String stripExtension(String fileName) {
    int dot = fileName.lastIndexOf('.');
    String base = dot < 0 ? fileName : fileName.substring(0, dot);
    if (base.endsWith(".9")) base = base.substring(0, base.length() - 2); // صور nine-patch
    return base;
  }

  /** موارد {@code values}: مسح محارف واحد لكل ملف يستخرج الوسوم وأسماءها. */
  private static void indexValuesFolder(File folder, HashMap<String, Declaration> map) {
    File[] files = folder.listFiles();
    if (files == null) return;
    for (File file : files) {
      if (map.size() >= MAX_DECLARATIONS || !file.isFile()) continue;
      if (!file.getName().toLowerCase(java.util.Locale.US).endsWith(".xml")) continue;
      if (file.length() > MAX_FILE_BYTES) continue;
      String text = read(file);
      if (text == null) continue;
      indexValuesText(text, absolute(file), map);
    }
  }

  /**
   * يستخرج الإعلانات من نص ملف قيم.
   *
   * <p>النوع من سمة {@code type} إن وُجدت (كما في {@code <item name="x" type="id"/>}) وإلا من
   * اسم الوسم ({@code <string>}، {@code <color>}، {@code <style>}…). والتعليقات تُتخطى فلا
   * يُفهرس اسم داخل تعليق.
   */
  static void indexValuesText(String text, String file, HashMap<String, Declaration> map) {
    int length = text.length();
    int line = 0;
    int i = 0;
    while (i < length && map.size() < MAX_DECLARATIONS) {
      char c = text.charAt(i);
      if (c == '\n') {
        line++;
        i++;
        continue;
      }
      if (c == '<' && XmlStructureScanner.regionMatches(text, i, "<!--")) {
        int close = XmlStructureScanner.indexOf(text, "-->", i + 4);
        if (close < 0) return;
        for (int k = i; k < close; k++) if (text.charAt(k) == '\n') line++;
        i = close + 3;
        continue;
      }
      if (c != '<' || i + 1 >= length || text.charAt(i + 1) == '/' || text.charAt(i + 1) == '!'
          || text.charAt(i + 1) == '?') {
        i++;
        continue;
      }

      int tagStart = i;
      int p = i + 1;
      while (p < length && isTagChar(text.charAt(p))) p++;
      String tag = text.substring(i + 1, p);
      int tagEnd = XmlStructureScanner.indexOf(text, ">", p);
      if (tagEnd < 0) return;

      String name = attribute(text, p, tagEnd, "name");
      if (name != null && !name.isEmpty() && !name.startsWith("@")) {
        String explicit = attribute(text, p, tagEnd, "type");
        String type = explicit != null && !explicit.isEmpty() ? explicit : tag;
        if (!type.isEmpty()) {
          int valueStart = tagEnd + 1;
          int valueEnd = XmlStructureScanner.indexOf(text, "</" + tag, valueStart);
          String value =
              valueEnd < 0 ? null : text.substring(valueStart, valueEnd).trim();
          put(map, new Declaration(type, name, value, file, line, tagStart, false));
        }
      }

      for (int k = i; k < tagEnd; k++) if (text.charAt(k) == '\n') line++;
      i = tagEnd + 1;
    }
  }

  /** يقرأ قيمة سمة ضمن مدى الوسم بمسح محارف، أو {@code null}. */
  private static String attribute(String text, int from, int to, String key) {
    int at = from;
    while (at < to) {
      int found = text.indexOf(key, at);
      if (found < 0 || found >= to) return null;
      boolean leftOk = found == from || !isTagChar(text.charAt(found - 1));
      int after = found + key.length();
      if (!leftOk || after >= to || text.charAt(after) != '=') {
        at = found + 1;
        continue;
      }
      int q = after + 1;
      while (q < to && (text.charAt(q) == ' ' || text.charAt(q) == '\t')) q++;
      if (q >= to) return null;
      char quote = text.charAt(q);
      if (quote != '"' && quote != '\'') return null;
      int close = text.indexOf(quote, q + 1);
      if (close < 0 || close > to) return null;
      return text.substring(q + 1, close);
    }
    return null;
  }

  private static boolean isTagChar(char c) {
    return (c >= 'a' && c <= 'z')
        || (c >= 'A' && c <= 'Z')
        || (c >= '0' && c <= '9')
        || c == '_'
        || c == '.'
        || c == ':'
        || c == '-';
  }

  /** أول تعريف يفوز — كسلوك aapt عند تكرار الاسم داخل الوحدة نفسها. */
  private static void put(HashMap<String, Declaration> map, Declaration declaration) {
    String key = declaration.type + "/" + declaration.name;
    if (!map.containsKey(key)) map.put(key, declaration);
  }

  private static String absolute(File file) {
    try {
      return file.getCanonicalPath();
    } catch (Exception ignored) {
      return file.getAbsolutePath();
    }
  }

  private static String read(File file) {
    java.io.InputStream stream = null;
    try {
      stream = new java.io.FileInputStream(file);
      java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream((int) Math.min(file.length(), MAX_FILE_BYTES));
      byte[] chunk = new byte[8192];
      int read;
      while ((read = stream.read(chunk)) > 0) buffer.write(chunk, 0, read);
      return new String(buffer.toByteArray(), "UTF-8");
    } catch (Exception ignored) {
      return null;
    } finally {
      if (stream != null) {
        try {
          stream.close();
        } catch (Exception ignored) {
          // لا إجراء
        }
      }
    }
  }
}
