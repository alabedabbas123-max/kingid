package almlk;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * مصدر الحقيقة الموحّد لقراءة مفاتيح الإعدادات — المرحلة 1 من خطة الإعدادات.
 *
 * <p>على منهج {@link CodeStyle}: قيمة فاسدة أو غائبة ترتدّ إلى الافتراضي بصمت بدل
 * إسقاط الميزة، والدوال النقية (تحليل/تقييد) قابلة للاختبار بلا Context.
 */
public final class AppSettings {
  public static final String KEY_LANGUAGE = "app_language";
  public static final String KEY_EDITOR_TABS = "editor_tabs";
  public static final String KEY_BROWSER_SWIPE = "browser_swipe";
  public static final String KEY_FONT_SIZE = "editor_font_size";
  public static final String KEY_AUTOSAVE = "autosafe_time";
  public static final String KEY_USE_SPACES = "use_spaces_for_tabs";
  public static final String KEY_TAB_SIZE = "tabsize";
  public static final String KEY_FORCE_SOFT_KEYBOARD = "force_soft_keyboard";
  public static final String KEY_COMPLETE_AFTER_DOT = "complete_after_dot";
  public static final String KEY_COMPLETE_AFTER_LETTER = "complete_after_letter";
  public static final String KEY_COMPLETE_ALL_TYPES = "complete_all_types";

  private AppSettings() {}

  public static SharedPreferences prefs(Context context) {
    return PreferenceManager.getDefaultSharedPreferences(context);
  }

  /**
   * مخزن مكتبات Maven وفق الإعدادات: {@code <noBackup>/.aide/maven} أو المجلد المخصّص (إن كان
   * مفعّلًا وقابلًا للكتابة)، مع مستودعات {@code user_m2repositories} المحلية.
   */
  public static MavenStore mavenStore(Context context) {
    SharedPreferences sp = prefs(context);
    return MavenStore.fromSettings(
        context.getNoBackupFilesDir(),
        sp.getBoolean(MavenStore.KEY_ENABLE_CUSTOM_DIR, false),
        sp.getString(MavenStore.KEY_CUSTOM_DIR, ""),
        sp.getString(MavenStore.KEY_LOCAL_REPOSITORIES, ""));
  }

  public static String language(Context context) {
    String value = prefs(context).getString(KEY_LANGUAGE, "default");
    return value == null ? "default" : value;
  }

  /** تبويبات المحرر ظاهرة افتراضيًا (سلوكنا القائم) ويمكن إخفاؤها. */
  public static boolean editorTabs(Context context) {
    return prefs(context).getBoolean(KEY_EDITOR_TABS, true);
  }

  public static boolean browserSwipe(Context context) {
    return prefs(context).getBoolean(KEY_BROWSER_SWIPE, true);
  }

  public static int fontSizeSp(Context context) {
    return clampInt(prefs(context).getString(KEY_FONT_SIZE, "12"), 12, 6, 40);
  }

  /** ثوانٍ؛ -1 = معطّل. */
  public static int autosaveSeconds(Context context) {
    return clampInt(prefs(context).getString(KEY_AUTOSAVE, "-1"), -1, -1, 3600);
  }

  public static boolean useSpacesForTabs(Context context) {
    return prefs(context).getBoolean(KEY_USE_SPACES, true);
  }

  public static int tabSize(Context context) {
    return choiceInt(prefs(context).getString(KEY_TAB_SIZE, "4"), 4, new int[] {2, 4, 8});
  }

  public static boolean forceSoftKeyboard(Context context) {
    return prefs(context).getBoolean(KEY_FORCE_SOFT_KEYBOARD, false);
  }

  public static boolean completeAfterDot(Context context) {
    return prefs(context).getBoolean(KEY_COMPLETE_AFTER_DOT, true);
  }

  public static boolean completeAfterLetter(Context context) {
    return prefs(context).getBoolean(KEY_COMPLETE_AFTER_LETTER, true);
  }

  public static boolean completeAllTypes(Context context) {
    return prefs(context).getBoolean(KEY_COMPLETE_ALL_TYPES, true);
  }

  // ═══════ الجولة 22/1 — صفوفُ Build & Run وAdvanced: كلُّ مفتاحٍ لهُ أثرٌ ═══════

  /** {@code advanced_setting_extra_repositories}: مستودعاتٌ يفصلُ بينَها {@code ;} (اصطلاحُ المرجعِ). */
  public static java.util.List<String> extraRepositories(Context context) {
    return RepositoryPolicy.split(
        prefs(context).getString(RepositoryPolicy.KEY_EXTRA_REPOSITORIES, ""));
  }

  /** {@code completion_show_api_info}: سطرُ «Added in API level …» في قائمةِ الإكمالِ. */
  public static boolean showApiInfo(Context context) {
    return prefs(context).getBoolean("completion_show_api_info", true);
  }

  /** {@code advanced_setting_enable_gradle}: true = {@code gradle} النظامِ، false = {@code gradlew} المشروعِ. */
  public static boolean useSystemGradle(Context context) {
    return prefs(context).getBoolean("advanced_setting_enable_gradle", false);
  }

  /** {@code adset_use_dexmerger}: «Fix the multiDex» عند المرجعِ ← قناةُ {@code SHIMA_DEX_MERGER}. */
  public static boolean dexMergerEnabled(Context context) {
    return prefs(context).getBoolean("adset_use_dexmerger", true);
  }

  /**
   * {@code advanced_setting_adjust_apk_build_path}: مخرَجُ APK معادُ تعريفِهِ — «build/bin» كما في
   * نصِّ المرجعِ حينَ يُفعَّلُ، وإلا "" فيُترَكُ للمخارجِ القياسيةِ. يُستعمَلُ مرتينِ: قناةُ
   * {@code SHIMA_APK_OUT} للمشروعِ، و`BuildOutputLocator` للبحثِ عن الناتجِ بعدَ البناءِ.
   */
  public static String apkOutputDir(Context context) {
    return prefs(context).getBoolean("advanced_setting_adjust_apk_build_path", false) ? "build/bin" : "";
  }

  /** {@code advanced_setting_package_prefix}: بادئةُ الحزمةِ في معالجِ «مشروعٌ جديدٌ» (com.mycompany.). */
  public static String packagePrefix(Context context) {
    String value = prefs(context).getString("advanced_setting_package_prefix", "com.mycompany.");
    return value == null || value.trim().isEmpty() ? "" : value.trim();
  }

  /** {@code project_home}: جذرُ المشاريعِ؛ "" = لا رأيَ للإعداداتِ. */
  public static String projectHome(Context context) {
    String value = prefs(context).getString("project_home", "");
    return value == null ? "" : value.trim();
  }

  /** ملفُّ قواعدِ إكمالِ Gradle المعتمدُ: `gradle_comple_file` أو الافتراضيُّ في ملفاتِ التطبيقِ. */
  public static java.io.File gradleRulesFile(Context context) {
    String custom = prefs(context).getString("gradle_comple_file", "");
    if (custom != null && !custom.trim().isEmpty()) return new java.io.File(custom.trim());
    return new java.io.File(context.getFilesDir(), "gradle_completion.rules");
  }

  /**
   * تطبيقُ قواعدِ الإكمالِ: تُحمَلُ من الملفِّ مرةً واحدةً لكلِّ نسخةٍ منهُ (طابعُ الحجمِ+التعديلِ)،
   * وتُسقَطُ كلُّها إذا أُقفِلَ `enable_gradle_comple`. تُنادى عندَ فتحِ المشروعِ وتطبيقِ الإعداداتِ
   * وحفظِ الملفِّ — لا عندَ كلِّ ضغطةِ مفتاحٍ.
   */
  public static void applyGradleCompletionRules(Context context) {
    boolean enabled = prefs(context).getBoolean("enable_gradle_comple", true);
    java.io.File file = gradleRulesFile(context);
    if (!enabled) {
      GradleCompletionProvider.USER_RULES = CompletionRules.EMPTY;
      GradleCompletionProvider.USER_RULES_ENABLED = false;
      cachedRules = CompletionRules.EMPTY;
      cachedStamp = "";
      return;
    }
    CompletionRules fresh = CompletionRules.load(file);
    if (cachedRules == null || !fresh.stamp().equals(cachedStamp) || cachedRules.isEmpty()) {
      cachedRules = fresh;
      cachedStamp = fresh.stamp();
    }
    GradleCompletionProvider.USER_RULES = cachedRules;
    GradleCompletionProvider.USER_RULES_ENABLED = true;
  }

  private static CompletionRules cachedRules;
  private static String cachedStamp = "";

  /** نقي: تحليل عدد صحيح مع تقييد بالنطاق، والفاسد يرتدّ للافتراضي. */
  public static int clampInt(String value, int fallback, int min, int max) {
    try {
      int parsed = Integer.parseInt(value == null ? "" : value.trim());
      return parsed < min || parsed > max ? fallback : parsed;
    } catch (NumberFormatException error) {
      return fallback;
    }
  }

  /** نقي: يقبل القيمة إن كانت ضمن مجموعة مسموحة فقط. */
  public static int choiceInt(String value, int fallback, int[] allowed) {
    try {
      int parsed = Integer.parseInt(value == null ? "" : value.trim());
      for (int candidate : allowed) if (candidate == parsed) return parsed;
    } catch (NumberFormatException ignored) {
      // يرتدّ للافتراضي
    }
    return fallback;
  }
}
