package almlk;

import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.shima.demo.R;
import java.util.ArrayList;
import java.util.List;

/**
 * فقاعة المؤشر: رسالة التشخيص وتحتها **صفٌّ لكل إصلاح سريع**، على شكل المرجع تمامًا
 * ({@code res/layout/error_popup.xml}: خلفية {@code @drawable/toast} وظلّ 4dp من
 * {@code style/ErrorPopup}، وحافة 10/6dp، ونصّ 14sp بتسطير مفرد مُبتَّر بـ«..»).
 *
 * <p>جاءت محلّ {@code ErrorMessagePopup} (رسالة فقط تُختتم ذاتيًا) لأن المرجع يعرض الإصلاحات **في
 * الفقاعة نفسها** عند موضع الخطأ، فلا يُرسل المستخدم إلى شريط «تحديد الإجراءات» ثم القائمة ثم الصف.
 * تبقى نافذة **بلا تركيز** كما كانت — فلا يُغلق الكيبورد ولا يُسرق التركيز من المحرر — لكنها صارت
 * <b>قابلة للمس</b> لتستجيب صفوف الإصلاح، وتُغلق بالنقر خارجها ({@code touchModal=false} فيمرّ
 * النقر الخارجي إلى المحرر ولا يُبتلع).
 *
 * <p>بلا إصلاحات تنحدر إلى السلوك القديم حرفيًا: رسالة تختفي بعد 2.5s (أو 4s للنص الطويل). ولمّا
 * تعذّر قياس موضع المؤشر (عرضٌ لم يُقَس بعد، أو محرر مُزال) استُعمل قاع الوعاء كما كان — فلا
 * استثناء ولا فقاعة خارج الشاشة.
 */
public final class QuickFixBubble {

  private static final long SHORT_MS = 2500L;
  private static final long LONG_MS = 4000L;
  private static final int LONG_TEXT = 60;
  /** هامش الفقاعة عن حافّتي الوعاء، وارتفاعها الأدنى عن أسفل الشاشة حين يسقط الموضع. */
  private static final float SIDE_MARGIN_DP = 16f;
  private static final float BOTTOM_FALLBACK_DP = 64f;
  private static final float EDGE_GAP_DP = 6f;

  /** صفّ في الفقاعة: {@code onPick == null} يعني سطر رسالة لا يُنقر عليه. */
  public static final class Entry {
    public final CharSequence label;
    public final Runnable onPick;

    public Entry(CharSequence label, Runnable onPick) {
      this.label = label == null ? "" : label;
      this.onPick = onPick;
    }
  }

  private final View anchor;
  private PopupWindow window;
  private LinearLayout rows;
  private CharSequence shownMessage = "";
  private final Runnable autoHide = this::dismiss;

  public QuickFixBubble(View anchor) {
    this.anchor = anchor;
  }

  /**
   * تعرض الفقاعة عند المؤشر: سطر الرسالة أولًا ثم صفوف الإصلاح بترتيبه (الأول أعلاه)، والنقر على
   * صفٍّ يطبّقه ويُغلق الفقاعة. {@code caretX/caretY} إحداثيات داخلية للوعاء أو {@code -1} عند
   * تعذّر القياس.
   */
  public void show(CharSequence message, List<Entry> fixes, int caretX, int caretY) {
    ArrayList<Entry> entries = new ArrayList<>();
    if (message != null && message.length() > 0) entries.add(new Entry(message, null));
    if (fixes != null) {
      for (Entry entry : fixes) if (entry != null && entry.label.length() > 0) entries.add(entry);
    }
    if (entries.isEmpty()) {
      dismiss();
      return;
    }
    if (anchor.getWindowToken() == null || !anchor.isShown()) return;
    ensureWindow();
    LayoutInflater inflater = LayoutInflater.from(anchor.getContext());
    rows.removeAllViews();
    for (Entry entry : entries) rows.addView(buildRow(inflater, entry));
    shownMessage = entries.get(0).label;
    boolean messageOnly = entries.size() == 1 && entries.get(0).onPick == null;
    place(caretX, caretY, messageOnly);
    anchor.removeCallbacks(autoHide);
    if (messageOnly) {
      anchor.postDelayed(autoHide, shownMessage.length() > LONG_TEXT ? LONG_MS : SHORT_MS);
    }
  }

  public void dismiss() {
    anchor.removeCallbacks(autoHide);
    shownMessage = "";
    if (window != null && window.isShowing()) {
      try {
        window.dismiss();
      } catch (RuntimeException alreadyGone) {
        // النافذة أُغلقت مع صاحبها (نشاط يُهدَم): لا شيء يُكمل.
      }
    }
  }

  private View buildRow(LayoutInflater inflater, Entry entry) {
    View row = inflater.inflate(R.layout.error_popup_entry, rows, false);
    TextView label = row.findViewById(R.id.errorPopupText);
    label.setText(entry.label);
    ImageView icon = row.findViewById(R.id.errorPopupIcon);
    // المرجع يستعمل project_errors للرسالة؛ وصفوف الإصلاح تحمل الحشرة نفسها في شريط التحديد.
    icon.setImageResource(entry.onPick == null ? R.drawable.project_errors : R.drawable.ic_menu_bugs);
    if (entry.onPick != null) {
      row.setClickable(true);
      row.setOnClickListener(
          view -> {
            Runnable pick = entry.onPick;
            dismiss();
            pick.run();
          });
    }
    return row;
  }

  /**
   * الموضع: عند المؤشر مع حجز داخل حدود الوعاء، أو قاع-وسط عند تعذّر القياس. {@code measureWidth}
   * يقيس المحتوى أولًا ليُحسب الانزلاق الأيمن (وإلا خرجت الفقاعة من الشاشة عند آخر سطر).
   */
  private void place(int caretX, int caretY, boolean measureWidth) {
    float density = anchor.getResources().getDisplayMetrics().density;
    int sideMargin = Math.round(SIDE_MARGIN_DP * density);
    View root = anchor.getRootView();
    int width = root.getWidth();
    int height = root.getHeight();
    boolean anchored = caretX >= 0 && caretY >= 0 && width > 0;
    if (anchored) {
      int gap = Math.round(EDGE_GAP_DP * density);
      if (measureWidth) {
        rows.measure(
            View.MeasureSpec.makeMeasureSpec(Math.max(0, width - sideMargin * 2),
                View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
      }
      int bubbleWidth = Math.max(1, rows.getMeasuredWidth());
      int x = Math.max(sideMargin, Math.min(caretX, width - sideMargin - bubbleWidth));
      int rowHeight = Math.max(1, rows.getMeasuredHeight());
      int y = Math.max(gap, Math.min(caretY + gap, height - gap - rowHeight));
      try {
        if (window.isShowing()) window.update(x, y, -1, -1);
        else window.showAtLocation(root, Gravity.TOP | Gravity.START, x, y);
        return;
      } catch (RuntimeException detached) {
        return;
      }
    }
    int bottomOffset = Math.round(BOTTOM_FALLBACK_DP * density);
    try {
      if (window.isShowing()) {
        window.getContentView().requestLayout();
        window.update();
      } else {
        window.showAtLocation(root, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, bottomOffset);
      }
    } catch (RuntimeException ignored) {
      // يختفي رمز النافذة بين الفحص والنداء (نشاط يُغلق): الفقاعة ترفه لا وظيفة.
    }
  }

  private void ensureWindow() {
    if (window != null) return;
    LinearLayout content =
        (LinearLayout)
            LayoutInflater.from(anchor.getContext()).inflate(R.layout.error_popup, null, false);
    rows = content;
    window =
        new PopupWindow(
            content,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            false);
    window.setTouchable(true);
    // اللمس خارجها يمرّ إلى المحرر (لا يبتلعه PopupWindow) ويغلقها في الوقت نفسه.
    window.setTouchModal(false);
    window.setOutsideTouchable(true);
    window.setFocusable(false);
    window.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED);
    window.setSoftInputMode(WindowManager_NeverAdjust());
    window.setBackgroundDrawable(new ColorDrawable(0));
    window.setAnimationStyle(android.R.style.Animation_Toast);
    window.setClippingEnabled(true);
    window.setOnDismissListener(() -> anchor.removeCallbacks(autoHide));
  }

  /** لا تُزاح الشاشة عند إظهار الفقاعة: الكيبورد يبقى كما هو (شرط لقطات المرجع). */
  private static int WindowManager_NeverAdjust() {
    return android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING;
  }
}
