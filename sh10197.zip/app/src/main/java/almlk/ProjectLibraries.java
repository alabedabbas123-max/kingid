package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * حالة مكتبات Maven للمشروع المفتوح (M3): ما حُقن بصمت في classpath، وما لم يُحلّ برسالته، وعلامات
 * أسطر الاعتماد في ملف الوحدة. جافا خالصة؛ دورة الفتح والحوار في الواجهة.
 *
 * <p>العلامات: متغير غير معرّف، و{@code $} داخل نص أحادي الاقتباس، وصيغة غير صالحة (من النص نفسه،
 * فتتبع التحرير الحي)، و«لم تُنزَّل بعد» أثناء التنزيل، و«Could not resolve g:a:v» بعد الفشل. ما
 * حُلّ لا يحمل أي علامة.
 */
public final class ProjectLibraries {

  /** سبب عدم الحلّ لجذر واحد. */
  public static final class Problem {
    public final String messageKey, fallback, argument;

    Problem(String messageKey, String fallback, String argument) {
      this.messageKey = messageKey;
      this.fallback = fallback;
      this.argument = argument;
    }

    public String message() {
      return String.format(java.util.Locale.US, fallback, argument);
    }
  }

  /** علامة على سطر اعتماد: مدى النص (إزاحات) وسطره وعموده (من 1) ورسالته. */
  public static final class Marker {
    public final int offset, end, line, column;
    public final Problem problem;

    Marker(int offset, int end, int line, int column, Problem problem) {
      this.offset = offset;
      this.end = end;
      this.line = line;
      this.column = column;
      this.problem = problem;
    }

    @Override
    public String toString() {
      return line + ":" + column + " " + problem.message();
    }
  }

  public static final String KEY_COULD_NOT_RESOLVE = "ui_maven_could_not_resolve";
  /** W21′3: الملفُّ موجودٌ باسمِ الأداةِ ولا يَحمِلُها — خطأٌ على سطرِها، لا رسالةُ «لم تُحَلَّ». */
  public static final String KEY_INCOMPLETE = "ui_maven_incomplete_install";
  public static final String KEY_NOT_DOWNLOADED = "ui_maven_not_downloaded";
  public static final String KEY_UNKNOWN_VARIABLE = "ui_maven_unknown_variable";
  public static final String KEY_LITERAL_DOLLAR = "ui_maven_literal_dollar";
  public static final String KEY_INVALID_NOTATION = "ui_maven_invalid_notation";

  private final Map<String, Problem> unresolved = new LinkedHashMap<>();
  private List<File> classpath = Collections.emptyList();
  private List<File> runtimeClasspath = Collections.emptyList();
  /** مجلدات AAR المفكوكة المرئية للترجمة (R.txt والموارد والحزمة لـM4). */
  private List<File> libraryDirs = Collections.emptyList();
  /** W22/4ب: ما في `libs/` من الوحدة؛ يُرصدُ فيزيائيًا ويُفهرسُ محليًّا بلا شبكةٍ. */
  private almlk.LocalLibraries.Finding locals = almlk.LocalLibraries.Finding.NONE;
  private String localsSignature = null;
  private String fingerprint = "";
  private boolean complete;
  /** إحداثيات كل الأدوات المحلولة للمشروع المفتوح (لحذف مكتباته وحده من الإعدادات). */
  private List<MavenStore.Coordinate> artifacts = Collections.emptyList();

  /**
   * يطبّق نتيجة حلّ. offlinePass: فحص الفتح المحلي — «غير موجود» يعني «لم تُنزَّل بعد» (ستُنزَّل)،
   * لا خطأً نهائيًا. الإلغاء لا يمسح الحقن السابق.
   */
  public synchronized void apply(MavenResolver.Result result, boolean offlinePass, String newFingerprint) {
    unresolved.clear();
    for (MavenResolver.Failure failure : result.failures) {
      if (failure.root == null) continue;
      String key = requestKey(failure.root);
      if (unresolved.containsKey(key)) continue;
      if (failure.type == MavenResolver.Failure.INCOMPLETE) {
        // «مكتبةٌ مُثبَّتةٌ» تُقالُ لمحتوى، لا لاسمٍ على القرصِ: السببُ يُذكَرُ كما وجدَهُ الفحصُ
        unresolved.put(key, new Problem(KEY_INCOMPLETE,
            "%1$s is not installed: the file under its name is not a usable library archive",
            failure.coordinate + (failure.reason == null || failure.reason.isEmpty()
                ? "" : " — " + failure.reason)));
        continue;
      }
      boolean pending = offlinePass && failure.type == MavenResolver.Failure.NOT_FOUND;
      unresolved.put(key, pending
          ? new Problem(KEY_NOT_DOWNLOADED, "Library not downloaded yet: %1$s", failure.coordinate)
          : new Problem(KEY_COULD_NOT_RESOLVE, "Could not resolve %1$s", failure.message().substring("Could not resolve ".length())));
    }
    if (!result.cancelled) {
      classpath = Collections.unmodifiableList(new ArrayList<>(result.classpath()));
      runtimeClasspath = Collections.unmodifiableList(new ArrayList<>(result.runtimeClasspath()));
      ArrayList<File> dirs = new ArrayList<>();
      for (MavenResolver.Artifact artifact : result.artifacts)
        if (artifact.compileVisible && artifact.aarDir != null && !dirs.contains(artifact.aarDir)) dirs.add(artifact.aarDir);
      libraryDirs = Collections.unmodifiableList(dirs);
      ArrayList<MavenStore.Coordinate> coordinates = new ArrayList<>();
      for (MavenResolver.Artifact artifact : result.artifacts) coordinates.add(artifact.coordinate);
      artifacts = Collections.unmodifiableList(coordinates);
    }
    complete = !result.cancelled && result.failures.isEmpty();
    fingerprint = newFingerprint == null ? "" : newFingerprint;
  }

  /** الإلغاء: الأسطر غير المنزّلة تبقى «لم تُنزَّل بعد» والبصمة تُنسى (يُعاد في الفتح القادم). */
  public synchronized void cancelled() {
    complete = false;
    fingerprint = "";
  }

  /** مكتبات المشروع حُذفت من المخزن: تُنسى البصمة والحقن فيُعاد الحلّ (والتنزيل) في الدورة القادمة. */
  public synchronized void invalidate() {
    locals = almlk.LocalLibraries.Finding.NONE;
    localsSignature = null;
    classpath = Collections.emptyList();
    runtimeClasspath = Collections.emptyList();
    libraryDirs = Collections.emptyList();
    artifacts = Collections.emptyList();
    complete = false;
    fingerprint = "";
  }

  /** إحداثيات أدوات المشروع المفتوح المحلولة (مباشرة ومتعدية). */
  public synchronized List<MavenStore.Coordinate> artifacts() {
    return artifacts;
  }

  public synchronized void clear() {
    locals = almlk.LocalLibraries.Finding.NONE;
    localsSignature = null;
    artifacts = Collections.emptyList();
    unresolved.clear();
    classpath = Collections.emptyList();
    runtimeClasspath = Collections.emptyList();
    libraryDirs = Collections.emptyList();
    fingerprint = "";
    complete = false;
  }

  /** الحلّ مكتمل لنفس ملفات البناء: لا حاجة لأي عمل عند الحفظ أو إعادة الفتح. */
  public synchronized boolean isUpToDate(String currentFingerprint) {
    return complete && !fingerprint.isEmpty() && fingerprint.equals(currentFingerprint);
  }

  public synchronized boolean isComplete() {
    // W32: «حُلَّ كلُّ شيءٍ» لا تُقالُ وفي `libs/` أرشيفٌ لم يُقرَأْ كلُّهُ: اليقينُ مِقبضٌ واحدٌ
    // للفهرسِ والمُحلِّلِ معًا (بلا استثناءِ مفاتيحَ)، فحيثُ لم نَعلَمْ لم نَحكُمْ.
    return complete && locals.isClean();
  }

  /** classpath الترجمة المحقون (للتحليل والإكمال في M4). */
  public synchronized List<File> classpath() {
    return classpath;
  }

  public synchronized List<File> runtimeClasspath() {
    return runtimeClasspath;
  }

  public synchronized List<File> libraryDirs() {
    return libraryDirs;
  }

  /**
   * W22/4ب: إعادةُ رصدٍ محليّةٍ رخيصةُ: قائمةُ `libs/` وبصمتُها فقطْ؛ إن لم
   * يتغيّر القرصُ لم يُفتّش-شَ أرشيفٌ ولا فُكَّ aar ولا لُمِسَت الشبكةُ. تُنادى من
   * خيطٍ الفهرسةٍ لا من خيطٍ الواجهةٍ — فتظهرُ أدواتُ المستخدمِ فورًا في الإكمالِ.
   */
  public synchronized void observeLocals(File moduleDir, File projectRoot, String buildText) {
    File libsDir = almlk.LocalLibraries.libsDirOf(moduleDir, projectRoot);
    String signature = almlk.LocalLibraries.signatureOf(libsDir);
    if (localsSignature != null && localsSignature.equals(signature)) return;
    locals = almlk.LocalLibraries.discover(moduleDir, projectRoot, buildText, null);
    localsSignature = signature;
  }

  public synchronized almlk.LocalLibraries.Finding localFinding() {
    return locals;
  }

  /** jar المحليّاتُ و`classes.jar` و`libs/*.jar` من aar — إلى classpath التحليلِ. */
  public synchronized List<File> localClasspath() {
    return locals.classpath;
  }

  /** عقدُ `‹اسمٌ›.exploded.aar` لمحليّاتُ الوحدةٍ (قيمٌ و`R.txt` و`res/`). */
  public synchronized List<File> localAarNodes() {
    return locals.aarNodes;
  }

  public synchronized Map<String, Problem> unresolved() {
    return new LinkedHashMap<>(unresolved);
  }

  /**
   * علاماتُ نصِّ ملفِّ الوحدةِ بحسبِ الحالةِ الحاليةِ: ما لم تُحَلَّ من ‏Maven، ثمَّ ما رُفِضَ من
   * ‏`libs/` باسمِهِ وسببِهِ (W32). لا قناةَ ثانيةَ ولا مُعرِّفَ جديدًا: المَرفوضُ محليًّا يُقالُ
   * برسالةِ «الملفُّ تحتَ الاسمِ ليسَ أرشيفًا مُستعمَلًا» نفسِها، فيَمُرُّ بالمِصفاةِ الواحدةِ إلى
   * اللوحةِ والمحرِّرِ جميعًا.
   */
  public synchronized List<Marker> markers(String text, List<GradleBuildModel.Dependency> dependencies) {
    List<Marker> out = new ArrayList<>(markers(text, dependencies, unresolved()));
    out.addAll(localIntegrityMarkers(text, locals.integrity));
    return out;
  }

  /** ‏`‹اسم› — ‏‹سبب›` → علامةٌ على سطرِ إعلانِ الأداةِ في ملفِّ البناءِ، أو على رأسِهِ إن لم يُعرَفْ. */
  public static List<Marker> localIntegrityMarkers(String text, List<String> integrity) {
    List<Marker> out = new ArrayList<>();
    if (text == null || text.isEmpty() || integrity == null || integrity.isEmpty()) return out;
    for (String line : integrity) {
      String name = line;
      int dash = name.indexOf(" — ");
      if (dash > 0) name = name.substring(0, dash);
      int at = text.indexOf(name);
      out.add(markerAt(text, at < 0 ? 0 : at, at < 0 ? 0 : at + name.length(), new Problem(KEY_INCOMPLETE,
          "%1$s is not installed: the file under its name is not a usable library archive", line)));
    }
    return out;
  }

  // ═══════════════ الحساب الخالص ═══════════════

  /** مفتاح الجذر: group:artifact:version (والإصدار فارغ إن غاب). */
  public static String requestKey(MavenResolver.Request request) {
    return request.group + ":" + request.artifact + ":" + (request.version == null ? "" : request.version);
  }

  /** المفتاح نفسه من إعلان ملف البناء، أو null لما لا يُحلّ عبر Maven. */
  public static String dependencyKey(GradleBuildModel.Dependency d) {
    if (d.kind == GradleBuildModel.Kind.MAVEN && d.coordinate != null) {
      return d.coordinate.group + ":" + d.coordinate.artifact + ":" + d.coordinate.version;
    }
    if (d.kind == GradleBuildModel.Kind.MISSING_VERSION && d.notation != null) {
      String notation = d.notation;
      int at = notation.lastIndexOf('@');
      if (at > 0) notation = notation.substring(0, at);
      String[] parts = notation.split(":");
      if (parts.length >= 2) return parts[0] + ":" + parts[1] + ":";
    }
    return null;
  }

  public static List<Marker> markers(String text, List<GradleBuildModel.Dependency> dependencies, Map<String, Problem> unresolved) {
    List<Marker> out = new ArrayList<>();
    if (text == null || dependencies == null) return out;
    for (GradleBuildModel.Dependency d : dependencies) {
      Problem problem = null;
      if (d.kind == GradleBuildModel.Kind.UNRESOLVED_VARIABLE) {
        problem = d.literalDollar
            ? new Problem(KEY_LITERAL_DOLLAR, "'$' is not substituted inside single quotes: %1$s", d.rawNotation)
            : new Problem(KEY_UNKNOWN_VARIABLE, "Could not get unknown property '%1$s'",
                d.unresolvedVariable == null ? d.rawNotation : d.unresolvedVariable);
      } else if (d.kind == GradleBuildModel.Kind.INVALID) {
        problem = new Problem(KEY_INVALID_NOTATION, "Invalid dependency notation: %1$s", d.rawNotation);
      } else if (d.forAnalysis() || d.platform) {
        String key = dependencyKey(d);
        if (key != null) problem = unresolved.get(key);
      }
      if (problem == null) continue;
      Marker marker = marker(text, d, problem);
      if (marker != null) out.add(marker);
    }
    return out;
  }

  /** المدى: نص الإحداثيات داخل الإعلان إن وُجد، وإلا الإعلان حتى نهاية سطره الأول. */
  static Marker marker(String text, GradleBuildModel.Dependency d, Problem problem) {
    int length = text.length();
    int start = Math.max(0, Math.min(d.start, length));
    int stop = Math.max(start, Math.min(d.end, length));
    int offset = -1, end = -1;
    if (d.rawNotation != null && !d.rawNotation.isEmpty()) {
      int found = text.indexOf(d.rawNotation, start);
      if (found >= 0 && found + d.rawNotation.length() <= Math.max(stop, start + 1) + 1) {
        offset = found;
        end = found + d.rawNotation.length();
      }
    }
    if (offset < 0) {
      offset = start;
      end = stop;
    }
    return markerAt(text, offset, end, problem);
  }

  /** المِسطرةُ نفسُها لكلِّ علامةٍ على نصِّ بناءٍ: مدىً معلومٌ ⇦ سطرٌ وعمودٌ بحسابٍ واحدٍ. */
  static Marker markerAt(String text, int offset, int end, Problem problem) {
    int length = text.length();
    if (offset >= length && length > 0) offset = length - 1;
    int lineStart = text.lastIndexOf('\n', Math.max(0, offset - 1)) + 1;
    if (offset == 0) lineStart = 0;
    int lineEnd = text.indexOf('\n', offset);
    if (lineEnd < 0) lineEnd = length;
    end = Math.max(offset + 1, Math.min(end, lineEnd));
    int line = 1;
    for (int i = 0; i < offset; i++) if (text.charAt(i) == '\n') line++;
    return new Marker(offset, end, line, offset - lineStart + 1, problem);
  }

  /**
   * بصمة ملفات البناء ومخزن المكتبات: أي تغيير في build/settings/gradle.properties/الكتالوج أو مجلد
   * التنزيل يعيد الحلّ.
   */
  public static String fingerprint(GradleBuildModel model, MavenStore store) {
    StringBuilder out = new StringBuilder();
    List<File> files = new ArrayList<>();
    files.add(model.buildFile);
    File root = model.projectRoot;
    files.add(new File(root, "build.gradle"));
    files.add(new File(root, "build.gradle.kts"));
    files.add(new File(root, "settings.gradle"));
    files.add(new File(root, "settings.gradle.kts"));
    files.add(new File(root, "gradle.properties"));
    files.add(new File(model.moduleDir, "gradle.properties"));
    File[] catalogs = new File(root, "gradle").listFiles();
    if (catalogs != null) {
      Arrays.sort(catalogs);
      for (File catalog : catalogs) if (catalog.getName().endsWith(".versions.toml")) files.add(catalog);
    }
    for (File file : files) {
      out.append(file.getAbsolutePath()).append('=');
      if (file.isFile()) out.append(file.lastModified()).append('/').append(file.length());
      out.append(';');
    }
    // W22/4ب٢‑ب: الوحداتُ المرتبطةُ جزءٌ من الاعتماداتِ: ملفُّ بنائِها و{@code libs/} لها يحرِّكانِ
    // البصمةَ، فحفظُ سطرِ اعتمادٍ داخلَ المكتبةِ يستدعي دورةً ولا يُترَكُ قديمًا صامتًا.
    if (model.projectModules != null && !model.projectModules.isEmpty()) {
      out.append(model.projectModules.fingerprintSuffix());
    }
    if (store != null) {
      out.append("store=").append(store.downloadDir().getAbsolutePath());
      for (File local : store.localRepositories()) out.append('|').append(local.getAbsolutePath());
    }
    return out.toString();
  }

  /** ملف يغيّر الاعتماديات عند حفظه. */
  public static boolean isBuildConfiguration(String name) {
    if (name == null) return false;
    String n = name.substring(name.lastIndexOf('/') + 1);
    return n.equals("build.gradle") || n.equals("build.gradle.kts") || n.equals("settings.gradle")
        || n.equals("settings.gradle.kts") || n.equals("gradle.properties") || n.endsWith(".versions.toml");
  }
}
