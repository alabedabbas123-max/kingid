package almlk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Json2Bean: صنف Java من نص JSON بخيارات المرجع السبعة. الكائنات تصبح أصنافًا داخلية static،
 * والمصفوفات List (أو مصفوفة). المفاتيح غير الصالحة كمعرّفات تُحوَّل إلى camelCase مع تعليق بالأصل.
 */
public final class JsonBeanGenerator {

  /** خيارات التوليد (افتراضيات المرجع: set وget مفعّلان). */
  public static final class Options {
    public String packageName;
    public String className;
    public boolean setters = true;
    public boolean getters = true;
    public boolean sortMethods;
    public boolean publicFields;
    public boolean useArrays;
    public boolean useInteger;
    public boolean toString;
    public int indent = 4;
  }

  private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
      "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
      "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
      "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
      "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
      "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
      "volatile", "while", "true", "false", "null", "var", "record", "yield", "sealed", "permits"));

  private final Options options;
  private final Set<String> classNames = new HashSet<>(Arrays.asList(
      "List", "Object", "String", "Integer", "Long", "Double", "Boolean", "Arrays"));
  private boolean usesList;
  private boolean usesArrays;
  private final String unit;

  private JsonBeanGenerator(Options options) {
    this.options = options;
    StringBuilder u = new StringBuilder();
    for (int i = 0; i < Math.max(1, options.indent); i++) u.append(' ');
    unit = u.toString();
  }

  public static String generate(String json, Options options) throws JsonText.SyntaxError {
    Object root = JsonText.parse(json);
    Map<String, Object> object;
    if (root instanceof Map) {
      object = cast(root);
    } else if (root instanceof List) {
      List<?> list = (List<?>) root;
      Map<String, Object> merged = mergeObjects(list);
      if (merged == null && !list.isEmpty())
        throw new IllegalArgumentException("This array conversion without key type is not supported");
      object = merged == null ? new LinkedHashMap<>() : merged;
    } else {
      throw new IllegalArgumentException("JSON must be an object or an array of objects");
    }
    JsonBeanGenerator g = new JsonBeanGenerator(options);
    String rootName = options.className == null ? null : g.uniqueClass(identifier(options.className, true));
    String body = g.members(object, 1);
    StringBuilder out = new StringBuilder();
    if (options.packageName != null && !options.packageName.trim().isEmpty())
      out.append("package ").append(options.packageName.trim()).append(";\n\n");
    if (rootName == null) {
      return out.append(g.unit).append(body.trim()).append('\n').toString();
    }
    if (g.usesList) out.append("import java.util.List;\n");
    if (g.usesArrays) out.append("import java.util.Arrays;\n");
    if (g.usesList || g.usesArrays) out.append('\n');
    out.append("public class ").append(rootName).append(" {\n\n").append(body).append("}\n");
    return out.toString();
  }

  @SuppressWarnings("unchecked")
  private static Map<String, Object> cast(Object value) {
    return (Map<String, Object>) value;
  }

  /** اتحاد مفاتيح كل كائنات المصفوفة (أول قيمة غير null تفوز)، أو null إن لم تكن كائنات. */
  private static Map<String, Object> mergeObjects(List<?> list) {
    LinkedHashMap<String, Object> merged = null;
    for (Object item : list) {
      if (!(item instanceof Map)) return null;
      if (merged == null) merged = new LinkedHashMap<>();
      for (Map.Entry<String, Object> e : cast(item).entrySet()) {
        Object old = merged.get(e.getKey());
        if (old == null || old == JsonText.NULL) merged.put(e.getKey(), e.getValue());
      }
    }
    return merged;
  }

  private static final class Field {
    final String key, name, type;
    final boolean array;

    Field(String key, String name, String type, boolean array) {
      this.key = key;
      this.name = name;
      this.type = type;
      this.array = array;
    }
  }

  private String members(Map<String, Object> object, int depth) {
    String pad = repeat(depth);
    ArrayList<Field> fields = new ArrayList<>();
    ArrayList<String> inner = new ArrayList<>();
    Set<String> used = new HashSet<>();
    for (Map.Entry<String, Object> e : object.entrySet()) {
      String name = identifier(e.getKey(), false);
      String base = name;
      for (int n = 2; !used.add(name); n++) name = base + n;
      Object value = e.getValue();
      String type;
      boolean array = false;
      if (value instanceof Map) {
        type = uniqueClass(identifier(name, true));
        inner.add(innerClass(type, cast(value), depth));
      } else if (value instanceof List) {
        array = true;
        type = listType(name, (List<?>) value, depth, inner, true);
      } else {
        type = scalar(value, false);
      }
      fields.add(new Field(e.getKey(), name, type, array));
    }
    StringBuilder out = new StringBuilder();
    String modifier = options.publicFields ? "public " : "private ";
    for (int i = 0; i < fields.size(); i++) {
      Field f = fields.get(i);
      out.append(pad).append(modifier).append(f.type).append(' ').append(f.name).append(';');
      if (!f.name.equals(f.key)) {
        out.append(" // \"");
        out.append(f.key.replace("\\", "\\\\").replace("\n", "\\n").replace("\"", "\\\""));
        out.append('"');
      }
      out.append('\n');
      if (i + 1 < fields.size()) out.append('\n');
    }
    if (!fields.isEmpty()) out.append('\n');
    ArrayList<String> setters = new ArrayList<>();
    ArrayList<String> getters = new ArrayList<>();
    for (Field f : fields) {
      String upper = Character.toUpperCase(f.name.charAt(0)) + f.name.substring(1);
      if (options.setters) {
        String type = options.useArrays && f.array && f.type.endsWith("[]")
            ? f.type.substring(0, f.type.length() - 2) + "..."
            : f.type;
        setters.add(pad + "public void set" + upper + "(" + type + " " + f.name + ") {\n"
            + pad + unit + "this." + f.name + " = " + f.name + ";\n" + pad + "}\n");
      }
      if (options.getters) {
        String prefix = "boolean".equals(f.type) ? "is" : "get";
        getters.add(pad + "public " + f.type + " " + prefix + upper + "() {\n"
            + pad + unit + "return " + f.name + ";\n" + pad + "}\n");
      }
    }
    if (!options.sortMethods && options.setters && options.getters) {
      for (int i = 0; i < setters.size(); i++) {
        out.append(setters.get(i)).append('\n').append(getters.get(i)).append('\n');
      }
    } else {
      for (String s : setters) out.append(s).append('\n');
      for (String g : getters) out.append(g).append('\n');
    }
    if (options.toString) {
      out.append(pad).append("@Override\n").append(pad).append("public String toString() {\n");
      out.append(pad).append(unit).append("return getClass().getSimpleName() + \"{\"");
      for (int i = 0; i < fields.size(); i++) {
        Field f = fields.get(i);
        String value = f.type.endsWith("[][]") ? "Arrays.deepToString(" + f.name + ")"
            : f.type.endsWith("[]") ? "Arrays.toString(" + f.name + ")" : f.name;
        if (f.type.endsWith("[]")) usesArrays = true;
        out.append('\n').append(pad).append(unit).append(unit).append("+ \"")
            .append(i == 0 ? "" : ", ").append(f.name).append("=\" + ").append(value);
      }
      out.append('\n').append(pad).append(unit).append(unit).append("+ \"}\";\n");
      out.append(pad).append("}\n\n");
    }
    for (String s : inner) out.append(s).append('\n');
    return out.toString();
  }

  private String innerClass(String name, Map<String, Object> object, int depth) {
    String pad = repeat(depth);
    StringBuilder out = new StringBuilder();
    out.append(pad).append("public static class ").append(name).append(" {\n\n");
    String body = members(object, depth + 1);
    if (!body.trim().isEmpty()) out.append(body);
    out.append(pad).append("}\n");
    return out.toString();
  }

  /** نوع حقل مصفوفة: List&lt;T&gt; (أو T[]) — الكائنات تُدمج في صنف داخلي واحد. */
  private String listType(String fieldName, List<?> list, int depth, List<String> inner, boolean top) {
    String element;
    if (list.isEmpty()) {
      element = "Object";
    } else {
      Map<String, Object> merged = mergeObjects(list);
      if (merged != null) {
        element = uniqueClass(identifier(fieldName, true));
        inner.add(innerClass(element, merged, depth));
      } else if (allLists(list)) {
        ArrayList<Object> flat = new ArrayList<>();
        for (Object o : list) flat.addAll((List<?>) o);
        element = listType(fieldName, flat, depth, inner, false);
      } else {
        element = commonScalar(list);
      }
    }
    if (options.useArrays) return primitiveOrSelf(element) + "[]";
    usesList = true;
    return "List<" + boxed(element) + ">";
  }

  private static boolean allLists(List<?> list) {
    for (Object o : list) if (!(o instanceof List)) return false;
    return true;
  }

  /** أوسع نوع مشترك لعناصر بسيطة: أعداد ← int/long/double، وإلا Object عند الاختلاف. */
  private String commonScalar(List<?> list) {
    String type = null;
    for (Object o : list) {
      if (o == JsonText.NULL) continue;
      String t = scalar(o, true);
      if (type == null) type = t;
      else if (!type.equals(t)) {
        if (isNumeric(type) && isNumeric(t)) type = rank(t) > rank(type) ? t : type;
        else return "Object";
      }
    }
    return type == null ? "Object" : type;
  }

  private static boolean isNumeric(String t) {
    return t.equals("int") || t.equals("long") || t.equals("double") || t.equals("Integer");
  }

  private static int rank(String t) {
    return t.equals("double") ? 3 : t.equals("long") ? 2 : 1;
  }

  private String scalar(Object value, boolean forList) {
    if (value instanceof String) return "String";
    if (value instanceof Boolean) return "boolean";
    if (value instanceof JsonText.Number) {
      JsonText.Number n = (JsonText.Number) value;
      if (n.fitsInt()) return options.useInteger && !forList ? "Integer" : "int";
      if (n.isInteger()) {
        try {
          Long.parseLong(n.text);
          return "long";
        } catch (NumberFormatException huge) {
          return "double";
        }
      }
      return "double";
    }
    return "Object";
  }

  private static String boxed(String type) {
    switch (type) {
      case "int": return "Integer";
      case "long": return "Long";
      case "double": return "Double";
      case "boolean": return "Boolean";
      default: return type;
    }
  }

  private String primitiveOrSelf(String type) {
    if (options.useInteger && type.equals("int")) return "Integer";
    return type;
  }

  private String uniqueClass(String name) {
    String candidate = name;
    for (int n = 2; !classNames.add(candidate); n++) candidate = name + n;
    return candidate;
  }

  /** معرّف Java صالح: camelCase من الأجزاء، وبادئة _ للرقم، ولاحقة _ للكلمة المحجوزة. */
  static String identifier(String key, boolean type) {
    StringBuilder out = new StringBuilder();
    boolean upperNext = type;
    for (int i = 0; i < key.length(); i++) {
      char c = key.charAt(i);
      if (Character.isLetterOrDigit(c) || c == '_' || c == '$') {
        if (c > 127 && !Character.isJavaIdentifierPart(c)) {
          upperNext = out.length() > 0 || type;
          continue;
        }
        out.append(upperNext ? Character.toUpperCase(c) : c);
        upperNext = false;
      } else {
        upperNext = out.length() > 0 || type;
      }
    }
    if (out.length() == 0) out.append(type ? "Item" : "field");
    if (!Character.isJavaIdentifierStart(out.charAt(0))) out.insert(0, '_');
    String result = out.toString();
    if (type) result = Character.toUpperCase(result.charAt(0)) + result.substring(1);
    if (KEYWORDS.contains(result.toLowerCase(Locale.ROOT)) && KEYWORDS.contains(result)) result += "_";
    return result;
  }

  private String repeat(int depth) {
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < depth; i++) out.append(unit);
    return out.toString();
  }
}
