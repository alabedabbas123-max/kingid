package almlk;

import java.util.IllegalFormatException;

/**
 * نَسْقُ القالبِ والحُجَّةِ — صَفيٌّ خالصٌ لا يَعرِفُ ‏`Resources`‏.
 *
 * <p>قالبُ الموردِ (`strings.xml`) وحُجَجُهُ يَأتِيانِ من مَكانَينِ: القالبُ يَكتِبُهُ المُترجِمُ،
 * والحُجَجُ يَبنيها المُحلِّلُ أو المُصلِحُ أو لَقطةُ القرصِ. وما دامَ المَصدَرانِ مُنفصِلَينِ
 * فَسُقوطُهُما في خِلافٍ حُكمٌ لا احتمالٌ: «‏`%1$d`‏» بِسِلسِلَةٍ يَرمِي ‏
 * `IllegalFormatConversionException`‏ من جَوفِ ‏`Resources.getString`‏، أي في مُنتَصَفِ ‏
 * `QuickFixExecutor.applyInTab`‏ **بَعدَ أن يُنجَحَ الإصلاحُ فَيَضِلَّ المُستَخدِمُ** (جِهَازُ
 * الجولةِ ٤١: «‏d != java.lang.String`‏ في إصَلاحةِ الدوالِّ المَجرَّدَةِ الجَماعِيَّةِ).
 *
 * <p>القرارُ هُنا لا في ‏`UiStrings`‏: لأنَّ ‏`UiStrings`‏ يَحمِلُ ‏`Context`‏ فلا يُختبَرُ صافيًا،
 * ولأنَّ الحُكمَ على القالبِ لُغَويٌّ لا نِظاميٌّ. ‏`apply`‏ يُحاوِلُ ‏`String.format`‏ **أولًا** —
 * فَما وافَقَ القالبَ يُترَكُ كما هُوَ بلا تَبدُّلِ أَرقامٍ ولا لُغةٍ؛ وإن شَذَّ يَنزِلُ إلى ‏
 * `substitute`‏ الذي يَضَعُ نَصَّ الحُجَّةِ حرفيًّا في مَكانِها، فلا يَختَرِعُ رقمًا ولا يَطمِسُ اسمًا،
 * ولا يَرمِي شَيئًا. لا صَمتَ: الحُجَّةُ الناقِصَةُ تُترَكُ قالبَها كما هُوَ ليُرى الخَللُ لا ليُخفَى.
 */
public final class UiFormat {

  private UiFormat() {}

  /** قالبٌ وحُجَجٌ: ‏`String.format`‏ عندَ الوِفاقِ، وبَدلٌ مَوضِعيٌّ عندَ الشُّذوذِ — لا استثناءَ أبدًا. */
  public static String apply(String template, Object... args) {
    if (template == null || template.isEmpty()) return template == null ? "" : template;
    if (args == null || args.length == 0) return template; // قالبٌ بلا حُجَجٍ: لا نَسقَ يَلزَمُ
    try {
      return String.format(template, args);
    } catch (IllegalFormatException mismatch) {
      return substitute(template, args);
    }
  }

  /**
   * بَدلٌ ‏`%1$s`‏ / ‏`%2$d`‏ (وبلا فُهرُسٍ: ‏`%s`‏ بالترتيبِ) بنصِّ الحُجَّةِ حرفيًّا. والوَسومُ كلُّها
   * تُستَهلَكُ — سِلكٌ ‏`%d`‏ بِسِلسِلَةٍ يَأخُذُ نَصَّها، وعَرضٌ ‏`%x`‏ يَأخُذُها هي لا قِيمتَها
   * المُصَيَّغَةِ: الغَرَضُ أن يُقرَأَ الخَطَأُ، لا أن يُزَيَّنَ. و‏`%%`‏ بَقِيَت_percentٍ واحِدَةً.
   */
  public static String substitute(String template, Object... args) {
    if (template == null || template.isEmpty()) return template == null ? "" : template;
    int n = args == null ? 0 : args.length;
    StringBuilder out = new StringBuilder(template.length() + 16);
    int cursor = 0;
    int positional = 0;
    while (cursor < template.length()) {
      char c = template.charAt(cursor);
      if (c != '%') {
        out.append(c);
        cursor++;
        continue;
      }
      int at = cursor + 1;
      if (at >= template.length()) { // «%» يتيمَةٌ في الآخِرِ: كما كُتِبَت.
        out.append('%');
        cursor++;
        continue;
      }
      if (template.charAt(at) == '%') {
        out.append('%');
        cursor = at + 1;
        continue;
      }
      int index = -1;
      while (at < template.length() && template.charAt(at) >= '0' && template.charAt(at) <= '9') at++;
      if (at < template.length() && template.charAt(at) == '$') {
        index = Integer.parseInt(template.substring(cursor + 1, at));
        at++;
      }
      while (at < template.length() && isFlag(template.charAt(at))) at++;
      int conversion = at;
      if (conversion >= template.length()) { // قالبٌ مبتورٌ: لا حُجَّةَ تُستَهلكُ ولا شَيءَ يُمسَحُ.
        out.append('%');
        cursor++;
        continue;
      }
      char conv = template.charAt(conversion);
      if (conv == 'n') {
        out.append('\n');
        cursor = conversion + 1;
        continue;
      }
      int slot = index >= 0 ? index - 1 : positional;
      if (conv != 's' && conv != 'd' && conv != 'c' && conv != 'b' && conv != 'x' && conv != 'X'
          && conv != 'o' && conv != 'f' && conv != 'e' && conv != 'g' && conv != 'h') {
        out.append('%'); // وسمٌ لا نَعرِفُهُ (‏`%<`‏ ونَحوُهُ): يُترَكُ ولا يُلتَمَسُ لَهُ حُجَّةٌ.
        cursor++;
        continue;
      }
      positional = slot + 1;
      if (slot < 0 || slot >= n) {
        out.append('%'); // حُجَّةٌ ناقِصَةٌ: القالبُ يَبقَى مَقطوعًا على وَجهِهِ، لا مُختَلَقًا.
        cursor++;
        continue;
      }
      Object arg = args[slot];
      out.append(conv == 'c' && arg instanceof Character ? String.valueOf(arg)
          : String.valueOf(arg));
      cursor = conversion + 1;
    }
    return out.toString();
  }

  /** الوَسومُ التَّي تَأتِي بَينَ الفَهرُسِ والحُرفِ (أعلامٌ وعَرضٌ ودِقَّةٌ) — تُستَهلكُ ولا تُطَبَّقُ. */
  private static boolean isFlag(char c) {
    return c == '-' || c == '+' || c == ' ' || c == '#' || c == '0' || c == ',' || c == '<'
        || c == '(' || c == ')' || (c >= '1' && c <= '9') || c == '.' || c == '$';
  }
}
