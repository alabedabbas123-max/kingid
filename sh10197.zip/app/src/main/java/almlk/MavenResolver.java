package almlk;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;

/**
 * محرك حلّ اعتماديات Maven وتنزيلها (M2) — بديل خدمة Maven المغلقة في المرجع.
 *
 * <p>من جذور ملف الوحدة: يبني النموذج الفعّال لكل POM (أب، خصائص، BOM مستورد، إعادة توجيه)، ويمشي
 * الشجرة متبعًا نطاقي compile/runtime فقط (لا test/provided/optional) مع الاستثناءات، ويحسم
 * التعارض بأعلى إصدار (كـGradle) بتكرار حتى الاستقرار، ثم ينزّل الملفات الثنائية (jar/aar مع
 * التبديل بينهما) ويفك AAR بجوارها. ما وُجد في المخزن أو المستودعات المحلية لا يُنزَّل (إلا عند
 * التحديث الإجباري).
 */
public final class MavenResolver {

  // ═══════════════ الواجهات ═══════════════

  /** طبقة النقل (HTTP في التطبيق، وأي بديل في الاختبار). */
  public interface Fetcher {
    /** يكتب الملف ذرّيًا إلى target؛ false = غير موجود في هذا المستودع؛ IOException = شبكة. */
    boolean fetch(String url, File target, boolean verify, Progress progress) throws IOException;

    /** عدد التنزيلات المتزامنة التي يحتملها الناقل؛ 1 = متسلسل (الافتراضي، ولكل ناقل غير آمن للخيوط). */
    default int parallelism() {
      return 1;
    }
  }

  /** بلا شبكة: «غير موجود» دائمًا — لفحص الفتح السريع (هل كل شيء في المخزن؟). */
  public static final Fetcher OFFLINE = (url, target, verify, progress) -> false;

  public interface Progress {
    void bytes(long done, long total);

    boolean cancelled();
  }

  /** تقدّم للحوار: اسم الأداة الحالية والنسبة الكلية 0..100. */
  public interface Listener {
    void onProgress(String name, int percent);
  }

  /** إلغاء المستخدم. */
  public static final class Cancelled extends RuntimeException {
    public Cancelled() {
      super("cancelled");
    }
  }

  /** خطأ شبكة بعد استنفاد المستودعات والمحاولات. */
  static final class NetworkError extends RuntimeException {
    NetworkError(String message) {
      super(message);
    }
  }

  /** مستودع: عنوان بعيد ينتهي بـ/ أو مجلد محلي. */
  public static final class Repo {
    public final String name;
    public final String url;
    public final File dir;
    /** مستودع احتياطي مدمج (لم يعلنه المشروع): يُجرَّب بعد المعلنة ويخضع للتوجيه. */
    public final boolean fallback;

    public Repo(String name, String url, File dir) {
      this(name, url, dir, false);
    }

    public Repo(String name, String url, File dir, boolean fallback) {
      this.name = name;
      this.url = url == null ? null : (url.endsWith("/") ? url : url + "/");
      this.dir = dir;
      this.fallback = fallback;
    }

    /** هوية العنوان بعد معادلة الأسماء البديلة (http/https، maven.google.com، repo1.maven.org). */
    public String identity() {
      return url != null ? canonicalUrl(url) : dir == null ? name : dir.getAbsolutePath();
    }

    @Override
    public String toString() {
      return name + " " + (url != null ? url : String.valueOf(dir));
    }
  }

  /** جذر من ملف الوحدة. version قد يكون null (ينتظر BOM). */
  public static final class Request {
    public final String group, artifact, version, classifier, extension;
    /** platform(...): يُقرأ منه dependencyManagement ولا ملف ثنائي له. */
    public final boolean platform;
    /** يدخل مسار الترجمة (implementation/api/compileOnly). */
    public final boolean compile;
    /** سطر الإعلان (0-based) أو -1 للضمني (kotlin-stdlib). */
    public final int line;

    public Request(String group, String artifact, String version, String classifier, String extension,
        boolean platform, boolean compile, int line) {
      this.group = group;
      this.artifact = artifact;
      this.version = version;
      this.classifier = classifier;
      this.extension = extension;
      this.platform = platform;
      this.compile = compile;
      this.line = line;
    }

    public static Request of(String coordinate) {
      MavenStore.Coordinate c = MavenStore.Coordinate.parse(coordinate);
      if (c == null) throw new IllegalArgumentException(coordinate);
      return new Request(c.group, c.artifact, c.version, c.classifier, c.extension, false, true, -1);
    }

    public String key() {
      return group + ":" + artifact;
    }

    @Override
    public String toString() {
      return key() + ":" + (version == null ? "" : version);
    }
  }

  public static final class Artifact {
    public final MavenStore.Coordinate coordinate;
    public final String packaging;
    /** jar أو aar، أو null لأداة pom فقط. */
    public final File binary;
    /** مجلد AAR المفكوك أو null. */
    public final File aarDir;
    /** ملفات classpath: الـjar نفسه، أو classes.jar وlibs/*.jar من AAR. */
    public final List<File> jars;
    /** مرئية للترجمة (طريق compile فقط من جذر compile). */
    public final boolean compileVisible;
    public final boolean direct;
    /** W21′3: حُكمُ فحصِ الملفِّ في المخزنِ (null = أداةٌ بلا ملفٍ ثنائيٍّ، كـpom). */
    public final LibraryInstallState.Verdict install;

    Artifact(MavenStore.Coordinate coordinate, String packaging, File binary, File aarDir, List<File> jars,
        boolean compileVisible, boolean direct) {
      this(coordinate, packaging, binary, aarDir, jars, compileVisible, direct, null);
    }

    Artifact(MavenStore.Coordinate coordinate, String packaging, File binary, File aarDir, List<File> jars,
        boolean compileVisible, boolean direct, LibraryInstallState.Verdict install) {
      this.coordinate = coordinate;
      this.packaging = packaging;
      this.binary = binary;
      this.aarDir = aarDir;
      this.jars = Collections.unmodifiableList(jars);
      this.compileVisible = compileVisible;
      this.direct = direct;
      this.install = install;
    }

    /** جاهزةٌ بالمعنى النفعيِّ: ملفٌّ يُفتَّحُ وفيهِ أصنافٌ (أو أداةُ pom بلا ملفٍ يُطالَبُ بهِ). */
    public boolean ready() {
      return install == null || install.installed();
    }

    @Override
    public String toString() {
      return coordinate + (binary == null ? " (pom)" : " " + binary.getName()) + (compileVisible ? "" : " [runtime]");
    }
  }

  public static final class Failure {
    /** INCOMPLETE: الملفُّ موجودٌ باسمِ الأداةِ لكنْ لا يُفتَّحُ — ليس تثبيتًا، وقابلٌ للإعادةِ. */
    public static final int NOT_FOUND = 0, NETWORK = 1, INVALID_POM = 2, NO_VERSION = 3, INCOMPLETE = 4;
    public final int type;
    public final String coordinate;
    public final String reason;
    /** الجذر الذي قاد إلى الفشل (لتعليم سطره) أو null. */
    public final Request root;

    Failure(int type, String coordinate, String reason, Request root) {
      this.type = type;
      this.coordinate = coordinate;
      this.reason = reason;
      this.root = root;
    }

    /** نص العرض كالمرجع: Could not resolve g:a:v ، وبلاغُ التلفِ صريحٌ لا يُخلَّطُ بالفقدِ */
    public String message() {
      boolean plain = reason == null || reason.isEmpty() || reason.equals("not found");
      if (type == INCOMPLETE) return "Not installed: " + coordinate + (plain ? "" : " — " + reason);
      return "Could not resolve " + coordinate + (plain ? "" : " (" + reason + ")");
    }

    @Override
    public String toString() {
      return message();
    }
  }

  public static final class Result {
    public final List<Artifact> artifacts = new ArrayList<>();
    public final List<Failure> failures = new ArrayList<>();
    public boolean cancelled;
    /** عدد الملفات المنزّلة فعلًا من الشبكة/المستودعات في هذا التشغيل. */
    public int downloaded;

    public boolean ok() {
      return !cancelled && failures.isEmpty();
    }

    /** عددُ ما ثُبِّتَ فعلًا: لا يُحسَبُ اسمٌ بلا مضمونٍ في «المكتباتُ جاهزةٌ». */
    public int readyCount() {
      int out = 0;
      for (Artifact artifact : artifacts) if (artifact.ready()) out++;
      return out;
    }

    /** سليمةُ الملفِ ولا أصنافَ فيها: مُثبَّتةٌ لكنْ لا تُحِلُّ شيئًا — تُبلَّغُ صراحةً. */
    public int withoutClassesCount() {
      int out = 0;
      for (Artifact artifact : artifacts)
        if (artifact.install != null && artifact.install.silent()) out++;
      return out;
    }

    /** الأدواتُ التي لا أصنافَ فيها (لحوارِ التنزيلِ وشاشةِ المكتباتِ). */
    public List<String> withoutClasses() {
      List<String> out = new ArrayList<>();
      for (Artifact artifact : artifacts)
        if (artifact.install != null && artifact.install.silent()) out.add(artifact.coordinate.toString());
      return out;
    }

    /** classpath الترجمة والتحليل (المرئي فقط) بلا تكرار. */
    public List<File> classpath() {
      Set<File> out = new LinkedHashSet<>();
      for (Artifact artifact : artifacts) if (artifact.compileVisible) out.addAll(artifact.jars);
      return new ArrayList<>(out);
    }

    /** كل ملفات jar (للتشغيل/التحزيم). */
    public List<File> runtimeClasspath() {
      Set<File> out = new LinkedHashSet<>();
      for (Artifact artifact : artifacts) out.addAll(artifact.jars);
      return new ArrayList<>(out);
    }

    public Artifact find(String key) {
      for (Artifact artifact : artifacts) if (artifact.coordinate.key().equals(key)) return artifact;
      return null;
    }
  }

  // ═══════════════ البناء من ملف الوحدة ═══════════════

  /**
   * مستودعاتُ الحلِّ — مسارٌ واحدٌ: معلَنُ المشروعِ (كما كُتِبَ حرفيًّا، بما فيهِ `jcenter()` المجمَّدُ
   * للقراءةِ عندنا) ← إضافاتُ المستخدمِ من الإعداداتِ (`advanced_setting_extra_repositories`،
   * بفاصلِ `;`) ← مستودعاتُ `buildscript` ← المدمَجُ: Google ثمَّ Maven Central ثمَّ JCenter ثمَّ JitPack،
   * بلا تكرارٍ (الأولُ يفوزُ، والهويّةُ تُوحِّدُ `repo1`=`repo.maven` و`maven.google.com`=`dl.google.com`).
   *
   * <p><b>ما للسياستِ وما ليس لها**: عناوينُ المشروعِ لا تُعرَّجُ — فقد تكونُ مرآةٌ خاصّةٌ يقصدُها
   * صاحبُ المشروعِ، ومرآةُ JCenter البطيئةُ تُجرَّبُ بعدَ Central لا قبلَهُ أصلًا. وأمّا ما يكتبُهُ
   * المستخدمُ في الصفِّ الجديدِ فيمرُّ بـ`almlk.RepositoryPolicy`: `http`←`https`، والاسمُ المستعارُ
   * (`jcenter`/`central`/`google`/`jitpack`) ← عنوانُهُ الحقيقيُّ، والمسارُ المطلقُ ← `file:`،
   * والمضيفُ الذي ماتَ (JCenter/Bintray) ← Maven Central، والفاصلُ والوهميُّ ← يُسقَطُ.
   */
  public static List<Repo> repositories(GradleBuildModel model, File mavenLocalDir, List<String> userRepositories) {
    List<Repo> out = declaredRepositories(model, mavenLocalDir);
    Set<String> seen = new HashSet<>();
    for (Repo repo : out) seen.add(repo.identity());
    List<Repo> after = new ArrayList<>();
    // إضافاتُ المستخدمِ أوّلَ ما بعدَ معلَنِ المشروعِ: تُطبَّعُ (https، اسمٌ مستعارٌ، مضيفٌ ميِّتٌ ←
    // Central، مسارٌ مطلقٌ ← file:) ثمَّ تُزالُكرارُها بالهويّةِ الموحَّدةِ.
    if (userRepositories != null) {
      for (String token : userRepositories) {
        String url = almlk.RepositoryPolicy.rescue(token);
        if (url == null) continue;
        Repo repo = new Repo("user", url, null, true);
        if (seen.add(repo.identity())) out.add(repo);
      }
    }
    for (GradleBuildModel.Repository hint : model.buildscriptRepositories) {
      if (hint.type == GradleBuildModel.Repository.REMOTE && hint.url != null && hint.url.startsWith("http"))
        after.add(new Repo(hint.name, hint.url, null, true));
    }
    after.add(new Repo("google", GradleBuildModel.GOOGLE_URL, null, true));
    after.add(new Repo("mavenCentral", GradleBuildModel.CENTRAL_URL, null, true));
    after.add(new Repo("jcenter", GradleBuildModel.JCENTER_URL, null, true));
    after.add(new Repo("jitpack", GradleBuildModel.JITPACK_URL, null, true));
    for (Repo repo : after) if (seen.add(repo.identity())) out.add(repo);
    return out;
  }

  /** المستودعات المعلنة وحدها بالترتيب؛ mavenLocal → mavenLocalDir إن وُجد؛ flatDir لا يُحلّ هنا. */
  public static List<Repo> declaredRepositories(GradleBuildModel model, File mavenLocalDir) {
    List<Repo> out = new ArrayList<>();
    Set<String> seen = new HashSet<>();
    for (GradleBuildModel.Repository repository : model.repositories) {
      Repo repo = null;
      if (repository.type == GradleBuildModel.Repository.REMOTE && repository.url != null) {
        String url = repository.url;
        if (url.startsWith("file:")) repo = new Repo(repository.name, null, new File(url.replaceFirst("^file:(//)?", "")));
        else repo = new Repo(repository.name, url, null);
      } else if (repository.type == GradleBuildModel.Repository.LOCAL) {
        File dir = repository.url != null ? new File(repository.url) : mavenLocalDir;
        if (dir != null) repo = new Repo(repository.name, null, dir);
      }
      if (repo != null && seen.add(repo.identity())) out.add(repo);
    }
    return out;
  }

  // ═══════════════ التوجيه ═══════════════

  /** عنوان موحَّد للمقارنة: https، مضيف صغير، بلا / أخيرة، والأسماء البديلة للمستودع نفسه. */
  public static String canonicalUrl(String url) {
    String u = url.trim();
    if (u.regionMatches(true, 0, "http://", 0, 7)) u = "https://" + u.substring(7);
    while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
    int slash = u.indexOf('/', 8);
    String host = (slash < 0 ? u.substring(8) : u.substring(8, slash)).toLowerCase(java.util.Locale.ROOT);
    String path = slash < 0 ? "" : u.substring(slash);
    if (host.equals("maven.google.com") && path.isEmpty()) return "https://dl.google.com/dl/android/maven2";
    if (host.equals("repo1.maven.org") || host.equals("repo.maven.apache.org") || host.equals("central.maven.org"))
      host = "repo.maven.apache.org";
    if (host.equals("jcenter.bintray.com") && path.isEmpty()) return "https://jcenter.bintray.com";
    if (host.equals("www.jitpack.io")) host = "jitpack.io";
    return "https://" + host + path;
  }

  private static final String[] GOOGLE_GROUPS = {
    "androidx.", "android.arch.", "com.android.", "com.google.android.", "com.google.firebase",
    "com.google.gms", "com.google.ads", "com.google.ar", "com.google.mlkit", "com.google.mediapipe",
    "com.google.play", "com.google.ai.", "com.google.camerax", "com.google.oboe", "com.google.prefab",
    "com.google.androidbrowserhelper", "com.google.testing.platform", "com.crashlytics", "io.fabric",
    "zipflinger", "tools.base", "org.chromium.net"
  };

  /** مجموعة يستضيفها مستودع Google (من master-index.xml). */
  static boolean isGoogleGroup(String group) {
    if (group == null) return false;
    for (String prefix : GOOGLE_GROUPS) {
      String bare = prefix.endsWith(".") ? prefix.substring(0, prefix.length() - 1) : prefix;
      if (group.equals(bare) || group.startsWith(bare + ".")) return true;
    }
    return false;
  }

  /** مجموعة تُبنى عند الطلب في JitPack (مستودعات git). */
  static boolean isGitGroup(String group) {
    return group != null && (group.startsWith("com.github.") || group.startsWith("com.gitlab.")
        || group.startsWith("org.bitbucket.") || group.startsWith("io.github.jitpack"));
  }

  private static boolean isGoogleRepo(Repo repo) {
    return repo.url != null && canonicalUrl(repo.url).equals("https://dl.google.com/dl/android/maven2");
  }

  private static boolean isJitpackRepo(Repo repo) {
    return repo.url != null && canonicalUrl(repo.url).startsWith("https://jitpack.io");
  }

  private static boolean isJcenterRepo(Repo repo) {
    return repo.url != null && canonicalUrl(repo.url).equals("https://jcenter.bintray.com");
  }

  /**
   * ترتيب المستودعات لمجموعة: مجموعات Google تبدأ بمستودع Google. وJCenter المجمَّد بعد Central، لأن
   * Central مرآة محتواه بالإحداثيات نفسها وأسرع منه بكثير، فيبقى JCenter لما لم يُنقل. وGoogle الاحتياطي
   * يأتي بعدهما لغير مجموعاته. أما JitPack فيؤخَّر للأخير ما لم تكن المجموعة من git، والاحتياطي منه لا
   * يُسأل عن غيرها أصلًا لأنه يبني عند الطلب فيبطئ. والترتيب داخل كل درجة كما هو (المعلن قبل الاحتياطي).
   */
  List<Repo> route(String group) {
    boolean google = isGoogleGroup(group);
    boolean git = isGitGroup(group);
    List<Repo> out = new ArrayList<>(repos.size());
    for (int rank = 0; rank <= 4; rank++) {
      for (Repo repo : repos) {
        int r;
        if (isJitpackRepo(repo) && !git) {
          if (repo.fallback) continue;
          r = 4;
        } else if (google && isGoogleRepo(repo)) r = 0;
        else if (isJcenterRepo(repo)) r = 2;
        else if (!google && repo.fallback && isGoogleRepo(repo)) r = 3;
        else r = 1;
        if (r == rank) out.add(repo);
      }
    }
    return out;
  }

  /**
   * جذور الوحدة: MAVEN وplatform وMISSING_VERSION (للتحليل) + kotlin-stdlib الضمني، ومعها runtimeOnly/apk
   * (تُنزَّل لأنها تُحزَّم مع التطبيق، وتدخل مسار التشغيل لا مسار الترجمة: compile=false).
   */
  public static List<Request> requests(GradleBuildModel model) {
    List<Request> out = new ArrayList<>();
    if (model == null) return out;
    Set<String> seen = new HashSet<>();
    // W22/4ب٢‑ب: المنادِي ثمَّ ما تبلُغُهُ إدراجَاتُ settings.gradle — إعلانُ الوحدةِ المرتبطةِ
    // طلبٌ مثلُهُ بالضبطِ: يُحلُّ محليًّا أوائلًا، ولا يُنزَّلُ منهُ إلا ما فعلًا ناقصٌ.
    for (GradleBuildModel source : model.modelsForAnalysis()) requestsFrom(source, out, seen);
    return out;
  }

  private static void requestsFrom(GradleBuildModel model, List<Request> out, Set<String> seen) {
    boolean stdlib = false;
    for (GradleBuildModel.Dependency d : model.dependencies) {
      boolean analysis = d.forAnalysis();
      boolean runtime = d.scope == GradleBuildModel.Scope.RUNTIME_ONLY;
      if (d.kind == GradleBuildModel.Kind.MAVEN && d.coordinate != null && (analysis || d.platform || runtime)) {
        MavenStore.Coordinate c = d.coordinate;
        Request request = new Request(c.group, c.artifact, c.version, c.classifier, c.extension, d.platform, analysis, d.line);
        if (seen.add((d.platform ? "p|" : "") + c)) out.add(request);
        if (c.group.equals("org.jetbrains.kotlin") && c.artifact.startsWith("kotlin-stdlib")) stdlib = true;
      } else if (d.kind == GradleBuildModel.Kind.MISSING_VERSION && analysis && d.notation != null) {
        String notation = d.notation;
        String extension = null;
        int at = notation.lastIndexOf('@');
        if (at > 0) {
          extension = notation.substring(at + 1);
          notation = notation.substring(0, at);
        }
        String[] parts = notation.split(":");
        if (parts.length >= 2 && seen.add(parts[0] + ":" + parts[1])) {
          out.add(new Request(parts[0], parts[1], null, null, extension, false, true, d.line));
        }
      }
    }
    if (model.kotlinPluginApplied && model.kotlinPluginVersion != null && !stdlib) {
      out.add(new Request("org.jetbrains.kotlin", "kotlin-stdlib", model.kotlinPluginVersion, null, null, false, true, -1));
    }
  }

  // ═══════════════ الحالة ═══════════════

  private static final int MAX_PARENT_DEPTH = 10;
  private static final int MAX_ITERATIONS = 12;

  private final MavenStore store;
  private final List<Repo> repos;
  private final Fetcher fetcher;

  private boolean refresh;
  private boolean refreshMetadata;
  private AtomicBoolean cancel;
  private Listener listener;
  private Result result;
  private final Map<String, Effective> effectiveCache = new HashMap<>();
  private final Map<String, String> effectiveErrors = new HashMap<>();
  private final Map<String, List<String>> versionsCache = new HashMap<>();
  private final Map<String, Repo> servedBy = Collections.synchronizedMap(new HashMap<String, Repo>());
  private final Set<String> refreshed = Collections.synchronizedSet(new HashSet<String>());
  /** W21′3: ما رُفِضَ من ملفاتِ المخزنِ (إحداثيات:امتداد ← سببٌ) ليميَّزَ التلفُ من الفقدِ في اللوحةِ. */
  private final Map<String, String> unusableReasons = new java.util.concurrent.ConcurrentHashMap<>();
  private String progressName = "";
  private int progressPercent = -1;

  public MavenResolver(MavenStore store, List<Repo> repos, Fetcher fetcher) {
    this.store = store;
    this.repos = repos == null ? Collections.<Repo>emptyList() : new ArrayList<>(repos);
    this.fetcher = fetcher;
  }

  /** نموذج POM فعّال. */
  static final class Effective {
    String groupId, artifactId, version, packaging;
    final Map<String, String> properties = new LinkedHashMap<>();
    final List<MavenPom.Dependency> management = new ArrayList<>();
    final List<MavenPom.Dependency> dependencies = new ArrayList<>();

    String key() {
      return groupId + ":" + artifactId;
    }
  }

  /** عقدة الشجرة للإصدار المختار. */
  private static final class Node {
    final Effective pom;
    final Request root;
    String classifier, type;
    boolean compileVisible, direct, expandedCompile;

    Node(Effective pom, Request root) {
      this.pom = pom;
      this.root = root;
    }
  }

  private static final class Visit {
    final String group, artifact, version, classifier, type;
    final Set<String> exclusions;
    final boolean compile, direct;
    final Request root;

    Visit(String group, String artifact, String version, String classifier, String type, Set<String> exclusions,
        boolean compile, boolean direct, Request root) {
      this.group = group;
      this.artifact = artifact;
      this.version = version;
      this.classifier = classifier;
      this.type = type;
      this.exclusions = exclusions;
      this.compile = compile;
      this.direct = direct;
      this.root = root;
    }

    String key() {
      return group + ":" + artifact;
    }
  }

  // ═══════════════ الحلّ ═══════════════

  /** Refresh Build: يعيد جلب maven-metadata للإصدارات الديناميكية دون إعادة تنزيل الملفات. */
  public MavenResolver refreshMetadata(boolean value) {
    refreshMetadata = value;
    return this;
  }

  /**
   * يحلّ وينزّل. refresh: يُعاد تنزيل ما في مجلد التنزيل (المستودعات المحلية تُستعمل كما هي)، ومع
   * انقطاع الشبكة تبقى النسخة القديمة.
   */
  public Result resolve(List<Request> requests, boolean refresh, Listener listener, AtomicBoolean cancel) {
    this.refresh = refresh;
    this.listener = listener;
    this.cancel = cancel == null ? new AtomicBoolean() : cancel;
    this.result = new Result();
    try {
      run(requests);
    } catch (Cancelled cancelled) {
      result.cancelled = true;
      result.artifacts.clear();
    } catch (RuntimeException | StackOverflowError | OutOfMemoryError unexpected) {
      // عطل داخلي غير متوقَّع: لا يُعلَّق الحوار ولا تُعدّ المكتبات محلولة؛ كل جذر يُعلَّم بالسبب.
      if (this.cancel.get()) {
        result.cancelled = true;
        result.artifacts.clear();
      } else {
        String reason = "internal error: " + unexpected;
        for (Request request : requests) {
          result.failures.add(new Failure(Failure.NETWORK, request.toString(), reason, request));
        }
      }
    }
    return result;
  }

  private void run(List<Request> requests) {
    report("", 0);
    // 1) BOM من platform(...): dependencyManagement يعطي الإصدار الغائب ويشارك في التعارض.
    Map<String, String> platformVersions = new LinkedHashMap<>();
    List<Failure> platformFailures = new ArrayList<>();
    for (Request request : requests) {
      if (!request.platform) continue;
      String version = concreteVersion(request.key(), request.version);
      if (version == null) {
        platformFailures.add(new Failure(Failure.NOT_FOUND, request.toString(), "no matching version", request));
        continue;
      }
      Effective bom = effective(request.group, request.artifact, version, request, platformFailures);
      if (bom == null) continue;
      for (MavenPom.Dependency managed : bom.management) {
        if (managed.version != null && !platformVersions.containsKey(managed.key())) {
          platformVersions.put(managed.key(), managed.version);
        }
      }
    }

    // 2) الشجرة مع حسم التعارض حتى الاستقرار.
    Map<String, String> selected = new HashMap<>();
    Map<String, Node> nodes = new LinkedHashMap<>();
    List<Failure> failures = new ArrayList<>();
    for (int iteration = 0; iteration < MAX_ITERATIONS; iteration++) {
      nodes = new LinkedHashMap<>();
      failures = new ArrayList<>(platformFailures);
      Map<String, Set<String>> requested = new LinkedHashMap<>();
      walk(requests, platformVersions, selected, nodes, requested, failures);
      Map<String, String> next = new HashMap<>();
      for (Map.Entry<String, Set<String>> entry : requested.entrySet()) {
        String best = null;
        for (String version : entry.getValue()) {
          if (best == null || MavenVersion.compare(version, best) > 0) best = version;
        }
        String constraint = platformVersions.get(entry.getKey());
        if (MavenVersion.exactRange(constraint) != null) constraint = MavenVersion.exactRange(constraint);
        if (constraint != null && !MavenVersion.isDynamic(constraint)
            && (best == null || MavenVersion.compare(constraint, best) > 0)) {
          best = constraint;
        }
        next.put(entry.getKey(), best);
      }
      if (next.equals(selected)) break;
      selected = next;
    }
    addFailures(failures);

    // 3) الملفات الثنائية: تنزيل مسبق متوازٍ إلى المخزن، ثم المرور المتسلسل المعتاد (يجدها محلية) فيبقى
    // ترتيب النتائج والأخطاء كما هو تمامًا.
    List<Node> ordered = new ArrayList<>(nodes.values());
    final int base = prefetchBinaries(ordered) ? 95 : 20;
    final double span = 100 - base;
    for (int i = 0; i < ordered.size(); i++) {
      checkCancelled();
      Node node = ordered.get(i);
      final int index = i;
      final int count = ordered.size();
      resolveBinary(node, new ProgressBridge(nodeName(node)) {
        @Override
        int percent(double fraction) {
          return base + (int) (span * (index + fraction) / count);
        }
      });
      report(nodeName(node), base + (int) (span * (i + 1) / count));
    }
    report(progressName, 100);
  }

  /** امتداد الملف الثنائي المتوقَّع للعقدة، أو null لحزمة pom. */
  private static String primaryExtension(Node node) {
    String packaging = node.pom.packaging == null ? "jar" : node.pom.packaging;
    if (node.type != null && !node.type.isEmpty()) return node.type.equals("bundle") ? "jar" : node.type;
    if (packaging.equals("pom")) return null;
    return packaging.equals("aar") ? "aar" : "jar";
  }

  /**
   * ينزّل بالتوازي الملفات الثنائية الغائبة عن المخزن إن كان الناقل يحتمل ذلك. لا يسجّل نتيجة ولا خطأ:
   * أي فشل هنا يُعاد في المرور المتسلسل الذي يملك الحكم (والمضيف الميت يُرفض فيه فورًا).
   */
  private boolean prefetchBinaries(List<Node> ordered) {
    int threads = Math.min(fetcher.parallelism(), 6);
    if (threads <= 1) return false;
    List<Node> missing = new ArrayList<>();
    for (Node node : ordered) {
      String primary = primaryExtension(node);
      if (primary == null) continue;
      MavenStore.Coordinate coordinate = new MavenStore.Coordinate(node.pom.groupId, node.pom.artifactId,
          node.pom.version, node.classifier, null);
      String alternative = primary.equals("jar") ? "aar" : primary.equals("aar") ? "jar" : null;
      if (local(coordinate, primary) != null || (alternative != null && local(coordinate, alternative) != null)) continue;
      if (!refresh && new File(store.artifactDir(coordinate), coordinate.fileName("nobinary")).isFile()) continue;
      missing.add(node);
    }
    if (missing.size() < 2) return false;
    java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(
        Math.min(threads, missing.size()), task -> {
          Thread thread = new Thread(task, "maven-prefetch");
          thread.setDaemon(true);
          return thread;
        });
    java.util.concurrent.ExecutorCompletionService<Node> done = new java.util.concurrent.ExecutorCompletionService<>(pool);
    try {
      for (Node node : missing) {
        done.submit(() -> {
          String primary = primaryExtension(node);
          MavenStore.Coordinate coordinate = new MavenStore.Coordinate(node.pom.groupId, node.pom.artifactId,
              node.pom.version, node.classifier, null);
          String alternative = primary.equals("jar") ? "aar" : primary.equals("aar") ? "jar" : null;
          try {
            File binary = obtain(coordinate, primary, true, progress());
            if (binary == null && alternative != null) obtain(coordinate, alternative, true, progress());
          } catch (Cancelled cancelled) {
            throw cancelled;
          } catch (RuntimeException ignored) {
            // يُعاد في المرور المتسلسل.
          }
          return node;
        });
      }
      for (int i = 0; i < missing.size(); i++) {
        java.util.concurrent.Future<Node> next;
        while ((next = done.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS)) == null) checkCancelled();
        try {
          Node node = next.get();
          report(nodeName(node), 20 + (int) (75.0 * (i + 1) / missing.size()));
        } catch (java.util.concurrent.ExecutionException failed) {
          if (failed.getCause() instanceof Cancelled) throw (Cancelled) failed.getCause();
        }
      }
    } catch (InterruptedException interrupted) {
      Thread.currentThread().interrupt();
      throw new Cancelled();
    } finally {
      pool.shutdownNow();
    }
    return true;
  }

  private void walk(List<Request> requests, Map<String, String> platformVersions, Map<String, String> selected,
      Map<String, Node> nodes, Map<String, Set<String>> requested, List<Failure> failures) {
    Deque<Visit> queue = new ArrayDeque<>();
    for (Request request : requests) {
      if (request.platform) continue;
      String version = request.version != null ? request.version : platformVersions.get(request.key());
      if (version == null) {
        failures.add(new Failure(Failure.NO_VERSION, request.key(), "no version", request));
        continue;
      }
      queue.add(new Visit(request.group, request.artifact, version, request.classifier, request.extension,
          Collections.<String>emptySet(), request.compile, true, request));
    }
    Set<String> failedKeys = new HashSet<>();
    int processed = 0;
    while (!queue.isEmpty()) {
      checkCancelled();
      Visit visit = queue.poll();
      String key = visit.key();
      if (visit.version == null) {
        if (failedKeys.add(key + ":")) failures.add(new Failure(Failure.NO_VERSION, key, "no version", visit.root));
        continue;
      }
      String concrete = concreteVersion(key, visit.version);
      if (concrete == null) {
        if (failedKeys.add(key + ":" + visit.version)) {
          failures.add(new Failure(Failure.NOT_FOUND, key + ":" + visit.version, "no matching version", visit.root));
        }
        continue;
      }
      Set<String> versions = requested.get(key);
      if (versions == null) requested.put(key, versions = new LinkedHashSet<>());
      versions.add(concrete);
      Node node = nodes.get(key);
      if (node != null) {
        node.direct |= visit.direct;
        if (visit.classifier != null && node.classifier == null) node.classifier = visit.classifier;
        if (visit.type != null && node.type == null) node.type = visit.type;
        if (visit.compile && !node.compileVisible) {
          node.compileVisible = true;
          if (!node.expandedCompile) enqueueChildren(node, visit.exclusions, true, queue);
        }
        continue;
      }
      String version = selected.containsKey(key) ? selected.get(key) : concrete;
      processed++;
      report(key + ":" + version, Math.min(19, (int) (20.0 * processed / (processed + queue.size() + 1))));
      if (failedKeys.contains(key + "@" + version)) continue;
      Effective pom = effective(visit.group, visit.artifact, version, visit.root, failures);
      if (pom == null) {
        failedKeys.add(key + "@" + version);
        continue;
      }
      node = new Node(pom, visit.root);
      node.classifier = visit.classifier;
      node.type = visit.type;
      node.direct = visit.direct;
      node.compileVisible = visit.compile;
      nodes.put(key, node);
      // إعادة توجيه إلى مفتاح آخر: الهدف يحلّ محلّ الأصل.
      if (!pom.key().equals(key)) {
        nodes.remove(key);
        queue.addFirst(new Visit(pom.groupId, pom.artifactId, pom.version, visit.classifier, visit.type,
            visit.exclusions, visit.compile, visit.direct, visit.root));
        continue;
      }
      enqueueChildren(node, visit.exclusions, visit.compile, queue);
    }
  }

  private void enqueueChildren(Node node, Set<String> exclusions, boolean compilePath, Deque<Visit> queue) {
    if (compilePath) node.expandedCompile = true;
    for (MavenPom.Dependency dependency : node.pom.dependencies) {
      if (dependency.optional) continue;
      String scope = dependency.scope == null ? "compile" : dependency.scope;
      if (!scope.equals("compile") && !scope.equals("runtime")) continue;
      if (excluded(exclusions, dependency.groupId, dependency.artifactId)) continue;
      if (dependency.version == null || dependency.version.indexOf("${") >= 0) {
        // بلا إصدار حتى بعد الأب وBOM: لا يمكن حلّه.
        queue.add(new Visit(dependency.groupId, dependency.artifactId, null, null, null, exclusions, false, false, node.root));
        continue;
      }
      Set<String> childExclusions = exclusions;
      if (!dependency.exclusions.isEmpty()) {
        childExclusions = new HashSet<>(exclusions);
        childExclusions.addAll(dependency.exclusions);
      }
      queue.add(new Visit(dependency.groupId, dependency.artifactId, dependency.version, dependency.classifier,
          dependency.type, childExclusions, compilePath && scope.equals("compile"), false, node.root));
    }
  }

  static boolean excluded(Set<String> exclusions, String group, String artifact) {
    for (String exclusion : exclusions) {
      int colon = exclusion.indexOf(':');
      String g = colon < 0 ? exclusion : exclusion.substring(0, colon);
      String a = colon < 0 ? "*" : exclusion.substring(colon + 1);
      if ((g.equals("*") || g.equals(group)) && (a.equals("*") || a.equals(artifact))) return true;
    }
    return false;
  }

  private void addFailures(List<Failure> failures) {
    Set<String> seen = new HashSet<>();
    for (Failure failure : failures) if (seen.add(failure.coordinate)) result.failures.add(failure);
  }

  // ═══════════════ الإصدارات الديناميكية ═══════════════

  /** إصدار ثابت كما هو، والديناميكي من maven-metadata.xml لكل المستودعات (اتحاد)؛ null إن لم يطابق. */
  private String concreteVersion(String key, String requested) {
    if (requested == null || requested.trim().isEmpty()) return null;
    String exact = MavenVersion.exactRange(requested);
    if (exact != null) return exact;
    if (!MavenVersion.isDynamic(requested)) return requested.trim();
    return MavenVersion.select(requested, availableVersions(key));
  }

  List<String> availableVersions(String key) {
    List<String> cached = versionsCache.get(key);
    if (cached != null) return cached;
    int colon = key.indexOf(':');
    String group = key.substring(0, colon);
    String artifact = key.substring(colon + 1);
    String relative = group.replace('.', '/') + "/" + artifact;
    File root = new File(store.downloadDir(), relative);
    Set<String> versions = new LinkedHashSet<>();
    boolean haveCache = false;
    File[] cachedFiles = root.listFiles();
    if (cachedFiles != null) {
      for (File file : cachedFiles) {
        if (file.isFile() && file.getName().startsWith("maven-metadata") && file.getName().endsWith(".xml")) haveCache = true;
      }
    }
    if (refresh || refreshMetadata || !haveCache) {
      List<Repo> routed = route(group);
      boolean found = false;
      for (int i = 0; i < routed.size(); i++) {
        checkCancelled();
        Repo repo = routed.get(i);
        if (repo.url == null) continue;
        // اتحاد المعلنة كما في Gradle؛ والاحتياطية تُسأل فقط إن لم يجد أحد قبلها شيئًا.
        if (repo.fallback && found) continue;
        File target = new File(root, "maven-metadata-" + Integer.toHexString(repo.url.hashCode()) + ".xml");
        try {
          if (fetcher.fetch(repo.url + relative + "/maven-metadata.xml", target, false, progress())) found = true;
        } catch (Cancelled cancelled) {
          throw cancelled;
        } catch (IOException ignored) {
          // مستودع غير متاح: يكفي ما في غيره أو في المخبأ.
        }
      }
    }
    cachedFiles = root.listFiles();
    if (cachedFiles != null) {
      for (File file : cachedFiles) {
        if (file.isFile() && file.getName().startsWith("maven-metadata") && file.getName().endsWith(".xml")) {
          readVersions(file, versions);
        } else if (file.isDirectory() && new File(file, artifact + "-" + file.getName() + ".pom").isFile()) {
          versions.add(file.getName());
        }
      }
    }
    List<File> localRoots = new ArrayList<>(store.localRepositories());
    for (Repo repo : repos) if (repo.dir != null) localRoots.add(repo.dir);
    for (File local : localRoots) {
      File dir = new File(local, relative);
      File[] children = dir.listFiles();
      if (children == null) continue;
      for (File child : children) {
        if (child.isFile() && child.getName().startsWith("maven-metadata") && child.getName().endsWith(".xml")) {
          readVersions(child, versions);
        } else if (child.isDirectory() && new File(child, artifact + "-" + child.getName() + ".pom").isFile()) {
          versions.add(child.getName());
        }
      }
    }
    List<String> out = new ArrayList<>(versions);
    versionsCache.put(key, out);
    return out;
  }

  private static void readVersions(File file, Set<String> out) {
    // W22/ب1: التعبيرُ النمطيُّ القديمُ كانَ يلتقطُ <version> من versioning/snapshot أيضًا، فيُعلَنُ
    // إصدارٌ لا يُنزَّلُ كإصدارٍ. MavenMetadata واعٍ بمسارِ العنصرِ، ويقرَأُ latest/release أيضًا.
    try {
      out.addAll(MavenMetadata.read(file).versions);
    } catch (Exception ignored) {
      // ملف تالف: يُتجاهل.
    }
  }

  // ═══════════════ POM الفعّال ═══════════════

  private Effective effective(String group, String artifact, String version, Request root, List<Failure> failures) {
    String id = group + ":" + artifact + ":" + version;
    Effective cached = effectiveCache.get(id);
    if (cached != null) return cached;
    String error = effectiveErrors.get(id);
    if (error == null) {
      try {
        cached = build(group, artifact, version, 0, new HashSet<String>());
        if (cached == null) error = "N|not found";
      } catch (NetworkError network) {
        error = "W|" + network.getMessage();
      } catch (Cancelled cancelled) {
        throw cancelled;
      } catch (Exception invalid) {
        error = "I|" + (invalid.getMessage() == null ? invalid.getClass().getSimpleName() : invalid.getMessage());
      }
    }
    if (cached != null) {
      effectiveCache.put(id, cached);
      return cached;
    }
    effectiveErrors.put(id, error);
    int type = error.startsWith("N") ? Failure.NOT_FOUND : error.startsWith("W") ? Failure.NETWORK : Failure.INVALID_POM;
    failures.add(new Failure(type, id, error.substring(2), root));
    return null;
  }

  /** null = POM غير موجود في أي مستودع. */
  private Effective build(String group, String artifact, String version, int depth, Set<String> chain) throws Exception {
    String id = group + ":" + artifact + ":" + version;
    Effective cached = effectiveCache.get(id);
    if (cached != null) return cached;
    if (depth > MAX_PARENT_DEPTH || !chain.add(id)) throw new IllegalStateException("parent cycle at " + id);
    MavenStore.Coordinate coordinate = new MavenStore.Coordinate(group, artifact, version, null, null);
    File file = obtain(coordinate, "pom", false, progress());
    if (file == null) return null;
    MavenPom pom;
    try {
      pom = MavenPom.parse(Files.readAllBytes(file.toPath()));
    } catch (Exception invalid) {
      throw new IllegalStateException("invalid POM " + file.getName());
    }
    Effective parent = null;
    if (pom.hasParent()) {
      parent = build(pom.parentGroupId, pom.parentArtifactId, pom.parentVersion, depth + 1, chain);
      // أب مفقود لا يُسقط الأداة: تُكمل بما فيها (Gradle يفشل هنا، لكن الإكمال أنفع للمحرر).
    }
    Effective out = new Effective();
    if (parent != null) out.properties.putAll(parent.properties);
    out.properties.putAll(pom.properties);
    out.groupId = pom.groupId != null ? pom.groupId : pom.parentGroupId != null ? pom.parentGroupId : group;
    out.artifactId = pom.artifactId != null ? pom.artifactId : artifact;
    out.version = pom.version != null ? pom.version : pom.parentVersion != null ? pom.parentVersion : version;
    out.packaging = pom.packaging == null ? "jar" : pom.packaging;
    putProject(out.properties, "project.", out.groupId, out.artifactId, out.version);
    if (pom.hasParent()) {
      putProject(out.properties, "parent.", pom.parentGroupId, pom.parentArtifactId, pom.parentVersion);
      putProject(out.properties, "project.parent.", pom.parentGroupId, pom.parentArtifactId, pom.parentVersion);
    }
    out.groupId = MavenPom.interpolate(out.groupId, out.properties);
    out.version = MavenPom.interpolate(out.version, out.properties);
    out.packaging = MavenPom.interpolate(out.packaging, out.properties);
    // الإحداثيات الحقيقية هي المطلوبة (POM قد يكتب ${} لا يُحلّ).
    out.groupId = group;
    out.artifactId = artifact;
    out.version = version;

    // dependencyManagement: الذاتي ثم BOM المستوردة ثم الأب.
    for (MavenPom.Dependency managed : pom.dependencyManagement) {
      MavenPom.Dependency d = interpolate(managed, out.properties);
      if ("import".equals(d.scope) && "pom".equals(d.type)) {
        if (d.version == null || d.version.indexOf("${") >= 0) continue;
        Effective imported = build(d.groupId, d.artifactId, d.version, depth + 1, new HashSet<>(chain));
        if (imported != null) out.management.addAll(imported.management);
      } else {
        out.management.add(d);
      }
    }
    if (parent != null) out.management.addAll(parent.management);

    // الاعتماديات: الموروثة ثم الذاتية (الذاتية تغلب بالمفتاح).
    Map<String, MavenPom.Dependency> merged = new LinkedHashMap<>();
    if (parent != null) for (MavenPom.Dependency d : parent.dependencies) merged.put(d.key() + "|" + d.classifier, d);
    for (MavenPom.Dependency raw : pom.dependencies) {
      MavenPom.Dependency d = interpolate(raw, out.properties);
      MavenPom.Dependency managed = managedFor(out.management, d);
      if (managed != null) {
        List<String> exclusions = d.exclusions;
        if (!managed.exclusions.isEmpty()) {
          exclusions = new ArrayList<>(d.exclusions);
          exclusions.addAll(managed.exclusions);
        }
        d = d.with(d.groupId, d.artifactId, d.version != null ? d.version : managed.version,
            d.scope != null ? d.scope : managed.scope, d.type, d.classifier, exclusions);
      }
      merged.put(d.key() + "|" + d.classifier, d);
    }
    out.dependencies.addAll(merged.values());

    // إعادة التوجيه: الأداة الحقيقية في مكان آخر.
    if (pom.isRelocated()) {
      String g = pom.relocationGroupId != null ? MavenPom.interpolate(pom.relocationGroupId, out.properties) : group;
      String a = pom.relocationArtifactId != null ? MavenPom.interpolate(pom.relocationArtifactId, out.properties) : artifact;
      String v = pom.relocationVersion != null ? MavenPom.interpolate(pom.relocationVersion, out.properties) : version;
      if (!(g + ":" + a + ":" + v).equals(id)) {
        Effective target = build(g, a, v, depth + 1, chain);
        if (target != null) return target;
      }
    }
    return out;
  }

  private static void putProject(Map<String, String> properties, String prefix, String group, String artifact, String version) {
    if (group != null) properties.put(prefix + "groupId", group);
    if (artifact != null) properties.put(prefix + "artifactId", artifact);
    if (version != null) properties.put(prefix + "version", version);
  }

  private static MavenPom.Dependency interpolate(MavenPom.Dependency d, Map<String, String> properties) {
    return d.with(MavenPom.interpolate(d.groupId, properties), MavenPom.interpolate(d.artifactId, properties),
        MavenPom.interpolate(d.version, properties), MavenPom.interpolate(d.scope, properties),
        MavenPom.interpolate(d.type, properties), MavenPom.interpolate(d.classifier, properties), d.exclusions);
  }

  private static MavenPom.Dependency managedFor(List<MavenPom.Dependency> management, MavenPom.Dependency d) {
    for (MavenPom.Dependency managed : management) {
      if (managed.groupId.equals(d.groupId) && managed.artifactId.equals(d.artifactId)) return managed;
    }
    return null;
  }

  // ═══════════════ الملفات ═══════════════

  /**
   * ملف من المخزن أو المستودعات: المحلي أولًا (مجلد التنزيل إلا عند التحديث، ثم المستودعات المحلية)،
   * ثم المستودعات بالترتيب بدءًا بمن خدم هذه الأداة. null = غير موجود في أي مستودع.
   */
  private File obtain(MavenStore.Coordinate coordinate, String ext, boolean verify, Progress progress) {
    File found = local(coordinate, ext);
    if (found != null) return found;
    File own = store.artifactFile(coordinate, ext);
    String ownKey = own.getAbsolutePath();
    String path = coordinate.relativeDir() + "/" + coordinate.fileName(ext);
    String gaKey = coordinate.key() + ":" + coordinate.version;
    List<Repo> order = route(coordinate.group);
    Repo first = servedBy.get(gaKey);
    if (first != null) {
      order.remove(first);
      order.add(0, first);
    }
    String networkError = null;
    for (Repo repo : order) {
      checkCancelled();
      if (repo.dir != null) {
        File candidate = new File(repo.dir, path);
        if (candidate.isFile()) return candidate;
        continue;
      }
      try {
        if (fetcher.fetch(repo.url + path, own, verify, progress)) {
          if (!usableDownloaded(own, ext, coordinate)) continue; // صفحةُ خطأٍ أو قطعٌ: جرِّبْ غيرَهُ
          servedBy.put(gaKey, repo);
          refreshed.add(ownKey);
          synchronized (this) {
            result.downloaded++;
          }
          return own;
        }
      } catch (Cancelled cancelled) {
        throw cancelled;
      } catch (IOException error) {
        networkError = error.getMessage() == null ? error.toString() : error.getMessage();
      }
    }
    if (own.isFile() && usableDownloaded(own, ext, coordinate)) {
      refreshed.add(ownKey); // تحديث فشل/غير موجود: تبقى النسخة القديمة صالحة
      return own;
    }
    if (networkError != null) throw new NetworkError(networkError);
    return null;
  }

  /** ما نزَلَتهُ الشبكةُ يَلِجُ المخزنَ: المقطوعُ وغيرُ الأرشيفِ يُحذَفانِ ولا يُقبَلانِ، ويُذكَرُ سببُها. */
  private boolean usableDownloaded(File own, String ext, MavenStore.Coordinate coordinate) {
    LibraryInstallState.Verdict verdict = LibraryInstallState.inspect(own, ext);
    if (verdict.state == LibraryInstallState.READY || verdict.state == LibraryInstallState.EMPTY) return true;
    LibraryInstallState.heal(store.downloadDir(), own, verdict);
    noteUnusable(coordinate, ext, verdict);
    return false;
  }

  /** مستودعٌ محليٌّ لا يملِكُهُ مخزنُنا: لا نُصلِحُ فيهِ، بل نَعُدِلُ عن ملفِّهِ ونُبلِّغُ سببَهُ. */
  private boolean usableForeign(File candidate, String ext, MavenStore.Coordinate coordinate) {
    if (!candidate.isFile()) return false;
    LibraryInstallState.Verdict verdict = LibraryInstallState.inspect(candidate, ext);
    if (verdict.state == LibraryInstallState.UNUSABLE) {
      noteUnusable(coordinate, ext, verdict);
      return false;
    }
    return true;
  }

  private void noteUnusable(MavenStore.Coordinate coordinate, String ext, LibraryInstallState.Verdict verdict) {
    if (coordinate == null || verdict == null) return;
    unusableReasons.put(coordinate + ":" + ext, verdict.reason.isEmpty() ? "unusable file" : verdict.reason);
  }

  String unusableReason(MavenStore.Coordinate coordinate, String ext) {
    return unusableReasons.get(coordinate + ":" + ext);
  }

  /**
   * ملف محلي بلا شبكة: مجلد التنزيل (إلا إن طُلب تحديثه ولم يُحدَّث بعد) ثم المستودعات المحلية.
   *
   * <p>W21′3: القبولُ اسمٌ **ومضمونٌ** — `LibraryInstallState` يفتحُ الأرشيفَ ويَعُدُّ أصنافَهُ، فلا
   * يبقى تنزيلٌ مقطوعٌ ولا صفحةُ خطأٍ «مكتبةً» إلى الأبدِ. ونسخةُنا الخاصةُ التالفةُ تُحذَفُ هنا،
   * لأنَّ إبقاءَها يعني أنَّ كلَّ دورةٍ تقرأُ نفسَ الخرابِ ولا تُجرِّبُ مصدرًا غيرَهُ؛ وأمّا مستودعٌ
   * محليٌّ غيرُنا فلا نَمَسُّ ملفَّهُ ونَعُدِلُ عنهُ مع بيانِ السببِ.
   */
  private File local(MavenStore.Coordinate coordinate, String ext) {
    File own = store.artifactFile(coordinate, ext);
    if (own.isFile() && (!refresh || refreshed.contains(own.getAbsolutePath()))) {
      LibraryInstallState.Verdict verdict = LibraryInstallState.inspect(own, ext);
      if (verdict.state == LibraryInstallState.READY || verdict.state == LibraryInstallState.EMPTY)
        return own;
      LibraryInstallState.heal(store.downloadDir(), own, verdict);
      noteUnusable(coordinate, ext, verdict);
    }
    for (File local : store.localRepositories()) {
      File candidate = new File(new File(local, coordinate.relativeDir()), coordinate.fileName(ext));
      if (usableForeign(candidate, ext, coordinate)) return candidate;
    }
    for (Repo repo : repos) {
      if (repo.dir == null) continue;
      File candidate = new File(new File(repo.dir, coordinate.relativeDir()), coordinate.fileName(ext));
      if (usableForeign(candidate, ext, coordinate)) return candidate;
    }
    return null;
  }

  private File stale(MavenStore.Coordinate coordinate, String ext) {
    File own = store.artifactFile(coordinate, ext);
    if (!own.isFile()) return null;
    LibraryInstallState.Verdict verdict = LibraryInstallState.inspect(own, ext);
    if (verdict.state == LibraryInstallState.READY || verdict.state == LibraryInstallState.EMPTY) return own;
    // نسخةٌ قديمةٌ تالفةٌ ليست «صلاحيةً» بعدَ انقطاعِ الشبكةِ: تُحذَفُ ويُعلَنُ سببُها
    LibraryInstallState.heal(store.downloadDir(), own, verdict);
    noteUnusable(coordinate, ext, verdict);
    return null;
  }

  private void resolveBinary(Node node, Progress progress) {
    Effective pom = node.pom;
    MavenStore.Coordinate coordinate =
        new MavenStore.Coordinate(pom.groupId, pom.artifactId, pom.version, node.classifier, null);
    String packaging = pom.packaging == null ? "jar" : pom.packaging;
    String primary;
    if (node.type != null && !node.type.isEmpty()) primary = node.type.equals("bundle") ? "jar" : node.type;
    else if (packaging.equals("pom")) primary = null;
    else if (packaging.equals("aar")) primary = "aar";
    else primary = "jar";
    File binary = null;
    try {
      if (primary != null) {
        String alternative = primary.equals("jar") ? "aar" : primary.equals("aar") ? "jar" : null;
        // المحلي بالامتدادين أولًا، ثم الشبكة؛ وعلامة «بلا ملف ثنائي» لجذور KMP تمنع السؤال كل مرة.
        File noBinary = new File(store.artifactDir(coordinate), coordinate.fileName("nobinary"));
        binary = local(coordinate, primary);
        if (binary == null && alternative != null) binary = local(coordinate, alternative);
        boolean knownShell = binary == null && noBinary.isFile() && !refresh;
        if (binary == null && !knownShell) {
          try {
            binary = obtain(coordinate, primary, true, progress);
            if (binary == null && alternative != null) binary = obtain(coordinate, alternative, true, progress);
          } catch (NetworkError offline) {
            // تحديث بلا شبكة: النسخة السابقة (بأي امتداد) أو علامة KMP تبقى صالحة.
            binary = stale(coordinate, primary);
            if (binary == null && alternative != null) binary = stale(coordinate, alternative);
            if (binary == null && !noBinary.isFile()) throw offline;
            if (binary == null) knownShell = true;
          }
          if (binary == null && knownShell) {
            // KMP معروف سابقًا.
          } else if (binary == null) {
            if (!isPlatformShell(pom)) {
              // وُجِدَ الملفُّ ورُفِضَ مضمونُه؟ تلفٌ لا فقدٌ: الرسالةُ تقولُ ذلكَ والسطرُ يُوسَمُ بهِ
              String damaged = primary == null ? null : unusableReason(coordinate, primary);
              result.failures.add(new Failure(damaged == null ? Failure.NOT_FOUND : Failure.INCOMPLETE,
                  coordinate.toString(),
                  damaged == null ? "missing " + primary : "unusable " + primary + " (" + damaged + ")",
                  node.root));
              return;
            }
            noBinary.getParentFile().mkdirs();
            noBinary.createNewFile();
          } else if (noBinary.isFile()) {
            noBinary.delete();
          }
        }
      }
    } catch (IOException marker) {
      // تعذّر كتابة العلامة: لا يضرّ (يُسأل في المرة القادمة).
    } catch (NetworkError network) {
      result.failures.add(new Failure(Failure.NETWORK, coordinate.toString(), network.getMessage(), node.root));
      return;
    }
    // W21′3: اسمُ الأداةِ لا يَكفي — ملفُّها يُفتَحُ ويُعَدُّ. والحُكمُ يَرفَقُ الأداةَ نفسها، فلا
    // يحتاجُ الحوارُ ولا شاشةُ المكتباتِ إلى إعادةِ قراءةِ القرصِ ليقولا «جاهزةٌ» أو «لا أصنافَ فيها».
    LibraryInstallState.Verdict verdict = binary == null ? null : LibraryInstallState.inspect(binary);
    if (verdict != null && verdict.broken()) {
      result.failures.add(new Failure(Failure.INCOMPLETE, coordinate.toString(),
          verdict.reason.isEmpty() ? "unusable file" : verdict.reason, node.root));
      return;
    }
    File aarDir = null;
    List<File> jars = new ArrayList<>();
    if (binary != null && binary.getName().endsWith(".aar")) {
      try {
        aarDir = extractAar(binary, store.artifactDir(coordinate), coordinate);
      } catch (IOException bad) {
        result.failures.add(new Failure(Failure.INVALID_POM, coordinate.toString(), "bad aar: " + bad.getMessage(), node.root));
        return;
      }
      File classes = new File(aarDir, "classes.jar");
      LibraryInstallState.Verdict nested = classes.isFile() ? LibraryInstallState.inspect(classes) : null;
      if (nested != null && nested.broken()) {
        // جدولُ الأرشيفِ يذكرُ classes.jar والملفُّ المخْرَجُ لا يُفتَحُ: فكٌّ قُطِعَ — فرصةُ إعادةٍ واحدةٌ
        refreshed.add(binary.getAbsolutePath());
        try {
          aarDir = extractAar(binary, store.artifactDir(coordinate), coordinate);
        } catch (IOException again) {
          result.failures.add(new Failure(Failure.INCOMPLETE, coordinate.toString(),
              "incomplete extraction: " + again.getMessage(), node.root));
          return;
        }
        classes = new File(aarDir, "classes.jar");
        nested = classes.isFile() ? LibraryInstallState.inspect(classes) : null;
        if (nested != null && nested.broken()) {
          result.failures.add(new Failure(Failure.INCOMPLETE, coordinate.toString(),
              "extracted classes.jar is not usable (" + nested.reason + ")", node.root));
          return;
        }
      }
      if (classes.isFile() && (nested == null || !nested.broken())) jars.add(classes);
      else if (verdict != null && verdict.listsClassesJar) {
        // المكتبةُ تُعلنُ أصنافًا والفكُّ لم يُخْرِجْها: لا يُقالُ «ثُبِّتَتْ» على نصفِ عملٍ
        result.failures.add(new Failure(Failure.INCOMPLETE, coordinate.toString(),
            "not extracted completely: classes.jar is missing", node.root));
        return;
      }
      List<File> sorted = almlk.AarExploder.bundledJars(aarDir);
      for (File lib : sorted) {
        if (LibraryInstallState.inspect(lib).broken()) {
          result.failures.add(new Failure(Failure.INCOMPLETE, coordinate.toString(),
              "bundled library " + lib.getName() + " is not usable", node.root));
          return;
        }
      }
      jars.addAll(sorted);
    } else if (binary != null) {
      jars.add(binary);
    }
    result.artifacts.add(new Artifact(coordinate, packaging, binary, aarDir, jars, node.compileVisible,
        node.direct, verdict));
  }

  /** جذر KMP (أو packaging خاطئ): لا ملف ثنائي وله اعتماد باسم artifactId-… يحمل الشيفرة. */
  private static boolean isPlatformShell(Effective pom) {
    for (MavenPom.Dependency d : pom.dependencies) {
      if (d.artifactId.startsWith(pom.artifactId + "-") && d.groupId.equals(pom.groupId)) return true;
    }
    return false;
  }

  /**
   * W22/4أ: العقدُ `.exploded.aar` بآليّتِهِ (`almlk/AarExploder`) — بصمةُ المصدرِ تحكُمُ على
   * إعادةِ الاستخدامِ لا زمنُ العلامةِ، والمكوِّناتُ معلَنةٌ، والفكُّ الناقصُ لا يعقُبُ عليهِ عقدةٌ.
   * لا مسارَ قديمًا موازيًا: كانَ هنا فكٌّ وعلامةُ `.extracted` فاستُبدِلا.
   */
  File extractAar(File aar, File writableDir, MavenStore.Coordinate coordinate) throws IOException {
    return almlk.AarExploder.ensure(aar, writableDir, new almlk.AarExploder.Progress() {
      @Override
      public void extracted(int entries, long bytes) {}

      @Override
      public boolean cancelled() {
        return cancel.get() || Thread.currentThread().isInterrupted();
      }
    }, refreshed.contains(aar.getAbsolutePath())).node;
  }

  static void deleteTree(File file) {
    File[] children = file.listFiles();
    if (children != null) for (File child : children) deleteTree(child);
    file.delete();
  }

  // ═══════════════ التقدّم والإلغاء ═══════════════

  private void checkCancelled() {
    if (cancel.get() || Thread.currentThread().isInterrupted()) throw new Cancelled();
  }

  private Progress progress() {
    return new Progress() {
      @Override
      public void bytes(long done, long total) {}

      @Override
      public boolean cancelled() {
        return cancel.get();
      }
    };
  }

  private abstract class ProgressBridge implements Progress {
    private final String name;

    ProgressBridge(String name) {
      this.name = name;
    }

    abstract int percent(double fraction);

    @Override
    public void bytes(long done, long total) {
      double fraction = total > 0 ? Math.min(1.0, (double) done / total) : 0;
      report(name, percent(fraction));
    }

    @Override
    public boolean cancelled() {
      return cancel.get();
    }
  }

  private static String nodeName(Node node) {
    return node.pom.groupId + ":" + node.pom.artifactId + ":" + node.pom.version;
  }

  private void report(String name, int percent) {
    percent = Math.max(0, Math.min(100, percent));
    if (percent < progressPercent && name.equals(progressName)) return;
    if (percent == progressPercent && name.equals(progressName)) return;
    progressName = name;
    progressPercent = percent;
    if (listener != null) listener.onProgress(name, percent);
  }

}
