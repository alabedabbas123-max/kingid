package almlk;

import android.view.KeyEvent;
import android.view.inputmethod.BaseInputConnection;

/**
 * بند almlk ← قناة الإدخال لـ«OEditor»: BaseInputConnection يوجّه أحداث الكيبورد الناعم
 * مباشرة إلى استبدالات {@link CodeEditorView} — لا Editable وسيط إطلاقًا (نموذجه هو
 * {@link LineDocument} حصرًا). الإنشاء (composing) يُعامل كإرسال مباشر كما في محرري الأكواد.
 */
public final class CodeInputConnection extends BaseInputConnection {

  private final CodeEditorView editor;

  public CodeInputConnection(CodeEditorView editor) {
    super(editor, true);
    this.editor = editor;
  }

  @Override
  public boolean commitText(CharSequence text, int newCursorPosition) {
    if (text == null) return false;
    editor.commitInput(text.toString());
    return true;
  }

  /** الإنشاء اللاتيني/التصحيح التلقائي: إرسال فوري (محرر كود بلا اقتراحات). */
  @Override
  public boolean setComposingText(CharSequence text, int newCursorPosition) {
    return commitText(text, newCursorPosition);
  }

  @Override
  public boolean deleteSurroundingText(int beforeLength, int afterLength) {
    editor.deleteSurrounding(beforeLength, afterLength);
    return true;
  }

  @Override
  public boolean sendKeyEvent(KeyEvent event) {
    if (event.getAction() != KeyEvent.ACTION_DOWN) return super.sendKeyEvent(event);
    switch (event.getKeyCode()) {
      case KeyEvent.KEYCODE_DEL:
        editor.deleteSurrounding(1, 0);
        return true;
      case KeyEvent.KEYCODE_ENTER:
        editor.newlineWithIndent();
        return true;
      case KeyEvent.KEYCODE_TAB:
        editor.insertTabOrSpaces();
        return true;
      default:
        return super.sendKeyEvent(event); // يمرر للـ onKeyDown (أسهم/الحدود/الحافظة).
    }
  }

  @Override
  public boolean setSelection(int start, int end) {
    int length = editor.getDocument().length();
    int from = Math.max(0, Math.min(start, length));
    int to = Math.max(0, Math.min(end, length));
    int startLine = editor.getDocument().lineForOffset(from);
    int endLine = editor.getDocument().lineForOffset(to);
    if (from == to) {
      editor.setCaret(startLine, from - editor.getDocument().lineStartOffset(startLine));
    } else {
      editor.setSelectionRange(
          startLine, from - editor.getDocument().lineStartOffset(startLine),
          endLine, to - editor.getDocument().lineStartOffset(endLine));
    }
    return true;
  }

  @Override
  public CharSequence getTextBeforeCursor(int n, int flags) {
    int caret = editor.selectionOffsets()[0];
    int from = Math.max(0, caret - n);
    return editor.getDocument().subText(from, caret);
  }

  @Override
  public CharSequence getTextAfterCursor(int n, int flags) {
    int caret = editor.selectionOffsets()[1];
    int length = editor.getDocument().length();
    int to = Math.min(length, caret + n);
    return editor.getDocument().subText(caret, to);
  }

  @Override
  public CharSequence getSelectedText(int flags) {
    return editor.selectedText();
  }

  @Override
  public boolean finishComposingText() {
    return true;
  }
}
