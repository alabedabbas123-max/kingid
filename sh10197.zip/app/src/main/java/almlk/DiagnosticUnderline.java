package almlk;

/** Immutable, line-relative diagnostic range consumed by the editor's drawing pass. */
public final class DiagnosticUnderline {
  public final int startColumn;
  public final int endColumn;
  public final boolean warning;
  /**
   * تلميحُ المحرِّرِ (الجولةُ ‏30، شرطٌ دائمٌ ‏21): يُرسَمُ لهُ خطٌّ أصفرُ متعرِّجٌ تحتَ الرمزِ، ولا
   * يُعتبَرُ خطأً ولا يُذكَرُ في لوحِ الأخطاءِ — «هذا التحويلُ غيرُ ضروريٍّ» وأمثالُهُ من «لا وصولَ
   * إلى…» أسرةٌ مستقلَّةٌ لا إنذارُ كودٍ.
   */
  public final boolean hint;

  public DiagnosticUnderline(int startColumn, int endColumn, boolean warning) {
    this(startColumn, endColumn, warning, false);
  }

  public DiagnosticUnderline(int startColumn, int endColumn, boolean warning, boolean hint) {
    this.startColumn = Math.max(0, startColumn);
    this.endColumn = Math.max(this.startColumn + 1, endColumn);
    this.warning = warning;
    this.hint = hint;
  }
}
