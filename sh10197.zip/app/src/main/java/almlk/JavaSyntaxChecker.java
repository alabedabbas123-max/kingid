package almlk;

import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * المحلل النحوي لجافا — المرجع الوحيد لنحو ملفات {@code .java} في المحرر.
 *
 * <p>مُرمِّز ومحلل تنازلي تعاودي مستقل يغطي قواعد جافا حتى الإصدار 21: الحزمة والاستيرادات و
 * module-info، وclass/interface/enum/record/@interface مع sealed/permits، والأعضاء والمعاملات
 * العامة والتعليقات التوضيحية، وكل الجمل (if/for/foreach/while/do/try-with-resources/multi-catch،
 * وswitch بنوعيه مع الأنماط وwhen، وyield/assert/labels)، والتعابير بكامل الأسبقية (lambda،
 * مراجع الدوال، cast، instanceof بالأنماط، إنشاء المصفوفات، الأصناف المجهولة، text blocks).
 *
 * <p>كل خطأ يُبلَّغ <em>في موضعه</em> بمفردات رسائل المرجع ({@code Missing ';'}، {@code Unexpected
 * 'x'}، {@code Unexpected end of expression}…). التعافي يتم بإدراج افتراضي للرمز الناقص أو بالقفز
 * إلى حد الجملة/العضو، مع كبت التسلسل داخل الجملة الواحدة، فيظهر أكثر من خطأ في الملف بلا سلسلة
 * وهمية. أي عطل داخلي (عمق مفرط، StackOverflowError…) يعيد قائمة فارغة: المحلل لا يخترع أخطاء أبدًا.
 */
public final class JavaSyntaxChecker {

  /** {@link Diagnostic#code} of every syntax diagnostic. */
  public static final String CODE = "SYNTAX";

  private static final int MAX_ISSUES = 100;
  private static final int MAX_DEPTH = 220;

  private static final int EOF = 0;
  private static final int IDENT = 1;
  private static final int KEYWORD = 2;
  private static final int OP = 3;
  private static final int NUMBER = 4;
  private static final int STRING = 5;
  private static final int CHAR = 6;
  private static final int ILLEGAL = 7;

  // Expression shapes — enough to tell statement expressions from the rest.
  private static final int K_OTHER = 0;
  private static final int K_NAME = 1;
  private static final int K_CALL = 2;
  private static final int K_NEW = 3;
  private static final int K_ASSIGN = 4;
  private static final int K_INCDEC = 5;

  private static final Set<String> KEYWORDS =
      new HashSet<>(Arrays.asList(
          "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class",
          "const", "continue", "default", "do", "double", "else", "enum", "extends", "final",
          "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int",
          "interface", "long", "native", "new", "package", "private", "protected", "public",
          "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
          "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false",
          "null"));
  private static final Set<String> PRIMITIVES =
      new HashSet<>(Arrays.asList(
          "boolean", "byte", "char", "short", "int", "long", "float", "double"));
  private static final Set<String> MODIFIERS =
      new HashSet<>(Arrays.asList(
          "public", "protected", "private", "static", "final", "abstract", "native",
          "synchronized", "transient", "volatile", "strictfp", "default"));
  private static final Set<String> ASSIGN_OPS =
      new HashSet<>(Arrays.asList(
          "=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<="));
  /** After an error, a new line starting with one of these ends the skipped statement. */
  private static final Set<String> STATEMENT_STARTS =
      new HashSet<>(Arrays.asList(
          "if", "for", "while", "do", "try", "switch", "return", "throw", "break", "continue",
          "synchronized", "assert", "final", "boolean", "byte", "char", "short", "int", "long",
          "float", "double"));
  /** After an error, a new line starting with one of these ends the skipped member. */
  private static final Set<String> MEMBER_STARTS =
      new HashSet<>(Arrays.asList(
          "public", "protected", "private", "static", "final", "abstract", "native",
          "synchronized", "transient", "volatile", "strictfp", "class", "interface", "enum",
          "void", "@", "boolean", "byte", "char", "short", "int", "long", "float", "double"));
  private static final String[] OPERATORS_3 = {"...", "<<="};
  private static final String[] OPERATORS_2 = {
    "->", "::", "++", "--", "&&", "||", "==", "!=", "<=", ">=", "+=", "-=", "*=", "/=", "%=",
    "&=", "|=", "^=", "<<"
  };
  private static final String OPERATORS_1 = "()[]{};,.@=><!~?:+-*/&|^%";

  private static final Pattern DECIMAL_INT = Pattern.compile("(0|[1-9](_*[0-9])*)[lL]?");
  private static final Pattern OCTAL_INT = Pattern.compile("0(_*[0-7])+[lL]?");
  private static final Pattern HEX_INT = Pattern.compile("0[xX][0-9a-fA-F](_*[0-9a-fA-F])*[lL]?");
  private static final Pattern BINARY_INT = Pattern.compile("0[bB][01](_*[01])*[lL]?");
  private static final Pattern DECIMAL_FLOAT =
      Pattern.compile(
          "([0-9](_*[0-9])*)?[.]?([0-9](_*[0-9])*)?([eE][+-]?[0-9](_*[0-9])*)?[fFdD]?");
  private static final Pattern HEX_FLOAT =
      Pattern.compile(
          "0[xX]([0-9a-fA-F](_*[0-9a-fA-F])*)?[.]?([0-9a-fA-F](_*[0-9a-fA-F])*)?"
              + "[pP][+-]?[0-9](_*[0-9])*[fFdD]?");

  private JavaSyntaxChecker() {}

  /** Syntax diagnostics of a Java compilation unit (empty when the source is valid). */
  public static List<Diagnostic> check(String source) {
    List<Diagnostic> result = checkOrNull(source);
    return result == null ? Collections.<Diagnostic>emptyList() : result;
  }

  /**
   * Like {@link #check} but returns null when the checker could not complete (excessive nesting,
   * StackOverflowError on a small worker stack…): the caller then keeps its lexical findings
   * instead of trusting an incomplete parse. The checker never invents errors from a failure.
   */
  public static List<Diagnostic> checkOrNull(String source) {
    if (source == null || source.isEmpty()) return Collections.emptyList();
    try {
      Parser parser = new Parser(source);
      parser.compilationUnit();
      return parser.diagnostics();
    } catch (Throwable internalFailure) {
      return null;
    }
  }

  /** Abort of the current statement/member; the enclosing loop resynchronizes. */
  private static final class Abort extends RuntimeException {
    Abort() {
      super(null, null, false, false);
    }
  }

  /** Nesting beyond {@link #MAX_DEPTH}: the whole check is abandoned silently. */
  private static final class GiveUp extends RuntimeException {
    GiveUp() {
      super(null, null, false, false);
    }
  }

  private static final Abort ABORT = new Abort();

  private static final class Issue {
    final int start, end;
    final String key, fallback;
    final Object[] args;
    /** The reference's "Insert 'x'" repair of a missing token (null for other issues). */
    QuickFix fix;

    Issue(int start, int end, String key, String fallback, Object... args) {
      this.start = start;
      this.end = end;
      this.key = key;
      this.fallback = fallback;
      this.args = args;
    }
  }

  // ===================================================================================== parser

  private static final class Parser {
    private final String src;
    private int count;
    private int[] kinds = new int[256];
    private int[] starts = new int[256];
    private int[] ends = new int[256];
    private String[] texts = new String[256];
    private boolean[] lineBreaks = new boolean[256];
    private int[] match;

    private final ArrayList<Issue> issues = new ArrayList<>();
    private final HashSet<Integer> reportedStarts = new HashSet<>();
    private boolean suppressed;
    private boolean endOfFileReported;
    private int p;
    /** First token of the statement being parsed: a failure right there is "Unexpected 'x'". */
    private int statementStart = -1;
    private int depth;
    private int noLambda;
    private int scanFailure;

    Parser(String source) {
      src = source;
      lex();
      matchBrackets();
    }

    // ------------------------------------------------------------------------------- lexer

    private void add(int kind, int start, int end, String text, boolean lineBreak) {
      if (count == kinds.length) {
        int size = count * 2;
        kinds = Arrays.copyOf(kinds, size);
        starts = Arrays.copyOf(starts, size);
        ends = Arrays.copyOf(ends, size);
        texts = Arrays.copyOf(texts, size);
        lineBreaks = Arrays.copyOf(lineBreaks, size);
      }
      kinds[count] = kind;
      starts[count] = start;
      ends[count] = end;
      texts[count] = text;
      lineBreaks[count] = lineBreak;
      count++;
    }

    private void lex() {
      int n = src.length();
      int i = 0;
      boolean lineBreak = false;
      while (true) {
        while (i < n) {
          char c = src.charAt(i);
          if (c == '\n') {
            lineBreak = true;
            i++;
          } else if (c == ' ' || c == '\t' || c == '\r' || c == '\f' || c == '\uFEFF'
              || Character.isWhitespace(c)) {
            i++;
          } else if (c == '/' && i + 1 < n && src.charAt(i + 1) == '/') {
            while (i < n && src.charAt(i) != '\n') i++;
          } else if (c == '/' && i + 1 < n && src.charAt(i + 1) == '*') {
            int close = src.indexOf("*/", i + 2);
            int stop = close < 0 ? n : close + 2;
            if (src.indexOf('\n', i) >= 0 && src.indexOf('\n', i) < stop) lineBreak = true;
            i = stop;
          } else break;
        }
        if (i >= n) {
          add(EOF, n, n, "", lineBreak);
          return;
        }
        int s = i;
        char c = src.charAt(i);
        int codePoint = src.codePointAt(i);
        if (Character.isJavaIdentifierStart(codePoint)) {
          i += Character.charCount(codePoint);
          while (i < n) {
            int part = src.codePointAt(i);
            if (!Character.isJavaIdentifierPart(part)) break;
            i += Character.charCount(part);
          }
          String word = src.substring(s, i);
          add(KEYWORDS.contains(word) ? KEYWORD : IDENT, s, i, word, lineBreak);
        } else if (isDigit(c) || (c == '.' && i + 1 < n && isDigit(src.charAt(i + 1)))) {
          i = scanNumber(i);
          String literal = src.substring(s, i);
          if (!validNumber(literal)) issue(s, i, "ui_diagnostic_invalid_literal", "Invalid literal");
          add(NUMBER, s, i, literal, lineBreak);
        } else if (c == '"') {
          i = src.startsWith("\"\"\"", i) ? scanTextBlock(i) : scanString(i);
          add(STRING, s, i, "\"", lineBreak);
        } else if (c == '\'') {
          i = scanChar(i);
          add(CHAR, s, i, "'", lineBreak);
        } else {
          String op = null;
          for (String candidate : OPERATORS_3) if (src.startsWith(candidate, i)) op = candidate;
          if (op == null)
            for (String candidate : OPERATORS_2) if (src.startsWith(candidate, i)) op = candidate;
          if (op == null && OPERATORS_1.indexOf(c) >= 0) op = String.valueOf(c);
          if (op == null) {
            int width = Character.charCount(codePoint);
            add(ILLEGAL, s, s + width, src.substring(s, s + width), lineBreak);
            i = s + width;
          } else {
            add(OP, s, s + op.length(), op, lineBreak);
            i = s + op.length();
          }
        }
        lineBreak = false;
      }
    }

    private static boolean isDigit(char c) {
      return c >= '0' && c <= '9';
    }

    private int scanNumber(int i) {
      int n = src.length();
      boolean hex = false;
      if (src.charAt(i) == '0' && i + 1 < n && (src.charAt(i + 1) == 'x' || src.charAt(i + 1) == 'X')) {
        hex = true;
        i += 2;
      }
      boolean dot = false;
      while (i < n) {
        char c = src.charAt(i);
        if (Character.isLetterOrDigit(c) || c == '_') {
          boolean exponent = hex ? (c == 'p' || c == 'P') : (c == 'e' || c == 'E');
          i++;
          if (exponent && i < n && (src.charAt(i) == '+' || src.charAt(i) == '-')) i++;
        } else if (c == '.' && !dot && !(i + 1 < n && src.charAt(i + 1) == '.')) {
          dot = true;
          i++;
        } else break;
      }
      return i;
    }

    private static boolean validNumber(String literal) {
      if (DECIMAL_INT.matcher(literal).matches()
          || OCTAL_INT.matcher(literal).matches()
          || HEX_INT.matcher(literal).matches()
          || BINARY_INT.matcher(literal).matches()
          || HEX_FLOAT.matcher(literal).matches()) return true;
      if (!DECIMAL_FLOAT.matcher(literal).matches()) return false;
      boolean digit = false, floatMark = false;
      for (int i = 0; i < literal.length(); i++) {
        char c = literal.charAt(i);
        if (isDigit(c)) digit = true;
        if (c == '.' || c == 'e' || c == 'E' || c == 'f' || c == 'F' || c == 'd' || c == 'D')
          floatMark = true;
      }
      return digit && floatMark;
    }

    /** Length of a valid escape at {@code i} (the backslash), or -1 when it is invalid. */
    private int escapeLength(int i, boolean textBlock) {
      int n = src.length();
      if (i + 1 >= n) return -1;
      char c = src.charAt(i + 1);
      if ("btnfrs\"'\\".indexOf(c) >= 0) return 2;
      if (textBlock && (c == '\n' || c == '\r')) return 2;
      if (c >= '0' && c <= '7') {
        int length = 2;
        int max = c <= '3' ? 4 : 3;
        while (length < max && i + length < n && src.charAt(i + length) >= '0'
            && src.charAt(i + length) <= '7') length++;
        return length;
      }
      if (c == 'u') {
        int j = i + 1;
        while (j < n && src.charAt(j) == 'u') j++;
        for (int k = 0; k < 4; k++)
          if (j + k >= n || Character.digit(src.charAt(j + k), 16) < 0) return -1;
        return j + 4 - i;
      }
      return -1;
    }

    private int scanString(int i) {
      int n = src.length();
      i++;
      while (i < n) {
        char c = src.charAt(i);
        if (c == '"') return i + 1;
        if (c == '\n') return i; // unclosed: the lexical pass reports it
        if (c == '\\') {
          int length = escapeLength(i, false);
          if (length < 0) {
            issue(i, Math.min(n, i + 2), "ui_diagnostic_invalid_literal", "Invalid literal");
            length = 2;
          }
          i += length;
        } else i++;
      }
      return n;
    }

    private int scanTextBlock(int i) {
      int n = src.length();
      int s = i;
      i += 3;
      int lineEnd = i;
      while (lineEnd < n && (src.charAt(lineEnd) == ' ' || src.charAt(lineEnd) == '\t'
          || src.charAt(lineEnd) == '\f' || src.charAt(lineEnd) == '\r')) lineEnd++;
      if (lineEnd < n && src.charAt(lineEnd) != '\n')
        issue(s, s + 3, "ui_diagnostic_invalid_literal", "Invalid literal");
      while (i < n) {
        char c = src.charAt(i);
        if (c == '"' && src.startsWith("\"\"\"", i)) return i + 3;
        if (c == '\\') {
          int length = escapeLength(i, true);
          if (length < 0) {
            issue(i, Math.min(n, i + 2), "ui_diagnostic_invalid_literal", "Invalid literal");
            length = 2;
          }
          i += length;
        } else i++;
      }
      return n;
    }

    private int scanChar(int i) {
      int n = src.length();
      int s = i;
      i++;
      int units = 0;
      boolean valid = true;
      while (i < n) {
        char c = src.charAt(i);
        if (c == '\'') {
          i++;
          if (units != 1) valid = false;
          if (!valid) issue(s, i, "ui_diagnostic_invalid_literal", "Invalid literal");
          return i;
        }
        if (c == '\n') return i; // unclosed: the lexical pass reports it
        if (c == '\\') {
          int length = escapeLength(i, false);
          if (length < 0) {
            valid = false;
            length = 2;
          }
          i += length;
        } else i++;
        units++;
      }
      return n;
    }

    private void matchBrackets() {
      match = new int[count];
      Arrays.fill(match, -1);
      int[] stack = new int[count + 1];
      int top = 0;
      for (int i = 0; i < count; i++) {
        if (kinds[i] != OP) continue;
        String t = texts[i];
        if (t.equals("(") || t.equals("[") || t.equals("{")) {
          stack[top++] = i;
        } else if (t.equals(")") || t.equals("]") || t.equals("}")) {
          String opener = t.equals(")") ? "(" : t.equals("]") ? "[" : "{";
          int found = -1;
          for (int k = top - 1; k >= 0; k--) {
            if (texts[stack[k]].equals(opener)) {
              found = k;
              break;
            }
          }
          if (found < 0) continue;
          match[stack[found]] = i;
          match[i] = stack[found];
          top = found;
        }
      }
    }

    // ------------------------------------------------------------------------- diagnostics

    private Issue issue(int start, int end, String key, String fallback, Object... args) {
      if (issues.size() >= MAX_ISSUES || !reportedStarts.add(start)) return null;
      Issue issue = new Issue(start, end, key, fallback, args);
      issues.add(issue);
      return issue;
    }

    /**
     * Reference anchor of "Missing"/"Unexpected end of" findings: the last character of the
     * previous token and the one after it; {@code [2]} is the insertion point (end of that token).
     */
    private int[] afterPrevious() {
      int previous = Math.min(p, count - 1) - 1;
      while (previous >= 0 && kinds[previous] == EOF) previous--;
      if (previous < 0) {
        int at = Math.min(starts[Math.max(0, Math.min(p, count - 1))], src.length());
        return new int[] {at, Math.min(src.length(), at + 1), at};
      }
      int end = ends[previous];
      int from = Math.max(0, end - 1);
      int to = Math.min(src.length(), end + 1);
      if (to <= from) to = Math.min(src.length(), from + 1);
      return new int[] {from, to, end};
    }

    /** "Unexpected end of …" reported after the previous token, as the reference does. */
    private void reportEnd(String key, String fallback) {
      if (suppressed) return;
      suppressed = true;
      int[] at = afterPrevious();
      issue(at[0], at[1], key, fallback);
    }

    /** كما {@code reportEnd} لكن لرسائل الكتالوج التي تُسمّي موضوعها بوسيط. */
    private void reportEnd(String key, String fallback, Object... args) {
      if (suppressed) return;
      suppressed = true;
      int[] at = afterPrevious();
      issue(at[0], at[1], key, fallback, args);
    }

    /** "Missing 'x'" after the previous token with its "Insert 'x'" repair. */
    private void reportMissing(String token, String key, String fallback, Object... args) {
      if (suppressed) return;
      suppressed = true;
      int[] at = afterPrevious();
      Issue issue = issue(at[0], at[1], key, fallback, args);
      if (issue != null) issue.fix = QuickFix.insertToken(token, at[2]);
    }

    private void report(int start, int end, String key, String fallback, Object... args) {
      if (suppressed) return;
      suppressed = true;
      issue(start, end, key, fallback, args);
    }

    private void reportAt(int token, String key, String fallback, Object... args) {
      int t = Math.max(0, Math.min(token, count - 1));
      int start = starts[t];
      int end = Math.max(start + 1, ends[t]);
      if (kinds[t] == EOF) {
        start = Math.max(0, src.length() - 1);
        end = src.length();
      }
      report(start, end, key, fallback, args);
    }

    /** Reports the current token as unexpected and aborts the statement. */
    private Abort unexpected() {
      if (kinds[p] == EOF) {
        reportAt(p, "ui_diagnostic_unexpected_end_of_file", "Unexpected end of file");
      } else if (isClosing(p)) {
        reportAt(p, "ui_diagnostic_unmatched_closing_delimiter", "Unexpected '%1$s'", texts[p]);
      } else {
        reportAt(p, "ui_diagnostic_unexpected_token", "Unexpected '%1$s'", display(p));
      }
      return ABORT;
    }

    /**
     * An expression was required at the current token. Like the reference: a statement that
     * cannot even start is "Unexpected 'x'"; otherwise the expression ended early.
     */
    private Abort expressionExpected() {
      if (p == statementStart || lexicalErrorAt(p)) return unexpected();
      reportEnd("ui_diagnostic_unexpected_end_of_expression", "Unexpected end of expression");
      return ABORT;
    }

    /** End of file or a token the lexical pass already flags: reported on the token itself. */
    private boolean lexicalErrorAt(int i) {
      return kinds[i] == EOF || kinds[i] == ILLEGAL || (kinds[i] == NUMBER && !validNumber(texts[i]));
    }

    /** The construct ended early: reported after its last token whatever follows. */
    private Abort endOf(String key, String fallback) {
      if (lexicalErrorAt(p)) return unexpected();
      reportEnd(key, fallback);
      return ABORT;
    }

    /** كما {@code endOf} لرسالةٍ تحمل واسطةً (اسم الصنف أو كلمته المفتاحية). */
    private Abort endOf(String key, String fallback, Object... args) {
      if (lexicalErrorAt(p)) return unexpected();
      reportEnd(key, fallback, args);
      return ABORT;
    }

    /** Virtual insertion: reports {@code token} as missing after the previous token. */
    private void missing(String token) {
      String key =
          token.equals(";")
              ? "ui_diagnostic_missing_semicolon"
              : token.equals(")") || token.equals("]") || token.equals("}")
                  ? "ui_diagnostic_mismatched_delimiter"
                  : "ui_diagnostic_missing_token";
      if (token.equals(";")) reportMissing(token, key, "Missing ';'");
      else reportMissing(token, key, "Missing '%1$s'", token);
    }

    private String display(int token) {
      if (kinds[token] == STRING || kinds[token] == CHAR || kinds[token] == NUMBER) {
        String text = src.substring(starts[token], ends[token]);
        int newline = text.indexOf('\n');
        if (newline >= 0) text = text.substring(0, newline);
        return text.length() > 24 ? text.substring(0, 24) + "…" : text;
      }
      return texts[token];
    }

    List<Diagnostic> diagnostics() {
      if (issues.isEmpty()) return Collections.emptyList();
      int[] lineStarts = lineStarts();
      ArrayList<Diagnostic> out = new ArrayList<>(issues.size());
      for (Issue issue : issues) {
        int line = lineOf(lineStarts, issue.start);
        int column = issue.start - lineStarts[line] + 1;
        out.add(
            withFix(
                Diagnostic.localized(
                    issue.start,
                    issue.end,
                    line + 1,
                    column,
                    Diagnostic.Severity.ERROR,
                    CODE,
                    issue.key,
                    issue.fallback,
                    issue.args),
                issue.fix));
      }
      Collections.sort(out, (a, b) -> a.offset != b.offset ? a.offset - b.offset : a.end - b.end);
      return out;
    }

    private static Diagnostic withFix(Diagnostic diagnostic, QuickFix fix) {
      return fix == null ? diagnostic : diagnostic.withQuickFixes(Collections.singletonList(fix));
    }

    private int[] lineStarts() {
      int lines = 1;
      for (int i = 0; i < src.length(); i++) if (src.charAt(i) == '\n') lines++;
      int[] result = new int[lines];
      int line = 1;
      for (int i = 0; i < src.length(); i++) if (src.charAt(i) == '\n') result[line++] = i + 1;
      return result;
    }

    private static int lineOf(int[] lineStarts, int offset) {
      int low = 0, high = lineStarts.length - 1;
      while (low < high) {
        int mid = (low + high + 1) >>> 1;
        if (lineStarts[mid] <= offset) low = mid;
        else high = mid - 1;
      }
      return low;
    }

    // ---------------------------------------------------------------------- token helpers

    private boolean is(String text) {
      return isAt(p, text);
    }

    private boolean isAt(int i, String text) {
      if (i < 0 || i >= count) return false;
      int kind = kinds[i];
      return (kind == OP || kind == KEYWORD) && texts[i].equals(text);
    }

    private boolean identAt(int i) {
      return i >= 0 && i < count && kinds[i] == IDENT;
    }

    private boolean ident() {
      return identAt(p);
    }

    private boolean identText(int i, String text) {
      return identAt(i) && texts[i].equals(text);
    }

    private boolean accept(String text) {
      if (!is(text)) return false;
      p++;
      return true;
    }

    private boolean atEnd() {
      return kinds[p] == EOF;
    }

    private boolean isClosing(int i) {
      return isAt(i, ")") || isAt(i, "]") || isAt(i, "}");
    }

    private boolean adjacent(int i) {
      return i > 0 && i < count && starts[i] == ends[i - 1];
    }

    private boolean primitiveAt(int i) {
      return i >= 0 && i < count && kinds[i] == KEYWORD && PRIMITIVES.contains(texts[i]);
    }

    /** {@code token} or a virtual insertion of it (reported). */
    private void expect(String token) {
      if (!accept(token)) missing(token);
    }

    /** A closer: virtual insertion when the code plainly moved on, otherwise an error. */
    private void expectClose(String closer) {
      if (accept(closer)) return;
      if (isClosing(p) || is(";") || is("{") || atEnd() || lineBreaks[p]) {
        missing(closer);
        return;
      }
      throw unexpected();
    }

    private void expectSemicolon() {
      if (accept(";")) return;
      if (atEnd() || is("}") || lineBreaks[p]) {
        missing(";");
        return;
      }
      throw unexpected();
    }

    private void expectIdent() {
      if (ident()) {
        p++;
        return;
      }
      throw unexpected();
    }

    private void enter() {
      if (++depth > MAX_DEPTH) throw new GiveUp();
    }

    private void leave() {
      depth--;
    }

    // ------------------------------------------------------------- speculative type scans

    private int fail(int i) {
      scanFailure = Math.max(scanFailure, i);
      return -1;
    }

    private int scanAnnotations(int i) {
      while (isAt(i, "@") && !isAt(i + 1, "interface")) {
        i++;
        if (!identAt(i)) return fail(i);
        i++;
        while (isAt(i, ".") && identAt(i + 1)) i += 2;
        if (isAt(i, "(")) {
          if (match[i] < 0) return fail(i);
          i = match[i] + 1;
        }
      }
      return i;
    }

    /** End of the type starting at {@code i}, or -1. */
    private int scanType(int i) {
      i = scanAnnotations(i);
      if (i < 0) return -1;
      if (primitiveAt(i)) {
        i++;
      } else if (identAt(i)) {
        i++;
        if (isAt(i, "<")) {
          i = scanTypeArguments(i);
          if (i < 0) return -1;
        }
        while (isAt(i, ".")) {
          int j = scanAnnotations(i + 1);
          if (j < 0 || !identAt(j)) break;
          i = j + 1;
          if (isAt(i, "<")) {
            i = scanTypeArguments(i);
            if (i < 0) return -1;
          }
        }
      } else {
        return fail(i);
      }
      while (true) {
        int j = scanAnnotations(i);
        if (j >= 0 && isAt(j, "[") && isAt(j + 1, "]")) i = j + 2;
        else break;
      }
      return i;
    }

    /** {@code i} is at {@code <}; returns the index after the matching {@code >}, or -1. */
    private int scanTypeArguments(int i) {
      i++;
      if (isAt(i, ">")) return i + 1; // diamond
      while (true) {
        i = scanAnnotations(i);
        if (i < 0) return -1;
        if (isAt(i, "?")) {
          i++;
          if (isAt(i, "extends") || isAt(i, "super")) {
            i = scanType(i + 1);
            if (i < 0) return -1;
            while (isAt(i, "&")) {
              i = scanType(i + 1);
              if (i < 0) return -1;
            }
          }
        } else {
          i = scanType(i);
          if (i < 0) return -1;
        }
        if (isAt(i, ",")) {
          i++;
          continue;
        }
        if (isAt(i, ">")) return i + 1;
        return fail(i);
      }
    }

    private void parseType() {
      scanFailure = p;
      int end = scanType(p);
      if (end < 0) {
        p = Math.max(p, Math.min(scanFailure, count - 1));
        if (is(";")) throw endOf("ui_diagnostic_unexpected_end_of_declaration", "Unexpected end of declaration");
        throw unexpected();
      }
      p = end;
    }

    private void typeArguments() {
      scanFailure = p;
      int end = scanTypeArguments(p);
      if (end < 0) {
        p = Math.max(p, Math.min(scanFailure, count - 1));
        throw unexpected();
      }
      p = end;
    }

    private void typeList() {
      parseType();
      while (accept(",")) parseType();
    }

    private void dims() {
      while (true) {
        int j = scanAnnotations(p);
        if (j >= 0 && isAt(j, "[") && isAt(j + 1, "]")) p = j + 2;
        else return;
      }
    }

    /** A local variable declaration starts at {@code i}: {@code Type name}. */
    private boolean declarationAhead(int i) {
      int end = scanType(i);
      return end > i && identAt(end);
    }

    private boolean recordAhead(int i) {
      return identText(i, "record") && identAt(i + 1) && (isAt(i + 2, "(") || isAt(i + 2, "<"));
    }

    private boolean typeDeclarationAhead() {
      return is("class") || is("interface") || is("enum")
          || (is("@") && isAt(p + 1, "interface")) || recordAhead(p);
    }

    // ------------------------------------------------------------------- compilation unit

    void compilationUnit() {
      while (!atEnd()) {
        suppressed = false;
        int start = p;
        try {
          topLevel();
        } catch (Abort abort) {
          recover(start, true);
          if (p == start) p++; // a stray '}' at top level
        }
      }
    }

    /** Something other than the package declaration was already seen at top level. */
    private boolean pastPackagePosition;

    private void topLevel() {
      if (!is("package") && !is("@")) pastPackagePosition = true;
      if (accept(";")) return;
      if (is("import")) {
        importDeclaration();
        return;
      }
      if ((identText(p, "module") && identAt(p + 1))
          || (identText(p, "open") && identText(p + 1, "module"))) {
        moduleDeclaration();
        return;
      }
      int start = p;
      modifiers();
      if (is("package")) {
        packageDeclaration();
        return;
      }
      if (typeDeclarationAhead()) {
        typeDeclaration();
        return;
      }
      if ((identText(p, "module") && identAt(p + 1))
          || (identText(p, "open") && identText(p + 1, "module"))) {
        moduleDeclaration();
        return;
      }
      // Only types may appear at top level (Java 21 without preview features). The reference
      // ends the declaration there: "Unexpected end of declaration" after the previous token.
      p = start;
      if (kinds[p] == EOF || isClosing(p) || p == 0) throw unexpected();
      throw endOf("ui_diagnostic_unexpected_end_of_declaration", "Unexpected end of declaration");
    }

    private void packageDeclaration() {
      if (pastPackagePosition) throw unexpected(); // the package must come first
      pastPackagePosition = true;
      p++;
      if (!ident()) throw endOf("ui_diagnostic_unexpected_end_of_package", "Unexpected end of package declaration");
      p++;
      while (accept(".")) {
        if (!ident()) throw endOf("ui_diagnostic_unexpected_end_of_package", "Unexpected end of package declaration");
        p++;
      }
      expectSemicolon();
    }

    private void importDeclaration() {
      p++;
      accept("static");
      if (!ident()) throw endOf("ui_diagnostic_unexpected_end_of_import", "Unexpected end of import");
      p++;
      // A single-segment import (`import Foo;`) is incomplete: imports are always qualified.
      if (!is(".")) throw endOf("ui_diagnostic_unexpected_end_of_import", "Unexpected end of import");
      while (accept(".")) {
        if (accept("*")) break;
        if (!ident()) throw endOf("ui_diagnostic_unexpected_end_of_import", "Unexpected end of import");
        p++;
      }
      expectSemicolon();
    }

    private void moduleDeclaration() {
      if (identText(p, "open")) p++;
      p++; // module
      expectIdent();
      while (accept(".")) expectIdent();
      int open = p;
      if (!accept("{")) throw unexpected();
      while (!is("}")) {
        if (atEnd()) {
          endOfFile(open);
          return;
        }
        while (!is(";") && !is("}") && !atEnd()) p++;
        accept(";");
      }
      p++;
    }

    // ----------------------------------------------------------------------------- types

    private void modifiers() {
      HashSet<String> seen = null;
      while (true) {
        if (is("@") && !isAt(p + 1, "interface")) {
          annotation();
        } else if (kinds[p] == KEYWORD && MODIFIERS.contains(texts[p])) {
          if (seen == null) seen = new HashSet<>();
          if (!seen.add(texts[p]))
            reportAt(p, "ui_diagnostic_duplicate_modifier", "Duplicate modifier");
          p++;
        } else if (identText(p, "sealed") && contextualModifierFollows(p + 1)) {
          p++;
        } else if (identText(p, "non") && isAt(p + 1, "-") && identText(p + 2, "sealed")
            && adjacent(p + 1) && adjacent(p + 2)) {
          p += 3;
        } else {
          return;
        }
      }
    }

    private boolean contextualModifierFollows(int i) {
      if (isAt(i, "class") || isAt(i, "interface") || isAt(i, "@")) return true;
      return i < count && kinds[i] == KEYWORD && MODIFIERS.contains(texts[i]);
    }

    private void annotation() {
      p++; // @
      expectIdent();
      while (is(".") && identAt(p + 1)) p += 2;
      if (!is("(")) return;
      p++;
      int saved = noLambda;
      noLambda = 0;
      try {
        if (!is(")")) {
          if (ident() && isAt(p + 1, "=")) {
            do {
              expectIdent();
              expect("=");
              elementValue();
            } while (accept(","));
          } else {
            elementValue();
          }
        }
        expectClose(")");
      } finally {
        noLambda = saved;
      }
    }

    private void elementValue() {
      if (is("@")) {
        annotation();
      } else if (is("{")) {
        p++;
        while (!is("}")) {
          elementValue();
          if (!accept(",")) break;
        }
        expectClose("}");
      } else {
        conditional();
      }
    }

    private void typeDeclaration() {
      enter();
      try {
        if (accept("class")) {
          String name = declaredName("class");
          typeParametersOpt();
          if (accept("extends")) expectSupertype(true, false);
          if (accept("implements")) expectSupertype(false, true);
          permitsOpt();
          classBody(name);
        } else if (accept("interface")) {
          String name = declaredName("interface");
          typeParametersOpt();
          if (accept("extends")) expectSupertype(true, true);
          permitsOpt();
          classBody(name);
        } else if (accept("enum")) {
          String name = declaredName("enum");
          if (accept("implements")) expectSupertype(false, true);
          enumBody(name);
        } else if (is("@")) {
          p += 2;
          classBody(declaredName("interface"));
        } else {
          p++; // record
          String name = declaredName("record");
          typeParametersOpt();
          if (!is("(")) throw unexpected();
          formalParameters();
          if (accept("implements")) expectSupertype(false, true);
          classBody(name);
        }
      } finally {
        leave();
      }
    }

    /**
     * اسمُ الصنف بعد كلمته المفتاحية. غيابُه معلَّلٌ في الكتالوج («The 'class' declaration is
     * missing a valid name.»)، فلا تُرمى «نهاية إعلان» العامة لنفس السبب — البند 4: الخاصة بدل
     * العامة، لا رسالتان متوازيتان.
     */
    private String declaredName(String keyword) {
      if (!ident())
        throw endOf("ui_diagnostic_invalid_declaration",
            "The %1$s declaration is missing a valid name.", keyword);
      return typeName();
    }

    /**
     * النوع الواجب بعد {@code extends}/{@code implements}: وُجد فُرسَم كما كان، وإلا فالرسالة
     * الخاصة به («Specify a class name after extends.» / «Specify an interface after implements.»).
     */
    private void expectSupertype(boolean isExtends, boolean commaList) {
      if (!startsType()) {
        throw endOf(
            isExtends
                ? "ui_diagnostic_missing_extends_type"
                : "ui_diagnostic_missing_implements_type",
            isExtends ? "Specify a class name after extends." : "Specify an interface after implements.");
      }
      if (commaList) typeList();
      else parseType();
    }

    /** هل يبدأ هنا اسمُ نوع (مُعلَّقٌ أو معرِّفٌ أو قوسُ نوعٍ عام)؟ */
    private boolean startsType() {
      return ident() || is("@") || is("(");
    }

    private String typeName() {
      if (ident()) {
        return texts[p++];
      }
      throw endOf("ui_diagnostic_unexpected_end_of_declaration", "Unexpected end of declaration");
    }

    private void permitsOpt() {
      if (identText(p, "permits")) {
        p++;
        typeList();
      }
    }

    private void typeParametersOpt() {
      if (is("<")) typeParameters();
    }

    private void typeParameters() {
      p++;
      do {
        annotationsOpt();
        expectIdent();
        if (accept("extends")) {
          parseType();
          while (accept("&")) parseType();
        }
      } while (accept(","));
      if (!accept(">")) throw unexpected();
    }

    private void annotationsOpt() {
      while (is("@") && !isAt(p + 1, "interface")) annotation();
    }

    /** Simple name of the type whose body is being parsed; null inside an anonymous body. */
    private String currentType;

    private void classBody(String name) {
      int open = p;
      if (!is("{")) {
        // صنفٌ بلا جسم: للسبب رسالةٌ في الكتالوج تسمّيه، لا «رمز غير متوقع» لا تقول شيئًا.
        if (name != null && !name.isEmpty()) {
          reportEnd("ui_diagnostic_missing_class_body",
              "Declaration %1$s has no body ({ ... }).", name);
          throw ABORT;
        }
        throw unexpected();
      }
      p++;
      int savedLambda = noLambda;
      noLambda = 0;
      String savedType = currentType;
      currentType = name;
      enter();
      try {
        while (!is("}")) {
          if (atEnd()) {
            endOfFile(open);
            return;
          }
          member();
        }
        p++;
      } finally {
        leave();
        noLambda = savedLambda;
        currentType = savedType;
      }
    }

    private void enumBody(String name) {
      int open = p;
      if (!is("{")) throw unexpected();
      p++;
      String savedType = currentType;
      currentType = name;
      try {
        enumBodyRest(open);
      } finally {
        currentType = savedType;
      }
    }

    private void enumBodyRest(int open) {
      suppressed = false;
      int start = p;
      try {
        while (!is(";") && !is("}") && !atEnd()) {
          annotationsOpt();
          expectIdent();
          if (is("(")) arguments();
          if (is("{")) classBody(null);
          if (!accept(",")) break;
        }
      } catch (Abort abort) {
        recover(start, true);
      }
      // `A, B  void f()`: the constants must be closed by ';' before any member.
      if (!is(";") && !is("}") && !atEnd()) missing(";");
      if (accept(";") || !is("}")) {
        while (!is("}")) {
          if (atEnd()) {
            endOfFile(open);
            return;
          }
          member();
        }
      }
      p++;
    }

    private void member() {
      suppressed = false;
      int start = p;
      try {
        memberDeclaration();
      } catch (Abort abort) {
        recover(start, true);
      }
    }

    private void memberDeclaration() {
      if (accept(";")) return;
      if (is("{")) {
        block();
        return;
      }
      if (is("static") && isAt(p + 1, "{")) {
        p++;
        block();
        return;
      }
      modifiers();
      if (typeDeclarationAhead()) {
        typeDeclaration();
        return;
      }
      if (is("<")) typeParameters();
      if (ident() && isAt(p + 1, "(")) { // constructor
        if (!texts[p].equals(currentType))
          reportAt(p, "ui_diagnostic_missing_return_type", "Missing method return type");
        p++;
        formalParameters();
        throwsOpt();
        methodBody();
        return;
      }
      if (ident() && isAt(p + 1, "{")) { // compact canonical constructor of a record
        p++;
        block();
        return;
      }
      if (!accept("void")) parseType();
      if (!ident()) throw endOf("ui_diagnostic_unexpected_end_of_declaration", "Unexpected end of declaration");
      p++;
      if (is("(")) {
        formalParameters();
        dims();
        throwsOpt();
        if (accept("default")) {
          elementValue();
          expectSemicolon();
        } else {
          methodBody();
        }
        return;
      }
      dims();
      if (accept("=")) variableInitializer();
      while (accept(",")) {
        expectIdent();
        dims();
        if (accept("=")) variableInitializer();
      }
      expectSemicolon();
    }

    private void methodBody() {
      if (is("{")) block();
      else expectSemicolon();
    }

    private void throwsOpt() {
      if (accept("throws")) typeList();
    }

    private void formalParameters() {
      p++; // (
      if (!is(")")) {
        do {
          modifiers();
          parseType();
          if (is("@")) { // type annotations are only allowed before '...'
            int at = p;
            annotationsOpt();
            if (!is("...")) {
              p = at;
              throw unexpected();
            }
          }
          accept("...");
          if (accept("this")) {
            // receiver parameter
          } else if (ident()) {
            p++;
            if (is(".") && isAt(p + 1, "this")) p += 2;
          } else {
            throw unexpected();
          }
          dims();
        } while (accept(","));
      }
      expectClose(")");
    }

    // ------------------------------------------------------------------------- statements

    private void block() {
      int open = p;
      if (!is("{")) throw unexpected();
      p++;
      int savedLambda = noLambda;
      noLambda = 0;
      enter();
      try {
        while (true) {
          if (is("}")) {
            p++;
            return;
          }
          if (atEnd()) {
            endOfFile(open);
            return;
          }
          if (memberAhead()) {
            // `void g() {` inside a method body: the method's closing brace is missing.
            suppressed = false;
            missing("}");
            return;
          }
          blockStatement();
        }
      } finally {
        leave();
        noLambda = savedLambda;
      }
    }

    /** A class member (never a statement) starts here — used to detect a missing '}'. */
    private boolean memberAhead() {
      // Reference block loop: these modifiers can never start a statement.
      if (is("public") || is("protected") || is("private") || is("static") || is("native")
          || is("transient") || is("volatile")) return true;
      if (is("@") && identText(p + 1, "Override")) return true;
      int i = p;
      if (isAt(i, "void")) i++;
      else {
        if (!identAt(i) && !primitiveAt(i)) return false;
        i = scanType(i);
        if (i < 0) return false;
      }
      if (!identAt(i) || !isAt(i + 1, "(")) return false;
      int close = match[i + 1];
      if (close < 0) return false;
      return isAt(close + 1, "{") || isAt(close + 1, "throws") || isAt(p, "void");
    }

    private void endOfFile(int open) {
      if (endOfFileReported) return;
      endOfFileReported = true;
      suppressed = false;
      // The reference expects '}' at the end of the file: reported after the last token.
      reportMissing("}", "ui_diagnostic_unclosed_opening_delimiter", "Missing '%1$s'", "}");
    }

    private void blockStatement() {
      suppressed = false;
      int start = p;
      int savedStart = statementStart;
      statementStart = p;
      try {
        statement();
      } catch (Abort abort) {
        recover(start, false);
      } finally {
        statementStart = savedStart;
      }
    }

    /** Skips to the end of the broken statement/member so parsing resumes cleanly. */
    private void recover(int start, boolean memberLevel) {
      int braces = 0;
      while (!atEnd()) {
        if (p > start && lineBreaks[p] && braces == 0 && kinds[p] != IDENT
            && (memberLevel ? MEMBER_STARTS : STATEMENT_STARTS).contains(texts[p])) break;
        if (is("{")) {
          braces++;
        } else if (is("}")) {
          if (braces == 0) break;
          braces--;
          if (braces == 0 && memberLevel) {
            p++;
            break;
          }
        } else if (is(";") && braces == 0) {
          p++;
          break;
        }
        p++;
      }
      if (p == start && !is("}") && !atEnd()) p++;
    }

    private void statement() {
      enter();
      try {
        statementBodyless();
      } finally {
        leave();
      }
    }

    private void statementBodyless() {
      if (atEnd()) throw unexpected();
      if (is("{")) {
        block();
        return;
      }
      if (accept(";")) return;
      if (kinds[p] == KEYWORD) {
        String word = texts[p];
        switch (word) {
          case "if":
            p++;
            parenthesized();
            body();
            if (accept("else")) body();
            return;
          case "while":
            p++;
            parenthesized();
            body();
            return;
          case "do":
            p++;
            body();
            if (!accept("while")) throw unexpected();
            parenthesized();
            expectSemicolon();
            return;
          case "for":
            forStatement();
            return;
          case "try":
            tryStatement();
            return;
          case "switch":
            p++;
            parenthesized();
            switchBody();
            return;
          case "return":
            p++;
            if (!is(";") && !is("}")) expression();
            expectSemicolon();
            return;
          case "break":
          case "continue":
            p++;
            if (ident()) p++;
            expectSemicolon();
            return;
          case "throw":
            p++;
            expression();
            expectSemicolon();
            return;
          case "synchronized":
            if (isAt(p + 1, "(")) {
              p++;
              parenthesized();
              block();
              return;
            }
            localWithModifiers();
            return;
          case "assert":
            p++;
            expression();
            if (accept(":")) expression();
            expectSemicolon();
            return;
          case "class":
          case "interface":
          case "enum":
            typeDeclaration();
            return;
          case "final":
          case "abstract":
          case "static":
          case "strictfp":
            localWithModifiers();
            return;
          case "this":
          case "super":
          case "new":
          case "true":
          case "false":
          case "null":
            expressionStatement();
            return;
          default:
            if (PRIMITIVES.contains(word)) {
              localVariable();
              return;
            }
            throw unexpected(); // else, case, default, catch, void, public…
        }
      }
      if (is("@")) {
        localWithModifiers();
        return;
      }
      if (ident()) {
        if (isAt(p + 1, ":")) { // label
          p += 2;
          statement();
          return;
        }
        if (yieldAhead()) {
          p++;
          expression();
          expectSemicolon();
          return;
        }
        if (recordAhead(p)) {
          typeDeclaration();
          return;
        }
        if (declarationAhead(p)) {
          localVariable();
          return;
        }
      }
      expressionStatement();
    }

    private boolean yieldAhead() {
      if (!identText(p, "yield")) return false;
      int next = p + 1;
      if (next >= count || kinds[next] == EOF) return false;
      if (kinds[next] != OP) return kinds[next] != KEYWORD || !isAt(next, "instanceof");
      String t = texts[next];
      // `yield (x)` is a yield statement too: an unqualified method named yield is illegal.
      return !(t.equals("=") || t.equals(".") || t.equals("[")
          || t.equals("->") || t.equals("::") || t.equals(";") || t.equals("++")
          || t.equals("--") || ASSIGN_OPS.contains(t) || t.equals(")") || t.equals(",")
          || t.equals("?") || t.equals(":"));
    }

    /** Body of if/while/for/do: a statement that may not be missing. */
    private void body() {
      if (is("}") || atEnd()) {
        reportEnd("ui_diagnostic_unexpected_end_of_statement", "Unexpected end of statement");
        return;
      }
      if (primitiveAt(p) || (ident() && !isAt(p + 1, ":") && !yieldAhead() && declarationAhead(p)))
        reportAt(p, "ui_diagnostic_unexpected_variable_declaration", "Unexpected variable declaration");
      statement();
    }

    private void parenthesized() {
      int open = p;
      expect("(");
      int saved = noLambda;
      noLambda = 0;
      try {
        expression();
        expectClose(")");
      } catch (Abort abort) {
        resumeAfter(open, abort);
      } finally {
        noLambda = saved;
      }
    }

    /**
     * An error inside a parenthesized group: when the group is balanced, parsing resumes right
     * after its ')' (the rest of the group is the same broken construct, not new errors).
     */
    private void resumeAfter(int open, Abort abort) {
      if (!isAt(open, "(") || match[open] <= open) throw abort;
      p = match[open] + 1;
    }

    private void localWithModifiers() {
      modifiers();
      if (typeDeclarationAhead()) {
        typeDeclaration();
        return;
      }
      localVariable();
    }

    private void localVariable() {
      parseType();
      variableDeclarators();
      expectSemicolon();
    }

    private void variableDeclarators() {
      do {
        if (!ident()) throw endOf("ui_diagnostic_unexpected_end_of_declaration", "Unexpected end of declaration");
        p++;
        dims();
        if (accept("=")) variableInitializer();
      } while (accept(","));
    }

    private void variableInitializer() {
      if (is("{")) arrayInitializer();
      else expression();
    }

    private void arrayInitializer() {
      p++; // {
      int saved = noLambda;
      noLambda = 0;
      try {
        while (!is("}")) {
          variableInitializer();
          if (!accept(",")) break;
        }
        expectClose("}");
      } finally {
        noLambda = saved;
      }
    }

    private void expressionStatement() {
      int start = p;
      int shape = expression();
      if (shape != K_CALL && shape != K_NEW && shape != K_ASSIGN && shape != K_INCDEC) {
        report(starts[start], Math.max(starts[start] + 1, ends[Math.max(start, p - 1)]),
            "ui_diagnostic_not_a_statement", "Not a statement");
      }
      expectSemicolon();
    }

    private void forStatement() {
      p++;
      int open = p;
      expect("(");
      int saved = noLambda;
      noLambda = 0;
      try {
        if (!is(";")) {
          if (is("final") || is("@") || declarationAhead(p)) {
            modifiers();
            parseType();
            expectIdent();
            dims();
            if (accept(":")) {
              expression();
              expectClose(")");
              body();
              return;
            }
            if (accept("=")) variableInitializer();
            while (accept(",")) {
              expectIdent();
              dims();
              if (accept("=")) variableInitializer();
            }
          } else {
            expression();
            while (accept(",")) expression();
          }
        }
        forSemicolon();
        if (!is(";")) expression();
        forSemicolon();
        if (!is(")")) {
          expression();
          while (accept(",")) expression();
        }
        expectClose(")");
      } catch (Abort abort) {
        resumeAfter(open, abort);
      } finally {
        noLambda = saved;
      }
      body();
    }

    private void forSemicolon() {
      if (accept(";")) return;
      if (is(")") || lineBreaks[p]) {
        missing(";");
        return;
      }
      throw unexpected();
    }

    private void tryStatement() {
      int at = p;
      p++;
      boolean resources = false;
      if (is("(")) {
        resources = true;
        p++;
        int saved = noLambda;
        noLambda = 0;
        try {
          while (!is(")")) {
            if (is("final") || is("@") || declarationAhead(p)) {
              modifiers();
              parseType();
              expectIdent();
              expect("=");
              expression();
            } else {
              expression();
            }
            if (!accept(";")) break;
          }
          expectClose(")");
        } finally {
          noLambda = saved;
        }
      }
      block();
      boolean handlers = false;
      while (is("catch")) {
        handlers = true;
        p++;
        expect("(");
        modifiers();
        parseType();
        while (accept("|")) parseType();
        expectIdent();
        expectClose(")");
        block();
      }
      if (accept("finally")) {
        handlers = true;
        block();
      }
      if (!handlers && !resources)
        reportAt(at, "ui_diagnostic_missing_catch_or_finally", "Missing 'catch' or 'finally'");
    }

    private void switchBody() {
      int open = p;
      if (!is("{")) throw unexpected();
      p++;
      int saved = noLambda;
      noLambda = 0;
      enter();
      try {
        boolean labelled = false;
        while (true) {
          if (is("}")) {
            p++;
            return;
          }
          if (atEnd()) {
            endOfFile(open);
            return;
          }
          if (is("case") || is("default")) {
            suppressed = false;
            int start = p;
            try {
              switchLabel();
            } catch (Abort abort) {
              recover(start, false);
            }
            labelled = true;
            continue;
          }
          if (!labelled) {
            suppressed = false;
            reportAt(p, "ui_diagnostic_missing_case_or_default", "Missing 'case' or 'default'");
            labelled = true;
            int start = p;
            try {
              statement();
            } catch (Abort abort) {
              recover(start, false);
            }
            continue;
          }
          blockStatement();
        }
      } finally {
        leave();
        noLambda = saved;
      }
    }

    private void switchLabel() {
      if (!accept("default")) {
        p++; // case
        do {
          caseLabelElement();
        } while (accept(","));
        if (identText(p, "when")) {
          p++;
          noLambda++;
          try {
            expression();
          } finally {
            noLambda--;
          }
        }
      }
      if (accept("->")) {
        if (is("{")) block();
        else if (is("throw")) statement();
        else {
          expression();
          expectSemicolon();
        }
        return;
      }
      if (accept(":")) return;
      if (lineBreaks[p] || is("}")) {
        missing(":");
        return;
      }
      throw unexpected();
    }

    private void caseLabelElement() {
      if (accept("null") || accept("default")) return;
      if (patternAhead(p)) {
        pattern();
        return;
      }
      noLambda++;
      try {
        conditional();
      } finally {
        noLambda--;
      }
    }

    private boolean patternAhead(int i) {
      if (isAt(i, "final")) return true;
      int end = scanType(i);
      if (end <= i) return false;
      if (identAt(end) && !identText(end, "when")) return true;
      return isAt(end, "(") && !primitiveAt(i);
    }

    private void pattern() {
      enter();
      try {
        modifiers();
        parseType();
        if (is("(")) {
          recordPatternComponents();
          return;
        }
        expectIdent();
      } finally {
        leave();
      }
    }

    private void recordPatternComponents() {
      p++; // (
      if (!is(")")) {
        do {
          pattern();
        } while (accept(","));
      }
      expectClose(")");
    }

    // ------------------------------------------------------------------------ expressions

    private boolean lambdaAhead() {
      if (noLambda > 0) return false;
      if (ident() && isAt(p + 1, "->")) return true;
      return is("(") && match[p] > 0 && isAt(match[p] + 1, "->");
    }

    private int expression() {
      enter();
      try {
        if (lambdaAhead()) return lambda();
        int shape = conditional();
        int width = assignmentOperatorWidth();
        if (width > 0) {
          p += width;
          expression();
          return K_ASSIGN;
        }
        return shape;
      } finally {
        leave();
      }
    }

    /** Tokens of the assignment operator at p (`>>=` is `>` + `>=`), or 0. */
    private int assignmentOperatorWidth() {
      if (kinds[p] != OP) return 0;
      if (ASSIGN_OPS.contains(texts[p])) return 1;
      if (is(">")) {
        if (isAt(p + 1, ">=") && adjacent(p + 1)) return 2;
        if (isAt(p + 1, ">") && adjacent(p + 1) && isAt(p + 2, ">=") && adjacent(p + 2)) return 3;
      }
      return 0;
    }

    private int lambda() {
      if (ident()) {
        p++;
      } else {
        p++; // (
        if (!is(")")) {
          do {
            modifiers();
            if (ident() && (isAt(p + 1, ",") || isAt(p + 1, ")"))) {
              p++;
            } else {
              parseType();
              accept("...");
              expectIdent();
              dims();
            }
          } while (accept(","));
        }
        expectClose(")");
      }
      p++; // ->
      int saved = noLambda;
      noLambda = 0;
      try {
        if (is("{")) block();
        else expression();
      } finally {
        noLambda = saved;
      }
      return K_OTHER;
    }

    private int conditional() {
      int shape = binary(1);
      if (!is("?")) return shape;
      p++;
      int saved = noLambda;
      noLambda = 0;
      try {
        expression();
      } finally {
        noLambda = saved;
      }
      if (!accept(":")) throw unexpected();
      if (lambdaAhead()) lambda();
      else conditional();
      return K_OTHER;
    }

    /** Precedence of the binary operator at p and its token width (via {@link #operatorWidth}). */
    private int operatorWidth;

    private int binaryPrecedence() {
      operatorWidth = 1;
      if (kinds[p] == KEYWORD) return is("instanceof") ? 7 : 0;
      if (kinds[p] != OP) return 0;
      switch (texts[p]) {
        case "||":
          return 1;
        case "&&":
          return 2;
        case "|":
          return 3;
        case "^":
          return 4;
        case "&":
          return 5;
        case "==":
        case "!=":
          return 6;
        case "<":
        case "<=":
        case ">=":
          return 7;
        case "<<":
          return 8;
        case "+":
        case "-":
          return 9;
        case "*":
        case "/":
        case "%":
          return 10;
        case ">":
          if (assignmentOperatorWidth() > 0) return 0;
          if (isAt(p + 1, ">") && adjacent(p + 1)) {
            operatorWidth = isAt(p + 2, ">") && adjacent(p + 2) ? 3 : 2;
            return 8;
          }
          return 7;
        default:
          return 0;
      }
    }

    private int binary(int minimum) {
      int shape = unary();
      while (true) {
        int precedence = binaryPrecedence();
        if (precedence == 0 || precedence < minimum) return shape;
        if (is("instanceof")) {
          p++;
          instanceofTarget();
        } else {
          p += operatorWidth;
          binary(precedence + 1);
        }
        shape = K_OTHER;
      }
    }

    private void instanceofTarget() {
      modifiers();
      parseType();
      if (is("(")) recordPatternComponents();
      else if (ident()) p++;
    }

    private int unary() {
      enter();
      try {
        if (is("++") || is("--")) {
          p++;
          unary();
          return K_INCDEC;
        }
        if (is("+") || is("-") || is("!") || is("~")) {
          p++;
          unary();
          return K_OTHER;
        }
        if (is("(") && match[p] > 0) {
          int close = match[p];
          if (isAt(close + 1, "->") && noLambda == 0) return lambda();
          if (castAhead(close)) {
            p = close + 1;
            if (lambdaAhead()) lambda();
            else unary();
            return K_OTHER;
          }
        }
        return postfix();
      } finally {
        leave();
      }
    }

    private boolean castAhead(int close) {
      int i = p + 1;
      int end = scanType(i);
      if (end < 0) return false;
      boolean primitive = primitiveAt(scanAnnotations(i));
      while (!primitive && isAt(end, "&")) {
        end = scanType(end + 1);
        if (end < 0) return false;
      }
      if (end != close) return false;
      if (primitive) return true;
      int next = close + 1;
      if (next >= count) return false;
      switch (kinds[next]) {
        case IDENT:
        case NUMBER:
        case STRING:
        case CHAR:
          return true;
        case KEYWORD:
          return isAt(next, "this") || isAt(next, "super") || isAt(next, "new")
              || isAt(next, "true") || isAt(next, "false") || isAt(next, "null")
              || isAt(next, "switch") || primitiveAt(next);
        case OP:
          return isAt(next, "(") || isAt(next, "!") || isAt(next, "~");
        default:
          return false;
      }
    }

    private int postfix() {
      int shape = primary();
      while (true) {
        if (is(".")) {
          p++;
          if (is("<")) {
            typeArguments();
            expectIdent();
            if (!is("(")) throw unexpected();
            arguments();
            shape = K_CALL;
          } else if (ident()) {
            p++;
            if (is("(")) {
              arguments();
              shape = K_CALL;
            } else shape = K_NAME;
          } else if (accept("this") || accept("class")) {
            shape = K_NAME;
          } else if (is("new")) {
            shape = creator();
          } else if (accept("super")) {
            if (is("(")) {
              arguments();
              shape = K_CALL;
            } else shape = K_NAME;
          } else {
            throw expressionExpected();
          }
        } else if (is("[")) {
          p++;
          int saved = noLambda;
          noLambda = 0;
          try {
            expression();
          } finally {
            noLambda = saved;
          }
          expectClose("]");
          shape = K_NAME;
        } else if (is("::")) {
          p++;
          if (is("<")) typeArguments();
          if (!accept("new")) expectIdent();
          shape = K_OTHER;
        } else break;
      }
      while (is("++") || is("--")) {
        p++;
        shape = K_INCDEC;
      }
      return shape;
    }

    private int primary() {
      switch (kinds[p]) {
        case NUMBER:
        case STRING:
        case CHAR:
          p++;
          return K_OTHER;
        case IDENT:
          {
            int end = scanType(p);
            if (end > p + 1) {
              if (isAt(end, "::") && typeOnlySyntax(p, end)) {
                p = end;
                return K_NAME;
              }
              if (isAt(end - 1, "]") && isAt(end, ".") && isAt(end + 1, "class")) {
                p = end + 2;
                return K_NAME;
              }
            }
            p++;
            if (is("(")) {
              arguments();
              return K_CALL;
            }
            return K_NAME;
          }
        case KEYWORD:
          switch (texts[p]) {
            case "true":
            case "false":
            case "null":
              p++;
              return K_OTHER;
            case "this":
            case "super":
              p++;
              if (is("(")) {
                arguments();
                return K_CALL;
              }
              return K_NAME;
            case "new":
              return creator();
            case "switch":
              p++;
              parenthesized();
              switchBody();
              return K_OTHER;
            case "void":
              p++;
              if (!accept(".")) throw unexpected();
              if (!accept("class")) throw unexpected();
              return K_NAME;
            default:
              if (primitiveAt(p)) {
                p++;
                dims();
                if (is("::")) return K_NAME;
                if (!accept(".")) throw unexpected();
                if (!accept("class")) throw unexpected();
                return K_NAME;
              }
              throw unexpected();
          }
        case OP:
          if (is("(")) {
            p++;
            int saved = noLambda;
            noLambda = 0;
            try {
              expression();
            } finally {
              noLambda = saved;
            }
            expectClose(")");
            return K_OTHER;
          }
          throw expressionExpected();
        default:
          throw expressionExpected();
      }
    }

    /** The scanned type contains generic arguments or array brackets (so it is not a name). */
    private boolean typeOnlySyntax(int from, int to) {
      for (int i = from; i < to; i++) if (isAt(i, "<") || isAt(i, "[")) return true;
      return false;
    }

    private void arguments() {
      int open = p;
      p++; // (
      int saved = noLambda;
      noLambda = 0;
      try {
        if (!is(")")) {
          do {
            expression();
          } while (accept(","));
        }
        expectClose(")");
      } catch (Abort abort) {
        resumeAfter(open, abort);
      } finally {
        noLambda = saved;
      }
    }

    private int creator() {
      p++; // new
      if (is("<")) typeArguments();
      annotationsOpt();
      if (primitiveAt(p)) {
        p++;
        arrayCreatorRest();
        return K_OTHER;
      }
      if (!ident()) throw expressionExpected();
      p++;
      if (is("<")) typeArguments();
      while (is(".")) {
        p++;
        annotationsOpt();
        expectIdent();
        if (is("<")) typeArguments();
      }
      annotationsOpt();
      if (is("[")) {
        arrayCreatorRest();
        return K_OTHER;
      }
      if (!is("(")) {
        missing("(");
        throw ABORT;
      }
      arguments();
      if (is("{")) classBody(null);
      return K_NEW;
    }

    private void arrayCreatorRest() {
      if (!is("[")) throw unexpected();
      if (isAt(p + 1, "]")) {
        dims();
        if (is("{")) arrayInitializer();
        else reportAt(p - 1, "ui_diagnostic_missing_array_dimension", "Missing array dimension");
        return;
      }
      while (is("[") && !isAt(p + 1, "]")) {
        p++;
        int saved = noLambda;
        noLambda = 0;
        try {
          expression();
        } finally {
          noLambda = saved;
        }
        expectClose("]");
      }
      dims();
    }
  }
}
