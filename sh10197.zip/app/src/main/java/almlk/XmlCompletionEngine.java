package almlk;

import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.almlkid.kay.ui.ProjectSymbolIndex.CompletionItem;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Context-aware XML completion driven by the SDK's own tables ({@link AndroidApiIndex}):
 *
 * <ul>
 *   <li>after {@code <}: inflatable views/layouts (class icon) plus the project's custom views, the
 *       manifest elements in AndroidManifest.xml, or the elements of keyboard/values files;
 *   <li>inside a tag: the attributes the element really accepts (its styleables along the class
 *       chain plus the parent's layout params), inserted as {@code android:name=""} with the caret
 *       between the quotes;
 *   <li>between quotes: the attribute's enum/flag values, booleans, number dimensions and
 *       resource prefixes.
 * </ul>
 */
public final class XmlCompletionEngine {

  private XmlCompletionEngine() {}

  private static final int MAX_RESULTS = 200;

  // ─────────────────────────── public API ───────────────────────────

  /** Plain suggestion texts for the cursor context (attributes keep their android: prefix). */
  public static List<String> complete(String text, int cursor) {
    String safe = text == null ? "" : text;
    ArrayList<String> out = new ArrayList<>();
    for (CompletionItem item : completeItems(null, safe, cursor)) {
      String insert = item.insertText;
      if (item.kind == CompletionItem.VARIABLE && insert.endsWith("=\"\"")) insert = insert.substring(0, insert.length() - 3);
      if (item.kind == CompletionItem.CLASS && insert.startsWith("/")) insert = insert.substring(1);
      out.add(insert.endsWith(">") && item.kind == CompletionItem.CLASS ? item.label : insert);
    }
    return out;
  }

  /** Start of the token replaced on commit — values include digits, dots, @, #, / and :. */
  public static int completionStart(String text, int cursor) {
    String safe = text == null ? "" : text;
    return analyze(safe, clamp(cursor, safe.length())).tokenStart;
  }

  /** Typed rows for the completion popup. {@code fileName} may be null (content decides). */
  public static List<CompletionItem> completeItems(String fileName, String text, int cursor) {
    String safe = text == null ? "" : text;
    int at = clamp(cursor, safe.length());
    Context context = analyze(safe, at);
    FileKind file = fileKind(fileName, safe);
    switch (context.kind) {
      case TAG:
        return tagItems(file, safe, context);
      case CLOSE_TAG:
        return closeTagItems(safe, context);
      case ATTRIBUTE:
        return attributeItems(file, safe, at, context);
      case VALUE:
        return valueItems(context);
      default:
        return new ArrayList<>();
    }
  }

  // ─────────────────────────── context ───────────────────────────

  enum Kind { NONE, VALUE, ATTRIBUTE, TAG, CLOSE_TAG }

  enum FileKind { LAYOUT, MANIFEST, VALUES, RES_XML, OTHER }

  static final class Context {
    Kind kind = Kind.NONE;
    String tag = "";
    String attribute = "";
    /** Namespace prefix of the attribute whose value is edited ("android", "app" or ""). */
    String namespace = "";
    String prefix = "";
    int tokenStart;
    int tagStart = -1;
  }

  private static int clamp(int value, int max) {
    return value < 0 ? 0 : Math.min(value, max);
  }

  static Context analyze(String text, int at) {
    Context context = new Context();
    context.tokenStart = at;
    int tagStart = -1;
    for (int i = at - 1; i >= 0; i--) {
      char c = text.charAt(i);
      if (c == '>') break;
      if (c == '<') {
        tagStart = i;
        break;
      }
    }
    if (tagStart < 0) return context;
    context.tagStart = tagStart;
    if (text.startsWith("<!--", tagStart) || text.startsWith("<?", tagStart) || text.startsWith("<!", tagStart))
      return context;
    int nameStart = tagStart + 1;
    boolean closing = nameStart < text.length() && text.charAt(nameStart) == '/';
    if (closing) nameStart++;
    int nameEnd = nameStart;
    while (nameEnd < at && isNameChar(text.charAt(nameEnd))) nameEnd++;
    context.tag = text.substring(nameStart, Math.min(nameEnd, at));
    if (at <= nameEnd) {
      context.kind = closing ? Kind.CLOSE_TAG : Kind.TAG;
      context.prefix = text.substring(nameStart, at);
      context.tokenStart = nameStart;
      return context;
    }
    String head = text.substring(tagStart, at);
    int quotes = 0;
    int lastQuote = -1;
    char quoteChar = 0;
    for (int i = 0; i < head.length(); i++) {
      char c = head.charAt(i);
      if (quoteChar == 0 && (c == '"' || c == '\'')) {
        quoteChar = c;
        lastQuote = i;
        quotes++;
      } else if (c == quoteChar) {
        quoteChar = 0;
        quotes++;
      }
    }
    if (quoteChar != 0) {
      int valueStart = tagStart + lastQuote + 1;
      context.kind = Kind.VALUE;
      context.attribute = attributeNameBefore(text, tagStart + lastQuote);
      context.namespace = attributeNamespaceBefore(text, tagStart + lastQuote);
      String value = text.substring(valueStart, at);
      int bar = value.lastIndexOf('|');
      context.prefix = bar >= 0 ? value.substring(bar + 1) : value;
      context.tokenStart = bar >= 0 ? valueStart + bar + 1 : valueStart;
      return context;
    }
    int wordStart = at;
    while (wordStart > nameEnd && isAttrChar(text.charAt(wordStart - 1))) wordStart--;
    if (wordStart > nameEnd && !Character.isWhitespace(text.charAt(wordStart - 1))) return context;
    if (wordStart == nameEnd) return context;
    context.kind = Kind.ATTRIBUTE;
    context.prefix = text.substring(wordStart, at);
    context.tokenStart = wordStart;
    return context;
  }

  private static String attributeNameBefore(String text, int quotePos) {
    int end = quotePos;
    while (end > 0 && (text.charAt(end - 1) == '=' || Character.isWhitespace(text.charAt(end - 1)))) end--;
    int start = end;
    while (start > 0 && isAttrChar(text.charAt(start - 1))) start--;
    String name = text.substring(start, end);
    int colon = name.indexOf(':');
    return colon >= 0 ? name.substring(colon + 1) : name;
  }

  private static String attributeNamespaceBefore(String text, int quotePos) {
    int end = quotePos;
    while (end > 0 && (text.charAt(end - 1) == '=' || Character.isWhitespace(text.charAt(end - 1)))) end--;
    int start = end;
    while (start > 0 && isAttrChar(text.charAt(start - 1))) start--;
    String name = text.substring(start, end);
    int colon = name.indexOf(':');
    return colon >= 0 ? name.substring(0, colon) : "";
  }

  private static final Pattern RES_AUTO =
      Pattern.compile("xmlns:([\\w-]+)\\s*=\\s*[\"']http://schemas\\.android\\.com/apk/res-auto[\"']");

  /** Prefix bound to res-auto (custom/library attributes); "app" when not declared yet. */
  static String customPrefix(String text) {
    Matcher m = RES_AUTO.matcher(text);
    return m.find() ? m.group(1) : "app";
  }

  private static boolean isNameChar(char c) {
    return Character.isLetterOrDigit(c) || c == '.' || c == '_' || c == '-' || c == '$';
  }

  private static boolean isAttrChar(char c) {
    return Character.isLetterOrDigit(c) || c == ':' || c == '_' || c == '-';
  }

  private static final Pattern ROOT = Pattern.compile("<([A-Za-z_][\\w.:-]*)");

  static FileKind fileKind(String fileName, String text) {
    String path = fileName == null ? "" : fileName.replace('\\', '/').toLowerCase(Locale.US);
    if (path.endsWith("androidmanifest.xml")) return FileKind.MANIFEST;
    if (path.contains("/layout")) return FileKind.LAYOUT;
    if (path.contains("/values")) return FileKind.VALUES;
    if (path.contains("/xml/")) return FileKind.RES_XML;
    Matcher root = ROOT.matcher(text);
    while (root.find()) {
      String name = root.group(1);
      if (name.equals("manifest")) return FileKind.MANIFEST;
      if (name.equals("resources")) return FileKind.VALUES;
      if (RES_XML_ELEMENTS.containsKey(name)) return FileKind.RES_XML;
      return path.isEmpty() || path.endsWith(".xml") ? FileKind.LAYOUT : FileKind.OTHER;
    }
    return path.contains("/menu") || path.contains("/drawable") ? FileKind.OTHER : FileKind.LAYOUT;
  }

  // ─────────────────────────── elements ───────────────────────────

  /** Elements of res/xml files and the styleables that define their attributes. */
  private static final LinkedHashMap<String, String[]> RES_XML_ELEMENTS = new LinkedHashMap<>();

  static {
    RES_XML_ELEMENTS.put("Keyboard", new String[] {"Keyboard"});
    RES_XML_ELEMENTS.put("Row", new String[] {"Keyboard_Row", "Keyboard"});
    RES_XML_ELEMENTS.put("Key", new String[] {"Keyboard_Key", "Keyboard_Row", "Keyboard"});
    RES_XML_ELEMENTS.put("input-method", new String[] {"InputMethod"});
    RES_XML_ELEMENTS.put("subtype", new String[] {"InputMethod_Subtype"});
  }

  private static final String[] VALUES_ELEMENTS = {
    "string", "color", "dimen", "style", "item", "array", "string-array", "integer-array", "integer",
    "bool", "declare-styleable", "attr", "plurals", "drawable", "fraction", "enum", "flag", "public"
  };

  private static final String[] LAYOUT_SPECIAL = {"include", "merge", "fragment", "requestFocus", "view", "tag"};

  private static List<CompletionItem> tagItems(FileKind file, String text, Context context) {
    String prefix = context.prefix;
    ArrayList<CompletionItem> out = new ArrayList<>();
    switch (file) {
      case MANIFEST:
        for (String element : manifestElements())
          if (CompletionMatcher.matches(element, prefix)) out.add(element(element, element, null));
        break;
      case VALUES:
        for (String element : VALUES_ELEMENTS)
          if (CompletionMatcher.matches(element, prefix)) out.add(element(element, element, null));
        break;
      case RES_XML:
        for (String element : RES_XML_ELEMENTS.keySet())
          if (CompletionMatcher.matches(element, prefix)) out.add(element(element, element, null));
        break;
      case LAYOUT:
      case OTHER:
      default:
        for (AndroidApiIndex.ClassInfo view : AndroidApiIndex.viewClasses()) {
          String tag = AndroidApiIndex.tagName(view);
          if (!CompletionMatcher.matches(view.simpleName, prefix) && !CompletionMatcher.matches(tag, prefix)) continue;
          CompletionItem item = element(view.simpleName, tag, tag.equals(view.simpleName) ? null : view.packageName);
          item.apiInfo = AndroidApiIndex.apiLevelText(view.since, view.deprecated, view.removed, true);
          out.add(item);
        }
        for (String view : projectViews()) {
          String simple = view.substring(view.lastIndexOf('.') + 1);
          if (CompletionMatcher.matches(simple, prefix) || CompletionMatcher.matches(view, prefix))
            out.add(element(simple, view, view.substring(0, Math.max(0, view.lastIndexOf('.')))));
        }
        for (String special : LAYOUT_SPECIAL)
          if (CompletionMatcher.matches(special, prefix)) out.add(element(special, special, null));
        break;
    }
    sort(out, prefix);
    return cap(out);
  }

  private static CompletionItem element(String label, String insert, String pkg) {
    CompletionItem item = new CompletionItem(CompletionItem.CLASS, label, insert, "");
    item.suffix = pkg == null || pkg.isEmpty() ? "" : " - " + pkg;
    return item;
  }

  private static List<String> manifestElements() {
    ArrayList<String> out = new ArrayList<>();
    out.add("manifest");
    for (String styleable : MANIFEST_STYLEABLES) out.add(manifestElementName(styleable));
    return out;
  }

  private static final String[] MANIFEST_STYLEABLES = {
    "AndroidManifestApplication", "AndroidManifestActivity", "AndroidManifestActivityAlias",
    "AndroidManifestService", "AndroidManifestReceiver", "AndroidManifestProvider",
    "AndroidManifestIntentFilter", "AndroidManifestAction", "AndroidManifestCategory",
    "AndroidManifestData", "AndroidManifestMetaData", "AndroidManifestUsesPermission",
    "AndroidManifestPermission", "AndroidManifestUsesSdk", "AndroidManifestUsesFeature",
    "AndroidManifestUsesLibrary", "AndroidManifestSupportsScreens", "AndroidManifestQueries",
    "AndroidManifestGrantUriPermission", "AndroidManifestPathPermission", "AndroidManifestInstrumentation",
    "AndroidManifestUsesConfiguration", "AndroidManifestCompatibleScreens", "AndroidManifestProperty",
    "AndroidManifestLayout", "AndroidManifestProfileable", "AndroidManifestPermissionGroup"
  };

  /** AndroidManifestIntentFilter → intent-filter, AndroidManifestUsesSdk → uses-sdk. */
  static String manifestElementName(String styleable) {
    String rest = styleable.substring("AndroidManifest".length());
    if (rest.isEmpty()) return "manifest";
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < rest.length(); i++) {
      char c = rest.charAt(i);
      if (Character.isUpperCase(c) && i > 0) b.append('-');
      b.append(Character.toLowerCase(c));
    }
    return b.toString();
  }

  private static String manifestStyleable(String element) {
    if (element.equals("manifest")) return "AndroidManifest";
    StringBuilder b = new StringBuilder("AndroidManifest");
    boolean upper = true;
    for (char c : element.toCharArray()) {
      if (c == '-') {
        upper = true;
        continue;
      }
      b.append(upper ? Character.toUpperCase(c) : c);
      upper = false;
    }
    return b.toString();
  }

  /** Project classes extending a view, as qualified tag names. */
  private static List<String> projectViews() {
    ArrayList<String> out = new ArrayList<>();
    for (String name : ProjectSymbolIndex.projectClassNamesMatching("", 400)) {
      if (viewClassChain(name).isEmpty()) continue;
      String pkg = ProjectSymbolIndex.packageOf(name);
      out.add(pkg == null || pkg.isEmpty() ? name : pkg + "." + name);
    }
    return out;
  }

  /**
   * Simple class names from the element up to View — project classes first, then the platform
   * hierarchy: SoftKeyboardView → [SoftKeyboardView, KeyboardView, View]. Empty when the tag is
   * not a view. Styleables are named after these classes.
   */
  static List<String> viewClassChain(String tag) {
    ArrayList<String> out = new ArrayList<>();
    if (tag == null || tag.isEmpty()) return out;
    String simple = tag.substring(tag.lastIndexOf('.') + 1);
    List<String> imports = new ArrayList<>();
    HashSet<String> seen = new HashSet<>();
    AndroidApiIndex.ClassInfo platform = AndroidApiIndex.viewClassForTag(tag);
    while (platform == null && seen.add(simple)) {
      ProjectSymbolIndex.ProjectClass project = ProjectSymbolIndex.projectClass(simple);
      if (project == null) {
        platform = AndroidApiIndex.resolve(simple, imports);
        break;
      }
      out.add(simple);
      String parent = project.superName;
      if (parent.isEmpty()) return new ArrayList<>();
      imports = project.imports;
      for (String written : project.supertypes)
        if (written.endsWith("." + parent) || written.equals(parent)) parent = written;
      simple = parent.substring(parent.lastIndexOf('.') + 1);
      platform = parent.indexOf('.') > 0 ? AndroidApiIndex.classByQualifiedName(parent) : null;
    }
    boolean isView = false;
    for (AndroidApiIndex.ClassInfo c = platform; c != null;
        c = c.superName.isEmpty() ? null : AndroidApiIndex.classByQualifiedName(c.superName)) {
      out.add(c.simpleName);
      if (c.qualifiedName.equals("android.view.View")) {
        isView = true;
        break;
      }
    }
    return isView ? out : new ArrayList<>();
  }

  private static List<CompletionItem> closeTagItems(String text, Context context) {
    ArrayList<CompletionItem> out = new ArrayList<>();
    String open = innermostOpenTag(text, context.tagStart);
    if (open != null && CompletionMatcher.matches(open, context.prefix))
      out.add(element(open, open + ">", null));
    return out;
  }

  // ─────────────────────────── attributes ───────────────────────────

  private static final Pattern TAG = Pattern.compile("<(/?)([A-Za-z_][\\w.:-]*)|(/>)|(-->)|(<!--)");

  /** Name of the innermost element still open before {@code limit}, or null. */
  static String innermostOpenTag(String text, int limit) {
    ArrayDeque<String> stack = new ArrayDeque<>();
    int i = 0;
    while (i < limit) {
      int lt = text.indexOf('<', i);
      if (lt < 0 || lt >= limit) break;
      if (text.startsWith("<!--", lt)) {
        int end = text.indexOf("-->", lt + 4);
        i = end < 0 ? limit : end + 3;
        continue;
      }
      if (text.startsWith("<?", lt) || text.startsWith("<!", lt)) {
        int end = text.indexOf('>', lt);
        i = end < 0 ? limit : end + 1;
        continue;
      }
      boolean closing = lt + 1 < text.length() && text.charAt(lt + 1) == '/';
      int nameStart = lt + (closing ? 2 : 1);
      int nameEnd = nameStart;
      while (nameEnd < text.length() && isNameChar(text.charAt(nameEnd)) || nameEnd < text.length() && text.charAt(nameEnd) == ':') nameEnd++;
      String name = text.substring(nameStart, Math.min(nameEnd, text.length()));
      int gt = tagEnd(text, nameEnd, limit);
      if (gt < 0) break; // the tag containing the cursor
      boolean selfClosing = gt > 0 && text.charAt(gt - 1) == '/';
      if (closing) {
        while (!stack.isEmpty()) if (stack.pop().equals(name)) break;
      } else if (!selfClosing && !name.isEmpty()) stack.push(name);
      i = gt + 1;
    }
    return stack.isEmpty() ? null : stack.peek();
  }

  /** Index of the '>' ending the tag (quotes respected) before {@code limit}, or -1. */
  private static int tagEnd(String text, int from, int limit) {
    char quote = 0;
    for (int i = from; i < limit; i++) {
      char c = text.charAt(i);
      if (quote != 0) {
        if (c == quote) quote = 0;
      } else if (c == '"' || c == '\'') quote = c;
      else if (c == '>') return i;
    }
    return -1;
  }

  private static Set<String> presentAttributes(String text, int tagStart, int cursorToken) {
    HashSet<String> present = new HashSet<>();
    int end = tagEnd(text, tagStart + 1, text.length());
    String inside = text.substring(tagStart, end < 0 ? Math.min(text.length(), tagStart + 4000) : end);
    Matcher m = Pattern.compile("([\\w:-]+)\\s*=").matcher(inside);
    while (m.find()) {
      if (tagStart + m.start(1) == cursorToken) continue;
      present.add(m.group(1)); // full spelling: android:elevation and app:elevation are distinct
    }
    return present;
  }

  private static List<CompletionItem> attributeItems(FileKind file, String text, int at, Context context) {
    String token = context.prefix;
    int colon = token.indexOf(':');
    String namespace = colon >= 0 ? token.substring(0, colon) : "";
    String prefix = colon >= 0 ? token.substring(colon + 1) : token;
    ArrayList<CompletionItem> out = new ArrayList<>();
    String custom = customPrefix(text);
    boolean customOnly = !namespace.isEmpty() && namespace.equals(custom);
    boolean androidOnly = namespace.equals("android");
    if (!namespace.isEmpty() && !androidOnly && !customOnly && !namespace.equals("xmlns")) return out;
    LinkedHashSet<String> names = new LinkedHashSet<>();
    LinkedHashSet<String> customNames = new LinkedHashSet<>();
    String tag = context.tag;
    switch (file) {
      case MANIFEST:
        names.addAll(AndroidApiIndex.styleable(manifestStyleable(tag)));
        break;
      case RES_XML:
        String[] styleables = RES_XML_ELEMENTS.get(tag);
        if (styleables != null) for (String s : styleables) names.addAll(AndroidApiIndex.styleable(s));
        break;
      case VALUES:
        break;
      default:
        String parent = innermostOpenTag(text, context.tagStart);
        names.addAll(layoutAttributes(tag, parent));
        // M4: styleables of library/project views — custom attrs (app:) and reused android: ones.
        for (String entry : customLayoutAttributes(tag, parent)) {
          if (entry.startsWith("android:")) names.add(entry.substring(8));
          else customNames.add(entry);
        }
        if (customOnly && customNames.isEmpty()) customNames.addAll(LibraryClassIndex.attrNames());
        break;
    }
    if (names.isEmpty() && file != FileKind.VALUES)
      for (AndroidApiIndex.AttrInfo a : AndroidApiIndex.allAttrs()) names.add(a.name);
    Set<String> present = presentAttributes(text, context.tagStart, context.tokenStart);
    boolean hasValue = followedByEquals(text, at);
    if (!androidOnly) {
      for (String name : customNames) {
        if (present.contains(custom + ":" + name) || !CompletionMatcher.matches(name, prefix)) continue;
        AndroidApiIndex.AttrInfo info = LibraryClassIndex.attr(name);
        String insert = custom + ":" + name;
        CompletionItem item = new CompletionItem(CompletionItem.VARIABLE, name, hasValue ? insert : insert + "=\"\"",
            info == null ? "int" : info.valueType());
        if (!hasValue) {
          item.caretBack = 1;
          item.reopen = info != null && (info.values.length > 0 || info.format.contains("boolean"));
        }
        out.add(item);
      }
    }
    if (customOnly) names.clear();
    for (String name : names) {
      if (present.contains("android:" + name) || present.contains(name) || !CompletionMatcher.matches(name, prefix)) continue;
      AndroidApiIndex.AttrInfo info = AndroidApiIndex.attr(name);
      if (info == null || info.removed > 0) continue;
      String insert = "android:" + name;
      CompletionItem item = new CompletionItem(CompletionItem.VARIABLE, name, hasValue ? insert : insert + "=\"\"", info.valueType());
      if (!hasValue) {
        item.caretBack = 1;
        item.reopen = info.values.length > 0 || info.format.contains("boolean");
      }
      item.apiInfo = AndroidApiIndex.apiLevelText(info.since, info.deprecated, info.removed, true);
      out.add(item);
    }
    if (file == FileKind.LAYOUT || file == FileKind.OTHER) {
      if (!present.contains("style") && namespace.isEmpty() && CompletionMatcher.matches("style", prefix)) {
        CompletionItem style = new CompletionItem(CompletionItem.VARIABLE, "style", hasValue ? "style" : "style=\"\"", "int");
        if (!hasValue) style.caretBack = 1;
        out.add(style);
      }
    }
    sort(out, prefix);
    return cap(out);
  }

  private static boolean followedByEquals(String text, int at) {
    int i = at;
    while (i < text.length() && isAttrChar(text.charAt(i))) i++;
    while (i < text.length() && text.charAt(i) == ' ') i++;
    return i < text.length() && text.charAt(i) == '=';
  }

  /** Library/project styleables along the element's chain and the parent's {@code _Layout} ones. */
  private static List<String> customLayoutAttributes(String tag, String parent) {
    LinkedHashSet<String> names = new LinkedHashSet<>();
    if (!LibraryClassIndex.isInstalled()) return new ArrayList<>(names);
    for (String cls : viewClassChain(tag)) names.addAll(LibraryClassIndex.styleable(cls));
    if (parent != null) for (String cls : viewClassChain(parent)) names.addAll(LibraryClassIndex.styleable(cls + "_Layout"));
    return new ArrayList<>(names);
  }

  /** Styleables along the element's class chain plus the parent's layout params. */
  private static List<String> layoutAttributes(String tag, String parent) {
    LinkedHashSet<String> names = new LinkedHashSet<>();
    for (String cls : viewClassChain(tag)) names.addAll(AndroidApiIndex.styleable(cls));
    if (names.isEmpty()) names.addAll(AndroidApiIndex.styleable("View"));
    List<String> parentChain = parent == null ? Arrays.asList("ViewGroup") : viewClassChain(parent);
    for (String cls : parentChain) names.addAll(AndroidApiIndex.styleable(cls + "_Layout"));
    names.addAll(AndroidApiIndex.styleable("ViewGroup_MarginLayout"));
    names.addAll(AndroidApiIndex.styleable("ViewGroup_Layout"));
    return new ArrayList<>(names);
  }

  // ─────────────────────────── values ───────────────────────────

  private static List<CompletionItem> valueItems(Context context) {
    String attr = context.attribute;
    String prefix = context.prefix;
    List<CompletionItem> references = referenceItems(prefix);
    if (references != null) return references;
    LinkedHashSet<String> values = new LinkedHashSet<>();
    boolean platformAttr = context.namespace.isEmpty() || context.namespace.equals("android");
    AndroidApiIndex.AttrInfo info = platformAttr ? AndroidApiIndex.attr(attr) : LibraryClassIndex.attr(attr);
    String format = info == null ? "" : info.format;
    if (info != null) values.addAll(Arrays.asList(info.values));
    if (format.contains("boolean")) {
      values.add("true");
      values.add("false");
    }
    if (attr.equals("id")) {
      values.add("@+id/");
      values.add("@id/");
    }
    boolean dimension = format.contains("dimension") || (info == null && !attr.isEmpty());
    if (dimension) values.addAll(dimensions(prefix));
    if (format.contains("string")) values.add("@string/");
    if (format.contains("color")) {
      values.add("#");
      values.add("@color/");
      values.add("@android:color/");
    }
    if (format.contains("reference") && !format.contains("string") && !format.contains("color")) {
      if (attr.equals("style") || attr.equals("theme") || attr.endsWith("Style") || attr.endsWith("Appearance")) {
        values.add("@style/");
        values.add("@android:style/");
      } else if (attr.equals("layout") || attr.endsWith("Layout")) {
        values.add("@layout/");
      } else if (attr.startsWith("layout_")) {
        values.add("@id/");
      } else {
        values.add("@drawable/");
        values.add("@android:drawable/");
        values.add("@color/");
      }
    }
    if (info == null && attr.isEmpty()) return new ArrayList<>();
    if (info == null) {
      values.add("true");
      values.add("false");
      values.add("@string/");
      values.add("@drawable/");
      values.add("@id/");
    }
    ArrayList<CompletionItem> out = new ArrayList<>();
    for (String value : values) {
      if (!prefix.isEmpty() && !value.toLowerCase(Locale.US).startsWith(prefix.toLowerCase(Locale.US))) continue;
      CompletionItem item = new CompletionItem(CompletionItem.VALUE, value, value, "");
      item.reopen = value.endsWith("/");
      out.add(item);
    }
    return cap(out);
  }

  private static final Pattern RESOURCE_REFERENCE = Pattern.compile("@(\\+)?(?:([\\w.]+):)?([a-z]+)/(.*)");
  private static final Pattern ATTR_REFERENCE = Pattern.compile("\\?(?:([\\w.]+):)?(attr/)?([\\w.]*)");

  /**
   * Resource names after {@code @type/} (project + libraries, or the platform for {@code @android:})
   * and theme attributes after {@code ?}/{@code ?attr/}; null when the value is not a reference.
   */
  private static List<CompletionItem> referenceItems(String prefix) {
    String head;
    String partial;
    java.util.Collection<String> names;
    if (prefix.startsWith("@")) {
      Matcher m = RESOURCE_REFERENCE.matcher(prefix);
      if (!m.matches()) return null;
      String pkg = m.group(2);
      String type = m.group(3);
      partial = m.group(4);
      head = "@" + (m.group(1) == null ? "" : "+") + (pkg == null ? "" : pkg + ":") + type + "/";
      names = "android".equals(pkg) ? platformResources(type)
          : pkg == null ? LibraryClassIndex.resourceNames(type) : new ArrayList<String>();
    } else if (prefix.startsWith("?")) {
      ArrayList<CompletionItem> out = new ArrayList<>();
      if (prefix.equals("?")) {
        for (String start : new String[] {"?attr/", "?android:attr/"}) {
          CompletionItem item = new CompletionItem(CompletionItem.VALUE, start, start, "");
          item.reopen = true;
          out.add(item);
        }
      }
      Matcher m = ATTR_REFERENCE.matcher(prefix);
      if (!m.matches()) return out.isEmpty() ? null : out;
      String pkg = m.group(1);
      partial = m.group(3);
      head = "?" + (pkg == null ? "" : pkg + ":") + (m.group(2) == null ? "" : "attr/");
      if ("android".equals(pkg)) {
        ArrayList<String> platform = new ArrayList<>();
        for (AndroidApiIndex.AttrInfo a : AndroidApiIndex.allAttrs()) platform.add(a.name);
        names = platform;
      } else names = pkg == null ? LibraryClassIndex.attrNames() : new ArrayList<String>();
      if (prefix.equals("?")) return out;
    } else {
      return null;
    }
    ArrayList<CompletionItem> out = new ArrayList<>();
    for (String name : names) {
      if (!partial.isEmpty() && !CompletionMatcher.matches(name, partial)) continue;
      out.add(new CompletionItem(CompletionItem.VALUE, name, head + name, ""));
    }
    sort(out, partial);
    return cap(out);
  }

  /** {@code @android:type/} names from the platform's android.R.type (styles use dots). */
  private static List<String> platformResources(String type) {
    ArrayList<String> out = new ArrayList<>();
    AndroidApiIndex.ClassInfo r = AndroidApiIndex.classByQualifiedName("android.R." + type);
    if (r == null) return out;
    for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(r)) {
      if (m.kind != AndroidApiIndex.Member.FIELD || m.removed > 0) continue;
      out.add(type.equals("style") ? m.name.replace('_', '.') : m.name);
    }
    return out;
  }

  /** Free dimensions: a typed number expands to the common units. */
  private static List<String> dimensions(String prefix) {
    List<String> out = new ArrayList<>();
    String digits = leadingNumber(prefix);
    if (digits.isEmpty()) return out;
    out.add(digits + ".0dip");
    out.add(digits + "dip");
    out.add(digits + "dp");
    out.add(digits + "sp");
    out.add(digits + "px");
    return out;
  }

  private static String leadingNumber(String prefix) {
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < prefix.length(); i++) {
      char c = prefix.charAt(i);
      if (Character.isDigit(c) || c == '.') out.append(c);
      else break;
    }
    return out.toString();
  }

  // ─────────────────────────── ordering ───────────────────────────

  private static void sort(List<CompletionItem> items, String prefix) {
    items.sort((a, b) -> {
      int r = Integer.compare(CompletionMatcher.rank(a.label, prefix) >= 3 ? 1 : 0,
          CompletionMatcher.rank(b.label, prefix) >= 3 ? 1 : 0);
      return r != 0 ? r : a.label.compareToIgnoreCase(b.label);
    });
  }

  private static List<CompletionItem> cap(List<CompletionItem> items) {
    return items.size() > MAX_RESULTS ? new ArrayList<>(items.subList(0, MAX_RESULTS)) : items;
  }
}
