package almlk;

/**
 * سياسةُ المفتاح الحامل لحرفًا — {@link CodeEditorView} ليس {@code TextView}، فلا أحدَ يترجم
 * {@code KeyEvent} إلى نصٍّ سواه.
 *
 * <p>العلّةُ التي يعالجها (W8): لوحاتُ الأرقام — صفُّ الأرقام في التخطيط العربي، واللوحةُ العتادية،
 * ومفاتيحُ الرموز — تُرسِل **أحداثَ مفاتيح** لا {@code commitText}، ولم يكن في المحرّر فرعٌ يستقبلها
 * فسقطت الأرقامُ **صامتةً** داخل أسماء المتغيّرات والأصناف وبين علامتَي الاقتباس (أي حيث لا يظهر
 * مُرشَّحُ الإكمال فيُظنّ أن المنعَ من السياق). حروفُ الأسماء تمرّ عبر {@code commitText} فلم يُلاحَظ
 * الخلل إلا في الأرقام.
 *
 * <p>القرارُ كله هنا لا في العرض: ما دام المفتاحُ يحمل حرفًا **قابلًا للطباعة** ولا تعديلَ مُحرِّكًا
 * عليه، فهو إدخالٌ؛ والمفاتيحُ التي تتحرّك أو تحذف أو تُنشئ سطرًا/جدولةً مستثناةٌ صراحةً حتى لا يزدوج
 * فعلُها مع نصٍّ. وقابلٌ للطباعةَ يشمل **العربية وعلاماتها** ({@code ،} و{@code ؛} و{@code ؟}) — لا
 * الحروفَ اللاتينية والأرقامَ فقط؛ وهذا هو الفارقُ عن مرشِّحٍ يكتفي بـ{@code a-z0-9}.
 */
public final class EditorKeyInput {

  private EditorKeyInput() {}

  /**
   * هل يُدرَج {@code unicodeChar} في المستند استجابةً لـ{@code keyCode}؟ القيمةُ صفرٌ تعني «لا حرف في
   * هذا المفتاح» كما تحسبها المنصّة، وعندها لا نصّ ولا إدخال.
   */
  public static boolean shouldCommitChar(int keyCode, boolean ctrlPressed, boolean altPressed,
      int unicodeChar) {
    if (unicodeChar <= 0) return false;
    // ctrl/alt اختصاراتٌ لا نصّ (حفظ/نسخ/لصق/تراجع…) — تمرّ لمساراتها القائمة.
    if (ctrlPressed || altPressed) return false;
    if (isNavigationOrEditingKey(keyCode)) return false;
    return isPrintable(unicodeChar);
  }

  /** كلُّ ما ليس تحكّمًا ولا مسافةً بيضاء خاصة: حروفٌ بأيِّ لغة، أرقامٌ، رموزٌ، وعلامات ترقيم. */
  private static boolean isPrintable(int c) {
    if (c == '\n' || c == '\r' || c == '\t') return false;
    return !Character.isISOControl(c);
  }

  /** المستثناة: التنقّل والحذف والإدخال والجدولة — لكلٍّ مسارٌ أوفى من إدراج حرف. */
  private static boolean isNavigationOrEditingKey(int keyCode) {
    switch (keyCode) {
      case android.view.KeyEvent.KEYCODE_DPAD_LEFT:
      case android.view.KeyEvent.KEYCODE_DPAD_RIGHT:
      case android.view.KeyEvent.KEYCODE_DPAD_UP:
      case android.view.KeyEvent.KEYCODE_DPAD_DOWN:
      case android.view.KeyEvent.KEYCODE_DPAD_CENTER:
      case android.view.KeyEvent.KEYCODE_DEL:
      case android.view.KeyEvent.KEYCODE_FORWARD_DEL:
      case android.view.KeyEvent.KEYCODE_ENTER:
      case android.view.KeyEvent.KEYCODE_TAB:
      case android.view.KeyEvent.KEYCODE_MOVE_HOME:
      case android.view.KeyEvent.KEYCODE_MOVE_END:
      case android.view.KeyEvent.KEYCODE_PAGE_UP:
      case android.view.KeyEvent.KEYCODE_PAGE_DOWN:
      case android.view.KeyEvent.KEYCODE_ESCAPE:
        return true;
      default:
        return false;
    }
  }
}
