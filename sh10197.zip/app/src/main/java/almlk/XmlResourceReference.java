package almlk;

/**
 * مرجع مورد XML عند موضع — المرحلة السابعة.
 *
 * <p>يقرأ الصيغ كلها بمدى دقيق: {@code @type/name} و{@code @+type/name} (إعلان) و
 * {@code @android:type/name} (إطار) و{@code ?attr/name} و{@code ?android:attr/name}.
 *
 * <p>دلالتان من المرجع مُعتمدتان حرفيًا:
 *
 * <ul>
 *   <li>الإعلان {@code @+id/x} والمرجع {@code @id/x} **يُطبَّعان إلى المفتاح نفسه** {@code id/x}
 *       — الفرق طول البادئة المقصوصة فقط.
 *   <li>ما لا يُحل يُعلن صراحة ({@code null}) بدل التخمين.
 * </ul>
 *
 * <p>الكلاس خالٍ من أندرويد فيُختبر مستقلًا، ولا يستخدم Regex — مسح محارف مباشر.
 */
public final class XmlResourceReference {

  private static final String FRAMEWORK = "android:";

  /** نوع المورد بلا بادئة الإطار: {@code string}، {@code id}، {@code color}… */
  public final String type;
  /** اسم المورد: {@code app_name}. */
  public final String name;
  /** إزاحة {@code @} أو {@code ?}. */
  public final int start;
  /** ما بعد نهاية الاسم (حصري). */
  public final int end;
  /** إزاحة بداية الاسم — لتثبيت مدى البحث على الاسم لا البادئة. */
  public final int nameStart;
  /** ما بعد نهاية الاسم. */
  public final int nameEnd;
  /** بادئة {@code android:} → مورد إطار لا يُحل إلى ملف محلي. */
  public final boolean framework;
  /** {@code @+} → إعلان يُنشئ المورد. */
  public final boolean declaration;
  /** {@code ?attr/…} أو {@code ?android:attr/…} → سمة ثيم. */
  public final boolean themeAttribute;

  private XmlResourceReference(
      String type,
      String name,
      int start,
      int end,
      int nameStart,
      int nameEnd,
      boolean framework,
      boolean declaration,
      boolean themeAttribute) {
    this.type = type;
    this.name = name;
    this.start = start;
    this.end = end;
    this.nameStart = nameStart;
    this.nameEnd = nameEnd;
    this.framework = framework;
    this.declaration = declaration;
    this.themeAttribute = themeAttribute;
  }

  /** مفتاح البحث الموحّد — نفسه للإعلان {@code @+id/x} والمرجع {@code @id/x}. */
  public String key() {
    return type + "/" + name;
  }

  /** العرض يحمل النوع لا الاسم المجرّد، فيعرف المستخدم ماذا فتح. */
  public String display() {
    return (framework ? "android:" : "") + type + "/" + name;
  }

  /**
   * المرجع الحاوي للموضع، أو {@code null} إن لم يوجد.
   *
   * <p>يبحث يسارًا عن أقرب {@code @} أو {@code ?} ضمن نافذة محدودة (لا مسح للنص كاملًا)، ثم
   * يتحقق أن الموضع داخل المدى فعلاً — فلا يُلتقط بريد إلكتروني ولا نص حر.
   */
  public static XmlResourceReference at(String text, int offset) {
    if (text == null || text.isEmpty()) return null;
    int length = text.length();
    int anchor = offset < 0 ? 0 : Math.min(offset, length - 1);
    int floor = Math.max(0, anchor - 96);
    for (int probe = anchor; probe >= floor; probe--) {
      char c = text.charAt(probe);
      if (c != '@' && c != '?') continue;
      XmlResourceReference reference = parseAt(text, probe);
      if (reference == null) continue;
      if (offset >= reference.start && offset <= reference.end) return reference;
      if (reference.end < anchor) return null; // مرجع سابق لا يحوي الموضع
    }
    return null;
  }

  /** محاولة قراءة مرجع يبدأ عند {@code probe}. */
  private static XmlResourceReference parseAt(String text, int probe) {
    int length = text.length();
    boolean theme = text.charAt(probe) == '?';
    int i = probe + 1;
    boolean declaration = false;
    if (i < length && text.charAt(i) == '+') {
      declaration = true;
      i++;
    }
    int typeStart = i;
    while (i < length && isTypeChar(text.charAt(i))) i++;
    if (i == typeStart || i >= length || text.charAt(i) != '/') return null;
    String rawType = text.substring(typeStart, i);
    i++; // تجاوز '/'
    int nameStart = i;
    while (i < length && isNameChar(text.charAt(i))) i++;
    int nameEnd = i;
    if (nameEnd == nameStart) return null;

    boolean framework = rawType.startsWith(FRAMEWORK);
    String type = framework ? rawType.substring(FRAMEWORK.length()) : rawType;
    if (type.isEmpty()) return null;
    return new XmlResourceReference(
        type,
        text.substring(nameStart, nameEnd),
        probe,
        nameEnd,
        nameStart,
        nameEnd,
        framework,
        declaration,
        theme && "attr".equals(type));
  }

  /** محارف اسم النوع؛ ASCII فقط حتى لا يُلتقط نص عربي مجاور. */
  private static boolean isTypeChar(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == ':';
  }

  /** محارف اسم المورد؛ النقطة مشمولة لأن أسماء الأنماط تحتويها (Theme.AppCompat). */
  private static boolean isNameChar(char c) {
    return (c >= 'a' && c <= 'z')
        || (c >= 'A' && c <= 'Z')
        || (c >= '0' && c <= '9')
        || c == '_'
        || c == '.';
  }
}
