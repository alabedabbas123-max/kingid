package almlk;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * ما يحمِلُهُ مخزنُ المفاتيحِ الذي أشارَ إليهِ مِلَفُّ البناءِ — قراءةً لا غيرُ.
 *
 * <p>هذهِ الطبقةُ شقُّ القراءةِ من التوقيعِ: {@link GradleSigningConfigs} يقرؤُ الإعلانَ في
 * {@code build.gradle}، وهذا يقرؤُ الملفَّ الذي أشارَ إليهِ ذاكُ الإعلانِ. لا نَكتُبُ على القرصِ،
 * ولا نُولِّدُ مفاتيحَ ولا شهاداتٍ، ولا نَفتَحُ محاوارَ «اكتُبِ كلمةَ السرِّ»، ولا نَستَدعي
 * {@code jarsigner} ولا {@code zipalign}؛ والمُخرَجُ حقائقُ عن المخزنِ وعُيوبٌ تُعرَضُ حيثَ تُعرَضُ
 * عُيوبُ الوحدةِ اليومَ.
 *
 * <p><b>كلمةُ السرِّ.</b> لا تُخبَّأُ ولا تُطبعُ ولا تَبرُزُ نصًّا مُطلَقًا: الفتحُ الافتراضيُّ
 * {@code load(stream, null)} — أي بلا فحصِ سلامةٍ — فيُقرَأُ ما يُقرَأُ بلا سرٍّ، والمفتاحُ الخاصُّ
 * لا يُطلَبُ لأنَّنا لا نوقِّعُ ههُنا. ومَن أرادَ ما يَفتَحُهُ السرُّ فلهُ {@link #inspect(File,
 * char[])}: يَأخُذُ الحروفَ وقتَ النداءِ ولا يَحفَظُ لها مرجعًا، ويَمحوها قبلَ الرجوعِ؛ فالمتصلُ
 * يَفقدُها معنا ولا تَبقَى في الحالةِ ولا في السطورِ.
 *
 * <p><b>خِفَّةٌ وسقوفٌ.</b> {@value #MAX_STORE_BYTES} بايتًا حدُّ القراءةِ، و{@value #MAX_ENTRIES}
 * اسمًا، و{@value #MAX_CHAIN} مستوىً لمَشيِ المصدرِ، و{@value #MAX_ISSUES} سطرًا للمخزنِ الواحدِ.
 * والنتيجةُ محفوظةٌ ببصمةِ القرصِ {@link #fingerprint(File)} بسقفِ {@value #MAX_CACHE} مخازنَ: لا
 * قرصَ مرّتينِ في دورةٍ، ومخزنٌ استُبدِلَ يُحاكَمُ من جديدٍ.
 *
 * <p><b>الصفاءُ.</b> {@code java.security} و{@code java.io} وحدَهُما: لا {@code android.*}، ولا
 * عمليةً خارجيّةً، ولا شبكةً، ولا {@code KeyStore.store} ولا {@code setKeyEntry}.
 */
public final class KeystoreInspector {

  /** فوقَ هذا الحدِّ لا نُصدِّقُ أنَّ الملفَّ مخزنُ مفاتيحَ، فنَدَعُهُ ونُخبِرُ. */
  public static final long MAX_STORE_BYTES = 4L * 1024 * 1024;
  /** عددُ الأسماءِ المقروءةِ؛ ما زادَ فمَعدودٌ في {@link Result#entriesTotal}. */
  public static final int MAX_ENTRIES = 32;
  /** أقصى ما نَمشيهِ من شهادةٍ إلى شهادةِ مصدرِها قبلَ أن نَقِفَ. */
  public static final int MAX_CHAIN = 6;
  /** عددُ أسطرِ العجزِ عن الأنواعِ المُجرَّبةِ. */
  public static final int MAX_FAILURES = 4;
  /** لا يُغلِقُ مخزنٌ واحدٌ لوحةَ المشاكلِ. */
  public static final int MAX_ISSUES = 4;
  /** عددُ المخازنِ المحفوظةِ البصمةِ. */
  public static final int MAX_CACHE = 8;

  /** أنواعُ {@code KeyStore} بالمَرجَعِيّةِ: ما يَكتُبُهُ {@code keytool} قديمًا، ثمَّ الحديثُ، ثمَّ{@code BKS}. */
  private static final String[] TYPES = {"JKS", "PKCS12", "BKS"};

  private KeystoreInspector() {
  }

  /** اسمُ مفتاحٍ واحدٍ في المخزنِ، مع ما يُعرَضُ من شهادتِهِ. */
  public static final class Entry {
    public final String alias;
    /** موضوعُ الشهادةِ كما يَراهُ {@code X500Principal#getName()}؛ فارغٌ إن لم تكنْ {@code X.509}. */
    public final String subjectDn;
    public final String issuerDn;
    public final String serial;
    public final String notBefore;
    public final String notAfter;
    public final String sigAlgName;
    public final String keyAlg;
    public final String creationDate;
    /** مدخلُ مفتاحٍ خاصٍّ: {@code isKeyEntry}. */
    public final boolean keyEntry;
    /** مدخلُ شهادةٍ موثوقٍ بها فقطْ: {@code isCertificateEntry}. */
    public final boolean trustedEntry;
    public final boolean expired;
    public final boolean notYetValid;
    /** كم مستوىً مَشَيتا من الشهادةِ إلى مصدرِها (1 للشهادةِ ذاتيةِ التوقيعِ). */
    public final int chainDepth;
    /** مدخلُ مفتاحٍ وشهادتُهُ مُغلَّقةٌ: لا تُقرَأُ بلا كلمةِ سرِّ المخزنِ (لا نَطلُبُها هنا). */
    public final boolean certEncrypted;

    Entry(String alias, String subjectDn, String issuerDn, String serial, String notBefore,
        String notAfter, String sigAlgName, String keyAlg, String creationDate, boolean keyEntry,
        boolean trustedEntry, boolean expired, boolean notYetValid, int chainDepth,
        boolean certEncrypted) {
      this.alias = orEmpty(alias);
      this.subjectDn = orEmpty(subjectDn);
      this.issuerDn = orEmpty(issuerDn);
      this.serial = orEmpty(serial);
      this.notBefore = orEmpty(notBefore);
      this.notAfter = orEmpty(notAfter);
      this.sigAlgName = orEmpty(sigAlgName);
      this.keyAlg = orEmpty(keyAlg);
      this.creationDate = orEmpty(creationDate);
      this.keyEntry = keyEntry;
      this.trustedEntry = trustedEntry;
      this.expired = expired;
      this.notYetValid = notYetValid;
      this.chainDepth = chainDepth;
      this.certEncrypted = certEncrypted;
    }

    /** سطرُ اللوحةِ: اسمٌ وشهادةٌ وسريانٌ — لا كلمةَ سرٍّ ولا بصمةَ شهادةٍ. */
    public String describe() {
      StringBuilder out = new StringBuilder();
      out.append("alias '").append(alias).append("' ");
      out.append(keyEntry ? "key" : (trustedEntry ? "trusted-cert" : "entry"));
      if (!subjectDn.isEmpty()) out.append(' ').append(subjectDn);
      if (!notBefore.isEmpty() || !notAfter.isEmpty()) {
        out.append(" valid ").append(notBefore).append("..").append(notAfter);
      }
      if (!sigAlgName.isEmpty()) out.append(" signed ").append(sigAlgName);
      if (!keyAlg.isEmpty()) out.append(' ').append(keyAlg);
      if (chainDepth > 1) out.append(" chain=").append(chainDepth);
      if (certEncrypted) out.append(" (certificate encrypted; store password not supplied)");
      return out.toString();
    }

    @Override public String toString() {
      return describe();
    }
  }

  /** نتيجةُ فحصِ مخزنٍ واحدٍ: هل فُتِحَ، وبأيِّ نوعٍ، وما فيه، ولماذا لم يَنفَتِحْ. */
  public static final class Result {
    public final File store;
    /** هل وُجِدَ الملفُّ على القرصِ. */
    public final boolean present;
    /** هل فُتِحَ بأحدِ أنواعِ {@code KeyStore}. */
    public final boolean opened;
    /** النوعُ الذي نجحَ، أو {@code null}. */
    public final String type;
    public final List<Entry> entries;
    /** عددُ ما في المخزنِ من أسماءَ (قد يزيدُ عن {@link #entries} بالسقفِ). */
    public final int entriesTotal;
    public final boolean entriesOverflow;
    /** هل جَاوَزَ {@value #MAX_STORE_BYTES} بايتًا فلم يُقرَأْ. */
    public final boolean tooLarge;
    /** هل أُعطِيَت حروفُ سرٍّ وقتَ النداءِ (لا تَبقَى منها نسخةٌ عندَنا أبدًا). */
    public final boolean passwordOffered;
    /** هل فُتِحَ المخزنُ بهذهِ الحروفِ فعلًا (لا بحذفِها)؟ */
    public final boolean passwordUsedForOpen;
    /** عُرضَ السرُّ فلم يَفتَحْ وبَرا المخزنُ بدُونِهِ: السرُّ المُعلَنُ خاطئٌ، لا الملفُّ. */
    public final boolean passwordRejected;
    /** لم يُفتَحْ لأنَّ السرَّ لم يُعطَ (لا أنَّ الملفَّ فاسدٌ): الفرقُ يُسمَعُ في اللوحةِ. */
    public final boolean needsPassword;
    /** سطرٌ لكلِّ نوعٍ جُرِّبَ فلم يَفتَحْ. */
    public final List<String> failures;
    /** بصمةُ القرصِ التي حُفِظَتِ النتيجةُ بها، أو {@code ""}. */
    public final String stamp;

    Result(File store, boolean present, boolean opened, String type, List<Entry> entries,
        int entriesTotal, boolean entriesOverflow, boolean tooLarge, boolean passwordOffered,
        boolean passwordUsedForOpen, boolean passwordRejected, boolean needsPassword,
        List<String> failures, String stamp) {
      this.store = store;
      this.present = present;
      this.opened = opened;
      this.type = type;
      this.entries = entries == null ? new ArrayList<Entry>() : entries;
      this.entriesTotal = entriesTotal;
      this.entriesOverflow = entriesOverflow;
      this.tooLarge = tooLarge;
      this.passwordOffered = passwordOffered;
      this.passwordUsedForOpen = passwordUsedForOpen;
      this.passwordRejected = passwordRejected;
      this.needsPassword = needsPassword;
      this.failures = failures == null ? new ArrayList<String>() : failures;
      this.stamp = orEmpty(stamp);
    }

    /** لا شيءَ يُخبِرُ عنهُ. */
    public boolean isEmpty() {
      return problems().isEmpty();
    }

    /** هل هذا الاسمُ في المخزنِ؟ */
    public boolean hasAlias(String alias) {
      if (alias == null || alias.isEmpty() || !opened) return false;
      for (Entry entry : entries) {
        if (entry.alias.equalsIgnoreCase(alias)) return true;
      }
      return false;
    }

    /** أسماءُ المفاتيحِ بترتيبِ المخزنِ، مَقطوعةً بالسقفِ. */
    public List<String> aliases() {
      List<String> out = new ArrayList<>();
      for (Entry entry : entries) out.add(entry.alias);
      return out;
    }

    /** سطورُ العُيوبِ عن المخزنِ وحدَهُ: لا أسماءَ وحداتٍ ولا تكويناتٍ، فتُسمِّيها الواصلةُ. */
    public List<String> problems() {
      List<String> out = new ArrayList<>();
      if (store == null) return out;
      if (!present) {
        out.add("keystore file does not exist: " + name());
        return out;
      }
      if (tooLarge) {
        out.add("keystore " + name() + " is over the " + (MAX_STORE_BYTES / (1024 * 1024))
            + " MiB limit — not inspected");
        return out;
      }
      if (passwordRejected) {
        out.add("the store password declared for " + name()
            + " does not match it: its integrity check failed (certificates were read without it)");
      }
      if (!opened) {
        if (needsPassword) {
          out.add("keystore " + name() + " could not be opened without a store password");
        } else {
          out.add("keystore " + name() + " could not be opened as a keystore" + failureTail());
        }
        return out;
      }
      if (entries.isEmpty()) {
        out.add("keystore " + name() + " holds no aliases");
      }
      if (entriesOverflow) {
        out.add("keystore " + name() + " lists " + entriesTotal + " aliases; only the first "
            + MAX_ENTRIES + " are read");
      }
      for (Entry entry : entries) {
        if (out.size() >= MAX_ISSUES) break;
        if (entry.certEncrypted) {
          out.add("alias '" + entry.alias + "' in " + name()
              + " keeps its certificate encrypted; the store password was not supplied");
        } else if (entry.expired) {
          out.add("certificate of alias '" + entry.alias + "' in " + name()
              + " expired on " + entry.notAfter);
        } else if (entry.notYetValid) {
          out.add("certificate of alias '" + entry.alias + "' in " + name()
              + " is not valid till " + entry.notBefore);
        }
      }
      return out;
    }

    /** سطرُ اللوحةِ: نوعٌ وعددٌ وسرٌّ لا يُحمَلُ. */
    public String describe() {
      StringBuilder out = new StringBuilder();
      out.append("keystore ").append(name());
      if (!present) return out.append(" — absent").toString();
      if (tooLarge) return out.append(" — too large, not read").toString();
      if (!opened) return out.append(needsPassword ? " — password required" : " — unreadable").toString();
      out.append(" [").append(type).append("] ").append(entriesTotal).append(" alias(es)");
      out.append(", password: ").append(passwordRejected ? "rejected (read without it)"
          : (passwordUsedForOpen ? "used and discarded"
              : (passwordOffered ? "offered, not needed" : "not held")));
      return out.toString();
    }

    @Override public String toString() {
      return describe();
    }

    private String failureTail() {
      if (failures.isEmpty()) return "";
      StringBuilder out = new StringBuilder(" (");
      for (int i = 0; i < failures.size(); i++) {
        if (i > 0) out.append("; ");
        out.append(failures.get(i));
      }
      return out.append(')').toString();
    }

    private String name() {
      return store == null || store.getName() == null ? "" : store.getName();
    }
  }

  /** يقرؤُ المخزنَ بلا كلمةِ سرٍّ: الشهاداتُ تُقرَأُ، والمفاتيحُ لا تُطلَبُ. */
  public static Result inspect(File store) {
    return inspect(store, null);
  }

  /**
   * يقرؤُ المخزنَ مستعينًا بالحروفِ وقتَ النداءِ. المِلْكِيَّةُ تنتقلُ إلينا: تُمحَى قبلَ الرجوعِ،
   * ولا تُستعادُ في نصٍّ ولا في حالةٍ ولا في سطرِ عجزٍ.
   */
  public static Result inspect(File store, char[] password) {
    boolean used = password != null && password.length > 0;
    List<String> failures = new ArrayList<>();
    KeyStore opened = null;
    String openedType = null;
    boolean present = false;
    boolean tooLarge = false;
    boolean openedWithSecret = false;
    try {
      present = store != null && store.isFile();
      if (present && !tooLarge(store, failures)) {
        List<String> ladder = types();
        // إن عُرضَ سرٌّ نُجرِّبُهُ أوَّلًا — لأنَّهُ يَكشِفُ خطأَ الإعلانِ بفحصِ السلامةِ — ثمَّ نَعودُ
        // إلى القراءةِ بدُونِهِ فلا يَذهَبُ مُلكُ صاحبِ المشروعِ على سُخْطِ كلمةِ سرٍّ.
        for (int round = 0; round < (used ? 2 : 1) && opened == null; round++) {
          char[] secret = (used && round == 0) ? password : null;
          for (String type : ladder) {
            KeyStore attempt = open(store, type, secret, failures);
            if (attempt != null) {
              opened = attempt;
              openedType = type;
              openedWithSecret = secret != null;
              break;
            }
          }
        }
      } else if (present) {
        tooLarge = true;
      } else {
        failures.add("no such file");
      }
    } catch (SecurityException | IllegalArgumentException failure) {
      failures.add(orUnknown(failure));
      opened = null;
    } finally {
      if (used) wipe(password);
    }
    List<Entry> entries = new ArrayList<>();
    int total = 0;
    boolean overflow = false;
    if (opened != null) {
      try {
        total = opened.size();
      } catch (Exception failure) {
        total = -1;
      }
      try {
        Enumeration<String> aliases = opened.aliases();
        while (aliases != null && aliases.hasMoreElements()) {
          String alias = aliases.nextElement();
          if (alias == null) continue;
          if (entries.size() >= MAX_ENTRIES) {
            overflow = true;
            break;
          }
          entries.add(read(opened, alias));
        }
      } catch (Exception failure) {
        // قائمةُ الأسماءِ نفسِها لا تُطلَقُ (نوعٌ مُقفَلٌ مثلًا): ما قُرِئَ باقٍ.
      }
      if (total < 0) total = entries.size();
      if (overflow && total < entries.size()) total = entries.size();
      link(opened, entries);
    }
    boolean passwordAsked = opened == null && !used && present && !tooLarge && mentionsPassword(failures);
    boolean rejected = used && opened != null && !openedWithSecret;
    return new Result(store, present, opened != null, openedType, entries, total, overflow,
        tooLarge, used, openedWithSecret, rejected, passwordAsked, failures, "");
  }

  /** يحكُمُ على القرصِ مرةً واحدةً لكلِّ بصمةٍ. */
  public static Result inspectCached(File store) {
    String stamp = fingerprint(store);
    Result previous = lookup(stamp);
    if (previous != null) return previous;
    Result fresh = inspect(store);
    Result held = new Result(fresh.store, fresh.present, fresh.opened, fresh.type, fresh.entries,
        fresh.entriesTotal, fresh.entriesOverflow, fresh.tooLarge, fresh.passwordOffered,
        fresh.passwordUsedForOpen, fresh.passwordRejected, fresh.needsPassword, fresh.failures,
        stamp);
    remember(stamp, held);
    return held;
  }

  /** بصمةُ القرصِ: مسارٌ + طولٌ + عدلةُ تعديلٍ. */
  public static String fingerprint(File store) {
    if (store == null) return "";
    try {
      return store.getAbsolutePath() + "|" + store.length() + '|' + store.lastModified();
    } catch (SecurityException failure) {
      return String.valueOf(store);
    }
  }

  /** مسارُ المخزنِ من بصمتِهِ: كلُّ ما قبلَ عددِ البايتاتِ وعدلةِ التماسِ. */
  private static String pathOf(String stamp) {
    int last = stamp.lastIndexOf('|');
    if (last < 0) return stamp;
    int before = stamp.lastIndexOf('|', last - 1);
    return before < 0 ? stamp : stamp.substring(0, before);
  }

  /** تَفريغُ الحفظِ (عندَ إعادةِ الربطِ، وفي الاختباراتِ). */
  public static void clearCache() {
    synchronized (CACHE) {
      CACHE.clear();
    }
  }

  /** كم مخزنًا محفوظٌ الآنَ. */
  public static int cacheSize() {
    synchronized (CACHE) {
      return CACHE.size();
    }
  }

  // ────────────────────────────────────────────────────────── ما داخليٌّ لا يُعرَضُ للمُستعمِلِ

  private static final LinkedHashMap<String, Result> CACHE =
      new LinkedHashMap<String, Result>(8, 0.75f, true);

  private static Result lookup(String stamp) {
    if (stamp == null || stamp.isEmpty()) return null;
    synchronized (CACHE) {
      return CACHE.get(stamp);
    }
  }

  private static void remember(String stamp, Result result) {
    if (stamp == null || stamp.isEmpty()) return;
    String path = pathOf(stamp);
    synchronized (CACHE) {
      // البصمةُ تتغيَّرُ بتماسِ القرصِ، فلا يَبقَى للمخزنِ الواحدِ بطاقةٌ قديمةٌ تأخذُ مَكانًا
      // سِوَى مَكانِها: مُختزنةٌ واحدةٌ لكلِّ ملفٍّ، لا أرشيفًا لتواريخِ القراءةِ.
      Iterator<String> keys = CACHE.keySet().iterator();
      while (keys.hasNext()) {
        if (pathOf(keys.next()).equals(path)) keys.remove();
      }
      CACHE.put(stamp, result);
      while (CACHE.size() > MAX_CACHE) {
        Iterator<String> oldest = CACHE.keySet().iterator();
        if (!oldest.hasNext()) return;
        oldest.next();
        oldest.remove();
      }
    }
  }

  /**
   * الأنواعُ المُجرَّبةُ بالترتيبِ: الثلاثةُ، ثمَّ نوعُ المنصّةِ الافتراضيُّ إن خالَفَها. عامّةٌ
   * لأنَّ سطرَ العجزِ يُسمّيها، ولئلّا يُعادَ ترتيبُ السُلَّمِ في الاختباراتِ على حِدَةٍ.
   */
  public static List<String> types() {
    List<String> out = new ArrayList<>();
    for (String type : TYPES) out.add(type);
    try {
      String def = KeyStore.getDefaultType();
      if (def != null && !out.contains(def)) out.add(def);
    } catch (SecurityException failure) {
      // لا نوعَ افتراضيًّا مسموحًا بهِ: الثلاثةُ تكفي.
    }
    return out;
  }

  private static boolean tooLarge(File store, List<String> failures) {
    long size;
    try {
      size = store.length();
    } catch (SecurityException failure) {
      failures.add(orUnknown(failure));
      return true;
    }
    if (size <= MAX_STORE_BYTES) return false;
    failures.add("larger than " + (MAX_STORE_BYTES / (1024 * 1024)) + " MiB (" + size + " bytes)");
    return true;
  }

  /** محاولةٌ على نوعٍ واحدٍ: {@code null} مع سطرِ عجزٍ إن لم يَفتَحْ. */
  private static KeyStore open(File store, String type, char[] password, List<String> failures) {
    InputStream raw = null;
    try {
      KeyStore out = KeyStore.getInstance(type);
      raw = new BufferedInputStream(new FileInputStream(store));
      out.load(raw, password);
      return out;
    } catch (Exception failure) {
      if (failures.size() < MAX_FAILURES) failures.add(type + ": " + orUnknown(failure));
      return null;
    } finally {
      close(raw);
    }
  }

  private static Entry read(KeyStore store, String alias) {
    boolean keyEntry = false;
    boolean trusted = false;
    String creation = "";
    try {
      keyEntry = store.isKeyEntry(alias);
      trusted = store.isCertificateEntry(alias);
      Date at = store.getCreationDate(alias);
      if (at != null) creation = DAY.get().format(at);
    } catch (Exception failure) {
      // نوعٌ لا يُميِّزُ المداخلَ: نَكتَفي بما تُخبِرُ عنهُ الشهادةُ.
    }
    String subject = "";
    String issuer = "";
    String serial = "";
    String notBefore = "";
    String notAfter = "";
    String sigAlg = "";
    String keyAlg = "";
    boolean expired = false;
    boolean notYet = false;
    boolean encrypted = false;
    try {
      Certificate found = store.getCertificate(alias);
      encrypted = found == null && keyEntry;
      if (found instanceof X509Certificate) {
        X509Certificate cert = (X509Certificate) found;
        subject = cert.getSubjectX500Principal().getName();
        issuer = cert.getIssuerX500Principal().getName();
        serial = cert.getSerialNumber().toString(16);
        notBefore = DAY.get().format(cert.getNotBefore());
        notAfter = DAY.get().format(cert.getNotAfter());
        sigAlg = cert.getSigAlgName();
        keyAlg = cert.getPublicKey().getAlgorithm();
        Date now = new Date();
        expired = cert.getNotAfter().before(now);
        notYet = cert.getNotBefore().after(now);
      } else if (found != null) {
        keyAlg = found.getType();
      }
    } catch (Exception failure) {
      // شهادةٌ لا تُقرَأُ بصيغةِ {@code X.509}: الاسمُ وحدَهُ ما نَجلِمُ بهِ.
      encrypted = keyEntry;
    }
    return new Entry(alias, subject, issuer, serial, notBefore, notAfter, sigAlg, keyAlg, creation,
        keyEntry, trusted, expired, notYet, 1, encrypted);
  }

  /**
   * مَشيُ المصدرِ بلا قرصٍ زائِدٍ: من الشهادةِ إلى شهادةِ مَن صَدَقَها، بقدرِ {@link #MAX_CHAIN}؛
   * تُستعمَلُ خريطةُ ما قُرِئَ من المخزنِ وحدَهُ، فما ليسَ فيهِ جِذعٌ لا مَشيَ بعدَهُ.
   */
  private static void link(KeyStore store, List<Entry> entries) {
    if (entries.isEmpty()) return;
    Map<String, String> bySubject = new LinkedHashMap<>();
    for (Entry entry : entries) {
      if (!entry.subjectDn.isEmpty() && !bySubject.containsKey(entry.subjectDn)) {
        bySubject.put(entry.subjectDn, entry.alias);
      }
    }
    List<Entry> withDepth = new ArrayList<>(entries.size());
    for (Entry entry : entries) {
      int depth = 1;
      String at = entry.issuerDn;
      try {
        while (at != null && !at.isEmpty() && depth < MAX_CHAIN) {
          if (at.equalsIgnoreCase(entry.subjectDn)) break;
          String parent = bySubject.get(at);
          if (parent == null) {
            depth++;
            break;
          }
          Certificate parentCert = store.getCertificate(parent);
          if (!(parentCert instanceof X509Certificate)) break;
          at = ((X509Certificate) parentCert).getIssuerX500Principal().getName();
          depth++;
        }
      } catch (Exception failure) {
        // سلسلةٌ لا تُستَكملُ: المَعروفُ يكفي.
      }
      withDepth.add(new Entry(entry.alias, entry.subjectDn, entry.issuerDn, entry.serial,
          entry.notBefore, entry.notAfter, entry.sigAlgName, entry.keyAlg, entry.creationDate,
          entry.keyEntry, entry.trustedEntry, entry.expired, entry.notYetValid, depth,
          entry.certEncrypted));
    }
    entries.clear();
    entries.addAll(withDepth);
  }

  /** هل قالَ العجزُ عن السرِّ صراحةً؟ (لا عن تآكُلِ الملفِّ ولا عن نوعٍ لا يُعرَفُ) */
  static boolean mentionsPassword(List<String> failures) {
    if (failures == null) return false;
    for (String failure : failures) {
      if (failure == null) continue;
      String low = failure.toLowerCase(Locale.ROOT);
      if (low.contains("password") || low.contains("integrity") || low.contains("mac")) return true;
    }
    return false;
  }

  private static String orUnknown(Exception failure) {
    String message = failure == null ? null : failure.getMessage();
    if (message == null || message.trim().isEmpty()) {
      return failure == null ? "failed" : failure.getClass().getSimpleName();
    }
    String one = message.replace('\n', ' ').trim();
    return one.length() <= 120 ? one : one.substring(0, 120) + "…";
  }

  private static String orEmpty(String value) {
    return value == null ? "" : value;
  }

  private static void close(InputStream stream) {
    if (stream == null) return;
    try {
      stream.close();
    } catch (Exception ignored) {
      // الإغلاقُ لا يُفشِلُ قراءةً تمتْ.
    }
  }

  private static void wipe(char[] password) {
    if (password == null) return;
    for (int i = 0; i < password.length; i++) password[i] = '\u0000';
  }

  private static final ThreadLocal<SimpleDateFormat> DAY = new ThreadLocal<SimpleDateFormat>() {
    @Override protected SimpleDateFormat initialValue() {
      return new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
    }
  };
}
