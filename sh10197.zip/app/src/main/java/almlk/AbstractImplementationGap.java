package almlk;

import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * W27/3 (‏1.0.180): a concrete class must implement the abstract methods it inherits — reported at
 * the class name, with one fix that writes every missing method at once.
 *
 * <p>الملفُّ صافٍ: لا استيرادَ من نظامٍ ولا قرصَ ولا شبكةَ. مَن يَعرِفُ الأصلَ يُعطى له من الخارجِ
 * ({@link SupertypeFacts})، وهو في التطبيقِ انِعكاسٌ على إطارِ الجهازِ الجاري ({@link
 * PlatformMemberLookup}) أو فِهرسُ أصنافِ المشروعِ، وفي البوّابةِ جَدوَلٌ مَكتوبٌ هُناك. لا تَخمينَ
 * أبدًا: أصلٌ لا يُعرَفُ عنهُ شيءٌ يسكُتُ عن الصنفِ كلِّهِ (حالةٌ مَسمّاةٌ {@code parent_unreadable})،
 * لأنَّ قُبحَ إصلاحٍ يَعرضُ ما ليسَ ناقصًا أعظمُ من نفعِهِ.
 *
 * <p>مرجعُنا في الشكلِ لا في النقلِ: المُحرِّكُ عندَهُ يَكتُبُ الرسالةَ ويَقرِنُها برقمِ إصلاحٍ
 * («{@code This class must implement abstract methods }»، «{@code Implement all abstract methods}» في
 * {@code abcd.dd$a}؛ الثابتانِ مُثبَّتانِ في ورقةِ دراسةِ الملحقاتِ)، فلا حِوارَ ولا شاشةَ وسيطةً:
 * التشخيصُ سطرٌ في اللوحةِ (‏1.0.179) والإصلاحُ صَفٌّ في صفحةِ الإجراءاتِ.
 *
 * <p>ما لا تَعُدُّهُ: ما نُفِّذَ في الصنفِ نفسِهِ (بالاسمِ وعَدَدِ المَعاملِ، كقاعدةِ {@link
 * QuickFix} القائمةِ)، وما تَكفَّلَ بهِ أصلٌ مَبنِيٌّ في سلسلةِ الأصلِ (يَسقُطُ عندَ أوَّلِ صنفٍ
 * غيرِ مجرَّدٍ)، ودوالُّ {@code Object} التي تُعدُّ مُنفَّذةٍ بحُكمِها. أمّا الصنفُ الذي يَزيدُ
 * ناقصُهُ على {@link #MAX_METHODS_PER_BATCH} فيُعلَنُ ولا يُلَقَّنُ: دفعةٌ ناقصةٌ تُورِثُ صنفًا
 * لا يُبنى، والصادقُ أن يُترَكَ للمُبرمِجِ.
 */
public final class AbstractImplementationGap {

  /** مفتاحُ الرسالةِ: واحدٌ لكلِّ صنفٍ ناقصٍ، فلا نصَّ مُختَرَعاتٍ في الغلافِ. */
  public static final String MESSAGE_KEY = "ui_diagnostic_must_implement_abstract_methods";

  /**
   * مفتاحُ رسالةِ الأخوِ كما نَصَّها المرجعُ: صنفٌ مُعيِّنٌ يُعلنُ دالةً مجرَّدةً فيُطلَبُ منهُ أن
   * يكونَ مُجرَّدًا. والمُرسِلُ واحدٌ عندَهُ ({@code abcd.dd$a.vJ}) والفرقُ بينَهُما رمزُ الرسالةِ
   * وحدَهُ، فهُنا مِثلَهُ: لا قاعدةَ ثانيةً في غلافٍ آخرَ.
   */
  public static final String ABSTRACT_MESSAGE_KEY = "ui_diagnostic_must_be_declared_abstract";

  /** ما يُلصِقُهُ المرجعُ عندَ كلمةِ الصنفِ، وتسميتُهُ الحرفيةُ {@code insert 'abstract '}. */
  public static final String ABSTRACT_FIX_TEXT = "abstract ";

  /** المفتاحُ المَسمّى للإعلامِ الفوريِّ: دالةٌ واحدةٌ، ثمَّ جَمعٌ إن زادَت. */
  public static final String TOAST_ONE_KEY = "ui_toast_abstract_method_one";
  public static final String TOAST_MANY_KEY = "ui_toast_abstract_methods";

  /** ما يَنقُصُ أكثرَ من هذا يُعلَنُ ولا يُلَقَّنُ (لا دفعةٌ تُنجِزُ نصفَ الصنفِ). */
  public static final int MAX_METHODS_PER_BATCH = 12;

  /** حالةٌ مَسمّاةٌ: الأصلُ لا يُعرَفُ عنهُ، فلا حُكمَ على الصنفِ. */
  public static final String PARENT_UNREADABLE = "parent_unreadable";

  /** حالةٌ مَسمّاةٌ: الناقصُ أكثرَ مما يُلقَّنُ دفعةً واحدةً. */
  public static final String OVER_BATCH_LIMIT = "over_batch_limit";

  /**
   * حالةُ سِلسِلَةِ الأصلِ — وهيَ الفَصلُ الَّذي طَلَبَتهُ الدِّراسَةُ (S3/G3): «لا جَدوَلَ» غيرُ
   * «لا نُقصَانَ». {@code FULL} السِّلسِلَةُ مُغلَقَةٌ فَما نَراهُ هُوَ الكُلُّ؛ {@code TRUNCATED}
   * مَا جَمَعْنَاهُ ثابِتٌ وَلكِنَّ فَوقَهُ حِجَابًا (صِنفٌ لا يُقرَأُ أو مَولَّدٌ) فَالقَائِمَةُ قَد
   * تَزيدُ وَلا تَنقُصُ؛ {@code UNSEEN} لم نَقْرَأْ شَيئًا — فَلا حُكمَ وَلا رَفعَ قَضاءٍ.
   */
  public enum SupertypeState {
    FULL,
    TRUNCATED,
    UNSEEN;

    /** أسوؤُ حالَتَينِ: الحِجَابُ يَغْلِبُ النَّقْصَ المَعلُومَ، والنَّقْصُ يَغْلِبُ اليَقينَ. */
    public static SupertypeState worst(SupertypeState a, SupertypeState b) {
      if (a == UNSEEN || b == UNSEEN) return UNSEEN;
      return a == TRUNCATED || b == TRUNCATED ? TRUNCATED : FULL;
    }
  }

  /** رسالةُ النَّاقِصِ المَعلُومِ: عَدَدٌ ثابِتٌ مَعَ إِعلَانِ الحِجَابِ، لا دَعوَى كَمالٍ. */
  public static final String TRUNCATED_MESSAGE_KEY =
      "ui_diagnostic_must_implement_known_abstract_methods";

  /** حالةٌ مَسمّاةٌ: نوعٌ في التوقيعِ لا يُكتَبُ في هذا الملفِّ (لا استيرادَ ناقصَ نُخلِفُهُ). */
  public static final String TYPES_UNRENDERABLE = "types_unrenderable";

  /** دالةٌ مجرّدةٌ مطلوبةٌ، كما وُجِدَت في الأصلِ (لا كما تُقرأ في نصٍّ). */
  public static final class Required {
    /** الصنفُ الذي أَعلَنَها (مُؤهَّلٌ مُنقَّطٌ): {@code android.widget.Adapter}. */
    public final String owner;
    public final String name;
    /** أنواعُ المَعاملِ أسماءً قانونيّةً مُبسَّطةً ({@code int}, {@code android.view.View}). */
    public final List<String> parameterTypes;
    public final String returnType;
    public final boolean varargs;

    public Required(String owner, String name, List<String> parameterTypes, String returnType,
        boolean varargs) {
      this.owner = owner == null ? "" : owner;
      this.name = name == null ? "" : name;
      this.parameterTypes = parameterTypes == null
          ? Collections.<String>emptyList()
          : Collections.unmodifiableList(new ArrayList<String>(parameterTypes));
      this.returnType = returnType == null || returnType.isEmpty() ? "void" : returnType;
      this.varargs = varargs;
    }

    /** كما مَثَّلَهُ الملحقُ: {@code android.widget.Adapter.getItem(int)}. */
    public String written() {
      StringBuilder out = new StringBuilder(owner).append('.').append(name).append('(');
      for (int i = 0; i < parameterTypes.size(); i++) {
        if (i > 0) out.append(", ");
        String type = parameterTypes.get(i);
        out.append(type != null && type.startsWith("java.lang.") && type.indexOf('.', 10) < 0
            ? type.substring("java.lang.".length())
            : type);
      }
      return out.append(')').toString();
    }

    /** بصمةُ المقارنةِ: الاسمُ وعَدَدُ المَعاملِ — نفسُ قاعدةِ {@link QuickFix#planInsertion}. */
    public String key() {
      return name + "/" + parameterTypes.size();
    }

    /** هل تَكفَّلَ بها {@code java.lang.Object} (فلا تُطلَبُ من صنفٍ يَرِثُهُ حتمًا). */
    public boolean suppliedByObject() {
      if (parameterTypes.size() == 1 && "java.lang.Object".equals(parameterTypes.get(0)))
        return name.equals("equals");
      if (!parameterTypes.isEmpty()) return false;
      return name.equals("hashCode") || name.equals("toString");
    }
  }

  /** مَن يُجيبُ عن أصنافٍ عليا: لا جَدوَلَ يدويًّا هنا، ولا تَخمينَ هناك. */
  public interface SupertypeFacts {
    /** {@code null} حينَ لا يُعرَفُ الأصلُ؛ وإلا الدوالُّ المجرّدةُ المَطلوبةُ منهُ (قد تَكونُ فارغةً). */
    List<Required> abstractMethodsOf(String qualifiedName);

    /**
     * الدوالُّ التي أَتَمَّها الأصلُ نفسُهُ أو أحدُ أسلافِهِ، بمفاتيحِ {@link Required#key()}: ما
     * نَفَّذَهُ الأصلُ لا يُطلَبُ من الوارثِ، وإلا صارتِ الدفعةُ تَزدادُ بما ليسَ ناقصًا وتَبلُغُ
     * {@link #MAX_METHODS_PER_BATCH} فتَسقُطُ الإصلاحاتٌ كلُّها (عطلُ 1.0.185: {@code extends
     * BaseAdapter} طَلَبَ ثلاثَ عشرةَ دالةً وحدَهُ، وإنما تَنقُصُ أربعٌ).
     *
     * <p>الافتراضُ مجموعةٌ فارغةٌ: مَن لا يُجيبُ عن الكفايةِ لا يَمنَعُ السؤالَ. و{@code null}
     * تعنيَ أنَّ الأصلَ لا يُعرَفُ ما نَفَّذَ — وعندَئذٍ لا حُكمَ على الصنفِ كلِّهِ، بابُ
     * {@code parent_unreadable} نفسُهُ.
     */
    default Set<String> implementedKeys(String qualifiedName) {
      return Collections.emptySet();
    }

    /**
     * هل القَائِمَةُ الَّتي أَعلَنَها {@link #abstractMethodsOf} كَامِلَةٌ؟ الافتراضُ {@code FULL}:
     * مَن لا يَعرِفُ الحِجَابَ لا يَسأَلُ عنهُ، وَمَن يَعرِفُهُ يَسمّيه — فَالكَذِبُ في الاتِّجَاهَينِ
     * مَمْنُوعٌ بِالبِنَاءِ.
     */
    default SupertypeState stateOf(String qualifiedName) {
      return SupertypeState.FULL;
    }
  }

  /** صنفٌ ناقصٌ واحدٌ: موضِعُ اسمِهِ، ودوالُّهُ، وجهزتُهُ للإصلاحِ. */
  public static final class Gap {
    public final String className;
    /** الأصلُ المَكتوبُ الذي طَلَبَ (لِلسطرِ في اللوحةِ). */
    public final String ownerWritten;
    public final List<Required> missing;
    public final int nameStart;
    public final int nameEnd;
    /**
     * مُرشَّحُ مرساةِ المرجعِ: إزاحةُ {@code '}{' } فاتحةِ جِسمِ الصنفِ — حيثُ يُدرَجُ الإصلاحُ فعلًا،
     * فيكونُ التشخيصُ والإصلاحُ على مرساةٍ واحدةٍ كما في {@code abcd.dd$a}. يَسقُطُ إليهِ اسمُ
     * الصنفِ إن لم تَكُنِ الإزاحةُ قوسًا (صنفٌ بلا جِسمٍ مَقروءٍ)، فلا ماركَ في الهواءِ.
     */
    public final int braceStart;
    /** {@code null} حينَ يُلَقَّنُ، وإلا اسمُ الحالةِ المَسمّاةِ {@link #OVER_BATCH_LIMIT}. */
    public final String state;
    /**
     * سِلسِلَةُ الأصلِ مَقطوعَةٌ فَوقَ مَا قَرَأْنَا: الدَّفعَةُ تَطلُبُ مَا ثَبَتَ فَقَط، وَالرِّسَالَةُ
     * وَالقَائِمَةُ تُصَرِّحَانِ بِذلِك (ج٤٤: «لا جَدوَلَ» غَيرُ «لا نُقصَانَ»). لا تُغَيِّرُ شَرطَ
     * {@link #isFixable()} لأنَّ الإِصلاحَ نَاقِصُ المُهِمَّةِ لا باطِلُها.
     */
    public boolean chainTruncated;

    Gap(String className, String ownerWritten, List<Required> missing, int nameStart, int nameEnd,
        int braceStart, String state) {
      this.className = className;
      this.ownerWritten = ownerWritten;
      this.missing = Collections.unmodifiableList(missing);
      this.nameStart = nameStart;
      this.nameEnd = nameEnd;
      this.braceStart = braceStart;
      this.state = state;
    }

    /** إزاحةُ الماركِ المَعتَمَدةُ بعدَ التأكُّدِ منَ النصِّ الحيِّ: القوسُ، وإلا اسمُ الصنفِ. */
    public int anchorStart(String source) {
      if (source != null && braceStart > 0 && braceStart < source.length()
          && source.charAt(braceStart) == '{') return braceStart;
      return Math.max(0, Math.min(nameStart, source == null ? 0 : source.length()));
    }

    /** مَدًى من محرفٍ واحدٍ عندَ القوسِ (ترميزُ المرجعِ للماركِ الصغرى)، ومَدَى الاسمِ خلافَ ذلكَ. */
    public int anchorEnd(String source, int start) {
      if (start == braceStart) return Math.min(source.length(), start + 1);
      return Math.max(start + 1, Math.min(nameEnd, source.length()));
    }

    public int count() {
      return missing.size();
    }

    public boolean isFixable() {
      return state == null;
    }

    /** بصمةُ الكبتِ: نفسُ الصنفِ ونفسُ الدوالِّ = لا رَجّةَ معَ كلِّ ضغطةِ مفتاحٍ. */
    public String key() {
      StringBuilder out = new StringBuilder(className);
      for (Required r : missing) out.append(' ').append(r.key());
      return out.toString();
    }

    /**
     * الدفعةُ: دالةٌ لكلِّ ناقصٍ، والأولى في حقولِ الإصلاحِ المَعتادِ فلا الغلافُ يتغيَّرُ ولا التراجعُ
     * يتعدَّدُ (خطوةُ تراجعٍ واحدةٌ تُمحو الدوالَّ كلَّها). {@code null} إن لم تَكُنِ الأنواعُ كلها
     * مَكتوبةً في هذا الملفِّ — لا سطرٌ ناقصُ الاستيرادِ تُورِثُهُ الشجرةُ.
     */
    public QuickFix fix() {
      List<QuickFix> all = new ArrayList<QuickFix>(missing.size());
      List<String> needed = new ArrayList<String>(); // استيراداتُ الدُّفعةِ كلِّها، بترتيبِها، بلا حَصرٍ
      for (Required r : missing) {
        List<QuickFix.Param> params = new ArrayList<QuickFix.Param>(r.parameterTypes.size());
        for (int i =0; i < r.parameterTypes.size(); i++) {
          String type = renderType(r.parameterTypes.get(i), imports, needed, ownPackage,
              declaredHere);
          if (type == null) return null;
          if (i == r.parameterTypes.size() - 1 && r.varargs) type = type + "...";
          params.add(new QuickFix.Param(type, "arg" + i));
        }
        String returnType = renderType(r.returnType, imports, needed, ownPackage, declaredHere);
        if (returnType == null) return null;
        QuickFix generated = QuickFix.createMethod(className, returnType, r.name, params, false);
        generated.overrides = true; // تنفيذُ طلبِ الأصلِ: Annotationُ جزءٌ من القالبِ لا زينةٌ
        all.add(generated);
      }
      QuickFix batch = QuickFix.implementAbstractMethods(all);
      if (batch != null) {
        batch.withImports(needed);
        // لا «كلَّها» إذْ قد تَحتَ الحِجَابِ غَيرُها: الصَّفُّ يَعِدُ بِمَا يَفْعَلُ حَرفيًّا.
        batch.listMayBeIncomplete = chainTruncated;
      }
      return batch;
    }

    /** استيراداتُ الملفِّ الحاملِ — تُثبَّتُ لحظةَ البناءِ لتَقريبِ الأسماءِ لا أكثرَ. */
    List<String> imports = Collections.emptyList();

    /**
     * حزمةُ الملفِّ الحاملِ وأسماءُ كلِّ صنفٍ مُعلَنٍ فيه: هذانِ يُكملانِ «حكمَ الظلِّ» (‏JLS 6.4.1‏)
     * قبلَ تقريبِ اسمٍ — فـ‏{@code Object} في ملفٍ يَعلَنُ صنفًا اسمُهُ {@code Object}، أو يستوردُ
     * {@code com.other.Object}، ليست {@code java.lang.Object} (جولةُ ٤٥).
     */
    String ownPackage = "";
    Set<String> declaredHere = Collections.emptySet();
  }

  /** ما يُعلَنُ في «التوستِ» عندَ رَدِّ المُحلِّلِ: مفتاحٌ وحِجَجُهُ، أو لا شيءَ. */
  public static final class Announcement {
    public final String messageKey;
    public final String firstMethod;
    public final int count;

    /** حِجَجُ {@code UiStrings.format}: واحدةٌ للمفردِ، واثنتانِ للجمعِ. */
    public Object[] args() {
      return count == 1 ? (Object[]) new Object[] {firstMethod} : (Object[]) new Object[] {Integer.valueOf(count), firstMethod};
    }
    /** البصمةُ التي تُحفَظُ للكبتِ في الدورةِ التاليةِ. */
    public final String fingerprint;

    Announcement(String messageKey, String firstMethod, int count, String fingerprint) {
      this.messageKey = messageKey;
      this.firstMethod = firstMethod;
      this.count = count;
      this.fingerprint = fingerprint;
    }
  }

  private AbstractImplementationGap() {}

  /**
   * المُجيبُ المُستعمَلُ في التطبيقِ: أصنافُ المشروعِ أولًا من أشجارِها المَصدريّةِ، ثمَّ إطارُ الجهازِ
   * الجاري ({@link PlatformMemberLookup#abstractMethodsOf}). ولا ثالثَ: ما لا يَعرِفُهُ واحدٌ منهُما
   * يَسكُتُ عنهُ، فلا جَدوَلًا يدويًّا للأطرِ ولا تَخمينًا بالاسمِ.
   */
  public static final SupertypeFacts RUNTIME = new SupertypeFacts() {
    @Override
    public List<Required> abstractMethodsOf(String qualifiedName) {
      if (qualifiedName == null || qualifiedName.isEmpty()) return null;
      List<Required> inProject = projectAbstracts(qualifiedName);
      return inProject != null ? inProject : PlatformMemberLookup.abstractMethodsOf(qualifiedName);
    }

    @Override
    public Set<String> implementedKeys(String qualifiedName) {
      if (qualifiedName == null || qualifiedName.isEmpty()) return Collections.emptySet();
      Set<String> inProject = projectImplemented(qualifiedName);
      return inProject != null ? inProject : PlatformMemberLookup.concreteMethodKeys(qualifiedName);
    }

    @Override
    public SupertypeState stateOf(String qualifiedName) {
      if (qualifiedName == null || qualifiedName.isEmpty()) return SupertypeState.UNSEEN;
      SupertypeState inProject = projectState(qualifiedName);
      if (inProject != null) return inProject;
      PlatformMemberLookup.Members m =
          PlatformMemberLookup.load(qualifiedName.replace('.', '$'));
      if (m == null) return SupertypeState.UNSEEN;
      return m.complete ? SupertypeState.FULL : SupertypeState.TRUNCATED;
    }
  };

  /**
   * الدوالُّ المجرّدةُ في صنفِ مشروعٍ: تُجمَعُ ما دامَ الأصلُ مُجرَّدًا أو واجهةً، وتُترَكُ عندَ أوَّلِ
   * مَبنيٍّ (كبابِ الإطارِ حرفيًّا). {@code null} حينَ لا يَستطيعُ النموذجُ أن يَقطعَ: صنفٌ غيرُ
   * مَوجودٍ، أو غيرُ مَوثوقٍ (مُولَّدٌ، أو {@code R})، أو سلسلةٌ لم تُحَلْ — فالحُكمُ على الناقصِ يَحتاجُ
   * إلى اليقينِ لا إلى الظنِّ.
   */
  static List<Required> projectAbstracts(String qualifiedName) {
    JavaTypeModel.SourceClass start = JavaProjectModel.classByQualifiedName(qualifiedName);
    if (start == null) return null;
    ArrayList<Required> out = new ArrayList<Required>();
    SupertypeState state = collectSource(start, out, new HashSet<String>(), true);
    // حِجَابٌ فَوقَ مَا قَرَأْنَاهُ: مَا ثَبَتَ ثَابِتٌ، تُطلَبُ الدَّفَعَةُ وَتُعلَنُ النَّقْصُ صَرِيحًا.
    if (state == SupertypeState.UNSEEN && out.isEmpty()) return null;
    return out;
  }

  /** حالَةُ سِلسِلَةِ صِنفِ مَشروعٍ؛ {@code null} أيْ لا رَأْيَ لَنا فيهِ (يَسأَلُ المَنصَّةَ). */
  static SupertypeState projectState(String qualifiedName) {
    JavaTypeModel.SourceClass start = JavaProjectModel.classByQualifiedName(qualifiedName);
    if (start == null) return null;
    return collectSource(start, new ArrayList<Required>(), new HashSet<String>(), true);
  }

  /**
   * ما أَتَمَّهُ صنفُ مشروعٍ: الدوالُّ المَبنيّةُ المَعلَنةُ فيهِ وفي أسلافِهِ — والصُّعودُ على بابِ
   * {@link #collectSource} نفسِهِ (حاجزُ المَبنيِّ)، ورابطٌ غيرُ مَقطوعٍ يَرُدُّ {@code null}: مَن لا
   * يَعرِفُ كفايةَ الأصلِ يَسكُتُ عن الوارثِ ولا يَختَرِعُ نقصًا. رابطٌ من المنصّةِ يُسأَلُ
   * {@link PlatformMemberLookup#concreteMethodKeys} — فسلسلةُ أصنافِ المشروعِ تَلجُ الإطارَ كثيرًا.
   */
  static Set<String> projectImplemented(String qualifiedName) {
    JavaTypeModel.SourceClass start = JavaProjectModel.classByQualifiedName(qualifiedName);
    if (start == null) return null;
    HashSet<String> out = new HashSet<String>();
    // ما قَرَأْنَاهُ نُقصِمُ بِهِ الدَّفَعَةَ (تنفيذٌ مَوضِعُهُ أَدفَنُ من طَلَبِهِ)؛ وَالحِجَابُ لا
    // يُبطِلُ مَا ثَبَتَ — لأنَّ تنفيذَ دالَّةٍ مُعلَنَةٍ في D لا يَكونُ إلّا في D أو في وارِثٍ لَها،
    // وكِلاهُمَا تَحتَ الحِجَابِ لا فَوقَهُ. فَلا وَهمَ في هذا الاتِّجَاهِ.
    collectImplemented(start, out);
    return out;
  }

  private static boolean collectImplemented(JavaTypeModel.ClassSymbol type, Set<String> out) {
    if (type == null || type.isError()) return false;
    // نِصفُ اليَقينِ أَفضَلُ مِنَ العَدَمِ هُنَا: نَجمَعُ مَا قَرَأْنَا وَنَقولُ «لا أدرِي ما فَوقَ».
    String qualified = type.qualifiedName();
    if (qualified != null && qualified.equals("java.lang.Object")) return true;
    if (type.isProject() && !type.reliable()) return false;
    List<JavaTypeModel.MethodSymbol> methods;
    try {
      methods = type.methods();
    } catch (Throwable broken) {
      return false;
    }
    if (methods == null) return false;
    for (JavaTypeModel.MethodSymbol method : methods) {
      if (method == null || method.isStatic || method.decl == null) continue;
      if (method.decl.mods.has(JavaSyntaxTree.ABSTRACT)) continue; // المجرَّدةُ تُطلَبُ لا تُحسَبُ كفايةً
      out.add(method.name + "/" + method.paramTypes.size());
    }
    boolean abstractLink =
        type.isInterface()
            || (type instanceof JavaTypeModel.SourceClass
                && ((JavaTypeModel.SourceClass) type).decl.mods.has(JavaSyntaxTree.ABSTRACT));
    if (!abstractLink) return true; // صنفٌ مَبنيٌّ: أسلافُهُ قُضيَ بها عليهِ، ولا صُعودَ بعدَهُ
    JavaTypeModel.ClassType parent = type.superclass();
    if (parent != null) {
      if (parent.symbol == null) return false;
      if (!parent.symbol.isProject()) {
        Set<String> fromPlatform =
            PlatformMemberLookup.concreteMethodKeys(parent.symbol.qualifiedName());
        if (fromPlatform == null) return false;
        out.addAll(fromPlatform);
      } else if (!collectImplemented(parent.symbol, out)) {
        return false;
      }
    }
    for (JavaTypeModel.ClassType iface : type.interfaces()) {
      if (iface == null || iface.symbol == null) return false;
      if (!iface.symbol.isProject()) {
        Set<String> fromPlatform = PlatformMemberLookup.concreteMethodKeys(iface.symbol.qualifiedName());
        if (fromPlatform == null) return false;
        out.addAll(fromPlatform);
        continue;
      }
      if (!collectImplemented(iface.symbol, out)) return false;
    }
    return true;
  }

  /** {@code false} = سلسلةٌ غيرُ قاطعةٍ (لا تُطلَقُ دعوةٌ عليهِ). */
  private static SupertypeState collectSource(JavaTypeModel.ClassSymbol type, List<Required> out,
      Set<String> seen, boolean top) {
    if (type == null || type.isError()) return SupertypeState.UNSEEN;
    String qualified = type.qualifiedName();
    if (qualified != null && qualified.equals("java.lang.Object")) return SupertypeState.FULL;
    if (type.isProject() && !type.reliable()) return SupertypeState.UNSEEN;
    boolean abstractType =
        type.isInterface()
            || (type instanceof JavaTypeModel.SourceClass
                && ((JavaTypeModel.SourceClass) type).decl.mods.has(JavaSyntaxTree.ABSTRACT));
    if (!abstractType) return SupertypeState.FULL; // صنفٌ مَبنيٌّ: تَكفَّلَ بما تَحتَهُ، ولا شَيءَ على الوارثِ
    List<JavaTypeModel.MethodSymbol> methods;
    try {
      methods = type.methods();
    } catch (Throwable broken) {
      return SupertypeState.UNSEEN;
    }
    if (methods == null) return SupertypeState.UNSEEN;
    for (JavaTypeModel.MethodSymbol method : methods) {
      if (method == null || method.isStatic || method.decl == null) continue;
      if (!method.decl.mods.has(JavaSyntaxTree.ABSTRACT)) continue;
      // ‏1.0.196 (طلبُ «Required بنوعٍ مُحلٍّ»): النصُّ المَكتوبُ في مِلَفِّ الأصلِ يُقرَأُ عليهِ لا
      // على الوارثِ؛ فـ‏{@code Object} هناك هوَ {@code java.lang.Object} هنا، وبهِ يَسقُطُ حَجزُ
      // «لا نَكتُبُ ما لَم يَذكُرْهُ المِلَفُّ» عَمَّا نَعرَفُ، وَيَبقَى حَجزُ ما لا اسمَ لَهُ عِندَنا
      // (مُتَغَيِّرُ نوعٍ، أوِ اسمٌ لَم يُحَلَّ) كما هوَ: لا اختراعَ في التوقيعِ المُولَّدِ.
      ArrayList<String> params = new ArrayList<String>(method.paramTypes);
      for (int i = 0; i < params.size() && i < method.decl.params.size(); i++) {
        String known = described(type, method.decl.params.get(i).type);
        if (known != null) params.set(i, known);
      }
      String returnType = described(type, method.decl.result);
      if (returnType == null) returnType = method.returnText; // جولةُ ٤٤: النصُّ المَكتوبُ مَرجِعًا
      Required required = new Required(qualified, method.name, params,
          returnType == null ? "void" : returnType, method.decl.varargs());
      if (required.suppliedByObject()) continue;
      if (seen.add(required.key())) out.add(required);
    }
    List<JavaTypeModel.ClassType> supers = new ArrayList<JavaTypeModel.ClassType>();
    JavaTypeModel.ClassType parent = type.superclass();
    if (parent != null) supers.add(parent);
    supers.addAll(type.interfaces());
    SupertypeState state = SupertypeState.FULL;
    for (JavaTypeModel.ClassType sup : supers) {
      if (sup == null || sup.symbol == null) continue;
      SupertypeState up = collectSource(sup.symbol, out, seen, false);
      if (up == SupertypeState.FULL) continue;
      // الحِجَابُ فَوقَ مَا قَرَأْنَا: مَا ثَبَتَ يَبقَى مَطلوبًا وَالحُكمُ يُعلَنُ «ناقِصًا مَعلُومًا»؛
      // وَمَا لَم نَقْرَأْ قَطرَةً مِنهُ يَبقَى بِلا حُكمٍ — فَلا قائمةَ تُبنى مِنَ العَدَمِ.
      boolean readSomething = !seen.isEmpty();
      state = SupertypeState.worst(state,
          up == SupertypeState.TRUNCATED || readSomething
              ? SupertypeState.TRUNCATED : SupertypeState.UNSEEN);
    }
    return state;
  }

  /**
   * التشخيصاتُ كلُّها: صِفْرٌ حينَ لا ناقِصَ، وإلا سطرٌ عندَ اسمِ كلِّ صنفٍ معَ دفعةِ الإصلاحِ.
   * تُستَعمَلُ في مِرقاةِ {@link JavaCodeAnalyzer} (خيطُ التحليلِ وفي المُحرِّرِ معًا)، فلا نسخةَ ثانيةً
   * للقاعدةِ في الغلافِ.
   */
  public static List<Diagnostic> inspect(String source, JavaSyntaxTree.Unit unit,
      SupertypeFacts facts) {
    List<Gap> found = gaps(source, unit, facts);
    List<Declared> declared = declaredAbstract(source, unit);
    if (found.isEmpty() && declared.isEmpty()) return Collections.emptyList();
    int[] lineStarts = lineStarts(source);
    ArrayList<Diagnostic> out = new ArrayList<Diagnostic>(found.size() + declared.size());
    for (Gap gap : found) {
      // المرجعُ يُرسِلُ هذِهِ على إزاحةِ رمزٍ من عقدةِ الصنفِ لا على اسمِهِ (FileHighlightings
      // كلُّها إزاحاتٌ)، ورمزُها هُنَا قوسُ الجِسمِ — لأنَّهُ موضعُ الإصلاحِ نفسِهِ.
      int start = gap.anchorStart(source);
      int end = gap.anchorEnd(source, start);
      int lo = lineIndex(lineStarts, start);
      boolean hidden = gap.chainTruncated;
      String key = hidden ? TRUNCATED_MESSAGE_KEY : MESSAGE_KEY;
      Diagnostic d =
          Diagnostic.localized(start, end, lo + 1, start - lineStarts[lo] + 1,
              Diagnostic.Severity.ERROR, JavaDiagnosticCodes.codeOf(key), key,
              hidden
                  ? "This class must implement %1$d known abstract methods of %2$s (the rest of "
                      + "its inheritance chain is not visible here)"
                  : "This class must implement %1$d abstract methods of %2$s",
              new Object[] {Integer.valueOf(gap.count()), gap.ownerWritten});
      if (gap.isFixable()) d = d.withQuickFixes(Collections.singletonList(gap.fix()));
      out.add(d);
    }
    for (Declared hit : declared) {
      int lo = lineIndex(lineStarts, hit.keywordStart);
      out.add(Diagnostic.localized(hit.keywordStart, hit.keywordEnd, lo + 1,
          hit.keywordStart - lineStarts[lo] + 1, Diagnostic.Severity.ERROR,
          JavaDiagnosticCodes.codeOf(ABSTRACT_MESSAGE_KEY), ABSTRACT_MESSAGE_KEY,
          "This class must be declared as abstract because it declares the abstract method '%1$s'",
          new Object[] {hit.signature}).withQuickFixes(
              Collections.singletonList(hit.fix(source))));
    }
    Collections.sort(out, new java.util.Comparator<Diagnostic>() {
      @Override public int compare(Diagnostic a, Diagnostic b) { return a.offset - b.offset; }
    });
    return out;
  }

  /** صنفٌ مُعيِّنٌ يُعلنُ دالةً مجرَّدةً: تشخيصٌ عندَ كلمةِ الصنفِ، كواحدٍ من المرجعِ. */
  public static final class Declared {
    public final String className;
    /** توقيعٌ على شاكلةِ {@code getItem(int)} — حِجَجُ الرسالةِ المَكتوبةِ بينَ قوسينِ. */
    public final String signature;
    public final int keywordStart;
    public final int keywordEnd;
    public final int methodStart;

    Declared(String className, String signature, int keywordStart, int keywordEnd, int methodStart) {
      this.className = className == null ? "" : className;
      this.signature = signature == null ? "" : signature;
      this.keywordStart = keywordStart;
      this.keywordEnd = keywordEnd;
      this.methodStart = methodStart;
    }

    /** بصمةُ الكبتِ: الصنفُ ودالتُهُ، فلا رَجَّةَ معَ كلِّ ضغطةِ مفتاحٍ. */
    public String key() {
      return className + '#' + signature;
    }

    /** {@code insert 'abstract '} قبلَ كلمةِ الصنفِ — التسميةُ كما يبنيها المرجعُ بالضبطِ. */
    public QuickFix fix(String source) {
      return QuickFix.insertText(source, keywordStart, ABSTRACT_FIX_TEXT,
          "ui_quick_fix_insert_token", ABSTRACT_FIX_TEXT.trim());
    }
  }

  /**
   * مَرٌّ على الشجرةِ لا على نصٍّ: كلُّ {@code class} (وليس {@code enum}/{@code interface}) غيرِ
   * مُجرَّدٍ يُعلنُ {@code abstract} دالةً بلا جِسمٍ يَنالُ تشخيصَهُ. تُتجَّهُ interfacesَ عمدًا: كلُّ
   * دالةٍ فيها مُجرَّدةٌ ضمنيًّا، والمرجعُ لا يرميها هناك. ولا سقوفَ مُختَرَعةً: ما زادَ على
   * {@link #MAX_METHODS_PER_BATCH} صنفًا يُجعَلُ بلا قوائمَ، والسقفُ للواحدِ لا للمجموعةِ.
   */
  public static List<Declared> declaredAbstract(String source, JavaSyntaxTree.Unit unit) {
    if (source == null || source.isEmpty() || unit == null) return Collections.emptyList();
    ArrayList<Declared> out = new ArrayList<Declared>();
    for (JavaSyntaxTree.TypeDecl decl : unit.types) collectDeclared(decl, source, out);
    return out;
  }

  private static void collectDeclared(JavaSyntaxTree.TypeDecl decl, String source,
      List<Declared> out) {
    if (decl == null) return;
    if (!decl.anonymous && decl.kind == JavaSyntaxTree.CLASS
        && !decl.mods.has(JavaSyntaxTree.ABSTRACT)) {
      int keyword = keywordStart(source, decl);
      if (keyword >= 0) {
        int taken = 0;
        for (JavaSyntaxTree.Member member : decl.members) {
          if (!(member instanceof JavaSyntaxTree.MethodDecl)) continue;
          JavaSyntaxTree.MethodDecl method = (JavaSyntaxTree.MethodDecl) member;
          if (method.body != null || method.bodySkipped) continue;
          if (!method.mods.has(JavaSyntaxTree.ABSTRACT) || method.mods.has(JavaSyntaxTree.STATIC))
            continue;
          out.add(new Declared(decl.name, signatureOf(method), keyword, keyword + keywordLength(
              source, keyword), method.nameStart));
          if (++taken >= MAX_METHODS_PER_BATCH) break;
        }
      }
    }
    for (JavaSyntaxTree.Member member : decl.members)
      if (member instanceof JavaSyntaxTree.TypeDecl)
        collectDeclared((JavaSyntaxTree.TypeDecl) member, source, out);
  }

  /** {@code getItem(int, String)} كما يكتبُها المرجعُ بينَ قوسينِ، بأسماءٍ مَكتوبةٍ لا مُؤهَّلةٍ. */
  private static String signatureOf(JavaSyntaxTree.MethodDecl method) {
    StringBuilder out = new StringBuilder(method.name == null ? "" : method.name).append('(');
    for (int i = 0; i < method.params.size(); i++) {
      if (i > 0) out.append(", ");
      JavaSyntaxTree.VarDecl param = method.params.get(i);
      out.append(typeWritten(param == null ? null : param.type));
    }
    return out.append(')').toString();
  }

  private static String typeWritten(JavaSyntaxTree.TypeRef ref) {
    if (ref == null) return "Object";
    String base = ref.primitive != null ? ref.primitive : writtenName(ref);
    if (base == null || base.isEmpty()) base = "Object";
    StringBuilder out = new StringBuilder(base);
    for (int d = 0; d < ref.dims; d++) out.append("[]");
    return out.toString();
  }

  /** أوَّلُ حرفٍ من كلمةِ {@code class} إعلانِ الصنفِ، أو ‏{@code -1} إذا لم تُدرَكْ يقينًا. */
  private static int keywordStart(String source, JavaSyntaxTree.TypeDecl decl) {
    if (source == null || decl == null) return -1;
    int p = Math.max(0, Math.min(decl.nameStart, source.length()));
    while (p > 0) {
      int q = p - 1;
      while (q >= 0 && Character.isWhitespace(source.charAt(q))) q--;
      int end = q + 1;
      while (q >= 0 && (Character.isJavaIdentifierPart(source.charAt(q)) || source.charAt(q) == '@'))
        q--;
      int word = q + 1;
      if (word >= end) return -1;
      String tok = source.substring(word, end);
      if (tok.equals("class") || tok.equals("interface") || tok.equals("enum")) return word;
      if (!tok.equals("public") && !tok.equals("private") && !tok.equals("protected")
          && !tok.equals("static") && !tok.equals("final") && !tok.equals("strictfp")) return -1;
      p = word;
    }
    return -1;
  }

  private static int keywordLength(String source, int keyword) {
    int p = keyword;
    while (p < source.length() && Character.isJavaIdentifierPart(source.charAt(p))) p++;
    return Math.max(1, p - keyword);
  }

  /** الصنوفُ الناقصةُ؛ لا تُرتَّبُ ولا تُقطَعُ — مَرٌّ واحدٌ على الشجرةِ كما هي. */
  public static List<Gap> gaps(String source, JavaSyntaxTree.Unit unit, SupertypeFacts facts) {
    if (source == null || source.isEmpty() || unit == null || facts == null)
      return Collections.emptyList();
    List<String> imports = new ArrayList<String>();
    for (JavaSyntaxTree.Import im : unit.imports)
      if (im != null && !im.onDemand && im.name != null) imports.add(im.name);
    ArrayList<Gap> out = new ArrayList<Gap>();
    for (JavaSyntaxTree.TypeDecl decl : unit.types) collect(decl, unit, imports, facts, out);
    return out;
  }

  private static void collect(JavaSyntaxTree.TypeDecl decl, JavaSyntaxTree.Unit unit,
      List<String> imports, SupertypeFacts facts, List<Gap> out) {
    if (decl == null) return;
    if (!decl.anonymous && (decl.kind == JavaSyntaxTree.CLASS || decl.kind == JavaSyntaxTree.ENUM)
        && !decl.mods.has(JavaSyntaxTree.ABSTRACT)) {
      Gap gap = gapOf(decl, unit, imports, facts);
      if (gap != null) out.add(gap);
    }
    for (JavaSyntaxTree.Member member : decl.members)
      if (member instanceof JavaSyntaxTree.TypeDecl)
        collect((JavaSyntaxTree.TypeDecl) member, unit, imports, facts, out);
  }

  private static Gap gapOf(JavaSyntaxTree.TypeDecl decl, JavaSyntaxTree.Unit unit,
      List<String> imports, SupertypeFacts facts) {
    ArrayList<Required> wanted = new ArrayList<Required>();
    HashSet<String> seen = new HashSet<String>();
    List<JavaSyntaxTree.TypeRef> supers = new ArrayList<JavaSyntaxTree.TypeRef>();
    if (decl.superclass != null) supers.add(decl.superclass);
    supers.addAll(decl.interfaces);
    if (supers.isEmpty()) return null;
    String ownerWritten = "";
    HashSet<String> provided = new HashSet<String>();
    boolean truncated = false;
    for (JavaSyntaxTree.TypeRef ref : supers) {
      String qualified = resolve(ref, unit);
      if (qualified == null) return null; // أصلٌ لا يُعرَفُ: الصمتُ أصدقُ من الادّعاءِ
      if (facts.stateOf(qualified) == SupertypeState.TRUNCATED) truncated = true;
      List<Required> fromParent = facts.abstractMethodsOf(qualified);
      if (fromParent == null) return null; // حالةٌ مَسمّاةٌ: parent_unreadable، بلا تشخيصٍ
      Set<String> done = facts.implementedKeys(qualified);
      if (done == null) return null; // لا يُدرَى ما أَتَمَّ الأصلُ: الدفعةُ تَعِدُ ما لا يَنقُصُ
      if (!done.isEmpty()) provided.addAll(done);
      if (ownerWritten.isEmpty()) ownerWritten = writtenName(ref);
      for (Required r : fromParent) {
        if (r == null || r.suppliedByObject()) continue;
        if (provided.contains(r.key())) continue; // كَفَى بهِ الأصلُ أو سلفُهُ
        if (seen.add(r.key())) wanted.add(r);
      }
    }
    if (wanted.isEmpty()) return null;
    for (JavaSyntaxTree.Member member : decl.members) {
      if (!(member instanceof JavaSyntaxTree.MethodDecl)) continue;
      JavaSyntaxTree.MethodDecl method = (JavaSyntaxTree.MethodDecl) member;
      if (method.body == null && !method.bodySkipped) continue; // إعلانٌ مجرَّدٌ هنا لا يَكفِي
      wanted.removeAll(byKey(wanted, method.name, method.params.size()));
    }
    if (wanted.isEmpty()) return null;
    List<Required> missing = new ArrayList<Required>(wanted);
    Gap gap = new Gap(decl.name, ownerWritten, missing, decl.nameStart,
        decl.nameStart + Math.max(1, decl.name.length()), decl.bodyStart,
        missing.size() > MAX_METHODS_PER_BATCH ? OVER_BATCH_LIMIT : null);
    gap.chainTruncated = truncated;
    ArrayList<String> visible = new ArrayList<String>();
    for (JavaSyntaxTree.Import im : unit.imports)
      if (im != null && !im.onDemand && im.name != null) visible.add(im.name);
    gap.imports = Collections.unmodifiableList(visible);
    gap.ownPackage = unit.packageName == null ? "" : unit.packageName;
    gap.declaredHere = declaredTypeNames(unit);
    if (gap.isFixable() && gap.fix() == null)
      gap = new Gap(gap.className, gap.ownerWritten, gap.missing, gap.nameStart, gap.nameEnd,
          gap.braceStart, TYPES_UNRENDERABLE);
    return gap;
  }

  /**
   * أسطرُ الاستيرادِ الباقيةُ للدَّفعَةِ على نصٍّ حيٍّ (‏1.0.191): المُحرِّكُ قالَ «ماذا يَحتاجُ
   * المولودُ» حينَ كانَ كلُّ صنفٍ مَعلومًا، وههُنا يُسأَلُ «أفي الملفِّ سطرُهُ الآنَ؟» — فَيُطرَحُ ما وُجِدَ
   * مُستورَدًا (صرِيحًا أو ب‏`.*`‏ من باقِيَتِهِ) وما كانَ في ‏`java.lang`‏، ويَبقَى الباقي بأسطرِهِ
   * المُقيَّدةِ كما قالَها المُحرِّكُ: لا اسمَ مُخمَّنًا، ولا سطرًا مُكرَّرًا، ولا صفرًا زورًا.
   */
  public static List<String> pendingFetches(List<String> requested, List<String> fileImports) {
    if (requested == null || requested.isEmpty()) return Collections.emptyList();
    ArrayList<String> out = new ArrayList<String>(requested.size());
    for (String qualified : requested) {
      if (qualified == null || qualified.isEmpty()) continue;
      if (qualified.startsWith("java.lang.")) continue; // لا سطرَ لِمَا يَراهُ المُترجِمُ وحدَهُ
      if (containsImport(fileImports, qualified)) continue;
      if (out.contains(qualified)) continue; // سطرٌ واحدٌ لكلِّ صنفٍ، ولو ذَكَرَهُ مولودَانِ
      out.add(qualified);
    }
    return Collections.unmodifiableList(out);
  }

  /** سطرٌ صَريحٌ أو باقِيَةٌ ب‏`.*`‏: كلتاهُا تُغني عن سطرٍ ثانٍ — ولا يُقبَلُ نصٌّ يَشمَلُ الاسمَ سِرًّا. */
  private static boolean containsImport(List<String> imports, String qualified) {
    if (imports == null || imports.isEmpty()) return false;
    for (String imp : imports) {
      if (imp == null) continue;
      if (imp.equals(qualified)) return true;
      if (imp.endsWith(".*") && qualified.startsWith(imp.substring(0, imp.length() - 1))) return true;
    }
    return false;
  }

  private static List<Required> byKey(List<Required> values, String name, int arity) {
    ArrayList<Required> hit = new ArrayList<Required>(1);
    for (Required r : values)
      if (r.name.equals(name) && r.parameterTypes.size() == arity) hit.add(r);
    return hit;
  }

  /** الاسمُ المَكتوبُ كما في الأصلِ، مُؤهَّلًا إن استُوردَ أو كانَ في حِزمةِ الصنفِ. */
  private static String writtenName(JavaSyntaxTree.TypeRef ref) {
    String written = ref.qualified();
    return written == null || written.isEmpty() ? "" : written;
  }

  /**
   * الاسمُ المَكتوبُ ← اسمٌ مُؤهَّلٌ: استيرادٌ صريحٌ أوَّلًا، ثمَّ حِزمةُ الملفِّ، ثمَّ ما كُتِبَ
   * مُؤهَّلًا. ولا ثالثَ: لا بحثٌ بالاسمِ المَبسَّطِ في أصنافِ المشروعِ — ذاكَ بابُ التَخمينِ.
   */
  /**
   * هل صِنفُ المَشرُوعِ مُسَجَّلٌ بهذا الاسمِ المؤهَّلِ؟ لا {@code JavaProjectModel.knows} — ذلكَ
   * سِجلُّ مَراجِعِ المِلَفَّاتِ (مسارٌ من المُحرِّكِ)، فَيَسأَلُهُ اسمُ صنفٍ فلا يَجِدُهُ أبدًا. وقد
   * كانَ هذا سببَ صمتِ «صنفٌ يَرِثُ صِنفًا في حِزمَتِهِ بلا سطرِ استيرادٍ»: الأشهرُ في مشاريعِ
   * أندرويد، ولا تشخيصَ فيهِ ولا دفعةَ (جولةُ ٤٥).
   */
  private static boolean knownProjectClass(String qualified) {
    return qualified != null && JavaProjectModel.classByQualifiedName(qualified) != null;
  }

  private static String resolve(JavaSyntaxTree.TypeRef ref, JavaSyntaxTree.Unit unit) {
    if (ref == null || ref.primitive != null) return null;
    String written = ref.qualified();
    if (written == null || written.isEmpty()) return null;
    int dot = written.indexOf('.');
    if (dot < 0) {
      for (JavaSyntaxTree.Import im : unit.imports) {
        if (im == null || im.onDemand || im.name == null) continue;
        int last = im.name.lastIndexOf('.');
        if (last > 0 && im.name.substring(last + 1).equals(written)) return im.name;
      }
      String pkg = unit.packageName == null ? "" : unit.packageName;
      String sibling = pkg.isEmpty() ? written : pkg + "." + written;
      if (knownProjectClass(sibling)) return sibling;
      // ‏java.lang مُستورَدٌ ضِمنًا بحُكمِ اللُّغةِ: لا تَخمينَ فيهِ، والمُجيبُ يَسكُتُ عن غيرِ المَوجودِ.
      return PlatformMemberLookup.isPlatformName("java.lang." + written)
          ? "java.lang." + written
          : null;
    }
    String head = written.substring(0, dot);
    for (JavaSyntaxTree.Import im : unit.imports) {
      if (im == null || im.onDemand || im.name == null) continue;
      int last = im.name.lastIndexOf('.');
      if (last > 0 && im.name.substring(last + 1).equals(head))
        return im.name + "." + written.substring(dot + 1);
    }
    // «‏Base.Inner» في ملفِّ الحزمةِ ذاتِها ليسَ اسمًا مُؤَهَّلًا بعدُ: إن كانَ صِنفَ المشروعِ فلهُ باقةٌ
    if (!knownProjectClass(written)) {
      String pkg = unit.packageName == null ? "" : unit.packageName;
      String nested = pkg.isEmpty() ? written : pkg + "." + written;
      if (knownProjectClass(nested)) return nested;
    }
    return written;
  }

  /**
   * نوعٌ كما وُصِفَ في الأصلِ ← كما يَنبغِي أن يُكتَبَ في هذا الملفِّ، أو {@code null} إذا لم يَكُنْ
   * مَكتوبًا فيهِ ولا سبيلَ إلى كِتابتِهِ: فالإصلاحُ الذي يُورِثُ سطرَ استيرادٍ ناقصًا أسوأُ من لا
   * إصلاحٍ. المَحوُّ مَقصودٌ: {@code List<E>} يَخرُجُ {@code List}، وهو تَجاوُزٌ قانونيٌّ بتَحذيرِ
   * نوعٍ خامٍ لا بخطإِ بناءٍ.
   *
   * <p>‏1.0.189 (طلبُ «حَيْثُمَا كانَ الاستيرادُ ناقصًا فليُكتَبْ، مهما كانَ عدَدُها»): الصنفُ
   * المَعروفُ في باقةٍ لا يَحمِلُها الملفُّ لم يَعُدْ يُترَكُ مُقيَّدًا في جِسمِ الدالةِ ولا يُطرَدُ
   * بسببِهِ الإصلاحُ — بل يُكتَبُ اسمُهُ المَبسَّطُ ويُذكَرُ مُستَوردُهُ في {@code importsToFetch}
   * (قائمةُ مُخرَجٍ يَقرَأُها {@code QuickFix.planInsertion} فيُدخِلُها بالمَصبِّ الواحدِ
   * {@code JavaImportResolver}). ومَوضِعُ الحَسمِ هنا لا هُناكَ لأنَّ المَبسَّطَ والمُقيَّدَ قرارٌ
   * واحدٌ: إن بقِيَ مُقيَّدًا فلا داعيَ لسطرٍ، وإن مُبَّسَطةٌ فالسطرُ شَرطُ صِحَّتِهِ. {@code null}
   * في المُخرَجِ يَسأَلُ بلا عَمَلٍ (قارئٌ للعرضِ وحدَهُ)، والتعارضُ — اسمٌ مَبسَّطٌ عليهِ سطرٌ
   * يُفيدُ صنفًا آخَرَ — يُبقي المُقيَّدَ ولا يَكتُمُ عليهِ سطرًا كاذبًا.
   */
  public static String renderType(String described, List<String> imports,
      List<String> importsToFetch) {
    return renderType(described, imports, importsToFetch, null, null);
  }

  /**
   * نوعٌ كما وُصِفَ في الأصلِ ← كما يَنبغِي أن يُكتَبَ في هذا الملفِّ، أو {@code null} إذا لم يَكُنْ
   * مَكتوبًا فيهِ ولا سبيلَ إلى كِتابتِهِ: فالإصلاحُ الذي يُورِثُ سطرَ استيرادٍ ناقصًا أسوأُ من لا
   * إصلاحٍ. المَحوُّ مَقصودٌ: {@code List<E>} يَخرُجُ {@code List}، وهو تَجاوُزٌ قانونيٌّ بتَحذيرِ
   * نوعٍ خامٍ لا بخطإِ بناءٍ.
   *
   * <p>‏1.0.189 (طلبُ «حَيْثُمَا كانَ الاستيرادُ ناقصًا فليُكتَبْ، مهما كانَ عدَدُها»): الصنفُ
   * المَعروفُ في باقةٍ لا يَحمِلُها الملفُّ لم يَعُدْ يُترَكُ مُقيَّدًا في جِسمِ الدالةِ ولا يُطرَدُ بسببِهِ
   * الإصلاحُ — بل يُكتَبُ اسمُهُ المَبسَّطُ ويُذكَرُ مُستَوردُهُ في {@code importsToFetch} (قائمةُ
   * مُخرَجٍ يَقرَأُها {@code QuickFix.planInsertion} فيُدخِلُها بالمَصبِّ الواحدِ
   * {@code JavaImportResolver}). ومَوضِعُ الحَسمِ هنا لا هُناكَ لأنَّ المَبسَّطَ والمُقيَّدَ قرارٌ واحدٌ.
   *
   * <p>‏1.0.196 (قَيسَ «حَيثُ يَنبَغِي أن تُكتَبَ الدَّفعَةُ»): قَبلَ هذا كانَت أقواسُ المَصفوفِ تُطرَحُ
   * تَمهيدًا للحُكمِ ثُمَّ لا تُرَدُّ، فَكانَ {@code int[] counts()} يَخرُجُ {@code public int counts()}
   * — تَنفِيذًا لا يُترجَمُ، وقَولًا إنَّهُ نَجَحَ. الأقواسُ الآنَ عَددٌ مَحمُولٌ إلى الآخِرِ. وَمَعَهَا
   * حُكمُ الاسمِ صارَ مُتَسَلْسِلًا صَرِيحًا: استيرادُ الملفِّ أوَّلاً؛ ثُمَّ {@code java.lang} وحُكمُ
   * الظِّلِّ عليهِ (‏JLS 6.4.1‏: سطرُ استيرادٍ صَرِيحٌ يُظلِّلُ ما في حِزمَةِ الملفِّ وما في
   * {@code java.lang})؛ وصِنفُ حِزمَةِ الملفِّ نَفسِهِ يُكتَبُ مُبسَّطًا بلا سطرٍ؛ وصِنفُ المَشرُوعِ
   * الغَيرُ المُستورَدِ يُكتَبُ مُؤَهَّلًا — قَانُونِيٌّ بلا سطرٍ ولا استيرادٍ، ولا يُطرَدُ من أجلِهِ
   * الإصلاحُ كما كانَ؛ وما لا اسمَ لهُ عِندَنَا (مُتَغَيِّرُ نوعٍ، أو اسمٌ لم يَحُلَّهُ مُفسِّرُ
   * الأصلِ) يَبقَى مَرفُوضًا: نَصفُ صَفٍّ مِثلُ صِفرِهِ.
   */
  public static String renderType(String described, List<String> imports,
      List<String> importsToFetch, String ownPackage, Set<String> declaredHere) {
    String type = PlatformMemberLookup.stripGenerics(described);
    if (type == null || type.isEmpty()) return null;
    StringBuilder dims = new StringBuilder(); // «‏int[]» ← «‏int» + «‏[]»، لا «‏int» وَحدَهُ
    while (type.endsWith("[]")) {
      dims.append("[]");
      type = type.substring(0, type.length() - 2);
    }
    if (type.endsWith("...")) type = type.substring(0, type.length() - 3); // العَلمُ عِندَ Required
    String written = writeElement(type, imports, importsToFetch, ownPackage, declaredHere);
    return written == null ? null : written + dims;
  }

  /** حُكمُ الاسمِ الوَاحدِ (بِلا أقواسَ ولا أوسَاعًا): مَبسَّطٌ أم مُؤَهَّلٌ أم لا يُكتَبُ. */
  private static String writeElement(String type, List<String> imports, List<String> importsToFetch,
      String ownPackage, Set<String> declaredHere) {
    if (type.equals("void") || type.equals("boolean") || type.equals("byte") || type.equals("short")
        || type.equals("int") || type.equals("long") || type.equals("char") || type.equals("float")
        || type.equals("double"))
      return type;
    List<String> fileImports = imports == null ? Collections.<String>emptyList() : imports;
    int dot = type.indexOf('.');
    if (dot < 0) {
      for (String im : fileImports) {
        int last = im.lastIndexOf('.');
        if (last > 0 && im.substring(last + 1).equals(type)) return type;
      }
      // لا ثالثَ: اسمٌ مُجرَّدٌ لم يَحُمِلْهُ الملفُّ ليسَ عندَنَا ما يُثبِتُ باقَتَهُ، فَنَرفُضُهُ
      // ونَدَعُ الحَجزَ مَكتوبًا — بَعدَ أن كانَ يَحمِلُ كُلَّ «‏Object» في مِلَفِّ الأصلِ، صَارَ
      // يَحمِلُ ما لَم يَحُلَّهُ مُفسِّرُهُ فَقط (جولةُ ٤٥).
      return type.startsWith("java.lang.") ? type : null;
    }
    String head = type.substring(0, dot);
    if (head.equals("java") && type.startsWith("java.lang.")
        && type.indexOf('.', "java.lang.".length()) < 0) {
      String flat = type.substring("java.lang.".length());
      return shadowed(flat, type, fileImports, ownPackage, declaredHere) ? type : flat;
    }
    for (String im : fileImports) {
      if (im.equals(type)) return simple(type); // مُستورَدٌ بحدِّ ذاتِهِ: يُكتَبُ مَبسَّطًا كما ألفَهُ الملفُّ
      int last = im.lastIndexOf('.');
      if (last > 0 && im.substring(last + 1).equals(head)) return type; // تابعٌ لصنفٍ مُستورَدٍ
    }
    if (ownPackage != null && !ownPackage.isEmpty() && type.startsWith(ownPackage + ".")
        && type.indexOf('.', ownPackage.length() + 1) < 0 && knownProjectClass(type)
        && !shadowed(simple(type), type, fileImports, null, declaredHere))
      return simple(type); // صِنفُ حِزمَةِ هذا الملفِّ: مَبسَّطًا، ولا سطرَ يَلزَمُ
    // صِنفُ المَشرُوعِ يُحكَمُ قَبلَ فَهرَسِ المَنصَّةِ: «‏com» قَد تَكونُ باقَةً مَعرُوفَةً لِلأَصحَارِ،
    // فَيَظُنُّنَا التَقريرُ أنَّ «‏Holder.Inside» مَنصَّةِيَّةٌ نُبسِطُهَا وَنَجلِبُ سَطرَهَا، وَهيَ صِنفٌ
    // حِزمِيٌّ في مَشرُوعِ المُستَخدِمِ لا يُرى من وَراءِ حِزمَتِهِ — فَالحُكمُ عِندَ مَن يَملِكُ الاسمَ.
    if (knownProjectClass(type)) {
      if (!nameableFrom(type, ownPackage)) return null; // لا يَراهُ الوارثُ: لا سطرَ يُجدي
      String mine = simple(type);
      for (String im : fileImports) {
        int last = im.lastIndexOf('.');
        if (last > 0 && !im.equals(type) && im.substring(last + 1).equals(mine)) return type;
      }
      if (declaredHere != null && declaredHere.contains(mine)) return type;
      if (importsToFetch != null) importsToFetch.add(type);
      return mine; // صِنفُ المَشرُوعِ العامُّ كَغَيرِهِ: مَبسَّطٌ وَسَطرُهُ (جولةُ ٤٠)، وَالحُكمُ قَبلَهُ
    }
    if (!(AndroidApiIndex.isKnownPackage(head) || PlatformMemberLookup.isPlatformName(type)))
      return null;
    String flat = simple(type);
    for (String im : fileImports) {
      int last = im.lastIndexOf('.');
      // اسمٌ مَبسَّطٌ عليهِ سطرٌ يَحمِلُ صنفًا آخَرَ: التعارضُ يُبقي المُقيَّدَ كما هو.
      if (last > 0 && !im.equals(type) && im.substring(last + 1).equals(flat)) return type;
    }
    if (importsToFetch != null) importsToFetch.add(type);
    return flat;
  }

  /**
   * هل يَسَعُ الوارثَ أن يُسمِّي هذا الصنفَ المؤهَّلَ بأمنٍ؟ صِنفُ المشروعِ إن لم يكنْ {@code public}
   * — أو كانَ داخلَ صنفٍ ليسَ عامًا — فلا سبيلَ إليهِ من حزمةٍ أخرى، ولا يُجديهِ سطرُ استيرادٍ؛
   * وكتابتُهُ ثمَّ التهنئةُ بها يعني شيفرةً لا تُترجَم، وهو أشرُّ من صمتِنا (عهدُ جولةِ ٤٤).
   * فَنَرفُضُ ونَدَعُ الحَجزَ مكتوبًا: {@code types_unrenderable} يعني اليومَ «لا اسمَ لهُ عندَنَا»
   * لا «لا نَجرُؤُ على اسمٍ نَعرِفُهُ».
   */
  private static boolean nameableFrom(String qualified, String ownPackage) {
    if (qualified == null || qualified.isEmpty()) return false;
    if (ownPackage != null && !ownPackage.isEmpty() && qualified.startsWith(ownPackage + ".")
        && qualified.indexOf('.', ownPackage.length() + 1) < 0)
      return knownProjectClass(qualified); // صِنفُ حِزمَتِهِ: تَسَعُهُ ولو كانَ حِزمِيَّ الرُّؤيَةِ
    JavaTypeModel.ClassSymbol c = JavaProjectModel.classByQualifiedName(qualified);
    if (c == null) return false;
    if (!(c instanceof JavaTypeModel.SourceClass)) return true; // أصنافُ المَنصَّةِ عامَّةٌ بطَبعِها
    for (JavaTypeModel.ClassSymbol o = c; o instanceof JavaTypeModel.SourceClass; o = o.outer()) {
      JavaSyntaxTree.TypeDecl declared = ((JavaTypeModel.SourceClass) o).decl;
      if (declared == null || !declared.mods.has(JavaSyntaxTree.PUBLIC)) return false;
    }
    return true;
  }

  /** هل لِهَذَا الاسمِ المَبسَّطِ ظِلٌّ في هذا الملفِّ؟ (سِطرٌ يَحمِلُ غَيرَهُ، أو نَوعٌ هُنَا مُعلَنٌ) */
  private static boolean shadowed(String flat, String qualified, List<String> fileImports,
      String ownPackage, Set<String> declaredHere) {
    for (String im : fileImports) {
      int last = im.lastIndexOf('.');
      if (last > 0 && !im.equals(qualified) && im.substring(last + 1).equals(flat)) return true;
    }
    if (declaredHere != null && declaredHere.contains(flat)) return true;
    return ownPackage != null && !ownPackage.isEmpty()
        && knownProjectClass(ownPackage + "." + flat);
  }

  /** أسماءُ كُلِّ صنفٍ يَكتُبُهُ الملفُّ (مَتبُوطًا): الظِلُّ يَجري عَلَيها قَبلَ تَقرِيبِ اسمٍ. */
  private static Set<String> declaredTypeNames(JavaSyntaxTree.Unit unit) {
    HashSet<String> out = new HashSet<String>();
    for (JavaSyntaxTree.TypeDecl decl : unit.types) collectTypeNames(decl, out);
    return out;
  }

  private static void collectTypeNames(JavaSyntaxTree.TypeDecl decl, Set<String> into) {
    if (decl == null) return;
    if (decl.name != null && !decl.name.isEmpty()) into.add(decl.name);
    for (JavaSyntaxTree.Member member : decl.members)
      if (member instanceof JavaSyntaxTree.TypeDecl) collectTypeNames((JavaSyntaxTree.TypeDecl) member, into);
  }

  /**
   * نوعٌ كَمَا حَلَّهُ مُفسِّرُ مِلَفِّ الأصلِ ← وَصفٌ مُؤَهَّلٌ يَصِحُّ في أَيِّ مِلَفٍّ، أو
   * {@code null} إذَا لَم يَكُنِ المُعلِنُ صِنفَ مَصدَرٍ مَحمُولَ الشَّجرةِ، أو لَم يُحَلَّ الاسمُ.
   * وَالأَثرُ أن «‏{@code Object}» في مِلَفِّ الأصلِ تَحمِلُ باقَتَها إلى الوارثِ، فَيُكتَبُ
   * مَبسَّطًا حَيثُ أُمِنَ الظِّلُّ بدلَ أن يُحفَظَ الحَجزُ عَن دَفَعَةٍ كامِلَةٍ.
   */
  private static String described(JavaTypeModel.ClassSymbol owner, JavaSyntaxTree.TypeRef ref) {
    if (ref == null || !(owner instanceof JavaTypeModel.SourceClass)) return null;
    JavaTypeModel.Type t;
    try {
      t = ((JavaTypeModel.SourceClass) owner).resolve(ref, null);
    } catch (Throwable broken) {
      return null; // مُفسِّرٌ عَثَرَ: نَكتُبُ كَمَا كَتَبَ الأصلُ، ولا نَزيِدُ ادِّعاءً
    }
    return qualifiedOf(t, ref.varargs);
  }

  /** {@link JavaTypeModel.Type} ← اسمٌ يُكتَبُ بِلا سِيَاقٍ؛ {@code null} لِمَا لا اسمَ لَهُ هُنَاكَ. */
  private static String qualifiedOf(JavaTypeModel.Type t, boolean unwrapVarargs) {
    if (t == null || t == JavaTypeModel.UNKNOWN) return null;
    if (unwrapVarargs && t instanceof JavaTypeModel.ArrayType)
      return qualifiedOf(((JavaTypeModel.ArrayType) t).element, false);
    if (t instanceof JavaTypeModel.Primitive) return ((JavaTypeModel.Primitive) t).name;
    if (t instanceof JavaTypeModel.ArrayType) {
      String element = qualifiedOf(((JavaTypeModel.ArrayType) t).element, false);
      return element == null ? null : element + "[]";
    }
    if (t instanceof JavaTypeModel.ClassType) {
      JavaTypeModel.ClassSymbol symbol = ((JavaTypeModel.ClassType) t).symbol;
      if (symbol == null || symbol.isError()) return null;
      if (symbol instanceof JavaTypeModel.SourceClass) {
        JavaSyntaxTree.TypeDecl declared = ((JavaTypeModel.SourceClass) symbol).decl;
        // صِنفٌ مَحَلِّيٌّ أو جُهنُمٌ لا باقَةَ لَهُ: اسمُهُ لا يُكتَبُ خارجَ مِلَفِّهِ، فَلا نَدَّعِي
        if (declared == null || declared.anonymous || declared.local) return null;
      }
      String name = symbol.qualifiedName();
      return name == null || name.isEmpty() ? null : name;
    }
    return null; // مُتَغَيِّرُ نَوعٍ أو بَدَلٌ: لا يَخرُجُ من لِسانِ مُعلِنِهِ إلى الوارثِ
  }


  private static String simple(String qualified) {
    int dot = qualified.lastIndexOf('.');
    return dot < 0 ? qualified : qualified.substring(dot + 1);
  }

  /**
   * الإعلامُ الفوريُّ عندَ رَدِّ المُحلِّلِ: {@code null} إن كانَ مَقولًا قبلَ هذا — الكبتُ قرارُ
   * الطبقةِ الصافيةِ لا ذاكرةُ غلافٍ، فيُثبَّتُ في البوّابةِ بلا شاشةٍ.
   */
  public static Announcement announcementFor(Gap gap, String announcedFingerprint) {
    if (gap == null) return null;
    String fingerprint = gap.key();
    if (fingerprint.equals(announcedFingerprint)) return null;
    return new Announcement(gap.count() == 1 ? TOAST_ONE_KEY : TOAST_MANY_KEY,
        gap.missing.get(0).written(), gap.count(), fingerprint);
  }

  /** أوّلُ ناقصٍ بصيغةِ الملحقِ، للسطرِ في اللوحةِ وحدَها عندَ الحاجةِ. */
  public static String firstWritten(Gap gap) {
    return gap == null || gap.missing.isEmpty() ? "" : gap.missing.get(0).written();
  }

  /**
   * الإعلامُ عندَ رَدِّ المُحلِّلِ من نصِّ الملفِّ نفسِهِ: {@code null} حينَ لا صِنفَ ناقِصَ، أو حينَ كانَ
   * مَقولًا في هذا الملفِّ بنفسِ البصمةِ (كبتُ الرَّجَّةِ قرارُ الطبقةِ، لا ذاكرةُ غلافٍ). يُدعى فقط إذا
   * كانَ في الرَّدِّ تشخيصٌ بمفتاحِنا — فلا مَرَّ ثانٍ على الشجرةِ لكلِّ ضغطةِ مفتاحٍ.
   */
  public static Announcement announcement(String source, String fingerprintSoFar) {
    if (source == null || source.isEmpty()) return null;
    try {
      JavaSyntaxTree.Unit unit = JavaParser.parse(source);
      if (!unit.errorRanges.isEmpty()) return null;
      for (Gap gap : gaps(source, unit, RUNTIME)) {
        Announcement note = announcementFor(gap, fingerprintSoFar);
        if (note != null) return note;
      }
      // لا ناقِصَ موروثًا: قد يبقى طلبُ «اجعلِ الصنفَ مُجرَّدًا»، ورسالتُهُ نصُّ المرجعِ حرفيًا.
      String signature = "";
      String fingerprint = "";
      for (Declared hit : declaredAbstract(source, unit)) {
        String candidate = declaredFingerprint(hit.className, hit.signature);
        if (candidate.equals(fingerprintSoFar)) return null;
        signature = hit.signature;
        fingerprint = candidate;
        break;
      }
      if (!fingerprint.isEmpty())
        return new Announcement(ABSTRACT_MESSAGE_KEY, signature, 1, fingerprint);
    } catch (Throwable ignored) {
      // لا «توستَ» يَسقُطُ بالمُحرِّرِ: الإعلامُ زينةُ الخبرِ لا خبرُهُ
    }
    return null;
  }

  /** هل يستحقُّ الرَّدُّ أن نَعودَ إلى الشجرةِ لأجلِ الإعلامِ؟ (سطرٌ واحدٌ في اللوحةِ، صِفرُ قَرنٍ) */
  public static boolean hasGapDiagnostic(List<Diagnostic> found) {
    if (found == null) return false;
    for (Diagnostic d : found)
      if (d != null && (MESSAGE_KEY.equals(d.messageKey) || ABSTRACT_MESSAGE_KEY.equals(d.messageKey)))
        return true;
    return false;
  }

  /** بصمةُ الأخوِ تُحفَظُ في الحقلِ نفسِهِ: صنفٌ واحدٌ لا لوحتا حالةٍ. */
  private static String declaredFingerprint(String className, String signature) {
    return "declared:" + className + '#' + signature;
  }

  // ───────────────────────── مَواضِعُ الأسطُرِ (كإجراءِ المُسنِدِ) ─────────────────────────

  private static int[] lineStarts(String source) {
    ArrayList<Integer> starts = new ArrayList<Integer>();
    starts.add(0);
    for (int i = 0; i < source.length(); i++)
      if (source.charAt(i) == '\n') starts.add(i + 1);
    int[] out = new int[starts.size()];
    for (int i = 0; i < out.length; i++) out[i] = starts.get(i);
    return out;
  }

  private static int lineIndex(int[] lineStarts, int offset) {
    int lo = 0;
    int hi = lineStarts.length - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (lineStarts[mid] <= offset) lo = mid;
      else hi = mid - 1;
    }
    return lo;
  }
}
