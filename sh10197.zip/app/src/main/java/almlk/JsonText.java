package almlk;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * محلّل JSON صارم صغير: كائنات بترتيب مفاتيحها ({@link LinkedHashMap})، ومصفوفات، ونصوص، وأرقام
 * تحفظ نصها الأصلي ({@link Number})، وBoolean، و{@link #NULL}. الخطأ {@link SyntaxError} بموضعه.
 */
public final class JsonText {

  private JsonText() {}

  /** قيمة null في JSON (تمييزًا لها عن غياب القيمة). */
  public static final Object NULL =
      new Object() {
        @Override
        public String toString() {
          return "null";
        }
      };

  /** رقم بنصه الأصلي كما ورد. */
  public static final class Number {
    public final String text;

    Number(String text) {
      this.text = text;
    }

    public boolean isInteger() {
      return text.indexOf('.') < 0 && text.indexOf('e') < 0 && text.indexOf('E') < 0;
    }

    /** عدد صحيح يسعه int. */
    public boolean fitsInt() {
      if (!isInteger()) return false;
      try {
        Integer.parseInt(text);
        return true;
      } catch (NumberFormatException overflow) {
        return false;
      }
    }

    @Override
    public String toString() {
      return text;
    }
  }

  /** خطأ صياغة بموضعه (فهرس المحرف، والسطر والعمود من 1). */
  public static final class SyntaxError extends Exception {
    public final int offset, line, column;

    SyntaxError(String message, String text, int offset) {
      super(message + " (" + lineOf(text, offset) + ":" + columnOf(text, offset) + ")");
      this.offset = offset;
      this.line = lineOf(text, offset);
      this.column = columnOf(text, offset);
    }

    private static int lineOf(String text, int offset) {
      int line = 1;
      for (int i = 0; i < Math.min(offset, text.length()); i++) if (text.charAt(i) == '\n') line++;
      return line;
    }

    private static int columnOf(String text, int offset) {
      int start = text.lastIndexOf('\n', Math.max(0, Math.min(offset, text.length()) - 1)) + 1;
      return Math.max(1, offset - start + 1);
    }
  }

  private static final int MAX_DEPTH = 512;

  public static Object parse(String text) throws SyntaxError {
    if (text == null) throw new SyntaxError("Empty input", "", 0);
    Parser p = new Parser(text);
    p.skipSpace();
    if (p.at >= text.length()) throw new SyntaxError("Empty input", text, p.at);
    Object value = p.value(0);
    p.skipSpace();
    if (p.at < text.length()) throw new SyntaxError("Unexpected character '" + text.charAt(p.at) + "'", text, p.at);
    return value;
  }

  /** تنسيق بإزاحة. */
  public static String pretty(String text, int indent) throws SyntaxError {
    StringBuilder out = new StringBuilder(text.length() * 2);
    write(parse(text), out, Math.max(0, indent), 0);
    return out.toString();
  }

  /** ضغط بلا مسافات. */
  public static String compact(String text) throws SyntaxError {
    StringBuilder out = new StringBuilder(text.length());
    write(parse(text), out, -1, 0);
    return out.toString();
  }

  /** كتابة قيمة: indent &lt; 0 مضغوط. */
  public static void write(Object value, StringBuilder out, int indent, int depth) {
    if (value instanceof Map) {
      Map<?, ?> map = (Map<?, ?>) value;
      if (map.isEmpty()) {
        out.append("{}");
        return;
      }
      out.append('{');
      boolean first = true;
      for (Map.Entry<?, ?> e : map.entrySet()) {
        if (!first) out.append(',');
        first = false;
        newline(out, indent, depth + 1);
        quote(String.valueOf(e.getKey()), out);
        out.append(indent < 0 ? ":" : ": ");
        write(e.getValue(), out, indent, depth + 1);
      }
      newline(out, indent, depth);
      out.append('}');
    } else if (value instanceof List) {
      List<?> list = (List<?>) value;
      if (list.isEmpty()) {
        out.append("[]");
        return;
      }
      out.append('[');
      for (int i = 0; i < list.size(); i++) {
        if (i > 0) out.append(',');
        newline(out, indent, depth + 1);
        write(list.get(i), out, indent, depth + 1);
      }
      newline(out, indent, depth);
      out.append(']');
    } else if (value instanceof String) {
      quote((String) value, out);
    } else {
      out.append(String.valueOf(value));
    }
  }

  private static void newline(StringBuilder out, int indent, int depth) {
    if (indent < 0) return;
    out.append('\n');
    for (int i = 0; i < indent * depth; i++) out.append(' ');
  }

  public static void quote(String s, StringBuilder out) {
    out.append('"');
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      switch (c) {
        case '"': out.append("\\\""); break;
        case '\\': out.append("\\\\"); break;
        case '\n': out.append("\\n"); break;
        case '\r': out.append("\\r"); break;
        case '\t': out.append("\\t"); break;
        case '\b': out.append("\\b"); break;
        case '\f': out.append("\\f"); break;
        default:
          if (c < 0x20) out.append(String.format("\\u%04x", (int) c));
          else out.append(c);
      }
    }
    out.append('"');
  }

  private static final class Parser {
    final String s;
    int at;

    Parser(String s) {
      this.s = s;
    }

    void skipSpace() {
      while (at < s.length()) {
        char c = s.charAt(at);
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\uFEFF') at++;
        else break;
      }
    }

    SyntaxError error(String message) {
      return new SyntaxError(message, s, at);
    }

    Object value(int depth) throws SyntaxError {
      if (depth > MAX_DEPTH) throw error("Nesting too deep");
      skipSpace();
      if (at >= s.length()) throw error("Unexpected end of input");
      char c = s.charAt(at);
      switch (c) {
        case '{': return object(depth);
        case '[': return array(depth);
        case '"': return string();
        case 't': return literal("true", Boolean.TRUE);
        case 'f': return literal("false", Boolean.FALSE);
        case 'n': return literal("null", NULL);
        default:
          if (c == '-' || (c >= '0' && c <= '9')) return number();
          throw error("Unexpected character '" + c + "'");
      }
    }

    Object literal(String word, Object value) throws SyntaxError {
      if (!s.startsWith(word, at)) throw error("Invalid literal");
      at += word.length();
      return value;
    }

    Map<String, Object> object(int depth) throws SyntaxError {
      LinkedHashMap<String, Object> map = new LinkedHashMap<>();
      at++;
      skipSpace();
      if (at < s.length() && s.charAt(at) == '}') {
        at++;
        return map;
      }
      while (true) {
        skipSpace();
        if (at >= s.length() || s.charAt(at) != '"') throw error("Expected a quoted key");
        String key = string();
        skipSpace();
        if (at >= s.length() || s.charAt(at) != ':') throw error("Expected ':'");
        at++;
        map.put(key, value(depth + 1));
        skipSpace();
        if (at >= s.length()) throw error("Unterminated object");
        char c = s.charAt(at++);
        if (c == '}') return map;
        if (c != ',') {
          at--;
          throw error("Expected ',' or '}'");
        }
      }
    }

    List<Object> array(int depth) throws SyntaxError {
      ArrayList<Object> list = new ArrayList<>();
      at++;
      skipSpace();
      if (at < s.length() && s.charAt(at) == ']') {
        at++;
        return list;
      }
      while (true) {
        list.add(value(depth + 1));
        skipSpace();
        if (at >= s.length()) throw error("Unterminated array");
        char c = s.charAt(at++);
        if (c == ']') return list;
        if (c != ',') {
          at--;
          throw error("Expected ',' or ']'");
        }
      }
    }

    String string() throws SyntaxError {
      at++;
      StringBuilder out = new StringBuilder();
      while (true) {
        if (at >= s.length()) throw error("Unterminated string");
        char c = s.charAt(at++);
        if (c == '"') return out.toString();
        if (c < 0x20) {
          at--;
          throw error("Control character in string");
        }
        if (c != '\\') {
          out.append(c);
          continue;
        }
        if (at >= s.length()) throw error("Unterminated escape");
        char e = s.charAt(at++);
        switch (e) {
          case '"': out.append('"'); break;
          case '\\': out.append('\\'); break;
          case '/': out.append('/'); break;
          case 'b': out.append('\b'); break;
          case 'f': out.append('\f'); break;
          case 'n': out.append('\n'); break;
          case 'r': out.append('\r'); break;
          case 't': out.append('\t'); break;
          case 'u':
            if (at + 4 > s.length()) throw error("Invalid unicode escape");
            int code = 0;
            for (int i = 0; i < 4; i++) {
              int d = Character.digit(s.charAt(at + i), 16);
              if (d < 0) throw error("Invalid unicode escape");
              code = code * 16 + d;
            }
            at += 4;
            out.append((char) code);
            break;
          default:
            at--;
            throw error("Invalid escape '\\" + e + "'");
        }
      }
    }

    Number number() throws SyntaxError {
      int start = at;
      if (s.charAt(at) == '-') at++;
      if (at >= s.length()) throw error("Invalid number");
      if (s.charAt(at) == '0') at++;
      else if (s.charAt(at) >= '1' && s.charAt(at) <= '9') digits();
      else throw error("Invalid number");
      if (at < s.length() && s.charAt(at) == '.') {
        at++;
        if (at >= s.length() || !isAsciiDigit(s.charAt(at))) throw error("Invalid number");
        digits();
      }
      if (at < s.length() && (s.charAt(at) == 'e' || s.charAt(at) == 'E')) {
        at++;
        if (at < s.length() && (s.charAt(at) == '+' || s.charAt(at) == '-')) at++;
        if (at >= s.length() || !isAsciiDigit(s.charAt(at))) throw error("Invalid number");
        digits();
      }
      return new Number(s.substring(start, at));
    }

    static boolean isAsciiDigit(char c) {
      return c >= '0' && c <= '9';
    }

    void digits() {
      while (at < s.length() && s.charAt(at) >= '0' && s.charAt(at) <= '9') at++;
    }
  }
}
