package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * مصدرُ الإصداراتِ الواحدُ: اتحادُ ما في المخبأِ، ثمَّ ما في المستودعاتِ المحليّةِ، ثمَّ ما تُجيبُ بهِ
 * المستودعاتُ عن {@code maven-metadata.xml} — بصيغةِ {@link MavenResolver.Fetcher} نفسِها (W22/ب1).
 *
 * <p><b>لماذا صنفٌ مستقلٌّ:</b> كانَ الجلبُ موجودًا لكنَّهُ <em>خاصٌّ بمحركِ الحلِّ</em>
 * ({@code MavenResolver.availableVersions})، فلا سبيلَ إلى أن يسألَ المستخدمُ «ما الإصداراتُ؟» قبلَ أن
 * يكتبَ السطرَ — وهذا جوهرُ طلبِ المرحلةِ (ب). الصنفُ صافٍ: لا {@code android.*}، ولا {@code HttpURLConnection}
 * فيهِ (النقلُ محقَنٌ)، فيُختبَرُ على المضيفِ بناقلٍ وهميٍّ على قرصٍ حقيقيٍّ مُؤقَّتٍ — لا بمحاكاةِ المنطقِ.
 *
 * <p><b>سياسةُ الاحتياطيّةِ كالتي في المحلِّلِ:</b> مستودعٌ مُعلَنٌ في المشروعِ يُسأَلُ دائمًا؛ والمستودعاتُ
 * المضمَنةُ احتياطًا (google/central/jcenter/jitpack) لا تُبرَحُ إلا إن لم يجدْ أحدٌ قبلَها شيئًا، أو كانَ
 * تخصُّصُها يطابقُ المجموعةَ — فلا شبكةَ بلا طائلِ لكلِّ بحثٍ، ولا اختلافَ عمّا سيحدُثُ عندَ البناءِ.
 */
public final class MavenVersionSource {

  /** إلغاءٌ اختياريٌّ: يُستَعمَلُ في الواجهةِ لإسقاطِ طلبٍ سابقٍ عندَ كلِّ ضغطةِ مفتاحٍ. */
  public interface Cancel {
    boolean cancelled();
  }

  public static final Cancel NEVER =
      new Cancel() {
        @Override
        public boolean cancelled() {
          return false;
        }
      };

  /** نتيجةٌ واحدةٌ لا تحتاجُ تفسيرًا: قائمةٌ مرتَّبةٌ، وأحدثُها، وأصدقُ وصفٍ لمصدرِها. */
  public static final class Result {
    public final List<String> versions;
    /** أحدثُ معلَنٍ (قد يكونُ snapshot)، أو "". */
    public final String newest;
    /** {@code <release>} أو آخرُ مستقرٍّ ترتيبًا، أو "". */
    public final String newestStable;
    /** جاءَ شيءٌ من قرصٍ فقط، فلم تجرِ شبكةٌ أصلًا. */
    public final boolean fromCache;
    /** جُرِّبَ مستودعٌ واحدٌ على الأقلُّ (نجاحًا أو فشلًا). */
    public final boolean asked;
    /** عناوينُ لم تُجبْ أو أجابتْ بغيرِ metadata — تُعرَضُ كي لا تُنسَبَ القائمةُ للنقلِ. */
    public final List<String> failedRepos;
    public final boolean cancelled;

    Result(
        List<String> versions, String newest, String newestStable, boolean fromCache, boolean asked,
        List<String> failedRepos, boolean cancelled) {
      this.versions = Collections.unmodifiableList(versions);
      this.newest = newest;
      this.newestStable = newestStable;
      this.fromCache = fromCache;
      this.asked = asked;
      this.failedRepos = Collections.unmodifiableList(failedRepos);
      this.cancelled = cancelled;
    }

    public boolean isEmpty() {
      return versions.isEmpty();
    }

    @Override
    public String toString() {
      return "versions=" + versions + " newest=" + newest + " stable=" + newestStable
          + " cache=" + fromCache + " asked=" + asked + " failed=" + failedRepos + " cancelled=" + cancelled;
    }
  }

  private MavenVersionSource() {}

  /** النقلُ لا يحتاجُ نسبةً هنا: القرصُ صغيرٌ والحوارُ يُظهرُ حالةً لا شريطًا. */
  private static final MavenResolver.Progress SILENT =
      new MavenResolver.Progress() {
        @Override
        public void bytes(long done, long total) {}

        @Override
        public boolean cancelled() {
          return false;
        }
      };

  /**
   * @param cacheDir مجلدُ الأداةِ في مخزنِ التطبيقِ (يُقرَأُ ويُكتَبُ فيهِ {@code maven-metadata-*.xml})
   * @param localRoots جذورُ المستودعاتِ المحليّةِ للقراءةِ (مخزنُ المستخدمِ و{@code user_m2repositories})
   * @param repos مستودعاتٌ كما يبنيها {@link MavenResolver#repositories} — تُسأَلُ بترتيبِها
   * @param fetcher النقلُ (في التطبيقِ {@link MavenDownloader}، وفي الاختبارِ ناقلٌ وهميٌّ)
   * @param forceRefresh true عندَ «تحديثِ الفهارسِ»: يُعادُ الجلبُ ولو وُجِدَ المخبأُ
   */
  public static Result load(
      String group,
      String artifact,
      File cacheDir,
      List<File> localRoots,
      List<MavenResolver.Repo> repos,
      MavenResolver.Fetcher fetcher,
      boolean forceRefresh,
      Cancel cancel) {
    Cancel guard = cancel == null ? NEVER : cancel;
    Set<String> versions = new LinkedHashSet<String>();
    String release = "";
    String latest = "";
    boolean localFound = false;
    String relative = (group == null ? "" : group.replace('.', '/')) + "/" + (artifact == null ? "" : artifact);

    if (cacheDir != null && cacheDir.isDirectory()) {
      MavenMetadata meta = firstMetadata(cacheDir);
      if (!meta.isEmpty()) {
        versions.addAll(meta.versions);
        localFound = true;
        if (meta.release.isEmpty() && !meta.latest.isEmpty()) latest = meta.latest;
      }
      List<String> published = publishedVersionDirs(cacheDir, artifact);
      if (!published.isEmpty()) {
        versions.addAll(published);
        localFound = true;
      }
    }
    if (localRoots != null) {
      for (File root : localRoots) {
        if (guard.cancelled()) return finish(versions, latest, release, true, false, Collections.<String>emptyList(), true);
        File dir = new File(root, relative);
        if (!dir.isDirectory()) continue;
        MavenMetadata meta = firstMetadata(dir);
        if (!meta.isEmpty()) {
          versions.addAll(meta.versions);
          localFound = true;
          if (release.isEmpty()) release = meta.release;
          if (latest.isEmpty()) latest = meta.latest;
        }
        versions.addAll(publishedVersionDirs(dir, artifact));
      }
    }

    List<String> failed = new ArrayList<String>();
    boolean asked = false;
    boolean fetched = false;
    boolean remoteFound = false;
    if (fetcher != null && repos != null) {
      for (MavenResolver.Repo repo : repos) {
        if (guard.cancelled()) return finish(versions, latest, release, localFound && !asked, asked, failed, true);
        if (repo == null || repo.url == null) continue;
        boolean special = isSpecialFor(repo, group);
        if (repo.fallback && (remoteFound || localFound) && !special) continue;
        asked = true;
        File target = new File(cacheDir == null ? new File(System.getProperty("java.io.tmpdir")) : cacheDir,
            MavenMetadata.cacheFileName(repo.url));
        if (!forceRefresh && target.isFile()) {
          MavenMetadata meta = MavenMetadata.read(target);
          if (!meta.isEmpty()) {
            versions.addAll(meta.versions);
            remoteFound = true;
            if (release.isEmpty()) release = meta.release;
            if (latest.isEmpty()) latest = meta.latest;
          }
          continue;
        }
        File parent = target.getParentFile();
        if (parent != null && !parent.isDirectory()) parent.mkdirs();
        try {
          if (fetcher.fetch(repo.url + relative + "/maven-metadata.xml", target, false, SILENT)) {
            MavenMetadata meta = MavenMetadata.read(target);
            if (meta.isEmpty()) {
              // ناقلٌ كتبَ صفحةَ خطأٍ برمزِ 200: لا تُصدَّقُ ولا تُترَكُ في المخبأِ.
              target.delete();
              failed.add(repo.name == null ? repo.url : repo.name);
            } else {
              versions.addAll(meta.versions);
              remoteFound = true;
              fetched = true;
              if (release.isEmpty()) release = meta.release;
              if (latest.isEmpty()) latest = meta.latest;
            }
          }
        } catch (Exception network) {
          failed.add(repo.name == null ? repo.url : repo.name);
        }
      }
    }
    return finish(versions, latest, release, localFound && !fetched, asked, failed, false);
  }

  /** نسخةُ ما في المخبأِ فقط، بلا شبكةٍ ولا قرصٍ خارجَهُ — لفحصِ «هل كلُّ شيءٍ هنا؟» السريعِ. */
  public static Result fromStore(String group, String artifact, File cacheDir, List<File> localRoots) {
    return load(group, artifact, cacheDir, localRoots, Collections.<MavenResolver.Repo>emptyList(), null, false, NEVER);
  }

  // ═══════════════ داخلِيّاتٌ ═════════════════

  private static Result finish(
      Set<String> versions, String latest, String release, boolean fromCache, boolean asked,
      List<String> failed, boolean cancelled) {
    List<String> sorted = new ArrayList<String>(versions);
    Collections.sort(
        sorted,
        new java.util.Comparator<String>() {
          @Override
          public int compare(String a, String b) {
            return MavenVersion.compare(a, b);
          }
        });
    String newest = sorted.isEmpty() ? "" : sorted.get(sorted.size() - 1);
    String stable = release != null && !release.isEmpty() && sorted.contains(release) ? release : "";
    if (stable.isEmpty()) {
      for (String version : sorted) if (MavenVersion.isStable(version)) stable = version;
    }
    if (newest.isEmpty() && latest != null && !latest.isEmpty()) newest = latest;
    return new Result(sorted, newest, stable, fromCache, asked, failed, cancelled);
  }

  /** metadata الأقدمِ حضورًا في المجلدِ: ملفُّ google الرسميُّ لا يُزاحَمُ بنسخٍ جانبيّةٍ. */
  private static MavenMetadata firstMetadata(File dir) {
    File[] children = dir.listFiles();
    if (children == null) return MavenMetadata.EMPTY;
    java.util.Arrays.sort(children, BY_NAME);
    for (File child : children) {
      if (child.isFile() && child.getName().startsWith("maven-metadata") && child.getName().endsWith(".xml")) {
        MavenMetadata meta = MavenMetadata.read(child);
        if (!meta.isEmpty()) return meta;
      }
    }
    return MavenMetadata.EMPTY;
  }

  private static final java.util.Comparator<File> BY_NAME =
      new java.util.Comparator<File>() {
        @Override
        public int compare(File a, File b) {
          // ما بلا بادئةٍ (ملفُّ google نفسُهُ) أوَّلًا، ثمَّ اسميًّا
          String x = a.getName(), y = b.getName();
          boolean xp = x.equals("maven-metadata.xml"), yp = y.equals("maven-metadata.xml");
          if (xp != yp) return xp ? -1 : 1;
          return x.compareTo(y);
        }
      };

  /** إصداراتٌ مثبتةٌ على القرصِ بمجرَّدِ وجودِ pom بجانبِها (مخزّناتٌ بلا metadata). */
  private static List<String> publishedVersionDirs(File artifactDir, String artifact) {
    List<String> out = new ArrayList<String>();
    File[] children = artifactDir.listFiles();
    if (children == null) return out;
    for (File child : children) {
      if (!child.isDirectory()) continue;
      if (artifact != null && new File(child, artifact + "-" + child.getName() + ".pom").isFile()) {
        out.add(child.getName());
      }
    }
    return out;
  }

  /** تخصُّصُ المستودعِ: ج gugle للمجموعاتِ التي يعرفُها، وJitPack لمصادرِ git، وCentral لغيرِ ذلكَ. */
  private static boolean isSpecialFor(MavenResolver.Repo repo, String group) {
    String url = MavenResolver.canonicalUrl(repo.url);
    if (url.equals("https://dl.google.com/dl/android/maven2")) return MavenResolver.isGoogleGroup(group);
    if (url.equals("https://jitpack.io")) return MavenResolver.isGitGroup(group);
    if (url.equals("https://repo.maven.apache.org/maven2")) return !MavenResolver.isGoogleGroup(group)
        && !MavenResolver.isGitGroup(group);
    return true;
  }
}
