package almlk;

import com.almlkid.kay.ui.ProjectSymbolIndex;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * قاعدة واحدة لاستيرادات جافا: ما هو مغطّى فعلًا، وأين يوضع سطر {@code import}، ومتى يُعرض صفّا
 * «Fix imports» و{@code Add 'import …'} في قائمة الإصلاح (W5).
 *
 * <p>كل الفحوص تُقرأ على النص **بعد طمس التعليقات والنصوص** بـ{@link QuickFix#mask} — فسطر معطَّل
 * بـ{@code //} لا يُعدّ استيرادًا (وهو بعينه ما كان يترك ملفًا استيرادُه معلَّق فيُبلَّغ عنه عشرة
 * أخطاء بلا مَخرج)، و{@code "import x;"} داخل نصّ حرفي لا يُعدّ هو الآخر. القاعدة نفسها يستعملها
 * المحرر عند قبول اقتراح، فلا قاعدة إدراج ثانية موازية لها.
 *
 * <p>الأصناف الصرفة: لا {@code android.*} هنا، فيُغطّى الإدراج والتصنيف باختبارات {@code qa} على
 * الكلاس المُصرَّف لا بفحص نصوص.
 */
public final class JavaImportResolver {

  private JavaImportResolver() {}

  /** حزمة الملف من سطر {@code package} فعلي (خارج التعليقات)، أو {@code ""} عند غيابها. */
  public static String currentPackage(String source) {
    if (source == null || source.isEmpty()) return "";
    String code = QuickFix.mask(source);
    int at = keywordAt(code, "package", 0);
    if (at < 0) return "";
    int i = at + "package".length();
    while (i < code.length() && Character.isWhitespace(code.charAt(i))) i++;
    int start = i;
    while (i < code.length()
        && (Character.isJavaIdentifierPart(code.charAt(i)) || code.charAt(i) == '.')) i++;
    if (i == start) return "";
    // سطر package لا يكون إلا قبل أول إعلان صنف؛ وإلا كان نصًا في موضع غريب فلا يُوثق به.
    int firstType = code.indexOf('{');
    if (firstType >= 0 && i > firstType) return "";
    return code.substring(start, i);
  }

  /** {@code import a.b.C;} أو {@code import a.b.*;} قائم فعلًا (ولا يُحسب المعلَّق). */
  public static boolean alreadyCovered(String source, String qualifiedName) {
    if (source == null || qualifiedName == null || qualifiedName.isEmpty()) return false;
    int dot = qualifiedName.lastIndexOf('.');
    if (dot <= 0) return false;
    String simple = qualifiedName.substring(dot + 1);
    for (String imported : importStatements(source)) {
      if (imported.equals(qualifiedName)) return true;
      if (imported.endsWith(".*")
          && qualifiedName.startsWith(imported.substring(0, imported.length() - 1))) {
        return true;
      }
      // استيراد صنف آخر بنفس الاسم البسيط يمنع إضافة ثانٍ بنفس الاسم.
      if (!imported.equals(qualifiedName)
          && imported.substring(imported.lastIndexOf('.') + 1).equals(simple)) {
        return true;
      }
    }
    return false;
  }

  /** هل يلزم استيراد {@code qualifiedName} أصلًا؟ (لا {@code java.lang}، ولا حزمة الملف نفسه). */
  public static boolean needsImport(String source, String qualifiedName) {
    if (source == null || qualifiedName == null || qualifiedName.isEmpty()) return false;
    int dot = qualifiedName.lastIndexOf('.');
    if (dot <= 0) return false;
    String pkg = qualifiedName.substring(0, dot);
    if (pkg.equals("java.lang") || pkg.equals(currentPackage(source))) return false;
    return !alreadyCovered(source, qualifiedName);
  }

  /**
   * خطة إدراج سطر الاستيراد في {@code source} الحيّ: {@code null} حين لا يلزم تغيير. يُدرج بعد آخر
   * استيراد فعلي (فتبقى الكتلة متصلة)، وإلا بعد سطر {@code package}، وإلا في أول الملف.
   */
  public static QuickFix.Insertion insertionFor(String source, String qualifiedName) {
    if (qualifiedName == null || qualifiedName.isEmpty()) return null;
    return insertionForAll(source, java.util.Collections.singletonList(qualifiedName));
  }

  /**
   * كتلةُ استيراداتٍ مُتَّصِلةٌ بأيِّ عدَدٍ (طلبُ ‏1.0.189: «مهما كانَ عدَدُها»). قاعدةُ المَوضِعِ هي
   * قاعدةُ السطرِ الواحدِ حرفيًّا — بعدَ آخرِ استيرادٍ فعليٍّ، وإلّا بعدَ سطرِ {@code package}، وإلّا
   * في أولِ الملفِّ — لأنَّ المِصبَّ مَصبٌّ واحدٌ: السطرُ الواحدُ الآنَ حالةٌ منَ القائمةِ. ما كانَ
   * مَكتوبًا أو كَفَتْتْهُ باقةٌ ساقِطٌ، والمُكرَّرُ يُحاسَبُ مَرَّةً، فلا سطرانِ لـ{@code import a.B;}.
   */
  public static QuickFix.Insertion insertionForAll(String source, List<String> qualifiedNames) {
    if (source == null || qualifiedNames == null || qualifiedNames.isEmpty()) return null;
    java.util.Set<String> seen = new LinkedHashSet<String>();
    StringBuilder block = new StringBuilder();
    for (String qualifiedName : qualifiedNames) {
      if (qualifiedName == null || !needsImport(source, qualifiedName)) continue;
      if (!seen.add(qualifiedName)) continue;
      block.append("\nimport ").append(qualifiedName).append(';');
    }
    if (block.length() == 0) return null;
    String code = QuickFix.mask(source);
    int lastImportEnd = -1;
    int at = -1;
    while ((at = keywordAt(code, "import", at + 1)) >= 0) {
      int semicolon = code.indexOf(';', at);
      if (semicolon < 0) break;
      lastImportEnd = semicolon + 1;
    }
    if (lastImportEnd >= 0) return new QuickFix.Insertion(lastImportEnd, block.toString(), -1, -1);
    int packageAt = keywordAt(code, "package", 0);
    if (packageAt >= 0) {
      int semicolon = code.indexOf(';', packageAt);
      if (semicolon >= 0) {
        return new QuickFix.Insertion(semicolon + 1, "\n" + block, -1, -1);
      }
    }
    return new QuickFix.Insertion(0, block.substring(1) + "\n", -1, -1);
  }

  /** النص بعد إضافة الاستيراد، أو {@code null} حين لا يلزم. */
  public static String withImport(String source, String qualifiedName) {
    QuickFix.Insertion plan = insertionFor(source, qualifiedName);
    return plan == null ? null : plan.applyTo(source);
  }

  /**
   * مرشّح الاستيراد الوحيد لاسم بسيط من {@code qualifiedCandidates} (أصناف المشروع المطابقة):
   * {@code null} عند انعدام المرشّح أو تعدّده — المرجع يبلّغ «Ambiguous type» ولا يخترع حزمة.
   */
  public static String uniqueCandidate(
      Collection<String> qualifiedCandidates, String currentPackage) {
    if (qualifiedCandidates == null || qualifiedCandidates.isEmpty()) return null;
    LinkedHashSet<String> distinct = new LinkedHashSet<>();
    for (String candidate : qualifiedCandidates) {
      if (candidate == null || candidate.isEmpty()) continue;
      int dot = candidate.lastIndexOf('.');
      if (dot <= 0) continue;
      String pkg = candidate.substring(0, dot);
      if (pkg.equals("java.lang") || pkg.equals(currentPackage)) continue;
      distinct.add(candidate);
    }
    return distinct.size() == 1 ? distinct.iterator().next() : null;
  }

  /** المرشّح الوحيد من أصناف المشروع المسجَّلة لـ{@code simpleName} (فارغ الحزمة = صنف بلا حزمة). */
  public static String uniqueProjectCandidate(String simpleName, String currentPackage) {
    if (simpleName == null || simpleName.isEmpty()) return null;
    ArrayList<String> qualified = new ArrayList<>();
    for (JavaTypeModel.SourceClass found : JavaProjectModel.classesNamed(simpleName)) {
      if (found == null) continue;
      String name = found.qualifiedName();
      if (name != null && !name.isEmpty()) qualified.add(name);
    }
    return uniqueCandidate(qualified, currentPackage);
  }

  /**
   * يضيف صفّ «Fix imports» الجماعي أمام صفوف الاستيراد الفردية حين وُجد واحد منها على الأقل —
   * كما في لقطة المرجع حيث يظهر السطران معًا. بلا استيراد محلول لا يُضاف شيء (لا صفّ كاذب).
   */
  public static List<QuickFix> withFixImportsRow(List<QuickFix> fixes) {
    ArrayList<QuickFix> out = new ArrayList<>();
    if (fixes == null || fixes.isEmpty()) return out;
    boolean seesImportFix = false;
    for (QuickFix fix : fixes) {
      if (fix == null) continue;
      if (fix.kind == QuickFix.Kind.ADD_IMPORT) seesImportFix = true;
      out.add(fix);
    }
    if (seesImportFix) out.add(0, QuickFix.fixImports());
    return out;
  }

  /** سطور {@code import} الفعلية (أسماء محزّمة، ودون المعلَّق) — للعرض والاختبار معًا. */
  public static List<String> importStatements(String source) {
    ArrayList<String> out = new ArrayList<>();
    if (source == null || source.isEmpty()) return out;
    String code = QuickFix.mask(source);
    int at = -1;
    while ((at = keywordAt(code, "import", at + 1)) >= 0) {
      int semicolon = code.indexOf(';', at);
      if (semicolon < 0) break;
      String name = code.substring(at + "import".length(), semicolon).trim();
      if (!name.isEmpty()) out.add(name);
      at = semicolon;
    }
    return out;
  }

  // ================= W5′: مصدر معرفة واحد للاسم غير المحلول =================

  /**
   * المرشَّحات بترتيبٍ حاسمٍ واحد، وهو القاعدة كلها: <b>أصناف المشروع</b> (موديل الفاحص ثم فهرس
   * الإكمال) ← <b>الكتلة المصونة</b> (اسم واحد لكل نوع شائع) ← <b>فهرس المنصّة/المكتبات</b>.
   * الترتيب لا الاتحاد: ففهرس المنصّة يعرف {@code List} في {@code java.util} و{@code java.awt} معًا،
   * ولو دُمج مع المشروع لصار كل {@code List} «غامضًا» وفقد التطبيق ما كان يفعله من قبل.
   */
  public static List<String> candidatesFor(String simpleName) {
    ArrayList<String> out = new ArrayList<>();
    if (simpleName == null || simpleName.isEmpty()) return out;
    LinkedHashSet<String> project = new LinkedHashSet<>();
    for (JavaTypeModel.SourceClass found : JavaProjectModel.classesNamed(simpleName)) {
      if (found != null && found.qualifiedName() != null && !found.qualifiedName().isEmpty())
        project.add(found.qualifiedName());
    }
    if (!project.isEmpty()) {
      out.addAll(project);
      return out;
    }
    // فهرس الإكمال الدائم يجيب إن كان جيلُ الفحص الحالي لم يسجّل الصنف بعد (ملفٌّ لم يُفتَح) —
    // ولا يُدمج مع الموديل أبدًا: المصدران يصفان نفس المشروع، فجمعهما يختلق غموضًا غير موجود.
    String indexed = ProjectSymbolIndex.packageOf(simpleName);
    if (indexed != null && !indexed.isEmpty()) {
      out.add(indexed + "." + simpleName);
      return out;
    }
    String curated = conservativeCandidate(simpleName);
    if (curated != null) {
      out.add(curated);
      return out;
    }
    if (AndroidApiIndex.isLoaded()) {
      LinkedHashSet<String> api = new LinkedHashSet<>();
      for (AndroidApiIndex.ClassInfo info : AndroidApiIndex.classesNamed(simpleName)) {
        if (info == null || info.hidden) continue;
        if (info.qualifiedName != null && !info.qualifiedName.isEmpty()) api.add(info.qualifiedName);
      }
      out.addAll(api);
    }
    return out;
  }

  /** هل تعرف طبقاتُ المعرفة (مشروعٌ أو منصّة/مكتبة) الصنفَ {@code pkg.simple} فعلًا؟ */
  public static boolean provides(String pkg, String simple) {
    if (pkg == null || simple == null || pkg.isEmpty() || simple.isEmpty()) return false;
    String qualified = pkg + "." + simple;
    if (JavaProjectModel.classByQualifiedName(qualified) != null) return true;
    return AndroidApiIndex.isLoaded() && AndroidApiIndex.classByQualifiedName(qualified) != null;
  }

  /** القرار الذي يتخذه الملف والكتلة المصونة عند غياب اسم المشروع: مرشَّح واحد أو لا شيء. */
  public static String conservativeCandidate(String simpleName) {
    return simpleName == null || simpleName.isEmpty() ? null : COMMON_TYPES.get(simpleName);
  }

  /** نتيجة اسمٍ بسيط غير محلول في ملفٍ حزمته {@code currentPackage}. */
  public static final class Resolution {
    public enum Kind { NONE, LOCAL, UNIQUE, AMBIGUOUS }

    public final Kind kind;
    public final String qualifiedName;
    public final List<String> candidates;

    Resolution(Kind kind, String qualifiedName, List<String> candidates) {
      this.kind = kind;
      this.qualifiedName = qualifiedName;
      this.candidates = candidates;
    }

    /** يُدرَج الاستيراد: مرشَّح وحيد لم يحسمه الملف بعد. */
    public boolean isFixable() {
      return kind == Kind.UNIQUE;
    }

    /** بلّغ غموضًا ولا تخترع حزمة. */
    public boolean isAmbiguous() {
      return kind == Kind.AMBIGUOUS;
    }
  }

  /**
   * قرار الاسم البسيط: {@code LOCAL} إن حسمه الملف (نفس الحزمة، أو استيراد صريح يثبّت الاسم، أو
   * {@code java.lang}) — فلا استيراد ولا ادّعاء؛ {@code UNIQUE} عند مرشَّح واحد صالح؛
   * {@code AMBIGUOUS} عند أكثر. لا نرجّح بالاسم ولا بترتيب الحزم أبدًا.
   */
  public static Resolution resolution(String simpleName, String currentPackage, String source) {
    if (simpleName == null || simpleName.isEmpty() || simpleName.indexOf('.') >= 0)
      return new Resolution(Resolution.Kind.NONE, null, java.util.Collections.emptyList());
    if (simpleName.charAt(0) < 'A' || simpleName.charAt(0) > 'Z')
      return new Resolution(Resolution.Kind.NONE, null, java.util.Collections.emptyList());
    if (currentPackage != null && currentPackage.isEmpty()) currentPackage = null;
    ArrayList<String> usable = new ArrayList<>();
    for (String candidate : candidatesFor(simpleName)) {
      int dot = candidate.lastIndexOf('.');
      if (dot <= 0) continue;
      String pkg = candidate.substring(0, dot);
      if (pkg.equals("java.lang")) {
        return new Resolution(Resolution.Kind.LOCAL, candidate, java.util.Collections.emptyList());
      }
      if (currentPackage == null || !pkg.equals(currentPackage)) {
        if (!usable.contains(candidate)) usable.add(candidate);
      } else {
        return new Resolution(Resolution.Kind.LOCAL, candidate, java.util.Collections.emptyList());
      }
    }
    if (source != null && !source.isEmpty()) {
      for (String imported : importStatements(source)) {
        if (imported.endsWith(".*") || imported.isEmpty()) continue;
        if (imported.substring(imported.lastIndexOf('.') + 1).equals(simpleName))
          return new Resolution(Resolution.Kind.LOCAL, imported, java.util.Collections.emptyList());
      }
    }
    if (usable.isEmpty())
      return new Resolution(Resolution.Kind.NONE, null, java.util.Collections.emptyList());
    if (usable.size() > 1)
      return new Resolution(Resolution.Kind.AMBIGUOUS, null, usable);
    String unique = usable.get(0);
    if (source != null && alreadyCovered(source, unique))
      return new Resolution(Resolution.Kind.LOCAL, unique, usable);
    return new Resolution(Resolution.Kind.UNIQUE, unique, usable);
  }

  /** الصيغة ذاتها التي يستعملها المنسّق (بلا نصّ ملف: لا سطرٌ يثبّت الاسم). */
  public static Resolution resolution(String simpleName, String currentPackage) {
    return resolution(simpleName, currentPackage, null);
  }

  // ================= الكتلة المصونة (كانت في JavaImportOrganizer) =================
  /**
   * اسمٌ واحد لكل نوع شائع: ما يُلهم الاستيراد حين لا يعرف المشروع الصنف. صارت هنا لأن الإصلاح
   * والتنظيم يقرآن الكتلة نفسها — لا كتالوجان متوازيان (البند 4).
   */
  private static final Map<String, String> COMMON_TYPES = commonTypes();

  private static Map<String, String> commonTypes() {
    Map<String, String> types = new LinkedHashMap<>();
    addTypes(types, "java.util", "ArrayDeque ArrayList Arrays BitSet Calendar Collection Collections Comparator Deque EnumMap EnumSet Enumeration HashMap HashSet Hashtable Iterator LinkedHashMap LinkedHashSet LinkedList List Locale Map NavigableMap NavigableSet Objects Optional Properties Queue Random Scanner Set SortedMap SortedSet Stack StringTokenizer Timer TreeMap TreeSet UUID Vector WeakHashMap");
    addTypes(types, "java.io", "BufferedInputStream BufferedOutputStream BufferedReader BufferedWriter ByteArrayInputStream ByteArrayOutputStream File FileInputStream FileNotFoundException FileOutputStream FileReader FileWriter FilterInputStream FilterOutputStream IOException InputStream InputStreamReader ObjectInputStream ObjectOutputStream OutputStream OutputStreamWriter PrintStream PrintWriter Reader Serializable StringReader StringWriter Writer");
    addTypes(types, "java.nio.file", "CopyOption DirectoryStream FileSystem FileSystems Files LinkOption Path PathMatcher Paths StandardCopyOption WatchKey WatchService");
    addTypes(types, "java.nio.charset", "Charset StandardCharsets");
    addTypes(types, "java.net", "HttpURLConnection InetAddress InetSocketAddress URI URL URLConnection URLEncoder URLDecoder");
    addTypes(types, "java.util.concurrent", "Callable CompletionService CountDownLatch CyclicBarrier Executor ExecutorService Executors Future FutureTask ScheduledExecutorService Semaphore TimeUnit TimeoutException");
    addTypes(types, "java.util.concurrent.atomic", "AtomicBoolean AtomicInteger AtomicLong AtomicReference");
    addTypes(types, "java.util.regex", "Matcher Pattern");
    addTypes(types, "java.text", "DateFormat DecimalFormat NumberFormat SimpleDateFormat");
    addTypes(types, "java.math", "BigDecimal BigInteger MathContext RoundingMode");
    addTypes(types, "java.time", "Clock Duration Instant LocalDate LocalDateTime LocalTime MonthDay Period Year YearMonth ZoneId ZonedDateTime");
    addTypes(types, "android.app", "Activity AlertDialog Application Dialog ProgressDialog Service");
    addTypes(types, "android.content", "BroadcastReceiver ContentProvider ContentResolver Context DialogInterface Intent SharedPreferences");
    addTypes(types, "android.os", "AsyncTask Bundle Handler Looper Message Parcelable StrictMode SystemClock");
    addTypes(types, "android.view", "Gravity KeyEvent LayoutInflater Menu MenuItem MotionEvent View ViewGroup Window");
    addTypes(types, "android.widget", "Adapter ArrayAdapter Button CheckBox EditText FrameLayout ImageButton ImageView LinearLayout ListView ProgressBar RelativeLayout ScrollView Spinner TextView Toast");
    addTypes(types, "android.graphics", "Bitmap BitmapFactory Canvas Color Paint Rect Typeface");
    addTypes(types, "android.net", "Uri ConnectivityManager NetworkInfo");
    addTypes(types, "androidx.recyclerview.widget", "LinearLayoutManager RecyclerView GridLayoutManager");
    addTypes(types, "androidx.appcompat.app", "AppCompatActivity AlertDialog");
    return java.util.Collections.unmodifiableMap(types);
  }

  private static void addTypes(Map<String, String> target, String packageName, String values) {
    for (String value : values.split(" ")) target.put(value, packageName + "." + value);
  }

  // ================= أدوات مشتركة =================

  /** موضع الكلمة المفتاحية {@code word} بدءًا من {@code from}، محاطة بحدّ رمز لا نصّ. */
  private static int keywordAt(String code, String word, int from) {
    int i = Math.max(0, from);
    while (true) {
      int at = code.indexOf(word, i);
      if (at < 0) return -1;
      boolean leftOk = at == 0 || !Character.isJavaIdentifierPart(code.charAt(at - 1));
      int after = at + word.length();
      // «import»/«package» كلمة قائمة بذاتها: حرف رمز بعدها يعني كلمة أخرى («important»).
      boolean rightOk = after >= code.length() || !Character.isJavaIdentifierPart(code.charAt(after));
      if (leftOk && rightOk) return at;
      i = at + 1;
    }
  }
}
