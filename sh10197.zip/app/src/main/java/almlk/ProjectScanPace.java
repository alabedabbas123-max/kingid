package almlk;

import java.util.Set;

/**
 * سياسةُ مسحِ المشروعِ عندَ الفتحِ (الجولةُ ٣٨): كم خيطًا، وبأيِّ ترتيبٍ، ومتى يَجوزُ حفظُ ما أنتَجَهُ.
 *
 * <p>الطبقةُ صافيةٌ كما في {@code AnalysisPace}: لا أقراصَ ولا خيوطَ ولا أندرويدَ — أرقامٌ ومقارنةٌ
 * واحدةٌ تُقاسُ في البوابةِ، والغلافُ الأندرويديُّ في {@code BrowserPager} يَنفُذُها. كلُّ ما كانَ
 * مُفرَّقًا في الشيفرةِ صارَ هنا: عددُ الخيوطِ، وحدُّ «لا فايدةَ من خيطٍ ثانٍ»، ودِلاءُ الأولويَّةِ،
 * وقِطَعُ القائمةِ، ومُهلَةُ النشرِ، وشرطُ القَطرةِ. فلا يُعرَّفُ ترتيبٌ ثانٍ للمسحِ واحدٍ.
 *
 * <p><b>لِمَ التدرُّجُ بالأولويَّةِ لا بالكمالِ؟</b> الملفُّ المفتوحُ هوَ الذي تُرى عليهِ العلاماتُ،
 * وما يَستورِدُهُ هوَ الذي يُجيبُ عن رموزِهِ؛ الباقي يصبرُ. وبهذا يُصبَحُ «فحصٌ عامٌّ لكلِّ الملفاتِ»
 * و«استجابةٌ فوريَّةٌ للمحرِّرِ» شرطَيْنِ لا يتناقضانِ.
 */
public final class ProjectScanPace {

  /** لا أكثرَ من أربعةِ خيوطٍ للفحصِ: الخامِسُ يَأخُذُ وقتَ الواجهةِ والقرصَ معًا. */
  public static final int MAX_WORKERS = 4;

  /** دونَ هذا العددِ من الملفاتِ لا فايدةَ في خيطٍ ثانٍ: ثمنُ التقسيمِ أوفرُ من عملِهِ. */
  public static final int MIN_FILES_PER_WORKER = 12;

  /** دلوُّ الملفِّ المفتوحِ: يُفحَصُ أوَّلًا لأنَّهُ ما تنظرُ إليهِ العينُ. */
  public static final int BUCKET_OPEN = 0;
  /** دلوُّ ما يَستورِدُهُ الملفُّ المفتوحُ: ثانِيًا لأنَّهُ جوابُ رموزِهِ. */
  public static final int BUCKET_DEPENDENT = 1;
  /** دلوُّ بقيَّةِ المشروعِ: ثالثًا، أبجديًّا، بلا جَزِمٍ ولا تَقدُّمٍ عليهِ. */
  public static final int BUCKET_REST = 2;

  /** سطرُ الإشعارِ حينَ يَمتلئُ الوعاءُ: إشارةٌ لا تشخيصٌ، فلا يُمحى عندَ أوَّلِ ضغطةِ حفظٍ. */
  public static final String LIMIT_KEY = "__project_diagnostics_limit__";

  private ProjectScanPace() {}

  /**
   * عددُ الخيوطِ من عددِ الأنويةِ: نواةٌ تُترَكُ دائمًا للواجهةِ والقرصِ، ولا تجاوزَ للسقفِ. نواةٌ
   * واحدةٌ (أو صفرٌ تُبلِغُهُ الأجهزةُ القديمةُ) تعني خيطًا واحدًا: نفسُ سلوكِ ما قبلَ الجولةِ ٣٨.
   */
  public static int workerCount(int availableProcessors) {
    int usable = availableProcessors - 1;
    if (usable < 1) return 1;
    return usable > MAX_WORKERS ? MAX_WORKERS : usable;
  }

  /** كم خيطًا يَصلُحُ لعددٍ من الملفاتِ: لا خيطٌ يقعدُ بلا عملٍ، ولا عملٌ ينتظِرُ خيطًا فارغًا. */
  public static int workerCountFor(int files, int availableProcessors) {
    int workers = workerCount(availableProcessors);
    if (files < MIN_FILES_PER_WORKER) return 1;
    int fit = files / MIN_FILES_PER_WORKER;
    return workers < fit ? workers : (fit < 1 ? 1 : fit);
  }

  /** دلوُّ مرجعٍ في طابورِ المسحِ. {@code priority} هو الملفُّ المفتوحُ، و{@code dependents} ما يَستورِدُهُ. */
  public static int bucket(String reference, String priority, Set<String> dependents) {
    if (reference == null) return BUCKET_REST;
    if (priority != null && !priority.isEmpty() && priority.equals(reference)) return BUCKET_OPEN;
    if (dependents != null && dependents.contains(reference)) return BUCKET_DEPENDENT;
    return BUCKET_REST;
  }

  /**
   * المقارنةُ الوحيدةُ لترتيبِ المرشَّحينِ: الدَّلُّ أوَّلًا ثمَّ الاسمُ. صيغةُ الاسمِ هنا هي الصيغةُ
   * نفسُها التي يَرتِّبُ بها {@code sortProjectDiagnostics} النتائجَ بعدَ الفراغِ، فلا يَعرِضُ المسحُ
   * ترتيبًا وتُخبِئُ النتائجُ ترتيبًا آخرَ.
   */
  public static int compare(String left, String right, String priority, Set<String> dependents) {
    int leftBucket = bucket(left, priority, dependents);
    int rightBucket = bucket(right, priority, dependents);
    if (leftBucket != rightBucket) return leftBucket < rightBucket ? -1 : 1;
    return String.valueOf(left).compareToIgnoreCase(String.valueOf(right));
  }

  /** أوَّلُ فهرسٍ في حِزْمةِ الخيطِ: قِطَعٌ مُتَّصِلةٌ محدَّدةٌ — نفسُ القائمةِ تُعطِي نفسَ القِطَعِ. */
  public static int startOf(int shard, int files, int workers) {
    if (files <= 0 || shard <= 0) return 0;
    if (workers <= 1 || shard >= workers) return files;
    return (int) ((long) files * shard / workers);
  }

  /** آخرُ فهرسٍ (مُستَبعَدٌ) في حِزْمةِ الخيطِ؛ الحِزْمةُ الأخيرَةُ تَأخُذُ البقيَّةَ كلَّها. */
  public static int endOf(int shard, int files, int workers) {
    if (files <= 0 || workers <= 1) return Math.max(0, files);
    if (shard >= workers - 1) return files;
    return (int) ((long) files * (shard + 1) / workers);
  }

  /**
   * هل يَنبَغي أن يُنشَرُ تقدُّمٌ الآنَ؟ أوَّلُ ما يَظهَرُ شيءٌ يُنشَرُ بلا انتظارٍ ({@code lastPublishMs}
   * صفرٌ)، ثمَّ كلَّ مُهلَةٍ — فلا شريطٌ يتقطَّعُ ولا واجهةٌ تُزعَجُ كلَّ مِلي ثانيةٍ.
   */
  public static boolean publishNow(int count, long nowMs, long lastPublishMs, long intervalMs) {
    if (count <= 0) return false;
    if (lastPublishMs == 0L) return true;
    return nowMs - lastPublishMs >= intervalMs;
  }

  /**
   * هل يُقبَلُ ما في الوعاءِ أن يُحفَظَ في قَطرةِ اللقطاتِ؟ لا، ما دامَ النموذجُ غيرَ جازمٍ: نتيجةٌ
   * حُسِبَتْ والفهرسُ نصْفُ مَبنيٍّ تُصبِحُ عندَ الفتحِ التالي «خطأً محفوظًا» على ملفٍّ لم يتغيَّرَ —
   * وهذهِ أخطاءُ وهميَّةٌ تُرى ولا تُبرَّرُ. تُعرَضُ في الجلسةِ ولا تُقفَّلُ في القرصِ.
   */
  public static boolean mayPersistSnapshot(boolean absenceProvablyComplete) {
    return absenceProvablyComplete;
  }
}
