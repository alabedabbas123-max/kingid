package almlk;

import java.util.ArrayDeque;

/**
 * بند almlk ← التراجع/الإعادة المدمج بالموديل (أسلوب «C0001g»): كل استبدال يُسجَّل بعملية
 * عكسية (موضع + النص المحذوف + النص المُدخَل)، مع دمج الكتابة المتتابعة في حركة واحدة —
 * كلمات متصلة ترجع دفعة واحدة — وسقف 500 عملية كي لا تتضخم الذاكرة مع ملفات ضخمة.
 */
public final class UndoRedoStack {

  /** عملية واحدة: استبدال removed بـ inserted عند start. عكسها = إرجاع removed. */
  public static final class Operation {
    public final int start;
    public final String removed;
    public final String inserted;
    private final long time;
    private final boolean insertion;

    Operation(int start, String removed, String inserted) {
      this.start = start;
      this.removed = removed;
      this.inserted = inserted;
      this.time = System.currentTimeMillis();
      this.insertion = removed.isEmpty() && !inserted.isEmpty();
    }

    private boolean isDeletion() {
      return !removed.isEmpty() && inserted.isEmpty();
    }

    /** دمج كتابة/حذف متتابعين (نفس النوع، متلاصقان، خلال 900ms). */
    boolean mergeWith(Operation next) {
      if (next.time - time > 900) return false;
      if (insertion && next.insertion && next.start == start + inserted.length()) return true;
      if (isDeletion() && next.isDeletion()) {
        // حذف أمامي متتابع (Delete) يلتصق عند نفس البداية، وخلفي (Backspace) يتقدّم للأمام.
        return next.start == start || next.start + next.removed.length() == start;
      }
      return false;
    }

    Operation merge(Operation next) {
      if (insertion) {
        return new Operation(start, removed, inserted + next.inserted);
      }
      // حذف: إما تراجعي (next.start == start → حذف أمامي متتابع) أو خلفي.
      String merged = next.start == start
          ? removed + next.removed
          : next.removed + removed;
      int mergedStart = Math.min(start, next.start);
      Operation out = new Operation(mergedStart, merged, inserted);
      return out;
    }
  }

  private final ArrayDeque<Operation> undo = new ArrayDeque<>();
  private final ArrayDeque<Operation> redo = new ArrayDeque<>();
  private static final int CAPACITY = 500;

  public static final class Applied {
    public final int start;
    public final String removed;
    public final String inserted;

    Applied(int start, String removed, String inserted) {
      this.start = start;
      this.removed = removed;
      this.inserted = inserted;
    }
  }

  /** يسجّل استبدالًا حدث للتو. start = بداية المقاطع، removed = ما حُذف، inserted = ما دخل. */
  public synchronized void record(int start, String removed, String inserted) {
    redo.clear();
    if (removed.isEmpty() && inserted.isEmpty()) return;
    Operation op = new Operation(start, removed, inserted);
    Operation top = undo.peekLast();
    if (top != null && top.mergeWith(op)) {
      undo.pollLast();
      undo.addLast(top.merge(op));
      return;
    }
    undo.addLast(op);
    while (undo.size() > CAPACITY) undo.pollFirst();
  }

  public synchronized boolean canUndo() {
    return !undo.isEmpty();
  }

  public synchronized boolean canRedo() {
    return !redo.isEmpty();
  }

  /** يسحب عملية للتراجع: على المحرك تنفيذ عكسها (استبدال inserted بـ removed). */
  public synchronized Applied popUndo() {
    Operation op = undo.pollLast();
    if (op == null) return null;
    redo.addLast(op);
    return new Applied(op.start, op.removed, op.inserted);
  }

  /** يسحب عملية للإعادة: على المحرك تنفيذها مجددًا (استبدال removed بـ inserted). */
  public synchronized Applied popRedo() {
    Operation op = redo.pollLast();
    if (op == null) return null;
    undo.addLast(op);
    return new Applied(op.start, op.removed, op.inserted);
  }

  public synchronized void clear() {
    undo.clear();
    redo.clear();
  }
}
