package almlk;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * فهرسةُ ما في المخازنِ من أدواتٍ، وترتيبُ نتائجِ البحثِ — صافٍ وحصورٌ (W22/ب1).
 *
 * <p><b>لماذا:</b> قائمةُ «إضافةَ اعتمادٍ» اليومَ مبنيةٌ على جدولَينِ اسميَّينِ
 * ({@link AndroidXMigration#androidxNames()} و{@link AndroidXMigration#appcompatNames()})؛ تكتبُ ما ليس
 * فيهما ولا ترى ما هو موجودٌ ولا ما له إصداراتٌ. البحثُ الحقيقيُّ يحتاجُ أن يعرفَ المحرِّرُ «ما الأدواتُ
 * التي لي بها مخبأٌ أو pom؟» — وهذا كلُّ ما في الصنفِ: مشيٌ محدودٌ على القرصِ، ثمَّ ترتيبٌ.
 *
 * <p><b>الحصّةُ مقدَّمًا لا بعدَ الوقوعِ:</b> {@value #MAX_NODES} عقدةً، وعمقُ {@value #MAX_DEPTH}،
 * و{@value #DEFAULT_LIMIT} نتيجةً — لأنَّ جذرَ البحثِ قد يكونُ {@code /sdcard} كلَّهُ بخطأِ إعدادٍ،
 * والمحرِّرُ الذي يتعثَّرُ في قائمةِ مكاتبَ ليس محرِّرًا. {@link Scan#truncated} يبلِّغُ القطعَ بدلَ
 * الصمتِ عليهِ.
 */
public final class MavenIndex {

  public static final int MAX_NODES = 5000;
  public static final int MAX_DEPTH = 8;
  public static final int DEFAULT_LIMIT = 200;

  /** أداةٌ واحدةٌ معروفةٌ محليًّا. */
  public static final class Hit {
    public final String group;
    public final String artifact;
    /** «store» لمخزنِ التطبيقِ، أو «local:‹اسمُ الجذرِ›» لغيرِهِ — لتُعرَفَ مصدرَ السطرِ. */
    public final String origin;
    /** إصداراتٌ موجودةٌ على القرصِ، بترتيبِ {@link MavenVersion} تصاعديًّا. */
    public final List<String> versions;

    Hit(String group, String artifact, String origin, List<String> versions) {
      this.group = group;
      this.artifact = artifact;
      this.origin = origin;
      this.versions = Collections.unmodifiableList(versions);
    }

    public String coordinate() {
      return group + ":" + artifact;
    }

    /** أحدثُ ما هو موجودٌ فعلًا على القرصِ (ليس ما أعلنتهُ الشبكةُ). */
    public String latestInstalled() {
      return versions.isEmpty() ? "" : versions.get(versions.size() - 1);
    }

    @Override
    public boolean equals(Object other) {
      return other instanceof Hit && ((Hit) other).coordinate().equals(coordinate());
    }

    @Override
    public int hashCode() {
      return coordinate().hashCode();
    }

    @Override
    public String toString() {
      return coordinate() + " " + versions + " @" + origin;
    }
  }

  /** نتيجةُ مشيِ القرصِ — القطعُ معلَنٌ لا مكتومٌ. */
  public static final class Scan {
    public final List<Hit> hits;
    public final boolean truncated;
    public final int visited;

    Scan(List<Hit> hits, boolean truncated, int visited) {
      this.hits = Collections.unmodifiableList(hits);
      this.truncated = truncated;
      this.visited = visited;
    }
  }

  private MavenIndex() {}

  /** جذورُ القراءةِ: مخزنُ التطبيقِ أولًا، ثمَّ مستودعاتُ المستخدمِ. */
  public static List<Source> sources(MavenStore store) {
    List<Source> out = new ArrayList<Source>();
    if (store != null && store.downloadDir() != null) out.add(new Source(store.downloadDir(), "store"));
    if (store != null) {
      for (File dir : store.localRepositories()) {
        out.add(new Source(dir, "local:" + dir.getName()));
      }
    }
    return out;
  }

  /** جذرٌ واحدٌ مع اسمِهِ (مفتوحٌ للاختبارِ). */
  public static final class Source {
    public final File root;
    public final String origin;

    public Source(File root, String origin) {
      this.root = root;
      this.origin = origin == null ? "local" : origin;
    }
  }

  public static Scan scan(List<Source> sources, int maxHits) {
    Map<String, Hit> byKey = new LinkedHashMap<String, Hit>();
    int visited = 0;
    boolean truncated = false;
    int budget = maxHits <= 0 ? DEFAULT_LIMIT : maxHits;
    if (sources != null) {
      for (Source source : sources) {
        if (source == null || source.root == null || !source.root.isDirectory()) continue;
        Deque<Object[]> queue = new ArrayDeque<Object[]>();
        queue.add(new Object[] {source.root, 0, ""});
        while (!queue.isEmpty()) {
          if (visited++ >= MAX_NODES) {
            truncated = true;
            break;
          }
          Object[] item = queue.poll();
          File dir = (File) item[0];
          int depth = ((Integer) item[1]).intValue();
          String groupPath = (String) item[2];
          File[] children = dir.listFiles();
          if (children == null) continue;
          List<File> subDirs = new ArrayList<File>();
          boolean metadata = false;
          for (File child : children) {
            if (child.isDirectory()) {
              subDirs.add(child);
            } else if (child.getName().startsWith("maven-metadata") && child.getName().endsWith(".xml")) {
              metadata = true;
            }
          }
          String selfGroup = groupPath;
          if (depth > 0 && !dir.getName().isEmpty()) {
            selfGroup = groupPath.isEmpty() ? dir.getName() : groupPath + "." + dir.getName();
          }
          if (depth > 0 && (metadata || hasVersionedPom(dir, dir.getName(), subDirs))) {
            // المجلدُ نفسُهُ أداةٌ: مجموعةُ أبيها، واسمُها اسمُها.
            int lastDot = groupPath.lastIndexOf('.');
            String group = lastDot < 0 ? "" : groupPath.substring(0, lastDot);
            if (byKey.size() < budget) {
              byKey.put(group + ":" + dir.getName(),
                  new Hit(group, dir.getName(), source.origin, installedVersions(dir, dir.getName())));
            } else {
              truncated = true;
            }
          }
          if (depth + 1 <= MAX_DEPTH) {
            for (File sub : subDirs) {
              String childGroup = groupPath.isEmpty() ? sub.getName() : groupPath + "." + sub.getName();
              queue.add(new Object[] {sub, depth + 1, childGroup});
            }
          } else {
            truncated = true;
          }
        }
      }
    }
    List<Hit> hits = new ArrayList<Hit>(byKey.values());
    return new Scan(hits, truncated, visited);
  }

  /** بحثٌ حيٌّ: مشيٌ ثمَّ ترتيبٌ ثمَّ حدُّ الحصيلةِ. فارغُ الاستعلامِ = كلُّ شيءٍ بالترتيبِ الطبيعيِّ. */
  public static List<Hit> search(String query, List<Source> sources, int limit) {
    Scan scan = scan(sources, MAX_NODES);
    return rank(query, scan.hits, limit);
  }

  /** ترتيبُ الاستعلامِ على نتائجَ جاهزةٍ (مكشوفٌ ليُختبَرَ بلا قرصٍ). */
  public static List<Hit> rank(String query, List<Hit> hits, int limit) {
    List<Hit> out = new ArrayList<Hit>();
    if (hits != null) {
      for (Hit hit : hits) {
        if (rankOf(query, hit.group, hit.artifact) >= 0) out.add(hit);
      }
    }
    final String needle = normalize(query);
    Collections.sort(
        out,
        new Comparator<Hit>() {
          @Override
          public int compare(Hit a, Hit b) {
            int x = rankOf(needle, a.group, a.artifact);
            int y = rankOf(needle, b.group, b.artifact);
            if (x != y) return x - y;
            int c = a.group.compareTo(b.group);
            if (c != 0) return c;
            return a.artifact.compareTo(b.artifact);
          }
        });
    if (limit > 0 && out.size() > limit) return new ArrayList<Hit>(out.subList(0, limit));
    return out;
  }

  /**
   * {@code 0} تطابقٌ تامٌّ، {@code 1} بادئةُ اسمِ الأداةِ، {@code 2} جزءٌ من الاسمِ، {@code 3} مجموعةٌ
   * فقط، {@code 4} الاستعلامُ فارغٌ، و{@code -1} لا يطابقُ. استعلامُ {@code مجموعة:أداةٌ} يشترطُ المجموعةَ.
   */
  public static int rankOf(String query, String group, String artifact) {
    String needle = normalize(query);
    String g = group == null ? "" : group.toLowerCase(Locale.US);
    String a = artifact == null ? "" : artifact.toLowerCase(Locale.US);
    if (needle.isEmpty()) return 4;
    int colon = needle.indexOf(':');
    if (colon >= 0) {
      String wantedGroup = needle.substring(0, colon);
      String wantedArtifact = needle.substring(colon + 1);
      if (!wantedGroup.isEmpty() && !g.startsWith(wantedGroup) && !g.contains(wantedGroup)) return -1;
      if (wantedArtifact.isEmpty()) return 3;
      if (a.equals(wantedArtifact)) return 0;
      if (a.startsWith(wantedArtifact)) return 1;
      return a.contains(wantedArtifact) ? 2 : -1;
    }
    if (a.equals(needle)) return 0;
    if (a.startsWith(needle)) return 1;
    if (a.contains(needle)) return 2;
    return g.contains(needle) ? 3 : -1;
  }

  /** إصداراتٌ على القرصِ: كلُّ مجلدٍ ابنٍ لهُ pom بهذهِ الصيغةِ القياسيّةِ. */
  private static List<String> installedVersions(File artifactDir, String artifact) {
    List<String> out = new ArrayList<String>();
    File[] children = artifactDir.listFiles();
    if (children != null) {
      for (File child : children) {
        if (!child.isDirectory()) continue;
        if (new File(child, artifact + "-" + child.getName() + ".pom").isFile()) out.add(child.getName());
      }
    }
    Collections.sort(
        out,
        new Comparator<String>() {
          @Override
          public int compare(String x, String y) {
            return MavenVersion.compare(x, y);
          }
        });
    return out;
  }

  private static boolean hasVersionedPom(File artifactDir, String artifact, List<File> subDirs) {
    for (File child : subDirs) {
      if (new File(child, artifact + "-" + child.getName() + ".pom").isFile()) return true;
    }
    return false;
  }

  private static String normalize(String query) {
    return query == null ? "" : query.trim().toLowerCase(Locale.US).replace('/', '.');
  }
}
