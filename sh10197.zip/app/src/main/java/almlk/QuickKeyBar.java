package almlk;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import com.shima.demo.R;
import java.util.List;

/**
 * شريطُ أدواتِ المحرّر: مالكُهُ النشاطَ لا المُحرِّر، يسكنُ {@code mainQuickKeyBarContainer}، ويرسمُ أدواتِهِ من
 * سلسلةِ نوعِ الملفِ المفتوح. بنيةٌ مُستخلَصةٌ من {@code C0034La} و{@code QuickKey} في المصدر — إعادةَ بناءٍ
 * بعقدِنا وأسمائِنا، لا نسخَ سطر.
 *
 * <p>ثلاثُ خصائصَ من المصدر حُفِظت كما هي، وهي ما كان ينقصُ شريطَنا:
 * <ol>
 *   <li><b>الشكلُ من {@code xml}</b>: {@code R.layout.quickkeysbar} (فاصلٌ 0.6dip، {@code HorizontalScrollView}،
 *       زرّا إغلاقٍ وفتحٍ 40×40dip) و{@code R.layout.quickkeysbar_key} للزرِّ الواحد؛ العرضُ {@code wrap_content}
 *       والارتفاعُ {@code dp(40)} ثابتًا لكلِّ زرّ.</li>
 *   <li><b>السهمُ أولُ السلسلة دائمًا</b> ({@link QuickKeySequences#SPECIAL_TOKEN}) ⇒ يفتحُ الشريطَ ويبقى في
 *       رأسِهِ مهما أعادَ المستخدمُ ترتيبَ ما بعدَه، وعملُهُ إزاحةٌ كـ Tab.</li>
 *   <li><b>لا إعادةَ بناءَ بغيرِ داعٍ</b>: ما لم تتغيّر السلسلةُ لا يُمسُّ أيُّ طفلٍ في الشاشة.</li>
 * </ol>
 *
 * <p>والإدراجُ لا يملكُ طريقًا خاصًّا: كلُّ أداةٍ تُسلَّمُ إلى {@link Host#onQuickKeyToken(String)} فيأخذُها
 * المحرّرُ من منفذِ الكتابةِ نفسِه ({@code replaceRange})، أو من منهجِ مفتاح Tab عند السهم — فلا شريطٌ يسلكُ
 * سبيلًا ولوحةٌ سبيلًا آخر.
 */
public final class QuickKeyBar {

  /** ما يحتاجُهُ الشريطُ من صاحِبِهِ: أين تُدرَجُ الأداة، وأيُّ ملفٍ مفتوحٌ الآن. */
  public interface Host {
    /** {@link QuickKeySequences#TAB_TOKEN} للسهمِ، ورمزٌ غيرُهُ لما يُنقَرُ من الأدوات. */
    void onQuickKeyToken(String actionToken);

    /** اسمُ الملفِ النشِط (أو {@code null}) — منه يُعرَفُ نوعُ السلسلة. */
    String currentFileName();
  }

  private final Context context;
  private final ViewGroup bar;
  private final ViewGroup keysContainer;
  private final ViewGroup openButtonContainer;
  private final ViewGroup keyList;
  private Host host;
  private String lastSequence = "";
  private boolean expanded = true;
  private boolean keyboardVisible;
  private boolean activityResumed = true;

  /** تفضيلُ الإبطالِ باسمِهِ في المصدر: يُبطِلُ الإظهارَ لا بناءَ الأدوات. */
  private static final String PREF_DISABLE_QUICK_KEY_BAR = "disable_quickkeybar";

  private static final int ROW_HEIGHT_DP = 40;

  /** يُنشَأُ بعد {@code setContentView} ويُزوَّدُ بالمُضيف؛ {@code container} هو {@code mainQuickKeyBarContainer}. */
  public QuickKeyBar(Context context, ViewGroup container, Host host) {
    this.context = context;
    this.host = host;
    ViewGroup root = container;
    if (root == null) {
      this.bar = null;
      this.keysContainer = null;
      this.openButtonContainer = null;
      this.keyList = null;
      return;
    }
    // التخطيطُ يُلحَمُ في الحاوية، ثم يعملُ المالكُ على جذرِهِ ({@code quickKeyBar}) كما في المصدر.
    LayoutInflater.from(context).inflate(R.layout.quickkeysbar, root, true);
    this.bar = (ViewGroup) root.findViewById(R.id.quickKeyBar);
    if (this.bar == null) {
      this.keysContainer = null;
      this.openButtonContainer = null;
      this.keyList = null;
      return;
    }
    this.keysContainer = (ViewGroup) this.bar.findViewById(R.id.quickKeyBarKeysContainer);
    this.openButtonContainer = (ViewGroup) this.bar.findViewById(R.id.quickKeyBarOpenButtonContainer);
    this.keyList = (ViewGroup) this.bar.findViewById(R.id.quickKeyBarList);
    this.bar.findViewById(R.id.quickKeyBarCloseButton)
        .setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            setExpanded(false);
          }
        });
    this.bar.findViewById(R.id.quickKeyBarOpenButton)
        .setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            setExpanded(true);
          }
        });
    // شاشةٌ أضيقُ من 360dip تبدأ مطويّةً إلى زرِّ الفتحِ وحدَه، كي لا يبتلعَ الصفُّ موضعَ المحرّر.
    setExpanded(context.getResources().getConfiguration().screenWidthDp >= 360);
    applyVisibility();
  }

  public void setHost(Host host) {
    this.host = host;
  }

  /** إعادةُ بناءٍ من التفضيلات: نوعُ الملفِ النشِط يحدّدُ السلسلة، وقيمتُها الغائبةُ تسقطُ إلى الافتراضي. */
  public void rebuild() {
    if (keyList == null) return;
    String type = QuickKeySequences.typeFor(host == null ? null : host.currentFileName());
    SharedPreferences prefs = almlk.AppSettings.prefs(context);
    String sequence = prefs.getString(type, QuickKeySequences.defaultSequence(type));
    rebuild(sequence);
  }

  /**
   * بناءُ الأزرارِ من سطرٍ لكلِّ أداة. الحارسُ أولُ ما يعمل: سلسلةٌ لم تتغيّر تعني شاشةً لا ترمُش، وهو ما
   * يحمي التبديلَ بين تبويباتٍ من نوعٍ واحد من إعادةِ توليدٍ لا طائلَ تحتها.
   */
  public void rebuild(String sequence) {
    if (keyList == null || sequence == null || sequence.equals(lastSequence)) return;
    lastSequence = sequence;
    keyList.removeAllViews();
    LayoutInflater inflater = LayoutInflater.from(context);
    int rowHeight = dp(ROW_HEIGHT_DP);
    List<String> tokens = QuickKeySequences.tokens(sequence);
    for (final String token : tokens) {
      TextView key = (TextView) inflater.inflate(R.layout.quickkeysbar_key, keyList, false);
      key.setText(QuickKeySequences.labelFor(token));
      key.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
          applyToken(token);
        }
      });
      keyList.addView(key, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, rowHeight));
    }
    applyVisibility();
  }

  /** الارتفاعُ الذي يحجزُهُ الشريطُ لنفسِه: مطوِيٌّ لا يحجزُ شيئًا — قياسُ {@code m277j6}. */
  public int heightPx() {
    if (bar == null || !expanded) return 0;
    return dp(ROW_HEIGHT_DP);
  }

  public void setKeyboardVisible(boolean keyboardVisible) {
    if (this.keyboardVisible == keyboardVisible) return;
    this.keyboardVisible = keyboardVisible;
    applyVisibility();
  }

  public void setActivityResumed(boolean activityResumed) {
    if (this.activityResumed == activityResumed) return;
    this.activityResumed = activityResumed;
    applyVisibility();
  }

  /** الطَّيُّ لا الإخفاء: مُغلِقُ الشريطِ يتركُ زرَّ فتحٍ صغيرًا، ومفتّحُهُ يعيدُ الصفَّ كاملًا. */
  public void setExpanded(boolean expanded) {
    if (bar == null) return;
    this.expanded = expanded;
    keysContainer.setVisibility(expanded ? View.VISIBLE : View.GONE);
    openButtonContainer.setVisibility(expanded ? View.GONE : View.VISIBLE);
    applyVisibility();
  }

  public boolean isExpanded() {
    return expanded;
  }

  /** جذرُ الشريطِ كما يُعرَض — ليحجزَهُ المُكمِّلُ فوقَهُ ولا يُغطِّيَ أدواتِهِ. */
  public View peekView() {
    return bar;
  }

  /**
   * الأداةُ تُطلَبُ من المضيفِ ثم تُجدَّدُ حالةُ اللوحةِ الحسية: عندنا {@code replaceRange} يبلّغُ اللوحةَ
   * بنفسِه، فاستدعاءُ {@code restartInput} يُترَكُ للوحةٍ حقيقيةٍ مُفتَّحة — لا يُكرَهُ عليه محرِّرٌ بلا تركيز.
   */
  private void applyToken(String token) {
    if (host == null) return;
    host.onQuickKeyToken(QuickKeySequences.actionFor(token));
    InputMethodManager imm =
        (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm != null && context instanceof android.app.Activity) {
      View focus = ((android.app.Activity) context).getCurrentFocus();
      if (focus != null) imm.restartInput(focus);
    }
  }

  private void applyVisibility() {
    if (bar == null) return;
    boolean disabled =
        almlk.AppSettings.prefs(context).getBoolean(PREF_DISABLE_QUICK_KEY_BAR, false);
    // بلا أدواتٍ أو بالتفضيلِ مُعطَّلةً لا يظهرُ الشريطُ أصلًا؛ والتوسيعُ يقرّرُ أيُّ نصفٍ منهُ يُرى.
    boolean tools = keyList != null && keyList.getChildCount() > 0;
    bar.setVisibility(!disabled && tools && keyboardVisible && activityResumed
            ? View.VISIBLE
            : View.GONE);
  }

  private int dp(int value) {
    return (int)
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
  }
}
