package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * دَفْتَرُ «علَيهِ تَعدِيلٌ لم يُحفَظ» — أيُّ لِسَانٍ في المُحرِّرِ يَنتَظِرُ حِفظًا، وبِأيِّ اسمٍ يُعرَفُ.
 *
 * <p>كانَتِ الحَالَةُ بُولِيَّةً واحِدَةً للِّسَانِ النَّشِطِ (‏`AIDEEditorPager.pendingEdits`‏)، فَما
 * عَدا النَّشِطِ لا يُعرَفُ تَغَيُّرُهُ: «احفَظِ الكلَّ» لا مَعنَى لَهُ، والحِفظُ القَبلِيُّ (قَبلَ البِناءِ
 * وفَحصِ المَشرُوعِ) يَحمِلُ النَّشِطَ وَحدَهُ فَتُفحَصُ شَيفَرَةٌ قَدِيمَةٌ على القُرسِ، وعَلامَةُ
 * التَّغَيُّرِ لا تَظهَرُ إلّا على اللِّسَانِ الذي يَنظُرُ إلَيهِ المُستَخدِمُ. الدَّفْتَرُ يَنقِلُ
 * الحُكمَ إلى الشِّفرَةِ الصَّافِيَةِ (هُنا) وَيُبقِي في الواجهةِ رَسمَ اللِّسَانِ وَحدَهُ.
 *
 * <p>الترتيبُ حِفظُ التَّرتيبِ (‏`LinkedHashSet`‏): مَن تَغَيَّرَ قَبلُ يُحفَظُ قَبلُ، فَالحِفظُ الجُمَلِيَّةُ
 * لا تُعَاكِسُ سَبَبَ البِناءِ ولا قِراءَةَ المُعظِّمِ. والحَفضُ مُتَكرِّرًا عَن صِفرِ أَثَرٍ (‏mark‏
 * جَامِدَةٌ، و‏clear‏ على غَيرِ مَوسُومٍ لا يَفعَلُ شَيئًا)، فَيَجوزُ أن تُنادِيَهُ الواجهةُ عِندَ كُلِّ
 * ضَغنَةِ مِفتاحٍ. لا مَنَابِرَ ولا حُرَاسَ: عَهدُها أنَّها تُدعَى من خيطِ الشَّاشَةِ.
 */
public final class EditorDirtyLedger {

  /** ما يَلصَقُ بالاسمِ عِندَ العَرضِ: نُقطَةٌ، لا نُجُومٌ تَتَّجِرُ في أسْمَاءِ المِلَفَّاتِ ولا رَقمٌ. */
  public static final String MARK = " \u25cf";

  private final LinkedHashSet<String> dirty = new LinkedHashSet<String>();

  /** لِسانٌ علَيهِ ما لم يُحفَظْ. والإِعلَانُ ثانِيَةً بلا أَثَرٍ: فَلا ضَرورَةَ أن تَحسِبَ الواجهَةُ. */
  public void mark(String tab) {
    if (tab == null || tab.isEmpty()) return;
    dirty.add(tab);
  }

  /** حُفِظَ: تُرفَعُ العَلامَةُ. وغَيرُ المَوسُومِ لا يَمسُّهُ شَيءٌ. */
  public void clear(String tab) {
    if (tab != null) dirty.remove(tab);
  }

  /** لِسانٌ أُغلِقَ أو نُفِيَت ذَاكِرَتُهُ: لا يَبقَى في الدَّفْتَرِ اسمٌ لا لِسانَ لَهُ. */
  public void forget(String tab) {
    if (tab != null) dirty.remove(tab);
  }

  public void clearAll() {
    dirty.clear();
  }

  public boolean isDirty(String tab) {
    return tab != null && dirty.contains(tab);
  }

  public int size() {
    return dirty.size();
  }

  public boolean isEmpty() {
    return dirty.isEmpty();
  }

  /** بالأَولَوِيَّةِ التي وُضِعَت بِها: لا قَبلَ الحَفظِ ولا تَرتِيبًا على الحُروفِ — الحَفظُ تَرتيبِيٌّ. */
  public List<String> dirtyTabs() {
    return Collections.unmodifiableList(new ArrayList<String>(dirty));
  }

  /** الاسمُ كما يُعرَضُ: مُعَلَّمًا إن كانَ علَيهِ تَعديلٌ. وحَرفيًّا إن لم يَكُنْ. */
  public static String decorate(String name, boolean isDirty) {
    String base = strip(name);
    if (base.isEmpty()) return base;
    return isDirty ? base + MARK : base;
  }

  /** النَّصُّ المَكتوبُ على اللِّسَانِ إلى الاسمِ الحَقِيقِيِّ: فَلا «‏Foo.java ●‏» يَصيرُ مَسارًا. */
  public static String strip(String label) {
    if (label == null) return "";
    return label.endsWith(MARK) ? label.substring(0, label.length() - MARK.length()) : label;
  }

  /** هَل هذَهُ العَلامَةُ عَلامَتُنا؟ (للبَوَّابَةِ: لا نَسقٌ آخَرُ يَلصَقُ بالأسْمَاءِ). */
  public static boolean hasMark(String label) {
    return label != null && label.endsWith(MARK);
  }
}
