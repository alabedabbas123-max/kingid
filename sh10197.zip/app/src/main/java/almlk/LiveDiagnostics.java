package almlk;

import com.almlkid.kay.ui.CodeLanguageTools.Diagnostic;
import java.util.ArrayList;
import java.util.List;

/**
 * Checking while typing: the scheduling policy of the editor's background analysis and the mapping
 * of a result computed on an older snapshot onto the text as it is now.
 *
 * <p>A run starts {@link #TYPING_DELAY_MS} after the last keystroke, but continuous typing can never
 * postpone it beyond {@link #MAX_WAIT_MS}; a result that arrives after further edits is not thrown
 * away — the findings outside the edited region are moved onto the current text.
 */
public final class LiveDiagnostics {
  public static final long TYPING_DELAY_MS = 250;
  public static final long MAX_WAIT_MS = 700;
  /** An analysis that has not answered for this long is considered lost (detached view). */
  public static final long STALE_RUN_MS = 8000;
  /**
   * W21′1 — leading edge of a burst: the first edit after quiet is answered almost at once, so a
   * marker appears (or goes away) the moment the user stops for a blink, the way the reference's
   * engine answers the modification it was just fed.
   */
  public static final long FIRST_RUN_DELAY_MS = 60;
  /** Quiet longer than this many typing debounces starts a new burst. */
  public static final long BURST_GAP_MS = TYPING_DELAY_MS * 3;

  private LiveDiagnostics() {}

  /**
   * Delay of the next run when edits have been pending since {@code pendingSince} (0 = none).
   */
  public static long delayFor(long now, long pendingSince, long requested) {
    if (pendingSince <= 0) return Math.max(0, requested);
    long left = MAX_WAIT_MS - (now - pendingSince);
    return Math.max(0, Math.min(requested, left));
  }

  /**
   * The caller's requested delay, lowered to {@link #FIRST_RUN_DELAY_MS} when this edit opens a
   * burst ({@code lastEditAt} is 0 or older than {@link #BURST_GAP_MS}). Keystrokes inside one burst
   * keep the requested debounce, so typing never queues an analysis per character.
   */
  public static long delayForBurst(long now, long lastEditAt, long requested) {
    if (requested <= 0) return 0; // an explicit "now" (reinspectNow) is never slowed down
    if (lastEditAt > 0 && now - lastEditAt < BURST_GAP_MS) return requested;
    return Math.min(requested, FIRST_RUN_DELAY_MS);
  }

  /**
   * Moves {@code found}, computed on {@code analysed}, onto {@code current}: findings before the
   * edited region stay, findings after it shift (fixes dropped until the next run recomputes them),
   * findings touching it are removed.
   */
  public static List<Diagnostic> remap(List<Diagnostic> found, String analysed, String current) {
    if (found == null || found.isEmpty() || analysed == null || current == null) return new ArrayList<>();
    if (analysed.equals(current)) return new ArrayList<>(found);
    int a = analysed.length(), c = current.length();
    int prefix = 0, max = Math.min(a, c);
    while (prefix < max && analysed.charAt(prefix) == current.charAt(prefix)) prefix++;
    int suffix = 0;
    while (suffix < a - prefix && suffix < c - prefix
        && analysed.charAt(a - 1 - suffix) == current.charAt(c - 1 - suffix)) suffix++;
    int oldEnd = a - suffix;
    int delta = c - a;
    int[] starts = null;
    ArrayList<Diagnostic> moved = new ArrayList<>(found.size());
    for (Diagnostic d : found) {
      if (d == null) continue;
      // a finding that touches the edit (a word being extended) is stale: dropped
      if (d.end < prefix) {
        moved.add(d);
      } else if (d.offset > oldEnd) {
        if (starts == null) starts = lineStarts(current);
        int o = d.offset + delta, e = d.end + delta;
        if (o < 0 || o > c) continue;
        int line = lineOf(starts, o);
        moved.add(d.movedTo(o, Math.max(o + 1, e), line + 1, o - starts[line] + 1, delta == 0));
      }
    }
    return moved;
  }

  private static int[] lineStarts(String s) {
    int count = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') count++;
    int[] starts = new int[count];
    int k = 1;
    for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') starts[k++] = i + 1;
    return starts;
  }

  private static int lineOf(int[] starts, int offset) {
    int lo = 0, hi = starts.length - 1;
    while (lo < hi) {
      int mid = (lo + hi + 1) >>> 1;
      if (starts[mid] <= offset) lo = mid;
      else hi = mid - 1;
    }
    return lo;
  }
}
