package almlk;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ما يُعلنُهُ المشروعُ نفسَهُ في ‏`android { signingConfigs { … } }` وربطُ أيِّ نمطِ بناءٍ
 * بهِ — من نصِّ ملفِّ البناءِ وحدَهُ، بلا قرصٍ في خيطِ الواجهةِ وبلا استدعاءِ أداةِ توقيعٍ.
 *
 * <p>المرجعُ يفعلُ ذلكَ بتتبُّعِ شجرةِ ‏Groovy (`android.signingConfigs` ثمَّ
 * `model.android.signingConfigs`) ويحمِلُ نتيجةَ التحليلِ في أربعةِ نصوصٍ وعَلَمَيْنِ، ثمَّ
 * يفتَحُ المرجعُ المخزنَ ويسألُ عن اسمِ المفتاحِ؛ ولا يُنقَلُ من كلِّ ذلكَ إلا
 * قرارُ القراءةِ من ملفِّ البناءِ: لا ‏`jarsigner` عندَنا ولا ‏`zipalign` ولا ‏`gradle
 * assembleRelease` — إملاءُ هذهِ الجولةِ أن ما على القرصِ يُقرَأُ ولا يُبتَدَعُ.
 *
 * <p><b>كلماتُ السرِّ لا تُحمَلُ</b>: الصنفُ يُثبِتُ {@code storePassword} و{@code keyPassword}
 * <i>موجودةٌ</i> أو غائبةٍ، ولا يحفظُ نصَّها في أيِّ حقلٍ ولا في أيِّ ‏`toString` — فكلُّ
 * لوحةٍ أو سِجلٍّ يرثُ عرضَ هذا الصنفِ لا يرثُ سرًّا. والقيمةُ التي فيها ‏`$` (سلسلةُ
 * ‏GString) تُعتبَرُ مُعلَّنةً ولا تُقيَّمُ: لا تقديرَ لمتغيّراتِ ‏Gradle من هنا.
 *
 * <p>صيغُ القراءةِ (‏Groovy و‏kts معًا): ‏`storeFile file('x')`، ‏`storeFile = file('x')`،
 * ‏`storeFile = rootProject.file("x")`، ‏`storePassword = 'x'` و‏`storePassword 'x'`،
 * وأسماءُ التكوينِ ب‏`release { … }` أو ‏`create("release") { … }` أو ‏`getByName("release")
 * { … }`؛ وربطُ النمطِ ب‏`signingConfig signingConfigs.release` أو ‏`= signingConfigs
 * .getByName("release")`.
 *
 * <p>ولا حُكمَ بلا علمٍ: ارتباطُ نمطٍ بتكوينٍ لا يراهُ هذا الملفُّ لا يُبلَّغُ عنهُ —
 * فقدَ يكونُ التعريفُ في ملفِّ الجذرِ أو في ‏`allprojects`، والباطلُ أن ندَّعِيَ غيابَ ما لم
 * نَفْحَصْ. أمّا إذا أعلنَ الملفُّ كتلةَ ‏`signingConfigs` ولم تُعرِّفِ الاسمَ المذكورَ
 * فذاك تعليقٌ حقيقيٌّ في ملفٍّ واحدٍ، ويُذكَرُ كما هو.
 */
public final class GradleSigningConfigs {

  /** أقصى ما يُحمَلُ من تكويناتٍ مُعلَنةٍ في ملفٍّ واحدٍ. */
  public static final int MAX_CONFIGS = 8;
  /** أقصى ما يُحمَلُ من ربطِ أنماطِ البناءِ بالتكويناتِ. */
  public static final int MAX_BINDINGS = 8;
  /** سقفُ نصِّ ملفِّ البناءِ حينَ يُقرَأُ من القرصِ وحدَهُ. */
  public static final int MAX_BUILD_TEXT_BYTES = 256 * 1024;

  /** ما يُعرَضُ بدلَ كلمةِ السرِّ في أيِّ وصفٍ — كلمةٌ لا قيمةٌ. */
  public static final String PASSWORD_SET = "set";
  public static final String PASSWORD_ABSENT = "absent";

  /** تكوينُ توقيعٍ واحدٌ كما كُتِبَ في ملفِّ البناءِ. */
  public static final class Config {
    public final String name;
    /** ‏`storeFile` كما كُتِبَ (نسبيٌّ لمجلدِ الوحدةِ أو مُطلَقٌ)، أو {@code ""}. */
    public final String storeFile;
    /** ‏`keyAlias`، أو {@code ""}. */
    public final String keyAlias;
    public final boolean storePasswordSet;
    public final boolean keyPasswordSet;
    /** موضعُ سطرِ ‏`storeFile` في النصِّ (‏-1 إن لم يُعلَنْ)، لسطرِ العلامةِ وعمودِها. */
    public final int storeFileOffset;
    /** موضعُ رأسِ ‏`storePassword` (‏-1 إن لم تُعلَنْ). موضعٌ لا نصٌّ: السرُّ لا يسكنُ الحالةَ. */
    public final int storePasswordOffset;
    /** {@code true} إن كُتِبَ المسارُ ب‏`rootProject.file(…)` — فيُنسَبُ إلى جذرِ المشروعِ. */
    public final boolean fromRootProject;

    Config(String name, String storeFile, String keyAlias, boolean storePasswordSet,
        boolean keyPasswordSet, int storeFileOffset, int storePasswordOffset,
        boolean fromRootProject) {
      this.name = name == null ? "" : name;
      this.storeFile = storeFile == null ? "" : storeFile;
      this.keyAlias = keyAlias == null ? "" : keyAlias;
      this.storePasswordSet = storePasswordSet;
      this.keyPasswordSet = keyPasswordSet;
      this.storeFileOffset = storeFileOffset;
      this.storePasswordOffset = storePasswordOffset;
      this.fromRootProject = fromRootProject;
    }

    /** وصفٌ للعرضِ: كلُّ شيءٍ عن التكوينِ إلّا كلمةَ السرِّ نفسَها. */
    public String describe() {
      return "signingConfig '" + name + "' storeFile=" + (storeFile.isEmpty() ? "<none>" : storeFile)
          + " keyAlias=" + (keyAlias.isEmpty() ? "<none>" : keyAlias)
          + " storePassword=" + (storePasswordSet ? PASSWORD_SET : PASSWORD_ABSENT)
          + " keyPassword=" + (keyPasswordSet ? PASSWORD_SET : PASSWORD_ABSENT)
          + (fromRootProject ? " rootProject" : "");
    }

    @Override
    public String toString() {
      return describe();
    }
  }

  /** ‏`buildTypes.<نمطٌ>.signingConfig signingConfigs.<اسمٌ>` — ارتباطٌ مَقرُوءٌ. */
  public static final class Binding {
    public final String buildType;
    public final String configName;
    /** موضعُ سطرِ الربطِ في النصِّ (‏-1 إن جهِلَ). */
    public final int offset;
    /** {@code true} إن لم تُعرِّفْ كتلةُ ‏`signingConfigs` هذا الاسمَ. */
    public final boolean dangling;

    Binding(String buildType, String configName, int offset, boolean dangling) {
      this.buildType = buildType == null ? "" : buildType;
      this.configName = configName == null ? "" : configName;
      this.offset = offset;
      this.dangling = dangling;
    }

    @Override
    public String toString() {
      return "buildTypes." + buildType + " -> signingConfigs." + configName
          + (dangling ? " (undefined)" : "");
    }
  }

  /** ما أعلنَهُ ملفُّ بناءٍ واحدٌ. */
  public static final class Model {
    public final List<Config> configs = new ArrayList<>();
    public final List<Binding> bindings = new ArrayList<>();
    /** هل رأى المحلِّلُ كتلةَ ‏`signingConfigs` أصلًا (ولو فارغةً)؟ */
    public boolean declaresConfigsBlock;
    /** الأنماطُ التي لها كتلةٌ في ‏`buildTypes` (بلا نظرٍ في التوقيعِ). */
    public final List<String> buildTypes = new ArrayList<>();

    public boolean isEmpty() {
      return configs.isEmpty() && bindings.isEmpty() && buildTypes.isEmpty();
    }

    public Config byName(String name) {
      if (name == null || name.isEmpty()) return null;
      for (Config config : configs) {
        if (config != null && name.equals(config.name)) return config;
      }
      return null;
    }

    /** اسمُ التكوينِ المُعلَّنِ لنمطٍ، أو {@code ""}. */
    public String configFor(String buildType) {
      if (buildType == null || buildType.isEmpty()) return "";
      for (Binding binding : bindings) {
        if (binding != null && buildType.equals(binding.buildType)) return binding.configName;
      }
      return "";
    }

    /** {@code true} إن كانَ للنمطِ كتلةٌ في ‏`buildTypes` ولا ‏`signingConfig` فيها. */
    public boolean typeWithoutConfig(String buildType) {
      if (buildType == null || buildType.isEmpty() || !buildTypes.contains(buildType)) return false;
      return configFor(buildType).isEmpty();
    }

    @Override
    public String toString() {
      return "configs" + configs + " bindings" + bindings;
    }
  }

  private GradleSigningConfigs() {}

  /** التحليلُ من نصٍّ؛ البياضُ والتلفُّفُ يعني بلا إعلانٍ، لا استثناءً. */
  public static Model of(String buildFileText) {
    Model out = new Model();
    if (buildFileText == null || buildFileText.isEmpty()) return out;
    // بوّابةٌ رخيصةٌ قبلَ أيِّ نسخٍ: التعليقُ يمحو ولا يُضيفُ، فما غابَ في الأصلِ يَغيبُ في
    // النسخةِ البيضاءِ — ومِلَفٌّ لا يذكُرُ التكويناتِ ولا الأنماطَ لا يُستَنْسَخُ لهُ شيءٌ.
    if (indexOfWord(buildFileText, 0, "signingConfigs") < 0
        && indexOfWord(buildFileText, 0, "buildTypes") < 0) return out;
    // الهيكلُ يُلتمَسُ في نسخةٍ بيضاءَ التعليقاتِ، والقيمُ تُقرَأُ من الأصلِ بمواضعِها:
    // ‏`// signingConfigs { … }` سطرٌ مَحْوٌ لا إعلانٌ، ولا يُبتَلَعُ منهُ مجلدٌ ولا تكوينٌ.
    String scan = maskComments(buildFileText);
    int configsAt = indexOfWord(scan, 0, "signingConfigs");
    if (configsAt >= 0) {
      int open = braceAfter(scan, configsAt + "signingConfigs".length());
      if (open >= 0) {
        int close = blockEnd(scan, open);
        // كتلةٌ لم تُغلَقْ: ملفٌّ مقطوعٌ أو مُختلٌّ — نُّخبِرُ بوجودِها ولا نبتدعُ نصفَ إعلانٍ
        out.declaresConfigsBlock = true;
        if (close > open) parseConfigs(scan, buildFileText, open + 1, close, out);
      }
    }
    int typesAt = indexOfWord(scan, 0, "buildTypes");
    if (typesAt >= 0) {
      int open = braceAfter(scan, typesAt + "buildTypes".length());
      if (open >= 0) {
        int close = blockEnd(scan, open);
        if (close > open) parseBuildTypes(scan, buildFileText, open + 1, close, out);
      }
    }
    return out;
  }

  /** نسخةٌ بالمواضعِ نفسِها: أجسادُ التعليقاتِ بيضاءُ (سطرُ ‏`//` وكتلةُ النجمةِ)، والاقباساتُ كما هي. */
  private static String maskComments(String text) {
    char[] out = text.toCharArray();
    int i = 0;
    while (i < out.length) {
      char c = out[i];
      if ((c == '"' || c == '\'')) {
        int end = text.indexOf(c, i + 1);
        if (end < 0) break;
        i = end + 1;
        continue;
      }
      if (c == '/' && i + 1 < out.length && out[i + 1] == '/') {
        int nl = text.indexOf('\n', i);
        int stop = nl < 0 ? out.length : nl;
        for (int k = i; k < stop; k++) out[k] = ' ';
        i = stop;
        continue;
      }
      if (c == '/' && i + 1 < out.length && out[i + 1] == '*') {
        int end = text.indexOf("*/", i + 2);
        int stop = end < 0 ? out.length : end + 2;
        for (int k = i; k < stop; k++) if (out[k] != '\n') out[k] = ' ';
        i = stop;
        continue;
      }
      i++;
    }
    return new String(out);
  }

  /** قراءةُ ملفِّ البناءِ للوحدةِ (‏`build.gradle` ثمَّ ‏`build.gradle.kts`) وتحليلُهُ. */
  public static Model ofModule(File moduleDir) {
    if (moduleDir == null) return new Model();
    String text = readText(new File(moduleDir, "build.gradle"));
    if (text.isEmpty()) text = readText(new File(moduleDir, "build.gradle.kts"));
    return of(text);
  }

  /**
   * مسارُ المخزنِ المُعلَنُ محمولًا على مجلدِ الوحدةِ: المُطلَقُ كما هو، والنسبيُّ يُنسَبُ؛
   * بلا علمٍ ‏{@code null}. لا يُسأَلُ القرصُ هنا — الموجودُ من عدمِهِ قرارُ صاحبِ العلامةِ.
   */
  public static File resolveStore(File moduleDir, String declared) {
    return resolveStore(moduleDir, null, declared, false);
  }

  /** كما ‏{@link #resolveStore(File, String)} مع أصلٍ معلومٍ: جذرُ المشروعِ أو مجلدُ الوحدةِ. */
  public static File resolveStore(File moduleDir, File projectRoot, String declared,
      boolean fromRootProject) {
    if (declared == null || declared.isEmpty()) return null;
    if (declared.charAt(0) == '/') return new File(declared);
    File base = fromRootProject && projectRoot != null ? projectRoot : moduleDir;
    if (base == null) return new File(declared);
    return new File(base, declared);
  }

  /** هل ذُكِرَتِ الكتلةُ في النصِّ؟ (سؤالٌ رخيصٌ يُوفِّرُ تحليلًا حينَ لا مسألةَ) */
  public static boolean mentionsSigningConfigs(String buildFileText) {
    return buildFileText != null && indexOfWord(buildFileText, 0, "signingConfigs") >= 0;
  }

  // ═══════════════ داخلَ الكتلتَيْنِ ═══════════════

  /** ‏`release { … }`، ‏`create("release") { … }`، ‏`getByName("release") { … }`, ‏`named(…)`. */
  private static void parseConfigs(String scan, String vals, int from, int to, Model out) {
    int at = from;
    while (at < to && out.configs.size() < MAX_CONFIGS) {
      int start = nextSignificant(scan, at, to);
      if (start < 0) break;
      int nameAt = blockName(scan, start, to);
      if (nameAt < 0) break;
      String name = readQuotedOrName(vals, nameAt);
      int open = braceAfter(scan, start);
      if (open < 0 || open > to) {
        at = nameAt + 1;
        continue;
      }
      int close = blockEnd(scan, open);
      if (close < 0 || close > to) break; // كتلةٌ داخلَها مُختلّةٌ: لا نَخْمُنْ
      int body = close;
      Config config = readConfig(scan, vals, open + 1, body, name.isEmpty() ? "\u00abunnamed\u00bb" : name);
      if (config != null && !containsName(out, config.name)) out.configs.add(config);
      at = body + 1;
    }
  }

  private static Config readConfig(String scan, String vals, int from, int to, String name) {
    String storeFile = "";
    String keyAlias = "";
    boolean storePasswordSet = false;
    boolean keyPasswordSet = false;
    int storeFileOffset = -1;
    int storePasswordOffset = -1;
    boolean fromRootProject = false;
    int at = from;
    while (at < to) {
      int start = nextSignificant(scan, at, to);
      if (start < 0) break;
      String prop = readName(scan, start, to);
      if (prop.isEmpty()) break;
      int value = valueStart(scan, start + prop.length(), to);
      int stop = value < 0 ? endOfLine(scan, start + prop.length(), to) : Math.min(valueEnd(scan, value, to), to);
      if (stop <= value) stop = to;
      String bare = bareName(prop);
      if (value >= 0) {
        if (bare.equals("storeFile")) {
          String found = firstQuoted(vals, value, stop);
          if (!found.isEmpty() && storeFile.isEmpty()) {
            storeFile = found;
            storeFileOffset = start;
            // ‏`rootProject.file(…)` عنوانُهُ من جذرِ المشروعِ لا من مجلدِ الوحدةِ
            fromRootProject = beginsWithRoot(scan, value, stop);
          }
        } else if (bare.equals("keyAlias")) {
          String found = firstQuoted(vals, value, stop);
          if (!found.isEmpty() && keyAlias.isEmpty()) keyAlias = found;
        } else if (bare.equals("storePassword")) {
          if (declaresValue(scan, value, stop)) {
            storePasswordSet = true;
            if (storePasswordOffset < 0) storePasswordOffset = start;
          }
        } else if (bare.equals("keyPassword")) {
          keyPasswordSet = keyPasswordSet || declaresValue(scan, value, stop);
        }
      }
      at = Math.max(stop, start + prop.length());
    }
    if (storeFile.isEmpty() && keyAlias.isEmpty() && !storePasswordSet && !keyPasswordSet) return null;
    return new Config(name, storeFile, keyAlias, storePasswordSet, keyPasswordSet, storeFileOffset,
        storePasswordOffset, fromRootProject);
  }

  /** أنماطُ ‏`buildTypes`: اسمُ النمطِ و‏`signingConfig` إن وُجِدَ في كتلتِهِ. */
  private static void parseBuildTypes(String scan, String vals, int from, int to, Model out) {
    int at = from;
    while (at < to) {
      int start = nextSignificant(scan, at, to);
      if (start < 0) break;
      int nameAt = blockName(scan, start, to);
      if (nameAt < 0) break;
      String type = readQuotedOrName(vals, nameAt);
      int open = braceAfter(scan, start);
      if (open < 0 || open > to) {
        at = nameAt + 1;
        continue;
      }
      int close = blockEnd(scan, open);
      if (close < 0 || close > to) break;
      int body = close;
      if (!type.isEmpty() && !out.buildTypes.contains(type)) out.buildTypes.add(type);
      int cursor = open + 1;
      while (cursor < body && out.bindings.size() < MAX_BINDINGS) {
        int prop = nextSignificant(scan, cursor, body);
        if (prop < 0) break;
        String name = readName(scan, prop, body);
        if (name.isEmpty()) break;
        int value = valueStart(scan, prop + name.length(), body);
        int stop = value < 0 ? endOfLine(scan, prop + name.length(), body)
            : Math.min(valueEnd(scan, value, body), body);
        if (value >= 0 && bareName(name).equals("signingConfig")) {
          String ref = configRef(scan, vals, value, stop);
          if (!ref.isEmpty()) {
            boolean dangling = out.declaresConfigsBlock && out.byName(ref) == null;
            if (!hasBinding(out, type, ref)) out.bindings.add(new Binding(type, ref, prop, dangling));
          }
        }
        cursor = Math.max(stop, prop + name.length());
      }
      at = body + 1;
    }
  }

  private static boolean hasBinding(Model out, String type, String ref) {
    for (Binding binding : out.bindings) {
      if (binding != null && binding.buildType.equals(type) && binding.configName.equals(ref)) return true;
    }
    return false;
  }

  private static boolean containsName(Model out, String name) {
    return out.byName(name) != null;
  }

  /** ما بعدَ ‏`signingConfigs.` : اسمٌ بسيطٌ، أو ‏`getByName("x")`/‏`named("x")`/‏`["x"]`. */
  private static String configRef(String scan, String vals, int from, int to) {
    if (from < 0) return "";
    int dot = scan.indexOf('.', from);
    int base = dot >= 0 && dot < to ? dot + 1 : from;
    int at = nextSignificant(scan, base, to);
    if (at < 0 || at >= to) return "";
    if (scan.charAt(at) == '[') return firstQuoted(vals, at + 1, to);
    String name = readName(scan, at, to);
    int open = name.indexOf('(');
    if (open >= 0) {
      String method = name.substring(0, open);
      if (method.equals("getByName") || method.equals("named") || method.equals("findByName")
          || method.equals("maybeCreate") || method.equals("getAt")) {
        return firstQuoted(vals, at + method.length() + 1, to);
      }
      return "";
    }
    return name;
  }

  /** هل تبدأُ القيمةُ ب‏`rootProject.` (أو ‏`project.rootProject.`)؟ */
  private static boolean beginsWithRoot(String scan, int from, int to) {
    int at = nextSignificant(scan, from, to);
    if (at < 0) return false;
    String head = readIdent(scan, at, to);
    if (head.equals("rootProject")) return true;
    if (head.isEmpty() || head.equals("file")) return false;
    int dot = scan.indexOf('.', at);
    while (dot >= 0 && dot < to) {
      String word = readIdent(scan, dot + 1, to);
      if (word.equals("rootProject")) return true;
      if (!Character.isJavaIdentifierStart(scan.charAt(dot + 1))) return false;
      int next = scan.indexOf('.', dot + 1);
      if (next < 0 || next >= to || next <= dot) return false;
      dot = next;
    }
    return false;
  }

  /** هل للقيمةِ نصٌّ أو مُعرِّفٌ (أيْ: كلمةُ سرٍّ مُعلَّنةٌ، بأيِّ وسيلةٍ جُمِعَتْ)؟ */
  /**
   * حروفُ ‏`storePassword` كما كُتِبَت في المِلَفِّ، تُقرَأُ وقتَ فتحِ المخزنِ وحدَهُ: لا تدخُلُ
   * الحالةَ ولا الوصفَ ولا العلامةَ، ومَن يَأخُذُها يَمحوها ({@code KeystoreInspector} يَمحوها قبلَ
   * الرجوعِ). {@code null} إن لم تُعلَنْ، أو كانتْ سلسلةَ استبدالٍ لا نصَّ لهُ عندَنا.
   */
  public static char[] readStorePassword(String buildFileText, Config config) {
    if (buildFileText == null || config == null || !config.storePasswordSet
        || config.storePasswordOffset < 0 || config.storePasswordOffset >= buildFileText.length()) {
      return null;
    }
    int from = config.storePasswordOffset;
    String head = readName(buildFileText, from, buildFileText.length());
    if (head.isEmpty() || !bareName(head).equals("storePassword")) return null;
    int lineEnd = endOfLine(buildFileText, from, buildFileText.length());
    int value = valueStart(buildFileText, from + head.length(), lineEnd);
    if (value < 0) return null;
    int stop = Math.min(valueEnd(buildFileText, value, lineEnd), lineEnd);
    String found = firstQuoted(buildFileText, value, stop);
    // «‏$» معناه استبدالٌ من متغيِّراتِ نظامِ البناءِ: لا نَحِلُّهُ، ولا نَرمي بنصفِهِ على القرصِ.
    if (found.isEmpty() || found.indexOf('$') >= 0) return null;
    return found.toCharArray();
  }

  private static boolean declaresValue(String text, int from, int to) {
    if (from < 0) return false;
    int at = nextSignificant(text, from, to);
    if (at < 0 || at >= to) return false;
    char c = text.charAt(at);
    if (c == '"' || c == '\'') {
      int end = text.indexOf(c, at + 1);
      return end > at + 1 && (to <= 0 || end <= to);
    }
    return Character.isJavaIdentifierStart(c) || c == '$';
  }

  /** اسمُ الكتلةِ: إمّا عاريًا، أو بعدَ ‏`create`/‏`getByName`/‏`named` بينَ قوسَيْنِ. */
  private static int blockName(String text, int from, int to) {
    int at = from;
    while (at < to) {
      int word = nextSignificant(text, at, to);
      if (word < 0) return -1;
      char c = text.charAt(word);
      if (c == '"') return word + 1;
      if (!Character.isJavaIdentifierStart(c)) {
        at = word + 1;
        continue;
      }
      String name = readIdent(text, word, to);
      int after = skipWord(text, word, to);
      if (after >= 0 && after < to && text.charAt(after) == '('
          && (name.equals("create") || name.equals("getByName") || name.equals("named")
              || name.equals("maybeCreate") || name.equals("register") || name.equals("findByName"))) {
        int q = nextSignificant(text, after + 1, to);
        if (q < 0 || q >= to) return -1;
        char quote = text.charAt(q);
        if (quote == '"' || quote == '\'') return q + 1;
        return q;
      }
      return word;
    }
    return -1;
  }

  /** قوسُ الفتحِ الذي يلي الموضعَ مباشرةً (يتجاوزُ ‏`(…)` في ‏`create("x")`). */
  private static int braceAfter(String text, int from) {
    int at = from;
    int depth = 0;
    while (at >= 0 && at < text.length()) {
      char c = text.charAt(at);
      if (c == '(') depth++;
      else if (c == ')') {
        if (depth > 0) depth--;
      } else if (c == '{' && depth == 0) return at;
      else if (c == '"' || c == '\'') {
        int end = text.indexOf(c, at + 1);
        if (end < 0) return -1;
        at = end;
      } else if (depth == 0 && c == '}') return -1;
      at++;
    }
    return -1;
  }

  private static int skipWord(String text, int from, int to) {
    int at = from;
    while (at < to && (Character.isJavaIdentifierPart(text.charAt(at)) || text.charAt(at) == '.')) at++;
    return at;
  }

  private static String readQuotedOrName(String text, int at) {
    if (at < 0 || at >= text.length()) return "";
    char c = text.charAt(at);
    if (c == '"' || c == '\'') {
      int end = text.indexOf(c, at + 1);
      return end < 0 ? "" : text.substring(at + 1, end).trim();
    }
    return readName(text, at, Math.min(text.length(), at + 64));
  }

  /** ‏`storeFile` و‏`storeFile(` و‏`setStoreFile` — تُرَدُّ كلُّها إلى اسمِ الخاصيّةِ. */
  private static String bareName(String name) {
    if (name == null || name.isEmpty()) return "";
    String head = name;
    int paren = head.indexOf('(');
    if (paren >= 0) head = head.substring(0, paren);
    int dot = head.lastIndexOf('.');
    if (dot >= 0) head = head.substring(dot + 1);
    if (head.length() > 3 && head.startsWith("set") && Character.isUpperCase(head.charAt(3))) {
      head = Character.toLowerCase(head.charAt(3)) + head.substring(4);
    }
    return head;
  }

  /** اسمٌ بسيطٌ بلا أقواسٍ ولا نقاطٍ: ‏`create` و‏`getByName` و‏`release`. */
  private static String readIdent(String text, int at, int to) {
    int i = Math.max(0, at);
    while (i < to && Character.isJavaIdentifierPart(text.charAt(i))) i++;
    return text.substring(Math.max(0, at), i);
  }

  private static String readName(String text, int at, int to) {
    int i = Math.max(0, at);
    while (i < to && (Character.isJavaIdentifierPart(text.charAt(i)) || text.charAt(i) == '.'
        || text.charAt(i) == '-' || text.charAt(i) == '(' )) i++;
    return text.substring(Math.max(0, at), i);
  }

  /** أينَ يبدأُ نصُّ القيمةِ: بعدَ ‏`=` أو ‏`+=`، أو بعدَ قوسِ الدالّةِ، أو تعبيرٌ في سطرِها. */
  private static int valueStart(String text, int from, int to) {
    int at = nextSignificant(text, from, to);
    if (at < 0 || at >= to) return -1;
    char c = text.charAt(at);
    if (c == '+') {
      int eq = nextSignificant(text, at + 1, to);
      if (eq < 0 || eq >= to || text.charAt(eq) != '=') return -1;
      return nextSignificant(text, eq + 1, to);
    }
    if (c == '=') return nextSignificant(text, at + 1, to);
    if (c == '(' || c == '"' || c == '\'') return at;
    // ‏`storeFile file('x')` و‏`signingConfig signingConfigs.rel`: قيمةٌ عاريَةٌ في سطرِها.
    // أمّا اسمٌ في سطرٍ تالٍ فليس قيمَتَنا: الخاصيّةُ بلا قيمةٍ تُترَكُ كما هي.
    if (Character.isJavaIdentifierStart(c)) {
      int nl = text.indexOf('\n', from);
      return (nl >= 0 && nl < at) ? -1 : at;
    }
    return -1;
  }

  /**
   * نهايةُ القيمةِ: سطرٌ نصّيٌّ كاملٌ عندَ الاقتباسِ، ومجموعةُ أقواسٍ مُتوازنةٌ عندَ ‏`file(…)`,
   * أو مَدى كلمةٍ واحدةٍ؛ وما بعدها سطرٌ آخرُ لا قيمةُ هذهِ الخاصيّةِ.
   */
  private static int valueEnd(String scan, int from, int to) {
    int at = from;
    if (at < 0 || at >= to) return to < 0 ? at : to;
    char first = scan.charAt(at);
    if (first == '"' || first == '\'') {
      int end = scan.indexOf(first, at + 1);
      return end < 0 ? at + 1 : Math.min(end + 1, to);
    }
    if (first != '(') {
      int open = scan.indexOf('(', at);
      int space = indexOfAny(scan, " \n;", at, to);
      if (open >= 0 && open < to && (space < 0 || open < space)) {
        int close = matchParen(scan, open, to);
        return close < 0 ? to : close + 1;
      }
      int stop = space < 0 ? to : Math.min(space, to);
      return stop <= at ? to : stop;
    }
    int close = matchParen(scan, at, to);
    return close < 0 ? to : close + 1;
  }

  /** موازنةُ ‏`(…)` مع تجاهلِ ما داخلَ الاقتباسِ؛ يُعيدُ موضعَ القوسِ الأخيرِ أو ‏-1. */
  private static int matchParen(String text, int openParen, int to) {
    int depth = 0;
    for (int i = openParen; i < to; i++) {
      char c = text.charAt(i);
      if (c == '"' || c == '\'') {
        int end = text.indexOf(c, i + 1);
        if (end < 0 || end >= to) return -1;
        i = end;
        continue;
      }
      if (c == '(') depth++;
      else if (c == ')') {
        if (--depth == 0) return i;
      }
    }
    return -1;
  }

  private static int indexOfAny(String text, String marks, int from, int to) {
    for (int i = Math.max(0, from); i < to; i++) {
      if (marks.indexOf(text.charAt(i)) >= 0) return i;
    }
    return -1;
  }

  private static int endOfLine(String text, int from, int to) {
    int nl = text.indexOf('\n', Math.max(0, from));
    return nl < 0 || nl > to ? to : nl;
  }

  /** تجاوزُ ما بقيَ من السطرِ — فلا ابتلاعَ لسطرٍ تالٍ ولا دورةً بلا نهايةٍ. */
  private static int skipStatement(String text, int from, int to) {
    int at = Math.max(from, 0);
    int depth = 0;
    while (at < to) {
      char c = text.charAt(at);
      if (c == '\'' || c == '"') {
        int end = text.indexOf(c, at + 1);
        if (end < 0 || end > to) return to;
        at = end + 1;
        continue;
      }
      if (c == '[' || c == '(' || c == '{') depth++;
      else if (c == ']' || c == ')' || c == '}') {
        if (depth == 0) return at + 1;
        depth--;
      } else if ((c == '\n' || c == ';') && depth == 0) return at + 1;
      at++;
    }
    return to;
  }

  /** أوّلُ سلسلةٍ نصّيّةٍ في المدى؛ ما فيها ‏`$` لا يُحمَلُ. */
  private static String firstQuoted(String text, int from, int to) {
    if (from < 0) return "";
    int limit = to < 0 ? text.length() : Math.min(to, from + 256);
    int quote = nextQuote(text, from, limit);
    if (quote < 0) return "";
    char mark = text.charAt(quote);
    int end = text.indexOf(mark, quote + 1);
    if (end < 0 || (to > 0 && end > to)) return "";
    String value = text.substring(quote + 1, end).trim();
    return value.indexOf('$') >= 0 || value.indexOf('\\') >= 0 ? "" : value;
  }

  private static int nextQuote(String text, int from, int to) {
    for (int i = Math.max(0, from); i < to; i++) {
      char c = text.charAt(i);
      if (c == '"' || c == '\'') return i;
    }
    return -1;
  }

  private static int nextSignificant(String text, int from, int to) {
    int at = Math.max(0, from);
    int limit = to < 0 ? text.length() : to;
    while (at < limit) {
      char c = text.charAt(at);
      if (c == '/' && at + 1 < limit && text.charAt(at + 1) == '/') {
        int nl = text.indexOf('\n', at);
        if (nl < 0 || nl > limit) return -1;
        at = nl + 1;
        continue;
      }
      if (c == '/' && at + 1 < limit && text.charAt(at + 1) == '*') {
        int end = text.indexOf("*/", at + 2);
        if (end < 0 || end > limit) return -1;
        at = end + 2;
        continue;
      }
      if (!Character.isWhitespace(c)) return at;
      at++;
    }
    return -1;
  }

  /** موضعُ كلمةٍ مستقلّةٍ (لا ذيلَ اسمٍ ولا جزءَ مسارٍ)، أو ‏-1. */
  private static int indexOfWord(String text, int from, String word) {
    int at = text.indexOf(word, Math.max(0, from));
    while (at >= 0) {
      boolean leftOk = at == 0 || !Character.isJavaIdentifierPart(text.charAt(at - 1));
      int after = at + word.length();
      boolean rightOk = after >= text.length() || !Character.isJavaIdentifierPart(text.charAt(after));
      if (leftOk && rightOk) return at;
      at = text.indexOf(word, after);
    }
    return -1;
  }

  /** مطابقةُ الأقواسِ مع تجاهلِ ما داخلَ الاقتباسِ؛ كتلةٌ غيرُ مُغلَقةٍ تُترَكُ مفتوحةً. */
  private static int blockEnd(String text, int openBrace) {
    int depth = 0;
    for (int i = openBrace; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '"' || c == '\'') {
        int end = text.indexOf(c, i + 1);
        if (end < 0) return -1;
        i = end;
        continue;
      }
      if (c == '{') depth++;
      else if (c == '}') {
        if (--depth == 0) return i;
      }
    }
    return -1;
  }

  static String readText(File file) {
    if (file == null || !file.isFile()) return "";
    long length = file.length();
    if (length <= 0 || length > MAX_BUILD_TEXT_BYTES) return "";
    try (InputStream in = new FileInputStream(file)) {
      byte[] buffer = new byte[(int) length];
      int got = 0;
      while (got < buffer.length) {
        int read = in.read(buffer, got, buffer.length - got);
        if (read <= 0) break;
        got += read;
      }
      return new String(buffer, 0, got, StandardCharsets.UTF_8);
    } catch (java.io.IOException unreadable) {
      return "";
    }
  }

  /** قائمةٌ فارغةٌ حينَ لا إعلانَ — لا {@code null} في أيِّ مَخرَجٍ. */
  public static List<String> names(Model model) {
    if (model == null || model.configs.isEmpty()) return Collections.emptyList();
    ArrayList<String> out = new ArrayList<>();
    for (Config config : model.configs) {
      if (config != null) out.add(config.name);
    }
    return out;
  }
}
