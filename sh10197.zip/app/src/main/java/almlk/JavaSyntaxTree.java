package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Syntax tree of the analysis engine (E1): the nodes {@link JavaParser} builds and {@link
 * JavaAttributor} walks. Fields are plain and public for speed; every node records its source range
 * ({@code start} inclusive, {@code end} exclusive) and named declarations keep the offset of their
 * name so diagnostics land on the identifier.
 */
public final class JavaSyntaxTree {

  private JavaSyntaxTree() {}

  // ───────────────────────────── modifiers ─────────────────────────────

  public static final int PUBLIC = 1;
  public static final int PRIVATE = 1 << 1;
  public static final int PROTECTED = 1 << 2;
  public static final int STATIC = 1 << 3;
  public static final int FINAL = 1 << 4;
  public static final int ABSTRACT = 1 << 5;
  public static final int DEFAULT = 1 << 6;
  public static final int NATIVE = 1 << 7;
  public static final int SYNCHRONIZED = 1 << 8;
  public static final int TRANSIENT = 1 << 9;
  public static final int VOLATILE = 1 << 10;
  public static final int STRICTFP = 1 << 11;
  public static final int SEALED = 1 << 12;
  public static final int NON_SEALED = 1 << 13;

  public abstract static class Node {
    public int start;
    public int end;
  }

  public static final class Modifiers {
    public int flags;
    public List<Annotation> annotations = Collections.emptyList();

    public boolean has(int flag) {
      return (flags & flag) != 0;
    }
  }

  public static final class Annotation extends Node {
    public TypeRef type;
    /** Element values (named or the single value); names parallel, null for the single form. */
    public final List<Expr> values = new ArrayList<>();
    public final List<String> names = new ArrayList<>();
  }

  // ───────────────────────────── types ─────────────────────────────

  public static final class TypeRef extends Node {
    /** Primitive keyword or {@code void}; null for class types. */
    public String primitive;
    public final List<String> names = new ArrayList<>();
    public final List<Integer> nameStarts = new ArrayList<>();
    /** Type arguments per name segment (null = none, empty = diamond). */
    public final List<List<TypeRef>> args = new ArrayList<>();
    public int dims;
    public boolean varargs;
    /** 0 = not a wildcard, 1 = {@code ?}, 2 = {@code ? extends B}, 3 = {@code ? super B}. */
    public int wildcard;
    public TypeRef bound;
    /** {@code var} in a local declaration or lambda parameter. */
    public boolean inferred;

    public String simpleName() {
      return names.isEmpty() ? (primitive == null ? "" : primitive) : names.get(names.size() - 1);
    }

    public String qualified() {
      if (primitive != null) return primitive;
      StringBuilder b = new StringBuilder();
      for (String n : names) {
        if (b.length() > 0) b.append('.');
        b.append(n);
      }
      return b.toString();
    }

    /** Source-like text without generics, e.g. {@code Map.Entry[]}. */
    public String display() {
      StringBuilder b = new StringBuilder(qualified());
      for (int i = 0; i < dims; i++) b.append("[]");
      if (varargs) b.append("...");
      return b.toString();
    }
  }

  public static final class TypeParam extends Node {
    public String name;
    public int nameStart;
    public final List<TypeRef> bounds = new ArrayList<>();
  }

  // ───────────────────────────── declarations ─────────────────────────────

  public static final class Unit extends Node {
    public String packageName = "";
    public int packageStart = -1;
    public int packageEnd = -1;
    public final List<Import> imports = new ArrayList<>();
    public final List<TypeDecl> types = new ArrayList<>();
    /** Syntax errors met while parsing: {offset, end} pairs with a message each. */
    public final List<int[]> errorRanges = new ArrayList<>();
    public final List<String> errorMessages = new ArrayList<>();
  }

  public static final class Import extends Node {
    public String name;
    public boolean isStatic;
    public boolean onDemand;
    public int nameStart;
    public int nameEnd;
    public final List<Integer> segmentStarts = new ArrayList<>();
  }

  public static final int CLASS = 0;
  public static final int INTERFACE = 1;
  public static final int ENUM = 2;
  public static final int RECORD = 3;
  public static final int ANNOTATION = 4;

  public abstract static class Member extends Node {}

  public static final class TypeDecl extends Member {
    public int kind;
    public Modifiers mods = new Modifiers();
    public String name = "";
    public int nameStart;
    public final List<TypeParam> typeParams = new ArrayList<>();
    public TypeRef superclass;
    public final List<TypeRef> interfaces = new ArrayList<>();
    public final List<VarDecl> recordComponents = new ArrayList<>();
    public final List<EnumConstant> constants = new ArrayList<>();
    public final List<Member> members = new ArrayList<>();
    public boolean local;
    public boolean anonymous;
    public int bodyStart;
    public int bodyEnd;
  }

  public static final class FieldDecl extends Member {
    public Modifiers mods;
    public TypeRef type;
    public final List<VarDecl> vars = new ArrayList<>();
  }

  public static final class VarDecl extends Node {
    public Modifiers mods = new Modifiers();
    /** Declared type; null for an implicit lambda parameter. */
    public TypeRef type;
    public String name = "";
    public int nameStart;
    public int extraDims;
    public Expr init;
  }

  public static final class MethodDecl extends Member {
    public Modifiers mods = new Modifiers();
    public final List<TypeParam> typeParams = new ArrayList<>();
    /** Result type; null for constructors. */
    public TypeRef result;
    public String name = "";
    public int nameStart;
    public final List<VarDecl> params = new ArrayList<>();
    public final List<TypeRef> thrown = new ArrayList<>();
    public Block body;
    public boolean constructor;
    /** Record compact canonical constructor {@code Name { ... }}. */
    public boolean compact;
    public Expr defaultValue;
    /** Parsed in skeleton mode: the body exists but was skipped. */
    public boolean bodySkipped;

    public boolean varargs() {
      return !params.isEmpty() && params.get(params.size() - 1).type != null
          && params.get(params.size() - 1).type.varargs;
    }
  }

  public static final class Initializer extends Member {
    public boolean isStatic;
    public Block body;
  }

  public static final class EnumConstant extends Node {
    public Modifiers mods = new Modifiers();
    public String name;
    public int nameStart;
    public List<Expr> args;
    public TypeDecl body;
  }

  // ───────────────────────────── statements ─────────────────────────────

  public abstract static class Stmt extends Node {}

  public static final class Block extends Stmt {
    public final List<Stmt> stmts = new ArrayList<>();
  }

  public static final class LocalVars extends Stmt {
    public Modifiers mods;
    public TypeRef type;
    public final List<VarDecl> vars = new ArrayList<>();
  }

  public static final class LocalClass extends Stmt {
    public TypeDecl decl;
  }

  public static final class ExprStmt extends Stmt {
    public Expr expr;
  }

  public static final class If extends Stmt {
    public Expr cond;
    public Stmt then;
    public Stmt otherwise;
  }

  public static final class While extends Stmt {
    public Expr cond;
    public Stmt body;
  }

  public static final class DoWhile extends Stmt {
    public Stmt body;
    public Expr cond;
  }

  public static final class For extends Stmt {
    public final List<Stmt> init = new ArrayList<>();
    public Expr cond;
    public final List<Expr> update = new ArrayList<>();
    public Stmt body;
  }

  public static final class ForEach extends Stmt {
    public VarDecl var;
    public Expr iterable;
    public Stmt body;
  }

  public static final class Return extends Stmt {
    public Expr value;
  }

  public static final class Jump extends Stmt {
    public boolean isBreak;
    public String label;
    public int labelStart;
  }

  public static final class Throw extends Stmt {
    public Expr value;
  }

  public static final class Try extends Stmt {
    /** {@link VarDecl} or {@link Expr} resources. */
    public final List<Node> resources = new ArrayList<>();
    public Block body;
    public final List<Catch> catches = new ArrayList<>();
    public Block fin;
  }

  public static final class Catch extends Node {
    public Modifiers mods;
    public final List<TypeRef> types = new ArrayList<>();
    public String name = "";
    public int nameStart;
    public Block body;
  }

  public static final class Switch extends Stmt {
    public Expr selector;
    public final List<Case> cases = new ArrayList<>();
  }

  public static final class Case extends Node {
    public final List<Expr> labels = new ArrayList<>();
    public boolean isDefault;
    public boolean arrow;
    public Expr guard;
    public final List<Stmt> body = new ArrayList<>();
  }

  public static final class Synchronized extends Stmt {
    public Expr lock;
    public Block body;
  }

  public static final class Labeled extends Stmt {
    public String label;
    public int labelStart;
    public Stmt body;
  }

  public static final class Yield extends Stmt {
    public Expr value;
  }

  public static final class Assert extends Stmt {
    public Expr cond;
    public Expr message;
  }

  public static final class Empty extends Stmt {}

  // ───────────────────────────── expressions ─────────────────────────────

  public abstract static class Expr extends Node {}

  public static final int LIT_INT = 1;
  public static final int LIT_LONG = 2;
  public static final int LIT_FLOAT = 3;
  public static final int LIT_DOUBLE = 4;
  public static final int LIT_CHAR = 5;
  public static final int LIT_STRING = 6;
  public static final int LIT_BOOLEAN = 7;
  public static final int LIT_NULL = 8;

  public static final class Literal extends Expr {
    public int kind;
  }

  public static final class Name extends Expr {
    public String id;
  }

  public static final class Select extends Expr {
    public Expr target;
    public String name;
    public int nameStart;
  }

  public static final class Call extends Expr {
    /** Receiver; null for an unqualified call or {@code this(...)}/{@code super(...)}. */
    public Expr target;
    public List<TypeRef> typeArgs;
    public String name;
    public int nameStart;
    public final List<Expr> args = new ArrayList<>();
    public int argsEnd;
  }

  public static final class NewObject extends Expr {
    public Expr outer;
    public TypeRef type;
    public final List<Expr> args = new ArrayList<>();
    public TypeDecl body;
  }

  public static final class NewArray extends Expr {
    public TypeRef elementType;
    public final List<Expr> dimExprs = new ArrayList<>();
    public int dims;
    public ArrayInit init;
  }

  public static final class ArrayInit extends Expr {
    public final List<Expr> elements = new ArrayList<>();
  }

  public static final class Index extends Expr {
    public Expr array;
    public Expr index;
  }

  public static final class Unary extends Expr {
    public String op;
    public boolean postfix;
    public Expr operand;
  }

  public static final class Binary extends Expr {
    public String op;
    public Expr left;
    public Expr right;
  }

  public static final class Assign extends Expr {
    public String op;
    public Expr target;
    public Expr value;
  }

  public static final class Conditional extends Expr {
    public Expr cond;
    public Expr whenTrue;
    public Expr whenFalse;
  }

  public static final class Cast extends Expr {
    public TypeRef type;
    public final List<TypeRef> extraBounds = new ArrayList<>();
    public Expr operand;
  }

  public static final class InstanceOf extends Expr {
    public Expr operand;
    public TypeRef type;
    public Pattern pattern;
  }

  /** Type pattern {@code Type name} or record pattern {@code Type(p1, p2)}. */
  public static final class Pattern extends Expr {
    public TypeRef type;
    public String binding;
    public int bindingStart;
    public List<Pattern> nested;
  }

  public static final class Lambda extends Expr {
    public final List<VarDecl> params = new ArrayList<>();
    /** {@link Expr} or {@link Block}. */
    public Node body;
  }

  public static final class MethodRef extends Expr {
    public Expr target;
    public TypeRef typeTarget;
    public String name;
    public int nameStart;
  }

  public static final class This extends Expr {
    /** {@code Outer.this}: the qualifying type name; null for plain {@code this}. */
    public Expr qualifier;
  }

  public static final class Super extends Expr {
    public Expr qualifier;
  }

  public static final class ClassLit extends Expr {
    public TypeRef type;
  }

  public static final class SwitchExpr extends Expr {
    public Expr selector;
    public final List<Case> cases = new ArrayList<>();
  }

  public static final class Paren extends Expr {
    public Expr inner;
  }

  /** A type in expression position, e.g. {@code int[]::new} or {@code List<String>::size}. */
  public static final class TypeExpr extends Expr {
    public TypeRef type;
  }

  public static final class ErrorExpr extends Expr {}
}
