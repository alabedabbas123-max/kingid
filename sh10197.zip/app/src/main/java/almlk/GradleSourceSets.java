package almlk;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * ما يُعلنُهُ المشروعُ نفسَهُ في ‏`android { sourceSets { … } }` — لا عُرفَ ‏Gradle.
 *
 * <p>المرجعُ لا يقرَأُ هذهِ الكتلةَ إطلاقًا (صفرُ ورودٍ لها في حمولتِهِ: جذورُهُ من
 * ‏`project.properties` و‏`.classpath`)، فلا واجهةَ تُنقَلُ ولا شاشةً تُختَرعُ؛ المطلوبُ
 * عندَنا أن تُصدَّقَ كلمةُ المشروعِ: إن قالَ ‏`main.java.srcDirs = ['code']` فذاك مجلدُ
 * مصادرِهِ، وما لم يقلْهُ لا يُفهرَسُ. لذا تُقبَلُ مجموعةُ ‏`main` (والوضعُ بلا مجموعةٍ
 * صريحةٍ) وحدَها — أمّا ‏`test` و‏`androidTest` والمجموعاتُ المخصّصةُ فسياستُنا القائمةُ
 * تُخرِجُها من الفهرسةِ، ولا معنى أن يُخالَفَ ذلكَ من بابِ الدعمِ.
 *
 * <p>الصيَغُ المدعومةُ (‏Groovy و‏kts معًا): ‏`srcDirs = ['a','b']`، ‏`srcDirs += ['a']`،
 * ‏`setSrcDirs(['a'])`، ‏`setSrcDirs(listOf("a"))`، ‏`srcDir 'a'`، وللمانيفستِ ‏`srcFile =
 * file('a.xml')` و‏`srcFile 'a.xml'` و‏`setSrcFile(file("a.xml"))`. و‏`fileTree(...)` لا
 * يُحمَلُ (شجرَةُ ملفاتٍ لا مجلدٌ)، والقيمةُ التي فيها ‏`$` (سلسلةُ ‏GString) تُهمَلُ: لا
 * تقديرَ لمتغيّراتِ ‏Gradle من هنا.
 */
public final class GradleSourceSets {

  /** أقصى ما يُحمَلُ لكلِّ نوعٍ من مجلداتٍ مُعلَنةٍ — بلا سقفٍ يبلعُهُ مشروعٌ كبيرٌ. */
  public static final int MAX_DECLARED_PER_KIND = 12;
  /** سقفُ نصِّ ملفِّ البناءِ حينَ يُقرَأُ من القرصِ وحدَهُ. */
  public static final int MAX_BUILD_TEXT_BYTES = 256 * 1024;

  /** أنواعُ المجلداتِ التي تُهمُّنا من الكتلةِ: لا ‏`aidl` ولا ‏`resources` (مواردُ جافانٍ). */
  public static final String KIND_JAVA = "java";
  public static final String KIND_KOTLIN = "kotlin";
  public static final String KIND_RES = "res";
  public static final String KIND_ASSETS = "assets";

  /** ما أعلنَهُ ملفُّ بناءٍ واحدٌ. القوائمُ نسبيّةٌ كما كُتِبَتْ، أو مطلقةٌ بلا مساسٍ. */
  public static final class Declared {
    public final List<String> java = new ArrayList<>();
    public final List<String> kotlin = new ArrayList<>();
    public final List<String> res = new ArrayList<>();
    public final List<String> assets = new ArrayList<>();
    /** ‏`manifest.srcFile`، أو {@code ""}. */
    public String manifestFile = "";

    /** المجلداتُ المُعلَنةُ لنوعٍ؛ قائمةٌ فارغةٌ إن لم يُعلِنْ المشروعُ شيئًا. */
    public List<String> kind(String kind) {
      if (KIND_JAVA.equals(kind)) return java;
      if (KIND_KOTLIN.equals(kind)) return kotlin;
      if (KIND_RES.equals(kind)) return res;
      if (KIND_ASSETS.equals(kind)) return assets;
      return Collections.emptyList();
    }

    public boolean isEmpty() {
      return java.isEmpty() && kotlin.isEmpty() && res.isEmpty() && assets.isEmpty()
          && manifestFile.isEmpty();
    }

    @Override
    public String toString() {
      return "java" + java + " kotlin" + kotlin + " res" + res + " assets" + assets
          + (manifestFile.isEmpty() ? "" : " manifest=" + manifestFile);
    }
  }

  private GradleSourceSets() {}

  /** تحليلُ نصِّ ملفِّ بناءٍ. نصٌّ فارغٌ أو بلا ‏`sourceSets` ← إعلانٌ فارغٌ، لا استثناءَ. */
  public static Declared of(String buildText) {
    Declared out = new Declared();
    String text = buildText == null ? "" : buildText;
    int word = indexOfWord(text, 0, "sourceSets");
    if (word < 0) return out;
    int open = text.indexOf('{', word + "sourceSets".length());
    if (open < 0) return out;
    int close = blockEnd(text, open);
    if (close < 0) return out;
    int at = open + 1;
    while (at < close) {
      int child = nextBlockName(text, at, close);
      if (child < 0) break;
      int nameStart = text.charAt(child) == '(' ? quotedStart(text, child, close) : child;
      String setName = nameStart < 0 ? "" : readNameOrQuoted(text, nameStart);
      int setOpen = text.indexOf('{', nameStart < 0 ? child : nameStart);
      if (setOpen < 0 || setOpen > close) break;
      int setClose = blockEnd(text, setOpen);
      if (setClose < 0 || setClose > close) break;
      if (setName.isEmpty() || setName.equals("main")) parseSet(text, setOpen, setClose, out);
      at = setClose + 1;
    }
    return out;
  }

  /** التحليلُ من ملفِّ وحدةٍ على القرصِ: ‏`build.gradle` ثمَّ ‏`build.gradle.kts`. */
  public static Declared ofModule(File moduleDir) {
    if (moduleDir == null) return new Declared();
    String text = readText(new File(moduleDir, "build.gradle"));
    if (text.isEmpty()) text = readText(new File(moduleDir, "build.gradle.kts"));
    return of(text);
  }

  /** مجلداتُ نوعٍ مُعلَنةٍ، محمولةً على مجلدِ الوحدةِ: الموجودُ فقط، وبلا تكرارٍ قانونيٍّ. */
  public static List<File> dirs(File moduleDir, List<String> declared) {
    ArrayList<File> out = new ArrayList<>();
    if (moduleDir == null || declared == null || declared.isEmpty()) return out;
    HashSet<String> seen = new HashSet<>();
    for (String raw : declared) {
      if (raw == null || raw.isEmpty()) continue;
      File dir = raw.charAt(0) == '/' ? new File(raw) : new File(moduleDir, raw);
      if (!dir.isDirectory()) continue;
      String key;
      try {
        key = dir.getCanonicalPath();
      } catch (IOException unreadable) {
        key = dir.getAbsolutePath();
      }
      if (!seen.add(key)) continue;
      out.add(dir);
    }
    return out;
  }

  /** مجلداتُ ‏`res` التي أعلنَتها الوحدةُ — يُستعمَلُ حينَ لا نموذجَ بناءٍ في اليدِ. */
  public static List<File> declaredResDirs(File moduleDir) {
    return dirs(moduleDir, ofModule(moduleDir).res);
  }

  // ═══════════════ داخلَ الكتلةِ ═══════════════

  /** أجسادُ المجموعةِ: إما ‏`java { srcDirs = … }` وإما ‏`java.srcDirs = …` (وفي ‏kts دوالٌ). */
  private static void parseSet(String text, int from, int to, Declared out) {
    int at = from + 1;
    while (at < to) {
      int kindAt = indexOfAnyKind(text, at, to);
      if (kindAt < 0) break;
      String kind = kindName(text, kindAt);
      int sign = nextSignificant(text, kindAt + kind.length(), to);
      if (sign < 0) break;
      char c = text.charAt(sign);
      if (c == '{') {
        int close = blockEnd(text, sign);
        if (close < 0 || close > to) break;
        int body = sign + 1;
        while (body < close) {
          int prop = nextSignificant(text, body, close);
          if (prop < 0) break;
          String name = readName(text, prop, close);
          if (name.isEmpty()) break;
          int value = valueStart(text, prop + name.length(), close);
          handle(text, value, close, name, kind, out);
          body = skipStatement(text, value < 0 ? prop + name.length() : value, close);
        }
        at = close + 1;
      } else if (c == '.') {
        int prop = nextSignificant(text, sign + 1, to);
        if (prop < 0) break;
        String name = readName(text, prop, to);
        if (name.isEmpty()) break;
        int value = valueStart(text, prop + name.length(), to);
        handle(text, value, to, name, kind, out);
        at = skipStatement(text, value < 0 ? prop + name.length() : value, to);
      } else break;
    }
  }

  /** خاصيّةٌ واحدةٌ: ‏`srcDirs`/‏`setSrcDirs`/‏`srcDir` للنوعِ، و‏`srcFile` للمانيفستِ. */
  private static void handle(String text, int value, int to, String name, String kind, Declared out) {
    if (value < 0 || name.isEmpty()) return;
    // نهايةُ العبارةِ حدٌّ للقراءةِ: ما بعدَ ‏`]`/‏`)` ليسَ من هذا الإعلانِ،
    // وإلا ابتلعَ ‏`java.srcDirs` ما يليهِ من سطورِ ‏`res`.
    int stop = Math.min(skipStatement(text, value, to), to);
    if (stop <= value) stop = to;
    if (kind.equals("manifest")) {
      if (name.equals("srcFile") || name.equals("setSrcFile")) {
        String file = firstQuoted(text, value, stop);
        if (!file.isEmpty() && out.manifestFile.isEmpty()) out.manifestFile = file;
      }
      return;
    }
    if (!name.startsWith("srcDir") && !name.startsWith("setSrcDir")) return;
    collect(text, value, stop, out.kind(kind));
  }

  /** ‏`srcDirs = ['a','b']`، ‏`setSrcDirs(listOf("a"))`، ‏`srcDir 'a'` — تُخفَّفُ كلُّها إلى ‏literals. */
  private static void collect(String text, int from, int to, List<String> into) {
    if (from < 0 || into == null) return;
    int at = from;
    while (at < to && into.size() < MAX_DECLARED_PER_KIND) {
      int quote = nextQuote(text, at, to);
      if (quote < 0) break;
      char mark = text.charAt(quote);
      int end = text.indexOf(mark, quote + 1);
      if (end < 0 || end > to) break;
      String value = text.substring(quote + 1, end).trim();
      at = end + 1;
      if (value.isEmpty() || value.indexOf('$') >= 0 || value.indexOf('\\') >= 0) continue;
      while (value.endsWith("/") || value.endsWith(File.separator)) {
        value = value.substring(0, value.length() - 1);
      }
      if (value.isEmpty() || into.contains(value)) continue;
      into.add(value);
    }
  }

  private static int indexOfAnyKind(String text, int from, int to) {
    int best = -1;
    String[] kinds = {KIND_JAVA, KIND_KOTLIN, KIND_RES, KIND_ASSETS, "manifest"};
    for (String kind : kinds) {
      int at = indexOfWord(text, from, kind);
      if (at >= 0 && at < to && (best < 0 || at < best)) best = at;
    }
    return best;
  }

  private static String kindName(String text, int at) {
    int end = at;
    while (end < text.length()
        && (Character.isJavaIdentifierPart(text.charAt(end)) || text.charAt(end) == '-')) end++;
    String name = text.substring(at, end);
    int dot = name.indexOf('.');
    return dot < 0 ? name : name.substring(0, dot);
  }

  /** اسمُ مجموعةٍ قد يكونُ داخلَ ‏`named("main")` أو ‏`getByName("main")`. */
  private static int nextBlockName(String text, int from, int to) {
    int at = from;
    while (at < to) {
      int word = nextSignificant(text, at, to);
      if (word < 0) return -1;
      char c = text.charAt(word);
      if (c == 'n' || c == 'g') {
        String name = readName(text, word, to);
        if (name.equals("named") || name.equals("getByName") || name.equals("maybeCreate")
            || name.equals("getByNameSafe")) {
          int q = quotedStart(text, word, to);
          return q < 0 ? -1 : q;
        }
      }
      if (Character.isJavaIdentifierStart(c)) return word;
      at = word + 1;
    }
    return -1;
  }

  private static int quotedStart(String text, int from, int to) {
    int at = text.indexOf('(', from);
    if (at < 0 || at > to) return -1;
    int q = nextSignificant(text, at + 1, to);
    if (q < 0 || q > to) return -1;
    char c = text.charAt(q);
    return (c == '"' || c == '\'') ? q + 1 : -1;
  }

  private static String readNameOrQuoted(String text, int at) {
    if (at < 0 || at >= text.length()) return "";
    char c = text.charAt(at);
    if (c == '"' || c == '\'') {
      int end = text.indexOf(c, at + 1);
      return end < 0 ? "" : text.substring(at + 1, end).trim();
    }
    return readName(text, at, Math.min(text.length(), at + 40));
  }

  private static String readName(String text, int at, int to) {
    int i = at;
    while (i < to && (Character.isJavaIdentifierPart(text.charAt(i)) || text.charAt(i) == '.'
        || text.charAt(i) == '-')) i++;
    return text.substring(at, i);
  }

  /** أينَ يبدأُ نصُّ القيمةِ بعدَ ‏`=` أو ‏`+=` أو مباشرةً بعدَ اسمِ الدالّةِ ‏`(`. */
  private static int valueStart(String text, int from, int to) {
    int at = nextSignificant(text, from, to);
    if (at < 0 || at >= to) return -1;
    char c = text.charAt(at);
    if (c == '+') {
      // ‏`srcDirs += ['x']` (‏Groovy) — العلامةُ قبلَ المساواةِ، لا بعدها
      int eq = nextSignificant(text, at + 1, to);
      if (eq < 0 || eq >= to || text.charAt(eq) != '=') return -1;
      return nextSignificant(text, eq + 1, to);
    }
    if (c == '=') {
      int plus = at + 1;
      if (plus < to && text.charAt(plus) == '+') at = plus;
      return nextSignificant(text, at + 1, to);
    }
    return c == '(' || c == '"' || c == '\'' ? at + (c == '(' ? 1 : 0) : -1;
  }

  /** تجاوزُ ما بقيَ من السطرِ عندَ قيمةٍ لا نفهمُها — فلا دورةَ بلا نهايةٍ. */
  private static int skipStatement(String text, int from, int to) {
    int at = Math.max(from, 0);
    int depth = 0;
    while (at < to) {
      char c = text.charAt(at);
      if (c == '\'' || c == '"') {
        int end = text.indexOf(c, at + 1);
        if (end < 0 || end > to) return to;
        at = end + 1;
        continue;
      }
      if (c == '[' || c == '(') depth++;
      else if (c == ']' || c == ')') {
        if (depth == 0) return at + 1;
        depth--;
      } else if ((c == '\n' || c == ';') && depth == 0) return at + 1;
      at++;
    }
    return to;
  }

  private static String firstQuoted(String text, int from, int to) {
    if (from < 0) return "";
    int quote = nextQuote(text, from, Math.min(to, from + 256));
    if (quote < 0) return "";
    char mark = text.charAt(quote);
    int end = text.indexOf(mark, quote + 1);
    if (end < 0 || end > to) return "";
    String value = text.substring(quote + 1, end).trim();
    return value.indexOf('$') >= 0 ? "" : value;
  }

  private static int nextQuote(String text, int from, int to) {
    for (int i = Math.max(0, from); i < to; i++) {
      char c = text.charAt(i);
      if (c == '"' || c == '\'') return i;
    }
    return -1;
  }

  private static int nextSignificant(String text, int from, int to) {
    int at = Math.max(0, from);
    while (at < to) {
      char c = text.charAt(at);
      if (c == '/' && at + 1 < to && text.charAt(at + 1) == '/') {
        int nl = text.indexOf('\n', at);
        if (nl < 0 || nl > to) return -1;
        at = nl + 1;
        continue;
      }
      if (!Character.isWhitespace(c)) return at;
      at++;
    }
    return -1;
  }

  /** موضعُ كلمةٍ مستقلةٍ (لا ذيلَ اسمٍ ولا جزءَ مسارٍ)، أو ‏-1. */
  private static int indexOfWord(String text, int from, String word) {
    int at = text.indexOf(word, Math.max(0, from));
    while (at >= 0) {
      boolean leftOk = at == 0 || !Character.isJavaIdentifierPart(text.charAt(at - 1));
      int after = at + word.length();
      boolean rightOk = after >= text.length() || !Character.isJavaIdentifierPart(text.charAt(after));
      if (leftOk && rightOk) return at;
      at = text.indexOf(word, after);
    }
    return -1;
  }

  /** مطابقةُ الأقواسِ مع تجاهلِ ما داخلَ الاقتباسِ؛ لا سلاسلَ نصّيّةً فيها ‏`{`. */
  private static int blockEnd(String text, int openBrace) {
    int depth = 0;
    for (int i = openBrace; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '"' || c == '\'') {
        int end = text.indexOf(c, i + 1);
        if (end < 0) return -1;
        i = end;
        continue;
      }
      if (c == '{') depth++;
      else if (c == '}') {
        if (--depth == 0) return i;
      }
    }
    return -1;
  }

  static String readText(File file) {
    if (file == null || !file.isFile()) return "";
    long length = file.length();
    if (length <= 0 || length > MAX_BUILD_TEXT_BYTES) return "";
    try (InputStream in = new FileInputStream(file)) {
      byte[] buffer = new byte[(int) length];
      int got = 0;
      while (got < buffer.length) {
        int read = in.read(buffer, got, buffer.length - got);
        if (read < 0) break;
        got += read;
      }
      return new String(buffer, 0, got, java.nio.charset.StandardCharsets.UTF_8);
    } catch (IOException | RuntimeException error) {
      return "";
    }
  }
}
