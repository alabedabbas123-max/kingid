package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * كتالوجُ قوالبِ الإنشاءِ — صافٍ بلا Android: يقرأُ {@code assets/templates/templates.json}،
 * ويُتحقَّقُ من عقدِهِ، ويقرِّرُ ما يُستبدَلُ في الملفاتِ وأيُّ اعتمادياتٍ تُحقَنُ وأيُّ مُنتقياتِ
 * إصدارٍ تُعرَضُ في حوارِ الاسمِ والحزمةِ.
 *
 * <p>العقدُ (أوسعُ من عقدِ المرجعِ {@code template.json} بزيادةِ {@code type}/{@code replaces}
 * والصدارفةِ، وبالحذفِ منه {@code template} لأنَّ اسمَ المجلدِ هو المعرِّفُ عندنا):
 * {@code categories[{title,icon,hide?,templates[{id,title,description?,icon?,type,main,hide?,
 * open[],replaces[],gradle{agp,wrapper,compileSdk,minSdk,targetSdk,androidx?,jvmargs?},
 * versions[{key,label,options[],default?,mode,coordinate?,prop?,file?}]}]}]}.
 *
 * <p>قراءتُنا JSON داخليّةٌ متعمَّدًا: لا {@code org.json} على المضيفِ، والاختبارُ يُطعَمُ
 * الملفَّ نفسَهُ الذي سيقرؤهُ الجهازُ — لا نسختانِ من التحليلِ.
 */
public final class TemplateCatalog {

  /** مُنتقى إصدارٍ واحدٌ: إمّا اعتماديةٌ تُحقَنُ، أو خاصيةٌ تُستبدَلُ في ملفٍّ. */
  public static final class VersionSpec {
    public final String key;
    public final String labelKey;
    public final List<String> options;
    public final int defaultIndex;
    public final boolean dependency;
    public final String coordinate;
    public final String property;
    public final String file;

    VersionSpec(
        String key,
        String labelKey,
        List<String> options,
        int defaultIndex,
        boolean dependency,
        String coordinate,
        String property,
        String file) {
      this.key = key;
      this.labelKey = labelKey;
      this.options = Collections.unmodifiableList(options);
      this.defaultIndex = defaultIndex;
      this.dependency = dependency;
      this.coordinate = coordinate;
      this.property = property;
      this.file = file;
    }

    public String defaultValue() {
      return options.get(defaultIndex);
    }

    /**
     * نصُّ الاعتماديةِ بعدَ اختيارِ الإصدارِ (فارغٌ إن كانت خاصيةً). والصيغةُ المقوّسةُ
     * {@code platform(…)} تُخرِجُ سطرَ المنصّةِ (BoM) لأنَّ Gradle يرفضُها كاعتماديةٍ عاديّةٍ.
     */
    public String dependencyLine(String version) {
      if (!dependency || coordinate == null) return "";
      String dep = coordinate.replace("$version$", version);
      // بلا بادئةٍ: المُحقِنُ (GradleDependencyEditor.addDependency) يزيِّنُ السطرَ، ومن يدسُّ
      // مسافاتِهِ هنا يحصلُ على ثمانيَ مسافاتٍ في dependencies {} — فالملفُّ لا يُنسخُ مرتينِ.
      if (dep.startsWith("platform(") && dep.endsWith(")")) {
        return "implementation platform('" + dep.substring("platform(".length(), dep.length() - 1) + "')";
      }
      return "implementation '" + dep + "'";
    }
  }

  /** قالبٌ واحدٌ قابلٌ للإنشاءِ. */
  public static final class Entry {
    public final String id;
    public final String titleKey;
    public final String descriptionKey;
    public final String icon;
    public final String type;
    public final String main;
    public final boolean hidden;
    public final List<String> open;
    public final List<String> replaces;
    public final String agp;
    public final String wrapper;
    public final int compileSdk;
    public final int minSdk;
    public final int targetSdk;
    public final boolean androidx;
    public final String jvmargs;
    public final List<VersionSpec> versions;

    Entry(
        String id,
        String titleKey,
        String descriptionKey,
        String icon,
        String type,
        String main,
        boolean hidden,
        List<String> open,
        List<String> replaces,
        String agp,
        String wrapper,
        int compileSdk,
        int minSdk,
        int targetSdk,
        boolean androidx,
        String jvmargs,
        List<VersionSpec> versions) {
      this.id = id;
      this.titleKey = titleKey;
      this.descriptionKey = descriptionKey;
      this.icon = icon;
      this.type = type;
      this.main = main;
      this.hidden = hidden;
      this.open = Collections.unmodifiableList(open);
      this.replaces = Collections.unmodifiableList(replaces);
      this.agp = agp;
      this.wrapper = wrapper;
      this.compileSdk = compileSdk;
      this.minSdk = minSdk;
      this.targetSdk = targetSdk;
      this.androidx = androidx;
      this.jvmargs = jvmargs;
      this.versions = Collections.unmodifiableList(versions);
    }

    /** هل يستبدَلُ نصُّ القالبِ في هذا الملفِّ؟ ({@code replaces} أنماطٌ «.*.امتدادٌ») */
    public boolean substitutes(String fileName) {
      String lower = fileName.toLowerCase(Locale.US);
      int dot = lower.lastIndexOf('.');
      if (dot < 0) return false;
      String extension = lower.substring(dot); // ".java"
      for (String pattern : replaces) {
        String p = pattern.toLowerCase(Locale.US);
        if (p.startsWith(".*")) p = p.substring(2);
        if (p.equals("*")) return true;
        if (p.equals(extension) || p.endsWith(extension)) return true;
      }
      return false;
    }

    /**
     * قيمُ الطوابعِ بقيمِ المُنتقياتِ كما اختارَها المستخدمُ: المفتاحُ {@code <key>_version}، وما لم
     * يُختَرْ يسقطُ إلى {@code options[default]} من المخطَّطِ. هي المسارُ الواحدُ للاستبدالِ،
     * و{@link #defaultVariables()} مجرَّدُ نداءٍ لها بـnull — فلا جدولَ قيمَ ثانِيَ في المعالجِ.
     */
    public Map<String, String> variablesFor(Map<String, String> chosen) {
      Map<String, String> vars = new LinkedHashMap<String, String>();
      vars.put("agp_version", agp);
      vars.put("compile_sdk", String.valueOf(compileSdk));
      vars.put("min_sdk", String.valueOf(minSdk));
      vars.put("target_sdk", String.valueOf(targetSdk));
      for (VersionSpec spec : versions) {
        String value = chosen == null ? null : chosen.get(spec.key + "_version");
        if (value == null || value.trim().isEmpty()) value = spec.defaultValue();
        vars.put(spec.key + "_version", value.trim());
      }
      return vars;
    }

    /** قيمُ الطوابعِ الافتراضيّةُ: ما يُكتبُ إن لم يلمسِ المستخدمُ مُنتقى. */
    public Map<String, String> defaultVariables() {
      return variablesFor(null);
    }

    /** هل يُدمَجُ {@code package=} في مانيفستِ هذا القالبِ؟ وحدةُ المكتبةِ لا (AGP 8 يُخطِئُها). */
    public boolean wantsManifestPackage() {
      return ProjectScaffold.wantsManifestPackage(type);
    }

    /** الاعتمادياتُ التي تُحقَنُ في {@code dependencies {}} بالقيمِ المختارةِ (فارغةٌ بلا مُنتقياتٍ). */
    public List<String> dependencyLines(Map<String, String> chosen) {
      List<String> out = new ArrayList<String>();
      for (VersionSpec spec : versions) {
        if (!spec.dependency) continue;
        String version = chosen == null ? null : chosen.get(spec.key + "_version");
        if (version == null || version.trim().isEmpty()) version = spec.defaultValue();
        String line = spec.dependencyLine(version.trim());
        if (!line.trim().isEmpty() && !out.contains(line)) out.add(line);
      }
      return out;
    }

    public List<VersionSpec> spinners() {
      List<VersionSpec> out = new ArrayList<VersionSpec>();
      for (VersionSpec s : versions) out.add(s);
      return out;
    }
  }

  /** فئةٌ في الحوارِ (رأسٌ قابلٌ للطيِّ). */
  public static final class Category {
    public final String titleKey;
    public final String icon;
    public final boolean hidden;
    public final List<Entry> entries;

    Category(String titleKey, String icon, boolean hidden, List<Entry> entries) {
      this.titleKey = titleKey;
      this.icon = icon;
      this.hidden = hidden;
      this.entries = Collections.unmodifiableList(entries);
    }
  }

  private final List<Category> categories;

  private TemplateCatalog(List<Category> categories) {
    this.categories = Collections.unmodifiableList(categories);
  }

  public List<Category> categories() {
    return categories;
  }

  public List<Category> categories(boolean includeHidden) {
    if (includeHidden) return categories;
    List<Category> out = new ArrayList<Category>();
    for (Category category : categories) {
      if (!category.hidden) out.add(category);
    }
    return out;
  }

  public Entry byId(String id) {
    for (Category category : categories) {
      for (Entry entry : category.entries) {
        if (entry.id.equals(id)) return entry;
      }
    }
    return null;
  }

  public int templateCount() {
    int n = 0;
    for (Category category : categories) n += category.entries.size();
    return n;
  }

  public String error() {
    return error;
  }

  private String error = "";

  // ═══════════════════════ التحليلُ والتحقُّقُ ═══════════════════════

  public static TemplateCatalog parse(String json) {
    List<String> problems = new ArrayList<String>();
    List<Category> categories = new ArrayList<Category>();
    try {
      Object root = Reader.parse(json);
      if (!(root instanceof Map)) throw bad("لا كائنَ جذريٌّ");
      Object list = ((Map) root).get("categories");
      if (!(list instanceof List)) throw bad("لا «categories»");
      for (Object groupObj : (List) list) {
        if (!(groupObj instanceof Map)) continue;
        Map group = (Map) groupObj;
        String groupTitle = text(group, "title", "");
        if (groupTitle.isEmpty()) problems.add("فئةٌ بلا عنوانٍ");
        boolean groupHidden = flag(group, "hide");
        List<Entry> entries = new ArrayList<Entry>();
        Object children = group.get("templates");
        if (!(children instanceof List)) {
          problems.add("فئةٌ بلا «templates»: " + groupTitle);
          continue;
        }
        for (Object childObj : (List) children) {
          if (!(childObj instanceof Map)) continue;
          Entry entry = readEntry((Map) childObj, problems);
          if (entry != null) entries.add(entry);
        }
        if (entries.isEmpty()) problems.add("فئةٌ خاليةٌ: " + groupTitle);
        categories.add(new Category(groupTitle, text(group, "icon", "ic_androidstudio"), groupHidden, entries));
      }
    } catch (RuntimeException failure) {
      problems.add("تحليلُ JSON: " + failure.getMessage());
    }
    TemplateCatalog catalog = new TemplateCatalog(categories);
    catalog.error = join(problems);
    return catalog;
  }

  private static Entry readEntry(Map raw, List<String> problems) {
    String id = text(raw, "id", "");
    if (id.isEmpty()) {
      problems.add("قالبٌ بلا id");
      return null;
    }
    String title = text(raw, "title", "");
    if (title.isEmpty()) problems.add(id + ": بلا عنوانٍ");
    String type = text(raw, "type", "android");
    if (!type.equals("android") && !type.equals("java") && !type.equals("library")) {
      problems.add(id + ": نوعٌ مجهولٌ «" + type + "»");
    }
    String main = text(raw, "main", "app");
    List<String> open = strings(raw.get("open"));
    if (open.isEmpty()) problems.add(id + ": بلا «open»");
    List<String> replaces = strings(raw.get("replaces"));
    if (replaces.isEmpty()) replaces = java.util.Arrays.asList(".*.xml", ".*.java", ".*.gradle");
    Map gradle = raw.get("gradle") instanceof Map ? (Map) raw.get("gradle") : Collections.emptyMap();
    List<VersionSpec> versions = new ArrayList<VersionSpec>();
    Object versionList = raw.get("versions");
    if (versionList instanceof List) {
      for (Object item : (List) versionList) {
        if (!(item instanceof Map)) continue;
        VersionSpec spec = readVersion((Map) item, id, problems);
        if (spec != null) versions.add(spec);
      }
    }
    return new Entry(
        id,
        title,
        text(raw, "description", ""),
        text(raw, "icon", "ic_project_android"),
        type,
        main,
        flag(raw, "hide"),
        open,
        replaces,
        text(gradle, "agp", "8.5.2"),
        text(gradle, "wrapper", "8.7"),
        integer(gradle, "compileSdk", 34),
        integer(gradle, "minSdk", 26),
        integer(gradle, "targetSdk", 34),
        flag(gradle, "androidx"),
        text(gradle, "jvmargs", "-Xmx2048m"),
        versions);
  }

  private static VersionSpec readVersion(Map raw, String templateId, List<String> problems) {
    String key = text(raw, "key", "");
    if (key.isEmpty()) {
      problems.add(templateId + ": مُنتقى بلا key");
      return null;
    }
    List<String> options = strings(raw.get("options"));
    if (options.size() < 2) {
      problems.add(templateId + "." + key + ": خيارٌ واحدٌ لا مُنتقى");
      return null;
    }
    int def = integer(raw, "default", 0);
    if (def < 0 || def >= options.size()) {
      problems.add(templateId + "." + key + ": «default» خارجُ القائمةِ");
      def = 0;
    }
    String mode = text(raw, "mode", "dependency");
    String coordinate = text(raw, "coordinate", "");
    String property = text(raw, "prop", "");
    String file = text(raw, "file", "");
    if (mode.equals("dependency")) {
      if (coordinate.isEmpty()) {
        problems.add(templateId + "." + key + ": اعتماديةٌ بلا «coordinate»");
        return null;
      }
      if (coordinate.startsWith("platform(") != coordinate.endsWith(")")) {
        problems.add(templateId + "." + key + ": أقواسُ platform() غيرُ متوازنةٍ");
      }
      if (!coordinate.contains("$version$")) {
        problems.add(templateId + "." + key + ": «coordinate» لا يحملُ $version$");
      }
      if (property.isEmpty()) property = key;
    } else if (mode.equals("property")) {
      if (file.isEmpty()) {
        problems.add(templateId + "." + key + ": خاصيةٌ بلا «file»");
        return null;
      }
      if (property.isEmpty()) property = key + "_version";
    } else {
      problems.add(templateId + "." + key + ": وضعٌ مجهولٌ «" + mode + "»");
      return null;
    }
    return new VersionSpec(key, text(raw, "label", "ui_wizard_version_" + key), options, def,
        mode.equals("dependency"), coordinate, property, file);
  }

  // ═══════════════════════ أدواتٌ صغيرةٌ ═══════════════════════

  private static String text(Map raw, String key, String fallback) {
    Object value = raw.get(key);
    return value == null ? fallback : String.valueOf(value);
  }

  private static boolean flag(Map raw, String key) {
    Object value = raw.get(key);
    return value instanceof Boolean ? ((Boolean) value).booleanValue() : "true".equals(String.valueOf(value));
  }

  private static int integer(Map raw, String key, int fallback) {
    Object value = raw.get(key);
    if (value instanceof Number) return ((Number) value).intValue();
    try {
      return Integer.parseInt(String.valueOf(value).trim());
    } catch (RuntimeException ignored) {
      return fallback;
    }
  }

  @SuppressWarnings("unchecked")
  private static List<String> strings(Object value) {
    List<String> out = new ArrayList<String>();
    if (value instanceof List) {
      for (Object item : (List<Object>) value) {
        if (item != null) out.add(String.valueOf(item));
      }
    }
    return out;
  }

  private static String join(List<String> parts) {
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < parts.size() && i < 6; i++) {
      if (out.length() > 0) out.append(" · ");
      out.append(parts.get(i));
    }
    if (parts.size() > 6) out.append(" · (+").append(parts.size() - 6).append(')');
    return out.toString();
  }

  private static RuntimeException bad(String message) {
    return new IllegalArgumentException(message);
  }

  /** قارئُ JSON مصغَّرٌ: كائناتٌ/مصفوفاتٌ/سلاسلُ بأرقامٍ و{@code true|false|null} فقطْ — بلا حالةٍ. */
  private static final class Reader {
    private final String s;
    private int i;

    private Reader(String text) {
      this.s = text;
    }

    static Object parse(String text) {
      Reader reader = new Reader(text == null ? "" : text);
      reader.skip();
      Object value = reader.value();
      reader.skip();
      if (reader.i < reader.s.length()) throw bad("ذيلٌ غيرُ مقروءٍ عندَ " + reader.i);
      return value;
    }

    private Object value() {
      if (i >= s.length()) throw bad("انتهى النصُّ");
      char c = s.charAt(i);
      if (c == '{') return object();
      if (c == '[') return array();
      if (c == '"') return string();
      if (c == 't' || c == 'f') return literal();
      if (c == 'n') {
        expect("null");
        return null;
      }
      return number();
    }

    private Map<String, Object> object() {
      Map<String, Object> out = new LinkedHashMap<String, Object>();
      i++; // {
      skip();
      if (peek() == '}') {
        i++;
        return out;
      }
      while (true) {
        skip();
        String key = string();
        skip();
        if (peek() != ':') throw bad("لا «:» بعدَ «" + key + "»");
        i++;
        skip();
        out.put(key, value());
        skip();
        char c = peek();
        if (c == ',') {
          i++;
          continue;
        }
        if (c == '}') {
          i++;
          return out;
        }
        throw bad("لا «,» ولا «}» عندَ " + i);
      }
    }

    private List<Object> array() {
      List<Object> out = new ArrayList<Object>();
      i++; // [
      skip();
      if (peek() == ']') {
        i++;
        return out;
      }
      while (true) {
        skip();
        out.add(value());
        skip();
        char c = peek();
        if (c == ',') {
          i++;
          continue;
        }
        if (c == ']') {
          i++;
          return out;
        }
        throw bad("لا «,» ولا «]» عندَ " + i);
      }
    }

    private String string() {
      if (peek() != '"') throw bad("لا افتتاحيّةَ سلاسلَ عندَ " + i);
      i++;
      StringBuilder out = new StringBuilder();
      while (true) {
        if (i >= s.length()) throw bad("سلسلةٌ بلا إغلاقٍ");
        char c = s.charAt(i++);
        if (c == '"') return out.toString();
        if (c != '\\') {
          out.append(c);
          continue;
        }
        char e = s.charAt(i++);
        if (e == 'n') out.append('\n');
        else if (e == 't') out.append('\t');
        else if (e == 'r') out.append('\r');
        else if (e == 'b') out.append('\b');
        else if (e == 'f') out.append('\f');
        else if (e == '/') out.append('/');
        else if (e == '"') out.append('"');
        else if (e == '\\') out.append('\\');
        else if (e == 'u') {
          out.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
          i += 4;
        } else throw bad("هروبٌ غيرُ معلومٍ \\" + e);
      }
    }

    private Object literal() {
      if (s.startsWith("true", i)) {
        i += 4;
        return Boolean.TRUE;
      }
      if (s.startsWith("false", i)) {
        i += 5;
        return Boolean.FALSE;
      }
      throw bad("قيمةٌ غيرُ مقروءةٌ عندَ " + i);
    }

    private Object number() {
      int start = i;
      while (i < s.length() && "+-.eE0123456789".indexOf(s.charAt(i)) >= 0) i++;
      String token = s.substring(start, i);
      if (token.isEmpty()) throw bad("قيمةٌ فارغةٌ عندَ " + start);
      try {
        if (token.indexOf('.') >= 0 || token.indexOf('e') >= 0 || token.indexOf('E') >= 0) {
          return Double.valueOf(token);
        }
        return Long.valueOf(token);
      } catch (NumberFormatException failure) {
        throw bad("عددٌ غيرُ سليمٍ «" + token + "»");
      }
    }

    private void expect(String word) {
      if (!s.startsWith(word, i)) throw bad("يُتوقَّعُ «" + word + "» عندَ " + i);
      i += word.length();
    }

    private char peek() {
      return i < s.length() ? s.charAt(i) : '\0';
    }

    private void skip() {
      while (i < s.length()) {
        char c = s.charAt(i);
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++;
        else break;
      }
    }
  }
}
