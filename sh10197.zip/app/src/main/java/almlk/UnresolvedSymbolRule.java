package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * الجسرُ بينَ تشخيصِ «رمزٌ لا يُحَلُّ» وقرارِ الجَلبِ: يَقرَأُ الموضعَ من نصِّ الملفِّ، ويَستخرِجُ الرمزَ
 * وصيغتَه المؤهَّلةَ، ويَستَعرِضُ مَصادرَ الإحداثيّةِ بالترتيبِ — المخزنُ المحليُّ أوّلًا (بوصفِهِ الحقيقةَ)،
 * ثمَّ اشتقاقُ ‏{@code androidx} الميكانيكيُّ، ثمَّ خريطةُ التهجيرِ من الجيلِ القديمِ.
 *
 * <p>لا تخمينَ فوقَ ذلك: حينَ لا تُعطِي القواعدُ إحداثيّةً تُرجَعُ حالةٌ مُسمّاةٌ (‏{@link
 * DependencyFetchPlan.Action#NOT_IN_CATALOG} أو {@code AMBIGUOUS}) بلا سطرٍ في ملفِّ البناءِ، لأنَّ المرجعَ
 * نفسَهُ يَترُكُ الإحداثيّةَ للمستخدمِ في محرِّرِ الإضافةِ ولا يَختَرِعُها.
 *
 * <p>لا {@code android.*} هنا أيضًا: القاعدَةُ تُختبَرُ في {@code qa.sh} فوقَ {@code almlk/} وحدَها.
 */
public final class UnresolvedSymbolRule {

  /** كمَ مُرشَّحًا يُنظَرُ فيهِ قبلَ عدِّ التجاوزِ (سقْفٌ معلَنٌ لا صامتٌ). */
  public static final int MAX_CANDIDATES = 64;
  /** فوقَهُ لا يُقرَأُ النصُّ كلُّهُ: تُطلَبُ إعادةُ فحصٍ كاملةٌ بدلَ التخطيطِ. */
  public static final int MAX_SOURCE_CHARS = 2 << 20;
  /** صيغٌ لا تَحتَمِلُ جَلبًا: نواةُ ‏{@code java}/{@code android} مؤمَّنةٌ بالمِنصَّةِ لا بالمخزنِ. */
  static final String[] PLATFORM_PREFIXES = {"java.", "javax.", "android.", "android.support.", "kotlin."};
  private UnresolvedSymbolRule() {}

  /** ما يَعرِفُهُ المضيفُ عن الصنوفِ والحُزَمِ — ثلاثُ مَداخلَ فقط، بلا فِعلٍ على الشبكةِ. */
  public interface Provider {
    /** الصيغةُ المؤهَّلةُ الوحيدةُ للاسمِ المُبسَّطِ؛ {@code null} عندَ الجهلِ أو التعدُّدِ. */
    String qualifiedFor(String simpleName);

    /** كمَ صنفًا يُوفِّرُ الاسمَ المُبسَّطَ في الطبقاتِ؟ (للفصلِ بينَ «لا شيءَ» و«مُلبِسٌ»). */
    int candidatesFor(String simpleName);

    /** إحداثيّةُ الحزمةِ التي يُثبَّتُ منها الصنفُ المؤهَّلُ؛ {@code null} إن لم تُعرَفْ. */
    String coordinateFor(String qualifiedName);
  }

  /** عدّاداتُ الجولةِ: كلُّ سقْفٍ مَسَّ عمَلًا يُعَدُّ هُنا، فلا يُبطَلُ عملٌ بلا أثَرٍ مَعدودٍ. */
  public static final class Tally {
    public int scanned;
    public int storeHits;
    public int derivedHits;
    public int migrated;
    public int notFound;
    public int ambiguous;
    public int alreadyListed;
    public int platformSkipped;
    public int overflow;

    public int planned() {
      return storeHits + derivedHits + migrated;
    }
  }

  /** الاسمُ عندَ الموضعِ: يَتمَدَّدُ على حروفِ المُعرِّفِ من الطرفينِ، {@code ""} إن لم يكنْ هُناكَ رمزٌ. */
  public static String symbolAt(CharSequence text, int from, int to) {
    if (text == null || text.length() == 0) return "";
    int n = text.length();
    int a = Math.max(0, Math.min(n, Math.min(from, to)));
    int b = Math.max(a, Math.min(n, Math.max(from, to)));
    if (a == b) {
      // نقطةَ مُطْلَقَةٍ (نقرةٌ أو مؤشِّرٌ): الرمزُ يَسبِقُها أو يَلِيها، لا ما بينهما.
      if (a > 0 && isIdentPart(text.charAt(a - 1))) b = a;
      else if (a < n && isIdentPart(text.charAt(a))) b = a + 1;
      else return "";
    }
    int probe = a;
    while (probe < b && !isIdentPart(text.charAt(probe))) probe++;
    if (probe >= b) return "";
    a = probe;
    b = Math.max(b, a + 1);
    while (a > 0 && isIdentPart(text.charAt(a - 1))) a--;
    while (b < n && isIdentPart(text.charAt(b))) b++;
    return b > a ? text.subSequence(a, b).toString() : "";
  }

  static boolean isIdentPart(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
        || c == '_' || c == '$';
  }

  /** هل النصُّ يُعلِنُ الصنفَ {@code symbol} فيهِ (تضمينًا أو في نفسِ الملفِّ)؟ فلا سببَ للجَلبِ. */
  public static boolean declaresType(CharSequence text, String symbol) {
    if (text == null || symbol == null || symbol.isEmpty()) return false;
    String s = text.toString();
    String[] heads = {"class ", "interface ", "enum ", "record ", "@interface "};
    for (String head : heads) {
      int at = 0;
      while ((at = s.indexOf(head, at)) >= 0) {
        int name = at + head.length();
        while (name < s.length() && s.charAt(name) == ' ') name++;
        if (s.startsWith(symbol, name)) {
          int end = name + symbol.length();
          if (end >= s.length() || !isIdentPart(s.charAt(end))) return true;
        }
        at = name;
      }
    }
    return false;
  }

  /** باقةُ الصيغةِ المؤهَّلةِ مُبسَّطةُ الاسمِ (‏{@code "a.b.C"} ← {@code "a.b"}). */
  public static String packageOf(String qualified) {
    if (qualified == null) return "";
    int dot = qualified.lastIndexOf('.');
    return dot <= 0 ? "" : qualified.substring(0, dot);
  }

  /** هل الصيغةُ المؤهَّلةُ مِنصَّةٌ (لا تُجلَبُ من مخزنٍ)؟ */
  public static boolean isPlatform(String qualified) {
    if (qualified == null || qualified.isEmpty()) return false;
    for (String prefix : PLATFORM_PREFIXES) {
      if (qualified.startsWith(prefix)) return true;
    }
    return false;
  }

  /**
   * اشتقاقُ {@code group:artifact} من باقةِ ‏{@code androidx}: القاعدةُ ميكانيكيّةُ الحدِ (البنيّةُ معلَنةٌ في
   * {@code AOSP}: {@code androidx.<حزمةٌ>:<حزمةٌ>})، فتُقبَلُ وحدَها؛ وباقي المَجالِ مَرفوضٌ لأنَّ اسمَ
   * الحزمةِ فيهِ لا يُستنتَجُ من الباقةِ.
   */
  public static String deriveCoordinate(String qualifiedName) {
    if (qualifiedName == null) return "";
    if (!qualifiedName.startsWith("androidx.")) return "";
    String[] parts = qualifiedName.split("\\.");
    if (parts.length < 2 || parts[1].length() < 2 || !Character.isLowerCase(parts[1].charAt(0))) return "";
    // عُرفُ androidx: androidx.<حزمةٌ>:<حزمةٌ>، فاسمُ الحزمةِ هو الجزءُ الثاني من الباقةِ دائمًا —
    // لا اسمُ الصنفِ ولا الجزءُ الوصفيُّ الثالثُ؛ ومشتقّاتُ ‏{@code -ktx}‏ لا تُخمَّنُ.
    return "androidx." + parts[1] + ":" + parts[1];
  }

  /** الإحداثيّةُ بعدَ التهجيرِ إن كانَ الاسمُ من جيلِ ‏{@code android.support}؛ {@code null} عندَ عدمِ الخريطةِ. */
  public static String migratedCoordinate(String groupArtifact) {
    if (groupArtifact == null || groupArtifact.indexOf(':') <= 0) return null;
    AndroidXMigration.Artifact moved = AndroidXMigration.oldToNew(groupArtifact);
    if (moved == null || moved.newName == null || moved.newName.indexOf(':') <= 0) return null;
    String version = moved.baseVersion == null ? "" : moved.baseVersion.trim();
    return moved.newName + ":" + (version.isEmpty() ? "+" : version);
  }

  /** مُرشَّحاتُ الإحداثيّةِ بالترتيبِ: المخزنُ، فالاشتقاقُ، فالتهجيرُ — مع سقْفٍ مُعَدٍّ. */
  public static List<String> candidates(String qualifiedName, Provider provider, Tally tally) {
    ArrayList<String> out = new ArrayList<>();
    if (qualifiedName == null || qualifiedName.isEmpty()) return out;
    if (provider != null) {
      String stored = null;
      try {
        stored = provider.coordinateFor(qualifiedName);
      } catch (RuntimeException ignored) {
        stored = null;
      }
      if (stored != null && !stored.trim().isEmpty()) {
        out.add(ensureVersion(stored.trim()));
        if (tally != null) tally.storeHits++;
      }
    }
    String derived = deriveCoordinate(qualifiedName);
    if (!derived.isEmpty() && !containsGroup(out, derived)) {
      out.add(derived + ":+");
      if (tally != null) tally.derivedHits++;
    }
    if (qualifiedName.startsWith("android.support.")) {
      String parts[] = qualifiedName.split("\\.");
      if (parts.length >= 4) {
        String legacy = "com.android.support:support-" + parts[2];
        String moved = migratedCoordinate(legacy);
        if (moved != null && !containsGroup(out, moved)) {
          out.add(moved);
          if (tally != null) tally.migrated++;
        }
      }
    }
    if (out.size() > MAX_CANDIDATES) {
      if (tally != null) tally.overflow += out.size() - MAX_CANDIDATES;
      return Collections.unmodifiableList(new ArrayList<>(out.subList(0, MAX_CANDIDATES)));
    }
    return out;
  }

  static boolean containsGroup(List<String> list, String coordinate) {
    String tail = coordinate.indexOf(':') > 0 ? coordinate.substring(0, coordinate.indexOf(':')) : coordinate;
    for (String item : list) {
      if (item.indexOf(':') > 0 && item.substring(0, item.indexOf(':')).equals(tail)) return true;
    }
    return false;
  }

  /** إصدارٌ معلَنٌ أو ‏{@code +} ديناميكيٌّ — لا يُترَكُ سطرٌ بلا إصدارٍ لأنَّ ملفَّ البناءِ يَرفَضُهُ. */
  public static String ensureVersion(String coordinate) {
    String value = coordinate.trim();
    int first = value.indexOf(':');
    if (first <= 0) return value;
    int second = value.indexOf(':', first + 1);
    if (second < 0) return value + ":+";
    return value.substring(second + 1).trim().isEmpty() ? value.substring(0, second + 1) + "+" : value;
  }

  /**
   * القرارُ كلُّهُ في ندائةٍ واحدةٍ: {@code text} نصُّ الملفِّ المُفحَصِ، {@code from}/{@code to} موضعُ
   * التشخيصِ، {@code buildText} نصُّ ملفِّ بناءِ الوحدةِ، و{@code offline} رايةُ انقطاعِ الشبكةِ.
   */
  public static DependencyFetchPlan plan(
      CharSequence text,
      int from,
      int to,
      String buildText,
      boolean kts,
      boolean offline,
      Provider provider,
      Tally tally) {
    return plan(text, from, to, buildText, kts, offline, provider, tally, null);
  }

  /** {@code filePackage} باقةُ الملفِّ نَفَسُها؛ تُستعمَلُ لئلّا يُطلَبَ جَلبُ صنفٍ من جوارِهُ. */
  public static DependencyFetchPlan plan(
      CharSequence text,
      int from,
      int to,
      String buildText,
      boolean kts,
      boolean offline,
      Provider provider,
      Tally tally,
      String filePackage) {
    if (text == null || text.length() == 0) return DependencyFetchPlan.none("no_text");
    if (text.length() > MAX_SOURCE_CHARS) {
      if (tally != null) tally.overflow++;
      return DependencyFetchPlan.none("too_large");
    }
    int a = Math.max(0, Math.min(text.length(), Math.min(from, to)));
    int b = Math.max(a, Math.min(text.length(), Math.max(from, to)));
    if (tally != null) tally.scanned++;

    // 1) سطرُ استيرادٍ يَمسُّ الموضعَ؟ فصاحبُ القرارِ صيغتَهُ المؤهَّلةُ، لا الاسمُ المُبسَّطُ.
    String symbol = "";
    String qualified = "";
    for (ImportSoundness.Line line : ImportSoundness.importLines(text)) {
      if (line.end < a || line.start > b) continue;
      symbol = line.simple;
      qualified = line.qualified;
      break;
    }
    if (symbol.isEmpty()) {
      symbol = symbolAt(text, a, b);
      if (symbol.isEmpty()) return DependencyFetchPlan.none("no_symbol");
      if (declaresType(text, symbol)) return DependencyFetchPlan.none("declared_here");
      if (filePackage != null && !filePackage.isEmpty() && symbol.length() > 0
          && packageOf(filePackage + "." + symbol).equals(filePackage)) {
        // صنفٌ في باقةِ الملفِّ لا يستوردُ نفسَهُ: لا جَلبَ لهُ.
        return DependencyFetchPlan.none("same_package");
      }
      qualified = provider == null ? "" : provider.qualifiedFor(symbol);
      if (qualified == null) qualified = "";
    }
    if (qualified.isEmpty()) {
      int count = provider == null ? 0 : provider.candidatesFor(symbol);
      if (count > 1) {
        if (tally != null) tally.ambiguous++;
        return DependencyFetchPlan.reject(DependencyFetchPlan.Action.AMBIGUOUS, symbol, count + " candidates");
      }
      if (tally != null) tally.notFound++;
      return DependencyFetchPlan.reject(DependencyFetchPlan.Action.NOT_IN_CATALOG, symbol, "no_candidate");
    }
    return decide(symbol, qualified, buildText, kts, offline, provider, tally);
  }

  /**
   * القرارُ نفسُهُ باسمٍ مُبسَّطٍ وصيغةٍ مؤهَّلةٍ مَعلومَتينِ: يَستعمِلُهُ المضيفُ على خيطِ المشروعِ، حيثُ لا
   * نصَّ للمُحرِّرِ يُقرَأُ منهُ الموضعُ (ولا قرصَ في خيطِ الواجهةِ).
   */
  public static DependencyFetchPlan planForSymbol(
      String symbol,
      String qualified,
      String buildText,
      boolean kts,
      boolean offline,
      Provider provider,
      Tally tally) {
    String name = symbol == null ? "" : symbol.trim();
    String name2 = qualified == null ? "" : qualified.trim();
    if (name2.isEmpty()) {
      if (tally != null) tally.notFound++;
      return DependencyFetchPlan.reject(DependencyFetchPlan.Action.NOT_IN_CATALOG, name, "no_qualified_name");
    }
    return decide(name, name2, buildText, kts, offline, provider, tally);
  }

  /** إحداثيّةٌ من مَصادِرِها المُرتَّبةِ، ثمَّ حالاتُ السطرِ والشبكةِ والصحةِ. */
  private static DependencyFetchPlan decide(
      String symbol,
      String qualified,
      String buildText,
      boolean kts,
      boolean offline,
      Provider provider,
      Tally tally) {
    if (isPlatform(qualified)) {
      if (tally != null) tally.platformSkipped++;
      return DependencyFetchPlan.none("platform");
    }

    List<String> candidates = candidates(qualified, provider, tally);
    if (candidates.isEmpty()) {
      if (tally != null) tally.notFound++;
      return DependencyFetchPlan.reject(DependencyFetchPlan.Action.NOT_IN_CATALOG, symbol, qualified);
    }
    String coordinate = candidates.get(0);
    String source = sourceOf(coordinate, qualified, provider);
    if (candidates.size() > 1 && !SOURCE_UNIQUE.equals(source)) {
      return DependencyFetchPlan.reject(DependencyFetchPlan.Action.AMBIGUOUS, symbol, candidates.size() + " sources");
    }
    DependencyFetchPlan.Action action =
        DependencyFetchPlan.SOURCE_MIGRATED.equals(source)
            ? DependencyFetchPlan.Action.MIGRATE_THEN_ADD
            : DependencyFetchPlan.Action.ADD_GRADLE_LINE;
    DependencyFetchPlan plan =
        DependencyFetchPlan.of(action, symbol, qualified, coordinate, source, "planned");
    if (plan.isListedIn(buildText == null ? "" : buildText, kts)) {
      if (tally != null) tally.alreadyListed++;
      return DependencyFetchPlan.of(
          DependencyFetchPlan.Action.ALREADY_LISTED, symbol, qualified, coordinate, source, "line_present");
    }
    if (offline) {
      return DependencyFetchPlan.of(
          DependencyFetchPlan.Action.OFFLINE, symbol, qualified, coordinate, source, "network_off");
    }
    if (!GradleDependencyEditor.isValidCoordinate(coordinate)) {
      return DependencyFetchPlan.reject(DependencyFetchPlan.Action.NOT_IN_CATALOG, symbol, "invalid_coordinate");
    }
    return plan;
  }

  /** أيُّ المَصادرِ أثَّرَ القرارَ؟ (يُطبعُ في السجلِّ، وتَختبِرُهُ البوّابةُ). */
  public static final String SOURCE_UNIQUE = "unique";
  static String sourceOf(String coordinate, String qualified, Provider provider) {
    if (qualified != null && qualified.startsWith("android.support.")) return DependencyFetchPlan.SOURCE_MIGRATED;
    if (provider != null) {
      String stored = null;
      try {
        stored = provider.coordinateFor(qualified);
      } catch (RuntimeException ignored) {
        stored = null;
      }
      if (stored != null && ensureVersion(stored.trim()).equals(coordinate)) return DependencyFetchPlan.SOURCE_STORE;
    }
    return DependencyFetchPlan.SOURCE_DERIVED;
  }

  /** كلُّ الحالاتِ التي يَنبَغي أن تَمُرَّ بالطابورِ (الكتابةُ أو التحققُ من التنزيلِ). */
  public static boolean shouldQueue(DependencyFetchPlan plan) {
    return plan != null
        && (plan.isActionable() || plan.action == DependencyFetchPlan.Action.ALREADY_LISTED);
  }

  /** خطّةُ ملفٍّ كاملٍ: كلُّ رموزِ ‏{@code missing}/{@code unknown} فيهِ، بسقْفِ {@code MAX_COORDINATES}. */
  public static List<DependencyFetchPlan> planFile(
      List<ImportSoundness.Issue> issues,
      CharSequence text,
      String buildText,
      boolean kts,
      boolean offline,
      Provider provider,
      Tally tally) {
    ArrayList<DependencyFetchPlan> out = new ArrayList<>();
    if (issues == null) return out;
    for (ImportSoundness.Issue issue : issues) {
      if (issue == null) continue;
      if (issue.kind != ImportSoundness.KIND_MISSING && issue.kind != ImportSoundness.KIND_UNKNOWN) continue;
      if (out.size() >= DependencyFetchPlan.MAX_COORDINATES) {
        if (tally != null) tally.overflow++;
        out.add(DependencyFetchPlan.reject(DependencyFetchPlan.Action.TOO_MANY, issue.name, "over limit"));
        break;
      }
      DependencyFetchPlan plan =
          plan(text, issue.start, issue.end, buildText, kts, offline, provider, tally, null);
      if (shouldQueue(plan)) out.add(plan);
    }
    return Collections.unmodifiableList(out);
  }
}
