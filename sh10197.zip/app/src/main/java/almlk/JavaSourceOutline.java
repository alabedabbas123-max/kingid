package almlk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Structural outline of one Java source for code completion: declared types with their fields,
 * methods (every overload, with parameter text) and constructors, and the local variables and
 * parameters visible at a given offset.
 *
 * <p>Input is the <em>masked</em> source (comments and literals blanked, same length), so braces
 * and semicolons can be trusted. The scan is linear and allocation-light; it never throws on
 * incomplete code — an unterminated body simply extends to the end of the text, which is exactly
 * the state of a file while it is being typed.
 */
public final class JavaSourceOutline {

  public static final class Field {
    public final String name, type;
    public final boolean isStatic;

    Field(String name, String type, boolean isStatic) {
      this.name = name;
      this.type = type;
      this.isStatic = isStatic;
    }
  }

  public static final class Method {
    public final String name, returnType, parameters;
    public final boolean isStatic, isConstructor;
    /** Offsets of the parameter list and body braces; bodyStart is -1 for abstract methods. */
    public final int paramsStart, paramsEnd, bodyStart, bodyEnd;

    Method(String name, String returnType, String parameters, boolean isStatic, boolean isConstructor,
        int paramsStart, int paramsEnd, int bodyStart, int bodyEnd) {
      this.name = name;
      this.returnType = returnType;
      this.parameters = parameters;
      this.isStatic = isStatic;
      this.isConstructor = isConstructor;
      this.paramsStart = paramsStart;
      this.paramsEnd = paramsEnd;
      this.bodyStart = bodyStart;
      this.bodyEnd = bodyEnd;
    }
  }

  public static final class Type {
    public final String name, kind;
    public final Type outer;
    public String superName = "";
    public final List<String> interfaces = new ArrayList<>();
    public final List<Field> fields = new ArrayList<>();
    public final List<Method> methods = new ArrayList<>();
    public final List<Method> constructors = new ArrayList<>();
    public final List<Type> nested = new ArrayList<>();
    public final int bodyStart;
    public int bodyEnd;

    Type(String name, String kind, Type outer, int bodyStart) {
      this.name = name;
      this.kind = kind;
      this.outer = outer;
      this.bodyStart = bodyStart;
    }
  }

  public static final class Local {
    public final String name, type;

    Local(String name, String type) {
      this.name = name;
      this.type = type;
    }
  }

  public final String packageName;
  public final List<String> imports;
  public final List<Type> types;

  private JavaSourceOutline(String packageName, List<String> imports, List<Type> types) {
    this.packageName = packageName;
    this.imports = imports;
    this.types = types;
  }

  private static final Set<String> MODIFIERS = new HashSet<>(java.util.Arrays.asList(
      "public", "protected", "private", "static", "final", "abstract", "synchronized", "native",
      "transient", "volatile", "strictfp", "default", "sealed", "non-sealed"));
  private static final Set<String> NOT_TYPES = new HashSet<>(java.util.Arrays.asList(
      "return", "new", "throw", "else", "case", "goto", "package", "import", "instanceof", "do",
      "break", "continue", "assert", "yield", "throws", "extends", "implements", "super", "this",
      "if", "while", "for", "switch", "try", "catch", "finally", "class", "interface", "enum"));
  private static final Pattern PACKAGE = Pattern.compile("\\bpackage\\s+([A-Za-z_$][\\w$.]*)\\s*;");
  private static final Pattern IMPORT =
      Pattern.compile("(?m)^\\s*import\\s+(?!static\\s)([A-Za-z_$][\\w$.]*(?:\\.\\*)?)\\s*;");
  private static final Pattern TYPE_HEADER = Pattern.compile(
      "\\b(class|interface|enum|record|@interface)\\s+([A-Za-z_$][\\w$]*)");
  private static final String TYPE_RE =
      "(?:byte|short|int|long|float|double|boolean|char|var|[A-Za-z_$][\\w$]*(?:\\s*\\.\\s*[A-Za-z_$][\\w$]*)*)"
          + "(?:\\s*<(?:[^<>;{}()]|<(?:[^<>;{}()]|<[^<>;{}()]*>)*>)*>)?(?:\\s*\\[\\s*\\])*";
  private static final Pattern LOCAL = Pattern.compile(
      "(?:^|[;{}(,:]|\\bfinal)\\s*(?:final\\s+)?(?:@[\\w$.]+\\s+)*(" + TYPE_RE + ")(\\s*\\.\\.\\.)?\\s+"
          + "([A-Za-z_$][\\w$]*)\\s*(?=[=;,:)]|\\[)");
  private static final Pattern ANNOTATION =
      Pattern.compile("@(?!interface\\b)[A-Za-z_$][\\w$.]*(?:\\s*\\([^()]*\\))?");
  private static final Pattern DECLARATOR = Pattern.compile("^\\s*([A-Za-z_$][\\w$]*)\\s*(?:=|$|\\[)");
  private static final Pattern FINAL = Pattern.compile("\\bfinal\\s+");
  private static final Pattern SPACES = Pattern.compile("\\s+");
  private static final Pattern LAMBDA_SINGLE = Pattern.compile("([A-Za-z_$][\\w$]*)\\s*->");

  public static JavaSourceOutline parse(String masked) {
    String code = masked == null ? "" : masked;
    Matcher p = PACKAGE.matcher(code);
    String pkg = p.find() ? p.group(1) : "";
    ArrayList<String> imports = new ArrayList<>();
    Matcher i = IMPORT.matcher(code);
    while (i.find()) imports.add(i.group(1));
    ArrayList<Type> top = new ArrayList<>();
    parseBody(code, 0, code.length(), null, top);
    return new JavaSourceOutline(pkg, Collections.unmodifiableList(imports), top);
  }

  /** Parses members between {@code from} and {@code to} belonging to {@code owner} (null = file). */
  private static void parseBody(String code, int from, int to, Type owner, List<Type> sink) {
    int pos = from;
    if (owner != null && owner.kind.equals("enum")) pos = parseEnumConstants(code, pos, to, owner);
    while (pos < to) {
      int start = skipSpace(code, pos, to);
      if (start >= to) break;
      char first = code.charAt(start);
      if (first == ';' || first == '}') {
        pos = start + 1;
        continue;
      }
      int end = start;
      int parens = 0;
      int angle = 0;
      boolean sawAssign = false;
      while (end < to) {
        char c = code.charAt(end);
        if (c == '(') parens++;
        else if (c == ')') parens--;
        else if (c == '=' && parens == 0) sawAssign = true;
        else if (c == '{' && parens == 0) {
          if (!sawAssign) break;
          end = matchBrace(code, end, to) + 1; // array initializer / anonymous class
          continue;
        } else if (c == ';' && parens <= 0) break;
        else if (c == '}' && parens <= 0) break;
        end++;
      }
      String header = code.substring(start, Math.min(end, to));
      if (end >= to || code.charAt(end) == '}') {
        if (owner != null) addField(owner, header);
        pos = end + 1;
        continue;
      }
      if (code.charAt(end) == ';') {
        if (owner != null) {
          int paren = header.indexOf('(');
          if (paren > 0 && !sawAssign && looksLikeMethod(header, paren)) addMethod(owner, code, start, header, -1, -1);
          else addField(owner, header);
        }
        pos = end + 1;
        continue;
      }
      // '{' — type, method, or initializer block
      int close = matchBrace(code, end, to);
      String clean = stripAnnotations(header);
      Matcher type = mayDeclareType(clean) ? TYPE_HEADER.matcher(clean) : null;
      if (type != null && type.find() && (clean.indexOf('(') < 0 || clean.indexOf('(') > type.start()
          || type.group(1).equals("record"))) {
        String kind = type.group(1).equals("@interface") ? "interface" : type.group(1);
        Type t = new Type(type.group(2), kind, owner, end);
        t.bodyEnd = close;
        readSupertypes(t, clean.substring(type.end()));
        if (owner != null) owner.nested.add(t);
        sink.add(t);
        parseBody(code, end + 1, close, t, sink);
      } else if (owner != null) {
        int paren = header.indexOf('(');
        if (paren > 0 && looksLikeMethod(header, paren)) addMethod(owner, code, start, header, end, close);
      }
      pos = close + 1;
    }
  }

  private static int parseEnumConstants(String code, int from, int to, Type owner) {
    int pos = from;
    int depth = 0;
    int end = from;
    while (end < to) {
      char c = code.charAt(end);
      if (c == '(' || c == '{') depth++;
      else if (c == ')' || c == '}') {
        if (depth == 0) break;
        depth--;
      } else if (c == ';' && depth == 0) break;
      end++;
    }
    String list = code.substring(pos, end);
    Matcher m = Pattern.compile("(?:^|,)\\s*(?:@[\\w$.]+\\s+)*([A-Za-z_$][\\w$]*)").matcher(stripNested(list));
    while (m.find()) owner.fields.add(new Field(m.group(1), owner.name, true));
    return end < to && code.charAt(end) == ';' ? end + 1 : end;
  }

  private static String stripNested(String text) {
    StringBuilder b = new StringBuilder(text.length());
    int depth = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '(' || c == '{') depth++;
      if (depth == 0) b.append(c);
      else b.append(' ');
      if ((c == ')' || c == '}') && depth > 0) depth--;
    }
    return b.toString();
  }

  private static boolean looksLikeMethod(String header, int paren) {
    String before = header.substring(0, paren).trim();
    if (before.isEmpty() || before.endsWith("=")) return false;
    int nameStart = before.length();
    while (nameStart > 0 && Character.isJavaIdentifierPart(before.charAt(nameStart - 1))) nameStart--;
    String name = before.substring(nameStart);
    return !name.isEmpty() && !NOT_TYPES.contains(name) && Character.isJavaIdentifierStart(name.charAt(0));
  }

  private static void readSupertypes(Type t, String rest) {
    String text = rest.replaceAll("<[^<>]*(?:<[^<>]*>[^<>]*)*>", " ");
    Matcher ext = Pattern.compile("\\bextends\\s+([\\w$.\\s,]+?)(?=\\bimplements\\b|\\bpermits\\b|$)").matcher(text);
    if (ext.find()) {
      String[] names = ext.group(1).trim().split("\\s*,\\s*");
      if (t.kind.equals("interface")) {
        for (String n : names) if (!n.isEmpty()) t.interfaces.add(n.trim());
      } else if (names.length > 0) t.superName = names[0].trim();
    }
    Matcher impl = Pattern.compile("\\bimplements\\s+([\\w$.\\s,]+?)(?=\\bpermits\\b|$)").matcher(text);
    if (impl.find()) for (String n : impl.group(1).trim().split("\\s*,\\s*")) if (!n.isEmpty()) t.interfaces.add(n.trim());
  }

  private static void addMethod(Type owner, String code, int start, String header, int bodyStart, int bodyEnd) {
    int paren = header.indexOf('(');
    int closeParen = matchParen(header, paren);
    String before = stripAnnotations(header.substring(0, paren)).trim();
    String params = collapseSpaces(header.substring(paren + 1, closeParen < 0 ? header.length() : closeParen).trim());
    params = withoutFinal(stripAnnotations(params)).trim();
    boolean isStatic = false;
    ArrayList<String> words = new ArrayList<>();
    for (String w : splitTypeWords(before)) {
      if (w.equals("static")) isStatic = true;
      if (!MODIFIERS.contains(w)) words.add(w);
    }
    if (words.isEmpty()) return;
    String name = words.get(words.size() - 1);
    if (words.size() >= 2 && words.get(0).startsWith("<")) words.remove(0); // generic method
    int ps = start + paren;
    int pe = closeParen < 0 ? start + header.length() : start + closeParen;
    if (words.size() == 1 && name.equals(owner.name)) {
      owner.constructors.add(new Method(name, owner.name, params, false, true, ps, pe, bodyStart, bodyEnd));
      return;
    }
    if (words.size() < 2) return;
    String ret = words.size() == 2 ? words.get(0) : String.join("", words.subList(0, words.size() - 1));
    owner.methods.add(new Method(name, ret, params, isStatic,
        false, ps, pe, bodyStart, bodyEnd));
  }

  private static void addField(Type owner, String header) {
    String text = stripAnnotations(header).trim();
    int eq = topLevelIndex(text, '=');
    String decl = eq < 0 ? text : text.substring(0, eq);
    // further declarators: "int a = 1, b, c = 2"
    ArrayList<String> extra = new ArrayList<>();
    if (eq >= 0) {
      String rest = text.substring(eq);
      for (String part : splitTopLevel(rest, ',')) {
        Matcher n = DECLARATOR.matcher(part);
        if (n.find() && !part.trim().startsWith("=")) extra.add(n.group(1));
      }
    }
    List<String> parts = splitTopLevel(decl, ',');
    if (parts.isEmpty()) return;
    ArrayList<String> words = new ArrayList<>();
    boolean isStatic = owner.kind.equals("interface");
    for (String w : splitTypeWords(parts.get(0))) {
      if (w.equals("static")) isStatic = true;
      if (!MODIFIERS.contains(w)) words.add(w);
    }
    if (words.size() < 2) return;
    String name = words.get(words.size() - 1).replace("[]", "");
    String type = String.join("", words.subList(0, words.size() - 1));
    if (!Character.isJavaIdentifierStart(name.charAt(0)) || NOT_TYPES.contains(words.get(0))) return;
    owner.fields.add(new Field(name, type, isStatic));
    for (int k = 1; k < parts.size(); k++) {
      String n = parts.get(k).trim().replace("[]", "");
      if (!n.isEmpty() && Character.isJavaIdentifierStart(n.charAt(0))) owner.fields.add(new Field(n, type, isStatic));
    }
    for (String n : extra) owner.fields.add(new Field(n, type, isStatic));
  }

  /** Splits "public static List<A, B> name" into words, keeping generic arguments attached. */
  private static List<String> splitTypeWords(String text) {
    ArrayList<String> out = new ArrayList<>();
    StringBuilder word = new StringBuilder();
    int angle = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '<') angle++;
      if (c == '>') angle--;
      if (Character.isWhitespace(c) && angle == 0) {
        if (word.length() > 0) {
          out.add(word.toString());
          word.setLength(0);
        }
        continue;
      }
      if ((c == '[' || c == ']' || c == '.') && word.length() == 0 && !out.isEmpty()) {
        word.append(out.remove(out.size() - 1));
      }
      if (!Character.isWhitespace(c)) word.append(c);
    }
    if (word.length() > 0) out.add(word.toString());
    // join "List <String>" or "String []" written with spaces
    ArrayList<String> joined = new ArrayList<>();
    for (String w : out) {
      if (!joined.isEmpty() && (w.startsWith("<") || w.startsWith("[") || w.startsWith("."))
          && !joined.get(joined.size() - 1).isEmpty() && !MODIFIERS.contains(joined.get(joined.size() - 1))) {
        joined.set(joined.size() - 1, joined.get(joined.size() - 1) + w);
      } else joined.add(w);
    }
    return joined;
  }

  private static String stripAnnotations(String text) {
    return text.indexOf('@') < 0 ? text : ANNOTATION.matcher(text).replaceAll(" ");
  }

  private static String withoutFinal(String text) {
    return text.contains("final") ? FINAL.matcher(text).replaceAll("") : text;
  }

  private static String collapseSpaces(String text) {
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c != ' ' && Character.isWhitespace(c) || c == ' ' && i + 1 < text.length() && text.charAt(i + 1) == ' ')
        return SPACES.matcher(text).replaceAll(" ");
    }
    return text;
  }

  /** Cheap pre-check so ordinary method headers skip the type-header regex. */
  private static boolean mayDeclareType(String header) {
    return header.contains("class") || header.contains("interface") || header.contains("enum")
        || header.contains("record");
  }

  private static List<String> splitTopLevel(String text, char separator) {
    ArrayList<String> out = new ArrayList<>();
    int depth = 0;
    int last = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '<' || c == '(' || c == '[' || c == '{') depth++;
      else if (c == '>' || c == ')' || c == ']' || c == '}') depth--;
      else if (c == separator && depth == 0) {
        out.add(text.substring(last, i));
        last = i + 1;
      }
    }
    out.add(text.substring(last));
    return out;
  }

  private static int topLevelIndex(String text, char wanted) {
    int depth = 0;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '<' || c == '(' || c == '[') depth++;
      else if (c == '>' || c == ')' || c == ']') depth--;
      else if (c == wanted && depth == 0) return i;
    }
    return -1;
  }

  private static int skipSpace(String code, int pos, int to) {
    while (pos < to && Character.isWhitespace(code.charAt(pos))) pos++;
    return pos;
  }

  /** Index of the brace closing the one at {@code open}, or {@code to} when unterminated. */
  static int matchBrace(String code, int open, int to) {
    int depth = 0;
    for (int i = open; i < to; i++) {
      char c = code.charAt(i);
      if (c == '{') depth++;
      else if (c == '}' && --depth == 0) return i;
    }
    return to;
  }

  private static int matchParen(String text, int open) {
    int depth = 0;
    for (int i = open; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '(') depth++;
      else if (c == ')' && --depth == 0) return i;
    }
    return -1;
  }

  // ───────────────────────────── queries ─────────────────────────────

  /** Innermost type whose body contains {@code offset}, or null. */
  public Type typeAt(int offset) {
    Type best = null;
    for (Type t : types)
      if (offset > t.bodyStart && offset <= t.bodyEnd && (best == null || t.bodyStart > best.bodyStart)) best = t;
    return best;
  }

  /** Method or constructor whose parameter list or body contains {@code offset}. */
  public Method methodAt(Type type, int offset) {
    if (type == null) return null;
    for (List<Method> list : java.util.Arrays.asList(type.methods, type.constructors))
      for (Method m : list)
        if ((m.bodyStart >= 0 && offset > m.bodyStart && offset <= m.bodyEnd)
            || (offset > m.paramsStart && offset <= m.paramsEnd)) return m;
    return null;
  }

  public Type type(String name) {
    for (Type t : types) if (t.name.equals(name)) return t;
    return null;
  }

  /**
   * Parameters of the enclosing method plus locals declared before {@code offset} in blocks that
   * are still open there (innermost first, so shadowing resolves to the nearest declaration).
   */
  public static List<Local> localsAt(String code, Method method, int offset) {
    ArrayList<Local> out = new ArrayList<>();
    if (method == null) return out;
    if (method.bodyStart < 0 || offset <= method.bodyStart) {
      addParameters(out, method.parameters);
      return out;
    }
    int end = Math.min(offset, code.length());
    // open-brace stack at the cursor
    ArrayDeque<Integer> stack = new ArrayDeque<>();
    for (int i = method.bodyStart; i < end; i++) {
      char c = code.charAt(i);
      if (c == '{') stack.push(i);
      else if (c == '}' && !stack.isEmpty()) stack.pop();
    }
    HashSet<Integer> open = new HashSet<>(stack);
    String region = code.substring(method.bodyStart, end);
    ArrayList<Local> found = new ArrayList<>();
    Matcher m = LOCAL.matcher(region);
    int searchFrom = 0;
    while (searchFrom < region.length() && m.find(searchFrom)) {
      int at = method.bodyStart + m.start(3);
      searchFrom = Math.max(m.end(3), m.start() + 1);
      String type = m.group(1).replaceAll("\\s+", "");
      String first = type.replaceAll("[<\\[.].*", "");
      if (NOT_TYPES.contains(first) || MODIFIERS.contains(first) || NOT_TYPES.contains(m.group(3))) continue;
      if (m.group(2) != null) type += "[]";
      if (visibleAt(code, method.bodyStart, at, end, open)) found.add(new Local(m.group(3), type));
    }
    Matcher lambda = LAMBDA_SINGLE.matcher(region);
    while (lambda.find()) {
      int at = method.bodyStart + lambda.start(1);
      if (visibleAt(code, method.bodyStart, at, end, open)) found.add(new Local(lambda.group(1), "var"));
    }
    Collections.reverse(found);
    HashSet<String> seen = new HashSet<>();
    for (Local l : found) if (seen.add(l.name)) out.add(l);
    ArrayList<Local> params = new ArrayList<>();
    addParameters(params, method.parameters);
    for (Local l : params) if (seen.add(l.name)) out.add(l);
    return out;
  }

  private static boolean visibleAt(String code, int bodyStart, int at, int cursor, Set<Integer> open) {
    // declarations inside "for (...)", "catch (...)" or "try (...)" belong to the following block
    int depth = 0;
    for (int i = at - 1; i > bodyStart; i--) {
      char c = code.charAt(i);
      if (c == ')') depth++;
      else if (c == '(') {
        if (depth == 0) {
          int close = matchParen(code, i);
          if (close < 0 || close >= cursor) return true; // cursor still inside the header
          int next = skipSpace(code, close + 1, code.length());
          return next < code.length() && code.charAt(next) == '{' && open.contains(next);
        }
        depth--;
      } else if ((c == ';' || c == '{' || c == '}') && depth == 0) break;
    }
    int block = bodyStart;
    int d = 0;
    for (int i = at - 1; i >= bodyStart; i--) {
      char c = code.charAt(i);
      if (c == '}') d++;
      else if (c == '{') {
        if (d == 0) {
          block = i;
          break;
        }
        d--;
      }
    }
    return open.contains(block);
  }

  private static void addParameters(List<Local> out, String parameters) {
    if (parameters == null || parameters.trim().isEmpty()) return;
    for (String part : splitTopLevel(parameters, ',')) {
      List<String> words = splitTypeWords(withoutFinal(stripAnnotations(part)).trim());
      if (words.size() < 2) continue;
      String name = words.get(words.size() - 1);
      String type = String.join("", words.subList(0, words.size() - 1)).replace("...", "[]");
      out.add(new Local(name, type));
    }
  }
}
