package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * جدولُ العلاماتِ ذو الصفَّينِ (الجولةُ ‏24/2): ما يَرسمُهُ المُحرِّرُ لا يُعيدُ بناءَهُ على خيطِ الرسمِ،
 * بل تُكتَبُ طائفةٌ جديدةٌ في المخزنِ الخَلفيِّ ثمَّ تُبَادَلُ، فيبقى {@code onDraw} قراءةً في صفوفٍ
 * جاهزةٍ. هذا حرفيًّا ما يَفعَلُهُ المرجعُ في {@code CodeEditText$b}: جدولا علاماتٍ (نحوٌ وأخطاءٌ)
 * بصفَّينِ لكلِّ جدولٍ، والقفلُ حولَ التبديلِ، و{@code post} لإعادةِ الرسمِ بعدَ التبديلِ.
 *
 * <p>ثلاثُ قواعدَ مأخوذةٌ من المرجعِ، وقاعدتانِ مُستبدَلتانِ:
 * <ul>
 *   <li><b>الاحترامُ الثنائيُّ للدورِ</b>: عندَ المرجعِ {@code EnumC0058m} أربعةَ عشرَ نمطًا، لكلِّ نمطٍ
 *       (اسمٌ، موردُ فاتحٌ، موردُ داكنٌ، {@code flag})؛ وعندَنا الأربعةَ عشرَ هي أدوارُ {@code
 *       CodeLanguageTools} نفسها (‏0 ساذجٌ … ‏13 تعليقُ وثائقَ، و{@link EditorSyntaxRoles} يَحمِلُ
 *       لونَها وعلامتَها)، فزِدنا عليها أدوارَ الفحصِ (خطأٌ/إنذارٌ/تكرارٌ/استيرادٌ) لا جدولَ ألوانٍ جديدًا.
 *   <li><b>تَقدِيمُ الفحصِ على التلوينِ</b>: {@code m361VH(line,col)} يختبِرُ أخطاءَ الفحصِ أولًا؛ وكذلكَ
 *       {@link #markAt} — فلا يُخبِّئُ لونُ مُعرِّفٍ إشارةَ تكرارٍ فوقَهُ.
 *   <li><b>المنجِزُ (revision)</b>: {@code FileHighlightings} يحملُ رقمَ مُنجِزٍ، والقديمُ لا يَقبَلُهُ
 *       الجدولُ؛ {@link #commit} يَرفُضُ ما كانَ أقدمَ أو مكرَّرًا.
 *   <li><b>مجموعاتُ المواضعِ</b>: بدلَ أن تكونَ العلامةُ نقطةً واحدةً، كلُّ علامةٍ تحملُ {@code group}؛
 *       و{@link #sitesOf} يَرُدُّ كلَّ مواضعِ العنصرِ المكرَّرِ معًا — وهو المطلوبُ في هذهِ الجولةِ
 *       (إبرازُ التكرارِ في كلِّ مواضعِ تواجدهِ لا في موضعٍ واحدٍ).
 *   <li><b>لا خيطَ هنا</b>: المرجعُ يستعملُ قفلينِ و{@code notify}؛ عندنا المتحدِّثُ خيطُ التحليلِ
 *       والراسمُ خيطُ الواجهةِ ولا حاجةَ إلى انتظارٍ: {@code synchronized} على التبديلِ وحدَهُ، ولا
 *       {@code wait} يُمسِكُ خيطًا.
 * </ul>
 *
 * <p>السقوفُ معلَنةٌ، والزيادةُ معدودةٌ مع سِجلٍّ ({@link #MAX_MARKS} علامةٌ، {@link #MAX_SITES} موضعًا
 * للمجموعةِ، {@link #MAX_PROBLEMS} سِجلًّا) — لا ضياعَ صامتٍ.
 */
public final class MarkTable {

  /** أدوارُ النحوِ ‏0..‏13 كما في {@code CodeLanguageTools} (ساذجٌ حتى تعليقِ الوثائقِ). */
  public static final int SYNTAX_COUNT = 14;
  public static final int ROLE_ERROR = 14;
  public static final int ROLE_WARNING = 15;
  /** موضعٌ من عنصرٍ مُكرَّرٍ — كلُّ مواضعِهِ تحملُ المجموعةَ نفسَها. */
  public static final int ROLE_DUPLICATE = 16;
  /** الاستيرادُ المُشكِلُ (مجهولٌ/زائدٌ/مُكرَّرٌ) — مُنفصِلٌ ليُصبَغَ بلونِهِ لا بلونِ الخطإِ النحويِّ. */
  public static final int ROLE_IMPORT = 17;
  public static final int ROLE_UNUSED_IMPORT = 18;
  /**
   * تلميحُ المحرِّرِ (الجولةُ ‏30، شرطٌ دائمٌ ‏21): التحويلُ غيرُ الضروريِ، وما لا وصولَ إليهِ من
   * متغيِّرٍ ودالةٍ وحقلٍ ومعامِلٍ — يُزَيَّنُ بأصفرَ تحتَهُ ولا يَجْلِسُ في لوحِ الأخطاءِ ولا يُعَدُّ
   * خطأً. الأسرةُ ثالثةٌ لا رابعةٌ: ‏`severityOf` يعيدُ ‏2، و‏`AlmlkEditor` يَبني منهُ ‏
   * `DiagnosticSpanIndex.Span.hint(...)`.
   */
  public static final int ROLE_HINT = 19;
  public static final int ROLE_COUNT = 20;

  public static final int MAX_MARKS = 4096;
  public static final int MAX_SITES = 64;
  public static final int MAX_PROBLEMS = 4;
  /** عددُ الأرقامِ لكلِّ علامةٍ: دورٌ، سطرٌ، عمودُ بدايةٍ، عمودُ نهايةٍ، مجموعةٌ. */
  public static final int STRIDE = 5;

  private final int[][] buffers = new int[2][MAX_MARKS * STRIDE];
  private final int[] counts = new int[2];
  private int back;
  private long revision;
  private int dropped;
  private int staleRejected;
  private int swaps;
  private final ArrayList<String> problems = new ArrayList<>(MAX_PROBLEMS + 1);

  /** هل هذا الدورُ من أسرةِ الفحصِ (تُقدَّمُ على التلوينِ عندَ الإصابةِ)؟ */
  public static boolean isInspection(int role) {
    return role >= SYNTAX_COUNT && role < ROLE_COUNT;
  }

  /**
   * مفتاحُ اللوحةِ لأدوارِ النحوِ عبرَ {@code EditorSyntaxRoles} (الدورُ يَحْمِلُ لونَهُ وعلامتَهُ كما في
   * جدولِ المرجعِ)؛ و{@code null} لأدوارِ الفحصِ: رسمُها تَسطيرٌ بثيمِ الخطإِ لا لونٌ من لوحةِ المحرِّرِ
   * القابلةِ للتحريرِ — وإلا صارتْ ألوانُ الأخطاءِ تُعَدَّلُ في شاشةِ الثيمِ بالخطإِ.
   */
  public static String paletteKey(int role) {
    return role >= 0 && role < SYNTAX_COUNT ? EditorSyntaxRoles.paletteKey(role) : null;
  }

  /**
   * أيُّ أسرةِ تَسطيرٍ: خطأٌ (‏0)، إنذارٌ (‏1)، تلميحٌ (‏2)؟ ‏0 و‏1 هما نفسُ دلالةِ ‏
   * {@code DiagnosticSpanIndex.Span.warning}؛ و‏2 أسرةٌ جديدةٌ لا تَظهَرُ في اللوحةِ أصلًا.
   */
  public static int severityOf(int role) {
    switch (role) {
      case ROLE_HINT:
        return 2;
      case ROLE_WARNING:
      case ROLE_UNUSED_IMPORT:
        return 1;
      case ROLE_ERROR:
      case ROLE_DUPLICATE:
      case ROLE_IMPORT:
        return 0;
      default:
        return -1; // نحوٌ: لا تَسطيرَ ولا أسرةَ فحصٍ
    }
  }

  /** هل يُرسَمُ للدورِ تَسطيرٌ تحتيٌّ؟ النحوُ لا يَسطُرُ، والفحصُ كلُّهُ يَسطُرُ. */
  public static boolean isUnderlined(int role) {
    return isInspection(role);
  }

  public synchronized long revision() {
    return revision;
  }

  public synchronized int size() {
    return counts[front()];
  }

  public synchronized int swapsCount() {
    return swaps;
  }

  public synchronized int droppedCount() {
    return dropped;
  }

  public synchronized int staleRejectedCount() {
    return staleRejected;
  }

  public synchronized List<String> problems() {
    return Collections.unmodifiableList(new ArrayList<>(problems));
  }

  /** حالةٌ مُسمّاةٌ للقياسِ: لا «نجاحٌ» غامضٌ، بل اسمٌ يُثبِتُ أنَّ الطائفةَ وصلَت أو رُفِضَت. */
  public synchronized String state() {
    if (!problems.isEmpty()) return "capped"; // السقفُ المُعلَنُ يُعلَنُ ولو كانتِ الصفيحةُ فارغةً
    if (swaps == 0) return "empty";
    if (staleRejected > 0) return "stale_seen";
    return "swapped";
  }

  public synchronized void clear() {
    counts[0] = 0;
    counts[1] = 0;
    back = 0;
    revision = 0L;
    dropped = 0;
    staleRejected = 0;
    swaps = 0;
    problems.clear();
  }

  /** أولُ كتابةِ الطائفةِ الخَلفيّةِ: يَمحُوها ويَحُدُّ عدَّادَها (الداعي على خيطِ التحليلِ). */
  public synchronized void begin() {
    counts[back] = 0;
  }

  /** تُضافُ علامةٌ إلى الطائفةِ الخَلفيّةِ؛ {@code false} عندَ بلوغِ {@link #MAX_MARKS} (معدودٌ). */
  public synchronized boolean append(int role, int line, int startColumn, int endColumn, int group) {
    if (role < 0 || role >= ROLE_COUNT || line < 0) return false;
    int[] buffer = buffers[back];
    int at = counts[back];
    if (at >= MAX_MARKS) {
      dropped++;
      note("marks capped at " + MAX_MARKS);
      return false;
    }
    int base = at * STRIDE;
    buffer[base] = role;
    buffer[base + 1] = line;
    buffer[base + 2] = Math.max(0, Math.min(startColumn, endColumn));
    buffer[base + 3] = Math.max(buffer[base + 2] + 1, endColumn);
    buffer[base + 4] = Math.max(0, group);
    counts[back] = at + 1;
    return true;
  }

  /**
   * التبديلُ: الخَلفيُّ يصيرُ مرئيًّا إن كانَ أحدثَ؛ والقديمُ لا يَمسُّ ما على الشاشةِ. تُعادُ {@code false}
   * عندَ الرفضِ (منجِزٌ أقدمُ أو مكرَّرٌ) فيُعلَمُ ذلكَ بالعدّادِ لا بالصمتِ.
   */
  public synchronized boolean commit(long nextRevision) {
    if (nextRevision <= revision) {
      staleRejected++;
      counts[back] = 0;
      return false;
    }
    revision = nextRevision;
    back = front();
    swaps++;
    return true;
  }

  /** الإصابةُ عندَ سطرٍ وعمودٍ: دورُ العلامةِ ومداها ومجموعتُها — الخطأُ أولًا ثمَّ التلوينُ. */
  public synchronized int[] markAt(int line, int column) {
    int[] buffer = buffers[front()];
    int total = counts[front()];
    int fallback = -1;
    int best = -1;
    for (int i = 0; i < total; i++) {
      int base = i * STRIDE;
      if (buffer[base + 1] != line) continue;
      if (column < buffer[base + 2] || column > buffer[base + 3]) continue;
      // الأسرةُ الفحصيّةُ بأرقامِها الصاعدةِ: خطأٌ ثمَّ إنذارٌ ثمَّ تكرارٌ ثمَّ استيرادٌ — لا «أولُ ما وُجِدَ»،
      // فطائفةُ التكرارِ تُبنى قبلَ طائفةِ الخطإِ في الردِّ نفسِهِ أحيانًا.
      if (isInspection(buffer[base]) && (best < 0 || buffer[base] < buffer[best])) best = base;
      if (fallback < 0) fallback = base;
    }
    if (best >= 0) return copy(buffer, best);
    return fallback < 0 ? null : copy(buffer, fallback);
  }

  /** كلُّ مواضعِ المجموعةِ (العنصرُ نفسُهُ حيثُ وُجِدَ): {@code {line,start,end, …}} مُسطَّحٌ. */
  public synchronized int[] sitesOf(int group) {
    if (group <= 0) return new int[0];
    int[] buffer = buffers[front()];
    int total = counts[front()];
    int[] out = new int[Math.min(total, MAX_SITES) * 3];
    int n = 0;
    for (int i = 0; i < total && n < MAX_SITES; i++) {
      int base = i * STRIDE;
      if (buffer[base + 4] != group) continue;
      out[n * 3] = buffer[base + 1];
      out[n * 3 + 1] = buffer[base + 2];
      out[n * 3 + 2] = buffer[base + 3];
      n++;
    }
    if (total > MAX_SITES && n == MAX_SITES) {
      dropped += total - MAX_SITES;
      note("sites capped at " + MAX_SITES);
    }
    return n * 3 == out.length ? out : java.util.Arrays.copyOf(out, n * 3);
  }

  /** عدُّ علاماتِ الدورِ — للبوّابةِ أن تُثبِتَ أنَّ الطائفةَ حُمِّلَت بلا أن تَقرَأَ رسمًا. */
  public synchronized int countOf(int role) {
    int[] buffer = buffers[front()];
    int total = counts[front()];
    int n = 0;
    for (int i = 0; i < total; i++) {
      if (buffer[i * STRIDE] == role) n++;
    }
    return n;
  }

  private static int[] copy(int[] buffer, int base) {
    return new int[] {
      buffer[base], buffer[base + 2], buffer[base + 3], buffer[base + 4]
    };
  }

  private int front() {
    return 1 - back;
  }

  private void note(String text) {
    if (problems.size() >= MAX_PROBLEMS) return;
    if (!problems.contains(text)) problems.add(text);
  }
}
