package almlk;

/**
 * جدولُ أدوارِ الكود: أيُّ لونٍ من {@link EditorThemePalette} لأيِّ نمطٍ لغويّ، وأيُّ علامةٍ (غامقٌ/مائلٌ)
 * تُرافِقُهُ — وهي «دوالُّ تلوينِ الكود» التي طلبَ نقلَها المصدر، لأنَّ الاحترافَ عندَهُم ليس ألوانًا أكثرَ
 * بل **نمطٌ واحدٌ يحمِلُ لونَهُ وعلامتَهُ معًا**.
 *
 * <p>المصدرُ يفصِلُ طبقتين: {@code EnumC0058m} (أربعةَ عشرَ نمطًا: اسمٌ، عنوانٌ، موردُ فاتح، موردُ داكن،
 * {@code flag}) و{@code ColorDefault} (ثلاثةَ عشرَ لونًا). نمطٌ لغويٌّ قد يشاركُ نمطًا آخرَ لونَهُ،
 * {@code KEYWORD} وحدهُ **غامق**، و{@code NAMESPACE_IDENTIFIER} و{@code DOC_COMMENT} **مائلة**، وما عداها
 * سادة. وهذه الجدولةُ هي التي تُعطِي الكودَ هيبتَهُ كما في لقطاتِهِ: مفتاحٌ غامقٌ أحمر، باقةٌ مائلةٌ
 * سادة. وهذه الجدولةُ هي التي تُعطِي الكودَ هيبتَهُ كما في لقطاتِهِ: مفتاحٌ غامقٌ أحمر، باقةٌ مائلةٌ
 * كهرمانية، تعليقُ وثائقَ مائلٌ بلونِ التعليق. وأمّا أسماءُ الدوالِ — تعريفًا ونداءً، محلِّيةً كانت أو
 * موروثةً عبرَ نقطةٍ أو سلسلةٍ — فتَأخُذُ نمطَ {@code FUNCTION} وتُصبَغُ بلونِ {@code Plain}: جدولُ
 * {@code EnumC0058m} أربعةَ عشرَ نمطًا ولا نمطَ للدالةِ فيهِ، فـ{@code ColorDefault} لا سطرَ لَهَا،
 * ولونُ ما لا سطرَ لهُ هو لونُ النصِّ الساذجِ. ذاكَ ما يَقرَأُهُ المِرصادُ أيضًا: في لقطةِ المصدرِ
 * «getView» و«getCount» بلونِ الجسدِ، و«name» و«id» — الحقولُ — عنبريَّةٌ؛ فمِنَ الخطأِ أن تُجعَلَ
 * الدالةُ والمعرِّفُ صَفًّا واحدًا (عَطَلُ ‏1.0.187: صارت أسماءُ الدوالِ بلونِ المتغيِّراتِ). ولا صَفَّ
 * رابعَ عشرَ يُختَرَعُ لها: اللوحةُ كما عندَهم ثلاثةَ عشرَ سطرًا، والدالةُ تَقرَأُ سطرَ {@code Plain}
 * القابلَ للتحريرِ كما يَفعَلُ المرجعُ. واسمُ الباني في تعريفِهِ صنفٌ لا دالةٌ
 * ({@code TYPE_IDENTIFIER}) كما يَنسِبُهُ المحرِّكُ.
 *
 * <p>أرقامُ العلاماتِ مُطابقةٌ للمصدرِ عمدًا ({@code 0} عاديٌّ، {@code 1} غامق، {@code 2} مائل) فلا تُترجَمُ
 * علاماتُهُ إلى أرقامٍ عندنا مرةً أخرى عندَ كلِّ قراءة.
 */
public final class EditorSyntaxRoles {

  /** عددُ الأنماطِ اللغويةِ التي يفهمُها المحرّر (٠ ساذجٌ حتى {@code DOC_COMMENT}=١٣) — حجمُ لوحةِ cache. */
  public static final int PALETTE_SIZE = com.almlkid.kay.ui.CodeLanguageTools.DOC_COMMENT + 1;

  public static final int FLAG_NONE = 0;
  public static final int FLAG_BOLD = 1;
  public static final int FLAG_ITALIC = 2;

  private EditorSyntaxRoles() {}

  /**
   * دورُ اللوحةِ الذي يُصبَغُ به نمطٌ من {@code CodeLanguageTools}. الحقولُ والمتغيّراتُ
   * {@code Identifier}، وأسماءُ الدوالِ {@code Plain} — لا سطرَ للدالةِ في لوحةِ المصدرِ فلا تَأخُذُ
   * لونَ غيرِها؛ والوسومُ وأسماءُ الأصنافِ والبواني {@code Type Identifier}، والعليقَةُ مفتاحٌ غامقٌ
   * لأنَّ المصدرَ لا يفردُ لها دورًا.
   */
  public static String paletteKey(int styleId) {
    switch (styleId) {
      case com.almlkid.kay.ui.CodeLanguageTools.KEYWORD:
      case com.almlkid.kay.ui.CodeLanguageTools.ANNOTATION:
        return EditorThemePalette.KEYWORD;
      case com.almlkid.kay.ui.CodeLanguageTools.STRING:
      case com.almlkid.kay.ui.CodeLanguageTools.NUMBER:
        return EditorThemePalette.LITERAL;
      case com.almlkid.kay.ui.CodeLanguageTools.COMMENT:
        return EditorThemePalette.COMMENT;
      case com.almlkid.kay.ui.CodeLanguageTools.TAG:
        return EditorThemePalette.TYPE_IDENTIFIER;
      case com.almlkid.kay.ui.CodeLanguageTools.NAMESPACE:
        return EditorThemePalette.NAMESPACE_IDENTIFIER;
      case com.almlkid.kay.ui.CodeLanguageTools.OPERATOR:
        return EditorThemePalette.OPERATOR;
      case com.almlkid.kay.ui.CodeLanguageTools.SEPARATOR:
        return EditorThemePalette.SEPARATOR;
      case com.almlkid.kay.ui.CodeLanguageTools.IDENTIFIER:
      case com.almlkid.kay.ui.CodeLanguageTools.VARIABLE:
        return EditorThemePalette.IDENTIFIER;
      case com.almlkid.kay.ui.CodeLanguageTools.FUNCTION:
        // ‏1.0.189: الدالةُ لا تُصبَغُ بلونِ المتغيِّرِ. المرجعُ لا يَفردُ لها صَفًّا، فلونُها لونُ
        // الجسدِ — تَشرُفُ على صَفِّ المعرِّفِ ولا تُشارِكُهُ، وهي سادةٌ لا غامقةٌ ولا مائلةٌ.
        return EditorThemePalette.PLAIN;
      case com.almlkid.kay.ui.CodeLanguageTools.DOC_COMMENT:
        // دورانِ منْ مواردِ النظام، خارجَ اللوحةِ القابلةِ للتحرير: لا ثيمَ يمسُّهُما ولا مُحرّرُ ألوانٍ.
        return EditorThemePalette.DOCUMENTATION_COMMENT;
      default:
        return EditorThemePalette.PLAIN;
    }
  }

  /** علاماتُ النمطِ كما في جدولِ المصدر: غامقٌ للمفاتيح، مائلٌ للباقةِ وتعليقِ الوثائقِ فقط. */
  public static int flagsFor(int styleId) {
    switch (styleId) {
      case com.almlkid.kay.ui.CodeLanguageTools.KEYWORD:
      case com.almlkid.kay.ui.CodeLanguageTools.ANNOTATION:
        return FLAG_BOLD;
      case com.almlkid.kay.ui.CodeLanguageTools.NAMESPACE:
      case com.almlkid.kay.ui.CodeLanguageTools.DOC_COMMENT:
        // علامةُ المصدرِ للاثنينِ flag=2 (مائلُ فقط)، كلُّها في جدولِ EnumC0058m.
        return FLAG_ITALIC;
      default:
        return FLAG_NONE;
    }
  }

  public static boolean isBold(int styleId) {
    return (flagsFor(styleId) & FLAG_BOLD) != 0;
  }

  public static boolean isItalic(int styleId) {
    return (flagsFor(styleId) & FLAG_ITALIC) != 0;
  }

  /** لونُ الدورِ في لوحةٍ بعينِها — المنفذُ الوحيدُ الذي يقرؤُهُ المحرّرُ والمِرساةَ والملوّحات. */
  public static int colorFor(int styleId, ThemeReader reader, boolean light) {
    return reader.color(paletteKey(styleId), light);
  }

  /** ما تحتاجُ الطبقةُ الرسّامةُ قراءتَهُ من اللوحة، بلا ربطٍ بصنفِ Android. */
  public interface ThemeReader {
    int color(String role, boolean light);
  }
}
