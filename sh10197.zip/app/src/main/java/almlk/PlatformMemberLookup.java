package almlk;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Knows the members of platform types (Stage 4 of error checking).
 *
 * <p>The semantic checker must never guess about SDK classes: an incomplete hand-written table is
 * exactly what produced false "missing method" reports before. Instead the members are read by
 * reflection from the classes of the running platform itself — on a device that is the Android
 * framework and its core library, loaded through the boot class loader, so the application's own
 * bundled libraries (androidx and friends, possibly in other versions) are never consulted.
 *
 * <p>M4: types of the <em>project's</em> libraries are read from {@link AndroidApiIndex}'s library
 * layer (the indexed dependency JARs) and their supertype chain is followed into the platform. Such
 * a type is only {@linkplain Members#complete complete} when every link of that chain is known;
 * otherwise an absent member stays unknown, as before.
 *
 * <p>An absent member is <em>definitive</em> unless the project is known to compile against a newer
 * SDK than the device (a newer API could then be missing here). Results, including unresolvable
 * names, are cached.
 */
public final class PlatformMemberLookup {

  /** Reflected member names of one platform type. */
  public static final class Members {
    /** Source spelling, e.g. {@code android.view.View.OnClickListener}. */
    public final String qualifiedName;
    /** Binary name, e.g. {@code android.view.View$OnClickListener}. */
    public final String binaryName;
    /** Every supertype was found: an absent member is proven absent (see isAbsenceDefinitive). */
    public final boolean complete;
    private final Set<String> methods;
    private final Set<String> fields;

    Members(String binaryName, Set<String> methods, Set<String> fields) {
      this(binaryName, methods, fields, true);
    }

    Members(String binaryName, Set<String> methods, Set<String> fields, boolean complete) {
      this.binaryName = binaryName;
      this.qualifiedName = binaryName.replace('$', '.');
      this.methods = methods;
      this.fields = fields;
      this.complete = complete;
    }

    public boolean hasMethod(String name) {
      return methods.contains(name);
    }

    public boolean hasField(String name) {
      return fields.contains(name);
    }
  }

  private static final String[] PLATFORM_PREFIXES = {
    "java.", "javax.", "android.", "dalvik.", "org.json.", "org.w3c.dom.", "org.xml.sax."
  };
  private static final Object MISSING = new Object();
  private static final ConcurrentHashMap<String, Object> CACHE = new ConcurrentHashMap<>();
  private static final int JVM = Integer.MAX_VALUE;
  /** null = boot class loader: framework + core library only, never the app's own libraries. */
  private static volatile ClassLoader loader;
  private static volatile int compileSdk;
  private static volatile int platformSdk = -1;

  private PlatformMemberLookup() {}

  /** Test hook: resolve against another loader (e.g. one that carries SDK stubs). */
  public static void useClassLoader(ClassLoader classLoader) {
    loader = classLoader;
    CACHE.clear();
  }

  /** The project's compileSdk (0 = unknown); see {@link #isAbsenceDefinitive()}. */
  public static void setCompileSdk(int value) {
    compileSdk = Math.max(0, value);
  }

  public static int compileSdk() {
    return compileSdk;
  }

  /**
   * True when "member not found" may be reported. The running platform is the reference (as the
   * source app judges by its bundled android.jar), so an unknown compileSdk — a file opened before
   * the project scan, or outside any project — does not silence the check. Only a project known to
   * compile against a newer SDK than this device stays uncertain.
   */
  public static boolean isAbsenceDefinitive() {
    int platform = platformSdk();
    return platform == JVM || compileSdk <= 0 || platform >= compileSdk;
  }

  /**
   * Absence on {@code type} may be reported: always for the root types whose members never changed
   * across API levels (Object, Enum), otherwise per {@link #isAbsenceDefinitive()}.
   */
  public static boolean isAbsenceDefinitive(Members type) {
    if (type != null && !type.complete) return false;
    if (type != null && STABLE_TYPES.contains(type.binaryName)) return true;
    return isAbsenceDefinitive();
  }

  private static final java.util.Set<String> STABLE_TYPES =
      new java.util.HashSet<>(java.util.Arrays.asList("java.lang.Object", "java.lang.Enum"));

  private static int platformSdk() {
    int value = platformSdk;
    if (value >= 0) return value;
    try {
      Class<?> version = Class.forName("android.os.Build$VERSION", false, null);
      value = version.getField("SDK_INT").getInt(null);
    } catch (Throwable notAndroid) {
      value = JVM; // plain JVM (regression suite): the loaded classes are the whole truth
    }
    platformSdk = value;
    return value;
  }

  private static final Pattern COMPILE_SDK =
      Pattern.compile(
          "\\bcompileSdk(?:Version)?\\s*(?:=|\\(|\\s)\\s*(?:android-)?[\"']?(?:android-)?(\\d{1,3})");
  private static final Pattern PROPERTIES_TARGET =
      Pattern.compile("(?m)^\\s*target\\s*=\\s*android-(\\d{1,3})");

  /** Reads compileSdk from build.gradle(.kts), or target=android-N from project.properties. */
  public static int parseCompileSdk(String text) {
    if (text == null) return 0;
    Matcher gradle = COMPILE_SDK.matcher(text);
    if (gradle.find()) return Integer.parseInt(gradle.group(1));
    Matcher properties = PROPERTIES_TARGET.matcher(text);
    return properties.find() ? Integer.parseInt(properties.group(1)) : 0;
  }

  public static boolean isPlatformName(String qualified) {
    if (qualified == null) return false;
    for (String prefix : PLATFORM_PREFIXES) if (qualified.startsWith(prefix)) return true;
    return false;
  }

  /**
   * Resolves a type as written in a source file ({@code TextView}, {@code View.OnClickListener},
   * {@code java.util.List<String>}) using that file's imports ({@code a.b.C} or {@code a.b.*}).
   * Returns null when it is not a resolvable platform type.
   */
  public static Members resolve(String typeRef, List<String> imports, String packageName) {
    String ref = stripGenerics(typeRef);
    if (ref.isEmpty() || ref.indexOf('[') >= 0 || ref.indexOf('?') >= 0) return null;
    List<String> fileImports = imports == null ? Collections.<String>emptyList() : imports;
    int dot = ref.indexOf('.');
    String pkg = packageName == null ? "" : packageName.trim();
    if (dot < 0) return resolveSimple(ref, fileImports, pkg);
    Members direct = loadQualified(ref);
    if (direct != null) return direct;
    Members outer = resolveSimple(ref.substring(0, dot), fileImports, pkg);
    if (outer == null) return null;
    return load(outer.binaryName + "$" + ref.substring(dot + 1).replace('.', '$'));
  }

  /**
   * Java's lookup order for a simple name: single-type imports, then the file's own package, then
   * on-demand imports and java.lang. A same-package class shadows java.lang (a project's own
   * {@code Record} or {@code Process} is not java.lang's), so when the package is not a platform
   * one — the class may simply not be loadable here — the name is left unresolved.
   */
  private static Members resolveSimple(String simple, List<String> imports, String packageName) {
    for (String imported : imports) {
      if (imported.endsWith(".*")) continue;
      if (imported.equals(simple) || imported.endsWith("." + simple)) return loadQualified(imported);
    }
    if (!packageName.isEmpty()) {
      Members samePackage = load(packageName + "." + simple);
      if (samePackage != null) return samePackage;
    }
    for (String imported : imports) {
      if (!imported.endsWith(".*")) continue;
      String owner = imported.substring(0, imported.length() - 2);
      Members found = load(owner + "." + simple);
      if (found == null) found = load(owner + "$" + simple); // import a.b.Outer.* (nested types)
      if (found != null) return found;
    }
    return load("java.lang." + simple);
  }

  /** {@code a.b.Outer.Inner} → tries a.b.Outer.Inner, then a.b.Outer$Inner, … */
  private static Members loadQualified(String name) {
    String candidate = name;
    while (true) {
      Members found = load(candidate);
      if (found != null) return found;
      int dot = candidate.lastIndexOf('.');
      if (dot < 0) return null;
      String owner = candidate.substring(0, dot);
      if (owner.indexOf('.') < 0 || Character.isLowerCase(owner.charAt(owner.lastIndexOf('.') + 1)))
        return null; // never turn a package segment into a nested class
      candidate = owner + "$" + candidate.substring(dot + 1);
    }
  }

  /**
   * Loads (and caches) one binary class name: a platform class by reflection, otherwise a class of
   * the project's libraries from the index; null when neither knows it.
   */
  public static Members load(String binaryName) {
    if (binaryName == null || binaryName.isEmpty()) return null;
    Object cached = CACHE.get(binaryName);
    if (cached != null) return cached == MISSING ? null : (Members) cached;
    Members members = isPlatformName(binaryName) ? reflect(binaryName) : null;
    if (members == null) members = fromLibraries(binaryName);
    CACHE.put(binaryName, members == null ? MISSING : members);
    return members;
  }

  /** The library layer changed: forget cached answers (reflection is cheap to redo). */
  static void clearLibraryCache() {
    CACHE.clear();
  }

  /**
   * Members of a library class: its own and its supertypes' (library ones from the index, platform
   * ones by reflection). Incomplete when any supertype is unknown or the class is provisional (R).
   */
  private static Members fromLibraries(String binaryName) {
    if (AndroidApiIndex.libraryClassCount() == 0) return null;
    AndroidApiIndex.ClassInfo start = AndroidApiIndex.classByQualifiedName(binaryName.replace('$', '.'));
    if (start == null || !start.library) return null;
    HashSet<String> methods = new HashSet<>();
    HashSet<String> fields = new HashSet<>();
    boolean complete = !start.provisional;
    java.util.ArrayDeque<String> queue = new java.util.ArrayDeque<>();
    HashSet<String> seen = new HashSet<>();
    queue.add(start.qualifiedName);
    while (!queue.isEmpty()) {
      String name = stripGenerics(queue.poll());
      if (name.isEmpty() || !seen.add(name)) continue;
      AndroidApiIndex.ClassInfo info = AndroidApiIndex.classByQualifiedName(name);
      if (info != null && info.library) {
        if (info.provisional) complete = false;
        for (AndroidApiIndex.Member m : AndroidApiIndex.declaredMembers(info))
          (m.kind == AndroidApiIndex.Member.FIELD ? fields : methods).add(m.name);
        if (info.kind.equals("e")) {
          methods.add("values");
          methods.add("valueOf");
        }
        if (!info.superName.isEmpty()) queue.add(info.superName);
        for (String i : info.interfaces) queue.add(i);
        continue;
      }
      Members platform = isPlatformName(name) ? loadQualified(name) : null;
      if (platform == null) {
        complete = false;
        continue;
      }
      methods.addAll(platform.methods);
      fields.addAll(platform.fields);
    }
    for (Method method : Object.class.getMethods()) methods.add(method.getName());
    methods.add("clone");
    methods.add("finalize");
    return new Members(binaryOf(start), methods, fields, complete);
  }

  /** a.b.Outer.Inner (index spelling) → a.b.Outer$Inner. */
  private static String binaryOf(AndroidApiIndex.ClassInfo info) {
    if (!info.isNested()) return info.qualifiedName;
    AndroidApiIndex.ClassInfo outer = AndroidApiIndex.classByQualifiedName(info.container);
    return (outer == null ? info.container : binaryOf(outer)) + "$" + info.simpleName;
  }

  private static Members reflect(String binaryName) {
    try {
      Class<?> type = Class.forName(binaryName, false, loader);
      HashSet<String> methods = new HashSet<>();
      HashSet<String> fields = new HashSet<>();
      for (Method method : type.getMethods()) methods.add(method.getName());
      for (Field field : type.getFields()) fields.add(field.getName());
      for (Class<?> k = type; k != null; k = k.getSuperclass()) {
        for (Method method : k.getDeclaredMethods()) methods.add(method.getName());
        for (Field field : k.getDeclaredFields()) fields.add(field.getName());
      }
      for (Method method : Object.class.getMethods()) methods.add(method.getName());
      methods.add("clone");
      methods.add("finalize");
      if (type.isEnum()) {
        methods.add("values");
        methods.add("valueOf");
      }
      return new Members(type.getName(), methods, fields);
    } catch (Throwable unavailable) {
      // ClassNotFound, LinkageError, hidden-API or security failures: the type stays unknown.
      return null;
    }
  }

  // ───────────────── W27/3 (‏1.0.180): ما يَطلُبُهُ الأصلُ من دونٍ — من الإطارِ الجاري ─────────────────

  /** نفسُ صندوقِ التَوسُّمِ للفهارسِ: لا مَرَّ ثانٍ على {@code getDeclaredMethods} لكلِّ نبضةِ مفتاحٍ. */
  private static final ConcurrentHashMap<String, Object> ABSTRACTS = new ConcurrentHashMap<>();

  /** كفايةُ الأصنافِ: صندوقٌ ثانٍ لنفسِ السببِ — انِعكاسٌ لكلِّ نبضةِ مفتاحٍ لا مَرَّتينِ. */
  private static final ConcurrentHashMap<String, Object> IMPLEMENTED = new ConcurrentHashMap<>();

  /**
   * الدوالُّ المجرّدةُ التي يَجِبُ على صنفٍ يَرِثُ {@code qualifiedName} أن يَكتُبَها، أو {@code null}
   * إذا لم يُحمَّلِ الصنفُ أصلاً (فلا حُكمَ على ما لا يُعرَفُ). القراءةُ انِعكاسٌ على مُحمِّلِ الطبقةِ
   * الابتدائيّةِ نفسِهِ الذي تَسأَلُهُ {@link #load(String)} — أي إطارُ الجهازِ الذي يُبنَى لهُ فعلًا،
   * لا جَدوَلٌ يدويٌّ ولا نسخةُ جَرَّةٍ مُغلَّفةٌ؛ وبابُ السلسلةِ هنا هو بابُ المُترجِمِ: نَصعَدُ ما دامَ
   * الأصلُ مُجرَّدًا أو واجهةً، ونَقفُ عندَ أوَّلِ صنفٍ مَبنيٍّ لأنَّهُ تَكفَّلَ بما تَحتَهُ.
   */
  public static List<AbstractImplementationGap.Required> abstractMethodsOf(String qualifiedName) {
    if (qualifiedName == null || qualifiedName.isEmpty()) return null;
    if (!isPlatformName(qualifiedName)) return null;
    Object cached = ABSTRACTS.get(qualifiedName);
    if (cached != null)
      return cached == MISSING ? null : (List<AbstractImplementationGap.Required>) cached;
    List<AbstractImplementationGap.Required> out = null;
    Class<?> type = loadType(qualifiedName);
    if (type != null) {
      out = new java.util.ArrayList<AbstractImplementationGap.Required>();
      HashSet<String> seen = new HashSet<>();
      collectAbstract(type, out, seen);
    }
    ABSTRACTS.put(qualifiedName, out == null ? MISSING : out);
    return out;
  }

  /**
   * الدوالُّ التي يُلبيها هذا الصنفُ أو أحدُ أسلافِهِ — أيْ ما لا يَنبغِي أن يُطلَبَ من وارثِهِ.
   * المفتاحُ {@code الاسم/عَدَدُ المَعاملِ} كما في {@code AbstractImplementationGap.Required#key()}.
   *
   * <p>القراءةُ {@code getMethods()} لا {@code getDeclaredMethods()}: الكفايةُ مورَثةٌ أيضًا (بعضُها
   * مُنفَّذٌ في صنفٍ بينَ الأصلِ والوارثِ)، والمجرَّدةُ لا تُحسَبُ كفايةً وإلّا أسقَطَتْ طلبًا واجبًا.
   * المِثاليُّ (static) لا دَخلَ لهُ بالتغطيةِ، والجسورُ والمُولَّدةُ تُترَكُ كما في {@link
   * #abstractMethodsOf}. و{@code null} عندَ صنفٍ لا يُحمَّلُ: لا حُكمَ على مجهولٍ.
   */
  public static Set<String> concreteMethodKeys(String qualifiedName) {
    if (qualifiedName == null || qualifiedName.isEmpty()) return null;
    if (!isPlatformName(qualifiedName)) return null;
    Object cached = IMPLEMENTED.get(qualifiedName);
    if (cached != null) return cached == MISSING ? null : (Set<String>) cached;
    Set<String> out = null;
    Class<?> type = loadType(qualifiedName);
    if (type != null) {
      HashSet<String> keys = new HashSet<>();
      try {
        for (Method method : type.getMethods()) {
          int mods = method.getModifiers();
          if (java.lang.reflect.Modifier.isAbstract(mods) || java.lang.reflect.Modifier.isStatic(mods))
            continue;
          if (method.isSynthetic() || method.isBridge()) continue;
          keys.add(method.getName() + "/" + method.getParameterTypes().length);
        }
        out = Collections.unmodifiableSet(keys);
      } catch (Throwable unavailable) {
        out = null; // NoClassDefFoundError على توقيعٍ لا تَحملُهُ المُحمِّلةُ: الجوابُ «لا أُدري»
      }
    }
    IMPLEMENTED.put(qualifiedName, out == null ? MISSING : out);
    return out;
  }

  /** الاسمُ المُنقَّطُ ← صنفٌ: {@code Map.Entry} يُجرَّبُ{@code Map$Entry} كما في {@link #loadQualified}. */
  private static Class<?> loadType(String qualifiedName) {
    String candidate = qualifiedName;
    while (true) {
      try {
        return Class.forName(candidate, false, loader);
      } catch (Throwable unavailable) {
        int dot = candidate.lastIndexOf('.');
        if (dot < 0) return null;
        String owner = candidate.substring(0, dot);
        if (owner.indexOf('.') < 0 || Character.isLowerCase(owner.charAt(owner.lastIndexOf('.') + 1)))
          return null;
        candidate = owner + "$" + candidate.substring(dot + 1);
      }
    }
  }

  private static void collectAbstract(Class<?> type, List<AbstractImplementationGap.Required> out,
      Set<String> seen) {
    if (type == null || type == Object.class) return;
    if (!type.isInterface() && !java.lang.reflect.Modifier.isAbstract(type.getModifiers()))
      return; // صنفٌ مَبنيٌّ: ما تَحتَهُ مَقضيٌّ عليهِ هو، لا على الوارثِ
    try {
      for (Method method : type.getDeclaredMethods()) {
        int mods = method.getModifiers();
        if (!java.lang.reflect.Modifier.isAbstract(mods) || java.lang.reflect.Modifier.isStatic(mods))
          continue;
        if (method.isSynthetic() || method.isBridge()) continue;
        Class<?>[] argTypes = method.getParameterTypes();
        List<String> params = new java.util.ArrayList<String>(argTypes.length);
        for (Class<?> arg : argTypes) params.add(canonicalName(arg));
        AbstractImplementationGap.Required required =
            new AbstractImplementationGap.Required(type.getName().replace('$', '.'),
                method.getName(), params, canonicalName(method.getReturnType()),
                method.isVarArgs());
        if (seen.add(required.key())) out.add(required);
      }
    } catch (Throwable unavailable) {
      // NoClassDefFoundError على أنواعٍ مُوقَّعةٍ لا تَحملُها هذهِ المُحمِّلةُ: ما وُجِدَ قَبلَها ثابتٌ.
      return;
    }
    for (Class<?> iface : type.getInterfaces()) collectAbstract(iface, out, seen);
    if (!type.isInterface()) collectAbstract(type.getSuperclass(), out, seen);
  }

  /** {@code void}/{@code int}/{@code java.lang.String[]}: الأسماءُ القانونيّةُ بلا قَرنٍ بمِثَالِ النوعِ. */
  private static String canonicalName(Class<?> type) {
    String name = type == null ? "void" : type.getCanonicalName();
    if (name == null || name.isEmpty()) return type == null ? "void" : type.getName();
    return name;
  }

  /** البوّابةُ وحدَها: نِسيانُ صندوقِ الدوالِّ المجرّدةِ (لا يُختبَرُ عليهِ بينَ مرحلتَينِ). */
  static void clearAbstractCache() {
    ABSTRACTS.clear();
    IMPLEMENTED.clear();
  }

  public static String stripGenerics(String typeRef) {
    if (typeRef == null) return "";
    StringBuilder out = new StringBuilder();
    int depth = 0;
    for (int i = 0; i < typeRef.length(); i++) {
      char c = typeRef.charAt(i);
      if (c == '<') depth++;
      else if (c == '>') depth = Math.max(0, depth - 1);
      else if (depth == 0 && !Character.isWhitespace(c)) out.append(c);
    }
    String value = out.toString();
    if (value.endsWith("...")) value = value.substring(0, value.length() - 3) + "[]";
    return value;
  }
}
