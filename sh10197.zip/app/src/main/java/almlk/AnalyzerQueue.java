package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * طابورُ الطلباتِ بينَ الواجهةِ وعمليةِ التحليلِ — وجهانِ تعلَّمَتُهُما الطبقةُ من المرجعِ:
 *
 * <ul>
 *   <li><b>طابورٌ معلَّقٌ يُصرَّفُ عندَ الاتصالِ</b>: في {@code com.aide.ui.build.android
 *       .ServiceConnectionC0053S} يضبطُ المُتّصِلُ الوكيلَ ثمَّ {@code while (!queue.isEmpty())
 *       queue.poll().run();}. عندَنا يُصرَّفُ مثلَهُ لكن بلا تنفيذٍ على خيطِ الربطِ: الجسرُ يطلبُ من
 *       الواجهةِ أن تُرسِلَ، فلا يعملُ خيطُ {@code ServiceConnection} شيئًا غيرَ تبديلِ الوكيلِ.
 *   <li><b>الدمجُ بآخرِ لقطةٍ لكلِّ ملفٍّ</b>: المرجعُ يُسقِطُ الطلبَ بلا وكيلٍ ({@code if (proxy == null)
 *       return;}) وهذا يُفقِدُ الفحصَ بعدَ إعادةِ الربطِ؛ عندَنا يبقى آخرُ لقطةٍ في الطابورِ وتُرسَلُ متى عادَتِ
 *       العمليةُ — ولا صفٌّ يُنمُو معَ كلِّ ضغطةِ مفتاحٍ.
 *   <li><b>الجيلُ الواحدُ الصالحُ</b>: كلُّ ردٍّ ليس من أحدثِ جيلٍ {@code stale}، فلا تُطبَّقُ نتيجةٌ على نصٍّ
 *       بائتٍ (معنى {@code abcd.Xj.Hw:AtomicInteger} هناك).
 *   <li><b>عصرُ الربطِ (epoch)</b>: يزدادُ عندَ كلِّ اتصالٍ وانقطاعٍ، فيَبطُلُ ما هو في الطريقِ حتمًا — لا
 *       بالتوقيتِ ولا بالحظِّ.
 * </ul>
 *
 * <p>الطبقةُ صافيةٌ: لا خيوطَ ولا {@code android}؛ التزامنُ قفلٌ واحدٌ لأنَّ المتنافِسَينِ فقط خيطُ الواجهةِ
 * وخيطُ ردِّ ‏{@code Messenger}.
 */
public final class AnalyzerQueue {

  /** أقصى عددٌ من اللقطاتِ المعلَّقةِ (ملفٌّ واحدٌ لكلِّ مُحرِّرٍ حيٍّ): ما زادَ يُعدُّ ويُطرَدُ أقدمُهُ. */
  public static final int MAX_QUEUED = 6;

  /**
   * الحالاتُ المسماةُ — تُطبعُ في السجلِّ وتُقرأُ في الاختباراتِ، لا أرقامَ عائمةً: {@code sending} طلبٌ في
   * الطريقِ، {@code queued} لقطاتٌ تنتظرُ الوصلَ، {@code idle} صَفرٌ مُنجَزٌ، {@code overflow} رُفِضَ طابورًا
   * سابقًا والعدادُ ما زالَ قائمًا (لا يُنسى الفيضانُ لأنَّهُ لم يُطبَّق).
   */
  public static final String STATE_IDLE = "idle";
  public static final String STATE_QUEUED = "queued";
  public static final String STATE_SENDING = "sending";
  public static final String STATE_OVERFLOW = "overflow";

  /** لقطةٌ واحدةٌ: ملفٌّ + جيلٌ + عصرٌ + النصُّ (مرجعٌ، لا استنساخٌ لكلِّ طابورٍ). */
  public static final class Job {
    public final long generation;
    public final int epoch;
    public final String file;
    public final int totalChars;
    public final String text;

    Job(long generation, int epoch, String file, String text) {
      this.generation = generation;
      this.epoch = epoch;
      this.file = file == null ? "" : file;
      this.text = text == null ? "" : text;
      this.totalChars = this.text.length();
    }
  }

  private final ArrayList<Job> pending = new ArrayList<>(MAX_QUEUED);
  private final ArrayList<String> problems = new ArrayList<>(4);
  private Job inFlight;
  private long generation;
  private int epoch;
  private int sent;
  private int applied;
  private int replies;
  private int stale;
  private int dropped;
  private boolean bound;
  private String state = STATE_IDLE;

  // ─────────────────────────── الإرسالُ والتطبيقُ ───────────────────────────

  /**
   * يُسجِّلُ أحدثَ لقطةٍ لملفٍّ: يرفعُ الجيلَ، ويَدمجُ مع ما هو معلَّقٌ من نفسِ الملفِّ، ويُبلِغُ إن كان
   * الصَّفُّ مُثقلًا. الطلبُ المُعادُ إليهِ جاهزٌ للإرسالِ عندَ {@link #ready()}.
   */
  public synchronized Job submit(String file, String text) {
    generation++;
    Job job = new Job(generation, epoch, file, text);
    for (int i = 0; i < pending.size(); i++) {
      if (pending.get(i).file.equals(job.file)) {
        pending.set(i, job);
        refresh();
        return job;
      }
    }
    if (pending.size() >= MAX_QUEUED) {
      pending.remove(0);
      dropped++;
      note("pending capped at " + MAX_QUEUED + " (oldest dropped)");
    }
    pending.add(job);
    refresh();
    return job;
  }

  /**
   * ما يصلحُ للإرسالِ الآنَ: لا شيءَ إن كانَ في الطريقِ طلبٌ لم يَرجِعْ بعدُ (الفاحصُ خيطٌ واحدٌ)،
   * وإلا فأقدمُ ما في الطابورِ.
   */
  public synchronized Job ready() {
    if (!bound || inFlight != null || pending.isEmpty()) return null;
    return pending.get(0);
  }

  /** انطلَقَ الطلبُ: يَخرُجُ من الطابورِ ويصيرُ «جارٍ» حتى يَرجِعَ جيلُهُ أو يبطُلَ. */
  public synchronized void noteSent(Job job) {
    if (job == null) return;
    pending.remove(job);
    inFlight = job;
    sent++;
    refresh();
  }

  /** الجوابُ وصلَ (صالحًا كانَ أو بائتًا): لا طلبَ في الطريقِ بعدَها. */
  public synchronized void noteReplied() {
    inFlight = null;
    replies++;
    refresh();
  }

  /** طُبِّقَتِ النتيجةُ: يُعلَمُ ذلكَ للقياسِ، ويُنظَرُ في التالي. */
  public synchronized void noteApplied(Job job) {
    if (job != null) applied++;
    noteReplied();
  }

  /** رُدَّ جوابٌ بائتٌ: يُعدُّ لتبقى الكميةُ معلومةً في السجلِّ لا ضائعةً. */
  public synchronized void noteStale() {
    stale++;
    noteReplied();
  }

  // ─────────────────────────── الربطُ والقطعُ ───────────────────────────

  /**
   * اتّصَلَ الوكيلُ: عصرٌ جديدٌ يُبطِلُ كلَّ ما هو في الطريقِ القديمِ، ويُعادُ ما في الطابورِ للإرسالِ
   * بالترتيبِ (الوجهانِ معًا كما في المرجعِ: تصفيرُ الوكيلِ عندَ القطعِ، وتصريفُ الطابورِ عندَ الاتصالِ).
   */
  public synchronized List<Job> noteBound() {
    bound = true;
    inFlight = null;
    epoch++;
    if (pending.isEmpty()) {
      refresh();
      return Collections.emptyList();
    }
    ArrayList<Job> out = new ArrayList<>(pending.size());
    // ما كانَ معلَّقًا يُطعَنُ من جديدٍ بجيلٍ وعصرِ اللحظةِ — جيلٌ جديدٌ لا القديمُ، وإلا اتَّفقَ ردٌّ من
    // العصرِ السابقِ مع الأحدثِ رقمًا فمَرَّ مُتظاهيًا بأنَّهُ صالحٌ. يبقى في الطابورِ بترتيبِهِ، فيأخذُ
    // دورَهُ عبرَ {@link #ready()} كأيِّ طلبٍ آخرَ: لا مسارَينِ للإرسالِ ولا قفزا على السقفِ.
    for (int i = 0; i < pending.size(); i++) {
      Job old = pending.get(i);
      Job stamped = new Job(++generation, epoch, old.file, old.text);
      pending.set(i, stamped);
      out.add(stamped);
    }
    refresh();
    return out;
  }

  /** فشلَ الإرسالُ (الوكيلُ انقطعَ في نصفِ الطلبِ): يعودُ الطلبُ إلى رأسِ الطابورِ بلا جيلٍ جديدٍ. */
  public synchronized void requeue(Job job) {
    if (job == null) return;
    inFlight = null;
    if (pending.contains(job)) {
      refresh();
      return;
    }
    if (pending.size() >= MAX_QUEUED) {
      pending.remove(pending.size() - 1);
      dropped++;
      note("pending capped at " + MAX_QUEUED + " (newest dropped on requeue)");
    }
    pending.add(0, job);
    sent = Math.max(0, sent - 1);
    refresh();
  }

  /** انقطعتِ العمليةُ: لا صالحَ لما في الطريقِ، والطابورُ يبقى لما بعدَ إعادةِ الربطِ. */
  public synchronized void noteUnbound() {
    bound = false;
    inFlight = null;
    epoch++;
    refresh();
  }

  /**
   * هل هذا الردُّ بائتٌ؟ الصالحُ وحدَهُ ما كان من أحدثِ جيلٍ أرسَلَهُ هذا الطابورُ: لا مقارنةَ بطولِ
   * النصِّ ولا بالوقتِ — جيلٌ واحدٌ يسودُ، وهو ما يجعلُ إهدارَ القديمِ حتميًا.
   */
  public synchronized boolean isStale(long replyGeneration) {
    return replyGeneration != generation;
  }

  /** الردُّ يخصُّ الطلبَ الجاريَ نفسَهُ؟ (اسمُ الملفِّ قيدٌ ثانٍ: لا تُطبَّقُ نتيجةُ ملفٍّ على آخرَ). */
  public synchronized boolean answers(long replyGeneration, String file) {
    Job flight = inFlight;
    if (flight == null) return false;
    return flight.generation == replyGeneration && flight.file.equals(file == null ? "" : file);
  }

  /** هل الطلبُ الذي أرسَلْتَهُ ما زالَ صالحًا للإرسالِ؟ (قد يَسبِقُهُ طلبٌ أحدثُ من نفسِ الملفِّ). */
  public synchronized boolean isCurrent(Job job) {
    return job != null && job.epoch == epoch && job.generation == generation;
  }

  // ─────────────────────────── القياسُ والحالاتُ ───────────────────────────

  public synchronized boolean isBound() {
    return bound;
  }

  public synchronized boolean isBusy() {
    return inFlight != null;
  }

  public synchronized int size() {
    return pending.size();
  }

  public synchronized boolean isEmpty() {
    return pending.isEmpty();
  }

  public synchronized long generation() {
    return generation;
  }

  public synchronized int epoch() {
    return epoch;
  }

  public synchronized int sentCount() {
    return sent;
  }

  /** عددُ ما رُدَّ على طلبٍ جارٍ (صالحًا كانَ أم فاضيَ النتيجةِ): يُثبِتُ أنَّ الردَّ لم يُسقَطْ بلا علمٍ. */
  public synchronized int replyCount() {
    return replies;
  }

  public synchronized int appliedCount() {
    return applied;
  }

  public synchronized int staleCount() {
    return stale;
  }

  public synchronized int droppedCount() {
    return dropped;
  }

  public synchronized String state() {
    return state;
  }

  public synchronized List<String> problems() {
    return Collections.unmodifiableList(new ArrayList<>(problems));
  }

  /** يُترَكُ الطابورُ (تبويبٌ أُغلِقَ أو المحرِّرُ انفصلَ): ما لم يُرسَلْ يَسقُطُ، والجارِي يَلغُوهُ الطرفُ الآخرُ. */
  public synchronized void clear() {
    pending.clear();
    inFlight = null;
    problems.clear();
    // الجلسةُ انتهَتْ: تُصفَّرُ العدّاداتُ حتى لا يَرى المُستعمِلُ الجديدُ «فيضانَ» الجلسةِ السابقةِ،
    // ويَبقى الجيلُ والعصرُ كما هما — ردٌّ تأخَّرَ من تلكَ الجلسةِ لا يَجوزُ أن يَطابِقَ جيلًا صِفرًا.
    dropped = 0;
    sent = 0;
    applied = 0;
    replies = 0;
    stale = 0;
    refresh();
  }

  private void refresh() {
    if (inFlight != null) state = STATE_SENDING;
    else if (dropped > 0 && pending.size() >= MAX_QUEUED) state = STATE_OVERFLOW; // ممتلئٌ ويُهدَرُ
    else if (!pending.isEmpty()) state = STATE_QUEUED;
    else if (dropped > 0) state = STATE_OVERFLOW; // لاصقةٌ حتى يُفرَّغَ الطابورُ من جديدٍ
    else state = STATE_IDLE;
  }

  private void note(String text) {
    if (problems.size() >= AnalyzerProtocol.MAX_PROBLEMS) return;
    if (!problems.contains(text)) problems.add(text);
  }
}
