package almlk;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * أينَ يقعدُ الـAPK بعدَ البناءِ — صافٍ قابلٌ للاختبارِ، يستعملُهُ قرارُ الإعدادِ
 * `advanced_setting_adjust_apk_build_path` («Redefine APK build path» عند المرجعِ:
 * أخرجْ إلى `build/bin` بدلَ مخبأِ النظامِ).
 *
 * <p>الترتيبُ: دليلُ المستخدمِ إنْ ضُبِطَ (مطلقًا أو نسبيًّا إلى الجذرِ أو إلى الوحدةِ `app`)،
 * ثمَّ مخارجُ AGP المعروفةُ للوحدةِ `app` ثمَّ للجذرِ، ثمَّ `build/bin` و`bin`. داخلَ كلِّ دليلٍ:
 * ملفاتُ `*.apk` مباشرةً، فإنْ لم يكن فمجلداتُ النسخِ (`debug`/`release`/نكهاتٌ) ثمَّ ما فيها.
 * والأحدثُ بعدلةِ التعديلِ يفوزُ داخلَ الدليلِ الرابحِ — لا يُمرَجُ عبرَ الأدلةِ.
 */
public final class BuildOutputLocator {

  private BuildOutputLocator() {}

  /** أدلّةُ البحثِ بترتيبِ الأولويّةِ (قد تحتوي ملفًّا بدلَ دليلٍ إن كتبَ المستخدمُ ملفًّا). */
  public static List<File> candidateDirs(File projectRoot, String apkOutDir, String variant) {
    List<File> out = new ArrayList<>();
    String v = variant == null || variant.trim().isEmpty() ? null : variant.trim().toLowerCase(Locale.US);
    if (projectRoot == null) return out;
    String dir = apkOutDir == null ? "" : apkOutDir.trim();
    if (!dir.isEmpty()) {
      File explicit = new File(dir);
      if (!explicit.isAbsolute()) {
        explicit = new File(projectRoot, dir);
        addVariant(out, new File(projectRoot, "app/" + dir), v);
      }
      addVariant(out, explicit, v);
    }
    File module = new File(projectRoot, "app/build/outputs/apk");
    if (v == null) addVariants(out, module);
    else addVariant(out, module, v);
    File rootOut = new File(projectRoot, "build/outputs/apk");
    if (v == null) addVariants(out, rootOut);
    else addVariant(out, rootOut, v);
    add(out, new File(projectRoot, "build/bin"));
    add(out, new File(projectRoot, "bin"));
    return out;
  }

  /**
   * دليلٌ من كتابةِ المستخدمِ؟ عندَها لا مرشِّفَ للنسخةِ: من يعرِّفْ مسارَ البناءِ يريدُ ما في
   * ذلكَ المسارِ مهما كان اسمُهُ (out.apk)، وإلا مرَّ البناءُ سليمًا وربحَ المخبأُ القياسيُّ.
   */
  public static boolean isExplicit(File dir, String apkOutDir) {
    String d = apkOutDir == null ? "" : apkOutDir.trim();
    d = d.replaceAll("^/+", "").replaceAll("/+$", "").replace('\\', '/');
    return !d.isEmpty() && dir.getAbsolutePath().replace('\\', '/').contains("/" + d);
  }

  /** أحدثُ APK في أولِ دليلٍ فيه شيءٌ؛ null إن لا شيءَ (قدرةُ الدليلِ لا عدلةُ الملفِّ). */
  public static File newestApk(File projectRoot, String apkOutDir, String variant) {
    for (File dir : candidateDirs(projectRoot, apkOutDir, variant)) {
      File found;
      if (dir.isFile()) found = nameEndsWithApk(dir) ? dir : null;
      else found = newestIn(dir, isExplicit(dir, apkOutDir) ? null : variant);
      if (found != null) return found;
    }
    return null;
  }

  /** أحدثُ APK داخلَ دليلٍ واحدٍ (ونسخِهِ الفرعيّةِ عند الحاجةِ)؛ null إن لا شيءَ. */
  private static File newestIn(File dir, String variant) {
    if (dir == null || !dir.isDirectory()) return null;
    File[] files = dir.listFiles();
    if (files == null) return null;
    File best = null;
    List<File> subdirs = new ArrayList<>();
    for (File f : files) {
      if (f.isDirectory()) {
        subdirs.add(f);
        continue;
      }
      if (!nameEndsWithApk(f)) continue;
      if (variant != null && !variant.isEmpty() && !f.getName().toLowerCase(Locale.US).contains(variant)) continue;
      if (best == null || f.lastModified() > best.lastModified()) best = f;
    }
    if (best != null) return best;
    for (File sub : subdirs) {
      File candidate = newestIn(sub, variant);
      if (candidate != null) return candidate;
    }
    return null;
  }

  private static void addVariants(List<File> out, File base) {
    if (base == null || !base.isDirectory()) {
      add(out, base);
      return;
    }
    File[] dirs = base.listFiles();
    if (dirs == null) return;
    java.util.Arrays.sort(dirs, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
    for (File d : dirs) if (d.isDirectory()) add(out, d);
  }

  private static void addVariant(List<File> out, File base, String variant) {
    add(out, base);
    if (variant != null) add(out, new File(base, variant));
  }

  private static void add(List<File> out, File dir) {
    if (dir != null && !out.contains(dir)) out.add(dir);
  }

  private static boolean nameEndsWithApk(File f) {
    return f.getName().toLowerCase(Locale.US).endsWith(".apk");
  }
}
