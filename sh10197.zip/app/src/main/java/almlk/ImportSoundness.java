package almlk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * سلامةُ قسمِ الاستيرادِ — طبقةٌ صافيةٌ للجولةِ ‏24/2 (البندُ الثالثُ من طلبِ المصدرِ: «التحقُّقُ من وجودِ
 * استدعاءاتِ الكلاساتِ المطلوبةِ في قسمِ ‏import والتأكُّدُ من سلامتها»).
 *
 * <p>ما عندَ المرجعِ في هذا البابِ: المُحرِّكُ يَحسِمُ الاستيرادَ نفسَهُ (إضافةً وتنظيمًا) ولا يَنسِجُ
 * تشخيصاتِهِ في الواجهةِ؛ وعناوينُ الإصلاحِ تُرسَلُ معَ الخطإِ ({@code SyntaxError.tp}) فلا تُحاوِرُ
 * الواجهةُ المُحرِّكَ عندَ النقرِ. نأخذُ الدلالةَ لا الشيفرةَ: ستُّ حالاتٍ مُسمّاةٍ، لكلٍّ مفتاحُ رسالةٍ
 * وإصلاحٌ مُعلَبٌ من {@link QuickFix} القائمِ، ومَداراتُ الاستخدامِ كلُّها تُرسَلُ معَ الحالةِ ليُزيَّنَ
 * كلُّ موضعٍ لا أوَّلُها (قاعدةُ الجولةِ).
 *
 * <p>طبقاتُ الحلِّ الثلاثُ (البندُ الثاني من الطلبِ: محليٌّ/موروثٌ/مكتباتٌ مُحمَّلةٌ ومحلّيّةٌ) تدخلُ من
 * {@link Resolver} وحدَهُ: الطبقةُ الصافيةُ لا تَعرِفُ {@code ProjectSymbolIndex} ولا {@code
 * LibraryClassIndex} ولا {@code SharedPreferences} — تُعطِيهِما مُنفِّذًا وتَسأَلُ، فتُختبَرُ هنا على
 * {@code JVM} بحَلٍّ زائفٍ، وتُطابِقُ على الجهازِ بالحَلِّ الحقيقيِّ. وهذا هو الفرقُ بينَ «فحصٌ يعملُ»
 * و«فحصٌ يَصرُخُ على كلِّ صنفٍ في مكتبةٍ\": حَلٌّ واحدٌ ناقصٌ يُنتِجُ إنذاراتٍ كاذبةً بالآلافِ.
 *
 * <p>السقوفُ: {@link #MAX_IMPORTS} سطرًا، {@link #MAX_SITES} موضعًا لكلِّ حالةٍ، {@link #MAX_NAMES} اسمًا
 * مُرشَّحًا للفحصِ، {@link #MAX_PROBLEMS} سِجلًّا — والزيادةُ معدودةٌ في {@link Result#dropped}.
 */
public final class ImportSoundness {

  /** صيغةٌ مستعمَلةٌ ولا سبيلَ إليها: إمّا استيرادٌ ناقصٌ أو باقةٌ مُبهَمةٌ. */
  public static final int KIND_MISSING = 0;
  /** استيرادٌ لا يَحُلُّهُ شيءٌ (لا المشروعُ ولا المكتباتُ). */
  public static final int KIND_UNKNOWN = 1;
  /** استيرادٌ لا usageَ لَهُ. */
  public static final int KIND_UNUSED = 2;
  /** الاسمُ المُؤَهَّلُ نفسُهُ مُستورَدٌ مرّتَينِ. */
  public static final int KIND_DUPLICATE = 3;
  /** استيرادٌ من ‏{@code java.lang} أو من باقةِ الملفِّ نفسِها: زائدٌ حتمًا. */
  public static final int KIND_REDUNDANT = 4;
  /** باقتانِ (‏{@code a.*} و{@code b.*}) تُوفِّيانِ الاسمَ نفسَهُ: لا يُختارُ واحدُهُما بصمتٍ. */
  public static final int KIND_AMBIGUOUS = 5;

  public static final int MAX_IMPORTS = 256;
  public static final int MAX_SITES = 16;
  public static final int MAX_NAMES = 96;
  public static final int MAX_PROBLEMS = 4;

  private ImportSoundness() {}

  /** ما يَعرِفُ الطبقاتٍ: المشروعُ، والميراثُ، والمكتباتُ المُحمَّلةُ والمحلّيّةُ. */
  public interface Resolver {
    /** هل {@code a.b.C} موجودٌ في أيِّ طبقةٍ؟ (صنفٌ، واجهةٌ، تعدادٌ، سجلٌّ). */
    boolean provides(String qualifiedName);

    /** هل {@code simple} مُتاحٌ بلا استيرادٍ (‏{@code java.lang} أو باقةُ الملفِّ أو صنفٌ مُضمَّنٌ)؟ */
    boolean availableWithoutImport(String simpleName, String filePackage);

    /** هل يُوفِّرُ الاسمَ أكثرُ من باقةٍ مُستورَدةٍ بنمطٍ عامٍّ؟ */
    boolean ambiguousByWildcard(String simpleName, String[] wildcardPackages);

    /** مُرشَّحٌ واحدٌ لصيغةٍ مُبسَّطةٍ (لإصلاحِ {@code Add 'import …'})؛ {@code null} عندَ التعدُّدِ. */
    String uniqueCandidate(String simpleName);
  }

  /** حالةٌ واحدةٌ: أينَ، وماذا، وحيثُ استُعمِلَ. */
  public static final class Issue {
    public final int kind;
    public final String name;
    public final String qualifiedName;
    /** موضعُ سطرِ الاستيرادِ (أو الاستعمالُ نفسُهُ لـ{@code KIND_MISSING}/{@code AMBIGUOUS}). */
    public final int start;
    public final int end;
    /** كلُّ مواضعِ الاستعمالِ مُسطَّحةٌ {@code {start,end,…}} — لإبرازِ العنصرِ حيثُ وُجِدَ لا حيثُ شُخِصَ. */
    public final int[] occurrences;

    Issue(int kind, String name, String qualifiedName, int start, int end, int[] occurrences) {
      this.kind = kind;
      this.name = name == null ? "" : name;
      this.qualifiedName = qualifiedName == null ? "" : qualifiedName;
      this.start = start;
      this.end = Math.max(start + 1, end);
      this.occurrences = occurrences == null ? new int[0] : occurrences;
    }
  }

  /** نتيجةُ الفحصِ: حالاتٌ، وعدُّ المسقَطاتِ، وسِجلّاتُ السقوفِ. */
  public static final class Result {
    public final List<Issue> issues;
    public final int dropped;
    public final List<String> problems;

    Result(List<Issue> issues, int dropped, List<String> problems) {
      this.issues =
          issues == null
              ? Collections.<Issue>emptyList()
              : Collections.unmodifiableList(new ArrayList<>(issues));
      this.dropped = Math.max(0, dropped);
      this.problems =
          problems == null
              ? Collections.<String>emptyList()
              : Collections.unmodifiableList(new ArrayList<>(problems));
    }

    public boolean isClipped() {
      return dropped > 0 || !problems.isEmpty();
    }
  }

  /** سطرُ استيرادٍ مقروءٌ — عامٌّ لأنَّ {@link #importLines} عامرةٌ بهِ وتَقرَؤُها البوّابةُ والقناةُ معًا. */
  public static final class Line {
    public int start;
    public int end;
    public String qualified = "";
    public String simple = "";
    public boolean wildcard;
    public boolean statik;
  }

  /** يَفصِلُ قسمَ الاستيرادِ (بعدَ ‏{@code package} وقبلَ أولِ إعلانِ صنفٍ) عن جسمِ الملفِّ. */
  public static List<Line> importLines(CharSequence text) {
    ArrayList<Line> out = new ArrayList<>();
    if (text == null) return out;
    int i = 0;
    int dropped = 0;
    while (i < text.length()) {
      int at = indexOf(text, "import ", i);
      if (at < 0) break;
      if (!atLineStart(text, at)) {
        i = at + 1;
        continue;
      }
      int semicolon = indexOf(text, ";", at);
      if (semicolon < 0) break;
      if (out.size() >= MAX_IMPORTS) {
        dropped++;
        i = semicolon + 1;
        continue;
      }
      String raw = text.subSequence(at + "import ".length(), semicolon).toString().trim();
      Line line = new Line();
      line.start = at;
      line.end = semicolon + 1;
      if (raw.startsWith("static ")) {
        line.statik = true;
        raw = raw.substring("static ".length()).trim();
      }
      line.wildcard = raw.endsWith(".*");
      if (line.wildcard) raw = raw.substring(0, raw.length() - 2);
      line.qualified = raw;
      int dot = raw.lastIndexOf('.');
      line.simple = dot < 0 ? raw : raw.substring(dot + 1);
      out.add(line);
      i = semicolon + 1;
    }
    return out;
  }

  /** الفحصُ كلُّهُ على الملفِّ كاملًا: ستُّ حالاتٍ، وكلُّ حالةٍ تحملُ مواضعَ استعمالِها. */
  public static Result check(String text, String filePackage, Resolver resolver) {
    return check(text, filePackage, resolver, 0, text == null ? 0 : text.length());
  }

  /**
   * الفحصُ المتدرِّجُ: {@code [from,to)} هو النطاقُ الحاضنُ للتعديلِ من {@code IncrementalScope.Plan}،
   * وقسمُ الاستيرادِ يُقرَأُ كلُّهُ دائمًا (سطورٌ معدودةٌ، والحكمُ عليهِ لا يستقيمُ بنصفِهِ).
   *
   * <p>قاعدةٌ صريحةٌ: <b>لا حُكمَ بإهمالِ استيرادٍ من نطاقٍ ضيِّقٍ</b> — استعمالٌ خارجَ النطاقِ يَكفي
   * لإبطالِهِ، فالإنذارُ الكاذبُ أسوأُ من إنذارٍ متأجِّلٍ؛ لذا تُرجَأُ {@code KIND_UNUSED} إلى جولةٍ كاملةٍ
   * ويُسجَّلُ ذلكَ سِجلًّا لا صمتًا. بقيتُ الحالاتِ (مجهولٌ، مكرَّرٌ، زائدٌ، ناقصٌ، مُبهَمٌ) مَحلِيّةَ الدليلِ
   * فتُبلَغُ من النطاقِ كلِّهِ.
   */
  public static Result check(String text, String filePackage, Resolver resolver, int from, int to) {
    if (text == null || text.isEmpty() || resolver == null) return new Result(null, 0, null);
    boolean partial = from > 0 || to < text.length();
    int scanFrom = Math.max(0, Math.min(from, text.length()));
    int scanTo = Math.max(scanFrom, Math.min(to, text.length()));
    ArrayList<String> notes = new ArrayList<>(2);
    boolean seenUnusedDeferred = false; // سِجلٌّ واحدٌ بالإرجاءِ، لا سِجلٌّ لكلِّ سطرٍ
    ArrayList<Issue> issues = new ArrayList<>();
    List<Line> lines = importLines(text);
    // 1.0.176: الجسمُ يبدأُ بعدَ **آخرِ** سطرِ استيرادٍ لا بعدَ أولِها: كانَ الحصرُ السابقُ يَترُكُ
    // سطورَ الاستيرادِ الثانيةَ فما بعدها داخلَ «الجسمِ»، فلا يُبلَّغُ مَن بعدَ الأولِ أبدًا (عيبٌ في
    // عَدِّ الاستيراداتِ الزائدةِ ظهرَ حينَ طُلِبَت دفعةُ حذفٍ تَجمَعُ الكلَّ).
    int bodyStart = 0;
    for (Line line : lines) bodyStart = Math.max(bodyStart, line.end);
    // 1) مكرَّرٌ وزائدٌ ومجهولٌ — على سطورِ الاستيرادِ نفسِها.
    Set<String> seen = new HashSet<>();
    ArrayList<String> wildcards = new ArrayList<>();
    for (Line line : lines) {
      if (line.wildcard) {
        wildcards.add(line.qualified);
        if (isJavaLang(line.qualified) || packageOf(line.qualified + ".X").equals(nullToEmpty(filePackage))) {
          issues.add(new Issue(KIND_REDUNDANT, "*", line.qualified + ".*", line.start, line.end, new int[0]));
        }
        continue;
      }
      if (!seen.add(line.qualified)) {
        issues.add(
            new Issue(
                KIND_DUPLICATE, line.simple, line.qualified, line.start, line.end, occurrences(text, line, bodyStart)));
        continue;
      }
      // ‏java.lang فقط: صنفٌ من باقةِ الملفِّ نفسِهِ مستعمَلٌ استيرادٌ قانونٌ شائعٌ لا زَيغٌ، والحُكمُ
      // عليهِ زَيادةً يَصنعُ إنذارًا كاذبًا لكلِّ مشروعٍ يَكتُبُ استيراداتٍ صريحةً — والبابُ لا يُغلَقُ
      // بإنذارٍ لا يَستندُ إلى دليلٍ (نفسُ قاعدةِ «الفهرسُ غيرُ كاملٍ لا يُجيَبُ عنهُ»).
      if (isJavaLang(line.qualified)) {
        issues.add(
            new Issue(
                KIND_REDUNDANT, line.simple, line.qualified, line.start, line.end,
                occurrences(text, line, bodyStart)));
        continue;
      }
      if (!resolver.provides(line.qualified)) {
        issues.add(
            new Issue(
                KIND_UNKNOWN, line.simple, line.qualified, line.start, line.end, occurrences(text, line, bodyStart)));
        continue;
      }
      if (partial) {
        if (!seenUnusedDeferred) {
          notes.add("unused-import verdict deferred to a full pass");
          seenUnusedDeferred = true;
        }
      } else if (IdentifierOccurrences.count(text.subSequence(bodyStart, text.length()), line.simple) == 0) {
        issues.add(new Issue(KIND_UNUSED, line.simple, line.qualified, line.start, line.end, new int[0]));
      }
    }
    // 2) مستعمَلٌ لا سبيلَ إليهِ: صيغةٌ تبدأُ بحرفٍ كبيرٍ، لا استيرادَ لها ولا باقةُ الملفِّ ولا ميراثٌ.
    String[] wildcardPackages = wildcards.toArray(new String[0]);
    Set<String> declared = declaredTypeNames(text);
    Set<String> flagged = new HashSet<>(); // اسمٌ واحدٌ = حالةٌ واحدةٌ: لا إنذارٌ لكلِّ استعمالٍ
    int names = 0;
    int i = Math.max(bodyStart, scanFrom);
    int nameLimit = partial ? Math.min(text.length(), scanTo) : text.length();
    while (i < nameLimit && names < MAX_NAMES) {
      char c = text.charAt(i);
      if (!IdentifierBounds.isStart(c)) {
        i++;
        continue;
      }
      int tokenStart = i;
      int tokenEnd = i + 1;
      while (tokenEnd < text.length() && IdentifierBounds.isPart(text.charAt(tokenEnd))) tokenEnd++;
      String name = text.substring(tokenStart, tokenEnd);
      i = tokenEnd;
      if (!Character.isUpperCase(name.charAt(0))) continue;
      if (precededByDot(text, tokenStart)) continue; // عضوٌ (‏x.Both) أو مُؤهَّلٌ (java.util.List)، لا صنفٌ
      if (declared.contains(name)) continue; // صنفٌ مُعلَنٌ في هذا الملفِّ: لا استيرادَ يَنقصُ لَهُ
      names++;
      boolean imported = false;
      for (Line line : lines) {
        if (line.wildcard || line.statik) continue;
        if (line.simple.equals(name)) {
          imported = true;
          break;
        }
      }
      // استيرادٌ صريحٌ يَحسِمُ الاسمَ: لا مُنافَسَةَ لأنماطٍ عامةٍ معه (كما في جافا نفسِها).
      if (imported || flagged.contains(name)) continue;
      if (resolver.availableWithoutImport(name, nullToEmpty(filePackage))) continue;
      if (resolver.ambiguousByWildcard(name, wildcardPackages)) {
        flagged.add(name);
        issues.add(
            new Issue(
                KIND_AMBIGUOUS, name, "", tokenStart, tokenEnd, occurrencesOf(text, name, bodyStart)));
        continue;
      }
      if (hasWildcardCovering(text, name, wildcardPackages, resolver)) continue;
      flagged.add(name);
      issues.add(
          new Issue(
              KIND_MISSING, name, resolver.uniqueCandidate(name), tokenStart, tokenEnd,
              occurrencesOf(text, name, bodyStart)));
    }
    int dropped = 0;
    if (issues.size() > MAX_IMPORTS) {
      notes.add("issues capped at " + MAX_IMPORTS);
    }
    if (names >= MAX_NAMES) {
      dropped++;
      notes.add("candidate names capped at " + MAX_NAMES);
    }
    if (dropped > MAX_PROBLEMS) dropped = MAX_PROBLEMS; // السجلُّ سقفُهُ مُعلَنٌ، والعدُّ يبقى كما هو
    if (!seen.isEmpty() && seen.size() > MAX_IMPORTS) {
      notes.add("imports capped at " + MAX_IMPORTS);
    }
    return new Result(issues, dropped, notes);
  }

  /** مفتاحُ الرسالةِ لكلِّ حالةٍ مُسمّاةٍ (نفسُها في اللغتَينِ، بلا نصٍّ مُختَرَعةٍ هذهِ الجولةَ). */
  public static String messageKey(int kind) {
    switch (kind) {
      case KIND_MISSING:
        return "ui_diagnostic_missing_import";
      case KIND_UNKNOWN:
        return "ui_diagnostic_unknown_import";
      case KIND_UNUSED:
        return "ui_diagnostic_unused_import";
      case KIND_DUPLICATE:
        return "ui_diagnostic_duplicate_import";
      case KIND_REDUNDANT:
        return "ui_diagnostic_redundant_import";
      case KIND_AMBIGUOUS:
        return "ui_diagnostic_ambiguous_import";
      default:
        return "ui_diagnostic_unknown_import";
    }
  }

  /** خطإٌ أم إنذارٌ: ما يَكسِرُ الترجمةَ خطأٌ، وما يُثقِلُ الملفَّ إنذارٌ — كما في حالاتِ {@code inspect}. */
  public static boolean isWarning(int kind) {
    return kind == KIND_UNUSED || kind == KIND_REDUNDANT;
  }

  /** الإصلاحُ الملائمُ من {@link QuickFix} القائمِ (لا نوعَ جديدًا هذهِ الجولةَ). */
  public static QuickFix.Kind fixKindFor(int kind) {
    switch (kind) {
      case KIND_MISSING:
        return QuickFix.Kind.ADD_IMPORT;
      case KIND_UNKNOWN:
      case KIND_AMBIGUOUS:
        return QuickFix.Kind.FIX_IMPORTS;
      case KIND_UNUSED:
      case KIND_REDUNDANT:
      case KIND_DUPLICATE:
        // 1.0.176: حذفٌ بدفَعَةٍ من سجلِّ عملياتٍ (نطاقٌ ببديلٍ فارغٍ) لا «EDIT_TEXT» عامٌّ.
        return QuickFix.Kind.REMOVE_IMPORTS;
      default:
        return null;
    }
  }

  /** نصُّ الحذفِ الآمنِ: سطرُ الاستيرادِ كلُّهُ معَ فاصلِهِ — يُستعمَلُ في {@code EDIT_TEXT}. */
  public static String removalText() {
    return "";
  }

  // ─────────────────────────── أدواتٌ داخليةٌ ───────────────────────────

  private static int[] occurrences(String text, Line line, int bodyStart) {
    return occurrencesOf(text, line.statik ? memberOf(line.qualified) : line.simple, bodyStart);
  }

  private static int[] occurrencesOf(String text, String name, int bodyStart) {
    IdentifierOccurrences.Result found =
        IdentifierOccurrences.scan(text, name, bodyStart, text.length(), MAX_SITES);
    return found.flat;
  }

  private static boolean hasWildcardCovering(
      String text, String name, String[] wildcardPackages, Resolver resolver) {
    for (String pkg : wildcardPackages) {
      if (resolver.provides(pkg + "." + name)) return true;
    }
    return false;
  }

  /**
   * أسماءُ الصنوفِ التي يُعلِنُها الملفُّ نفسُهُ (علويٌّ ومُضمَّنٌ): كلٌّ منها مُتاحٌ بلا استيرادٍ بحكمِ
   * اللغةِ، فعدُّهُ «استيرادًا ناقصًا» يَملأُ كلَّ ملفٍّ بإنذارٍ كاذبٍ على صنفِهِ الرئيسيِّ. نَكتفي
   * بعلامةِ الإعلانِ (‏{@code class}/{@code interface}/{@code enum}/{@code record}) ثمَّ المعرِّفُ التالي لَهَا.
   */
  public static Set<String> declaredTypeNames(CharSequence text) {
    HashSet<String> out = new HashSet<>();
    if (text == null) return out;
    int i = 0;
    while (i < text.length()) {
      char c = text.charAt(i);
      if (c == '/' && i + 1 < text.length() && (text.charAt(i + 1) == '/' || text.charAt(i + 1) == '*')) {
        int nl = text.toString().indexOf('\n', i);
        i = text.charAt(i + 1) == '/' ? (nl < 0 ? text.length() : nl + 1) : i + 2;
        continue;
      }
      if (c == '"' || c == '\'') {
        int j = i + 1;
        while (j < text.length() && text.charAt(j) != c) j += text.charAt(j) == '\\' ? 2 : 1;
        i = j + 1;
        continue;
      }
      if (!IdentifierBounds.isStart(c)) {
        i++;
        continue;
      }
      int tokenEnd = i + 1;
      while (tokenEnd < text.length() && IdentifierBounds.isPart(text.charAt(tokenEnd))) tokenEnd++;
      String word = text.subSequence(i, tokenEnd).toString();
      if ((word.equals("class") || word.equals("interface") || word.equals("enum") || word.equals("record"))
          && !precededByDot(text, i)) {
        int at = tokenEnd;
        while (at < text.length() && (text.charAt(at) == ' ' || text.charAt(at) == '\t' || text.charAt(at) == '\n'
            || text.charAt(at) == '\r')) at++;
        int nameStart = at;
        while (at < text.length() && IdentifierBounds.isPart(text.charAt(at))) at++;
        if (at > nameStart) out.add(text.subSequence(nameStart, at).toString());
      }
      i = tokenEnd;
    }
    return out;
  }

  private static boolean precededByDot(CharSequence text, int at) {
    int i = at - 1;
    while (i >= 0 && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) i--;
    return i >= 0 && (text.charAt(i) == '.' || text.charAt(i) == '@');
  }

  private static boolean isJavaLang(String qualified) {
    return qualified.equals("java.lang") || qualified.startsWith("java.lang.");
  }

  private static String memberOf(String qualified) {
    int dot = qualified.lastIndexOf('.');
    return dot < 0 ? qualified : qualified.substring(dot + 1);
  }

  private static String packageOf(String qualified) {
    int dot = qualified.lastIndexOf('.');
    return dot < 0 ? "" : qualified.substring(0, dot);
  }

  private static String nullToEmpty(String value) {
    return value == null ? "" : value;
  }

  private static boolean atLineStart(CharSequence text, int at) {
    int i = at - 1;
    while (i >= 0 && (text.charAt(i) == ' ' || text.charAt(i) == '\t' || text.charAt(i) == '\r')) i--;
    return i < 0 || text.charAt(i) == '\n' || text.charAt(i) == '}';
  }

  private static int indexOf(CharSequence text, String needle, int from) {
    return text.toString().indexOf(needle, from);
  }

  /** عددُ حالاتِ كلِّ نوعٍ — للبوّابةِ أن تُثبِتَ أنَّ الحالاتِ الستَّ تُستَعرَضُ لا تُختَزلُ في واحدةٍ. */
  public static Map<Integer, Integer> tally(Result result) {
    HashMap<Integer, Integer> out = new HashMap<>();
    if (result == null) return Collections.emptyMap();
    for (Issue issue : result.issues) {
      Integer seen = out.get(issue.kind);
      out.put(issue.kind, seen == null ? 1 : seen + 1);
    }
    return out;
  }
}
