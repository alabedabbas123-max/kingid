package almlk;

import java.io.File;

/**
 * توقيتُ الفحصِ المشروطُ بالملفِّ المستهدَفِ (ملحقُ ‏W27/1).
 *
 * <p>المبدأُ كما في المرجعِ: المحرِّكُ الخادميُّ يُهيَّأُ مرّةً واحدةً ولا تَقرِّرُ طبقةُ الواجهةِ «متى
 * يبدأُ الفحصُ»، لكنَّها هي التي تُبلِغُهُ <em>ما يُعتَبَرُ عملًا</em>. لذلكَ لا يُعتَبَرُ المشروعُ
 * نشِطًا تحليليًّا بمجردِ النقرِ على مجلدٍ أو ملفٍّ جانبيٍّ، ولا يَخرُجُ حوارُ «افتح المشروعَ» إلا عندَ
 * استهدافِ ملفٍّ جوهريٍّ داخلَ مجلدِ التطبيقِ، وهي أربعةُ أنواعٍ فقط: ملفُّ البناءِ ‏{@code
 * app/build.gradle} (أو ‏{@code .kts})، و{@code AndroidManifest.xml}، وملفاتُ المواردِ ‏{@code *.xml}
 * تحتَ {@code src/…/res}، وملفاتُ المصدرِ ‏{@code .java} و{@code .kt} تحتَ {@code src}.
 *
 * <p>طبقةٌ نقيةٌ: لا {@code android.*}، ولا قراءةَ نصوصٍ، ولا قرارَ في الحالةِ العامةِ — تُخرِجُ حالةً
 * مُسمّاةً وسببًا ومجلدَ مشروعٍ مُقترَحًا، ويَقرِّرُ الغلافُ الأندرويديُّ ما يَفعَلُ بها. ولا نداءَ
 * للمحرِّكِ من هنا.
 */
public final class AnalysisTargets {

  /** ملفٌّ جوهريٌّ داخلَ المشروعِ المفتوحِ: يُسلَّحُ الفحصُ، ولا حوارَ ولا تبديلَ سياقٍ. */
  public static final String ANALYSIS = "analysis";
  /** تصفُّحٌ داخلَ المشروعِ المفتوحِ: فتحٌ للتحريرِ وحدَهُ، بلا إقلاعِ محركٍ ولا وصايةٍ. */
  public static final String BROWSE = "browse";
  /** ملفٌّ جوهريٌّ في مشروعٍ آخرِ: الوجهُّ الوحيدُ الباقي لعمليةِ «افتح المشروعَ». */
  public static final String FOREIGN = "foreign";
  /** خارجَ كلِّ مشروعٍ مُعرَفٍ: لا رسالةَ ولا قرارَ — كما يَخرُجُ المرجعُ صامتًا من {@code m401j6}. */
  public static final String OUTSIDE = "outside";

  /** أنواعُ الملفِّ الجوهريِّ الأربعةُ، كما عَدَّها الملحقُ. */
  public static final String KIND_BUILD = "build";
  public static final String KIND_MANIFEST = "manifest";
  public static final String KIND_LAYOUT = "layout";
  public static final String KIND_SOURCE = "source";

  /**
   * أقصى ما يُصعَدُ من الملفِّ إلى مجلدِ الوحدةِ: الحزمُ العميقةُ (‏{@code com/example/app/ui}) تُبلِغُ
   * ستّةَ مستوياتٍ فما فوقَ، فالسقفُ مُرخًى إلى أربعٍ وعشرينَ — الكلفةُ مقارنةُ أسماءِ مجلداتٍ لا قرصَ.
   */
  public static final int MAX_WALK_DEPTH = 24;
  /** لا حِوارٌ على مسارٍ أطولَ من هذا: يُترَكُ كما هو (حِمايةٌ من دَخلٍ مَلفوفٍ). */
  public static final int MAX_PATH_CHARS = 4096;
  /** اسمُ مجلدِ وحدةِ التطبيقِ الذي يَعمَلُ الفحصُ داخلَهُ وحدَهُ. */
  public static final String APP_MODULE = "app";

  /** نتيجةُ التصنيفِ: حالةٌ مُسمّاةٌ، وسببٌ يُقرَأُ في اللوحةِ، وجذرُ مشروعٍ مُقترَحٌ عندَ الحاجةِ. */
  public static final class Decision {

    /** أحدُ الحالاتِ الأربعِ: {@link #ANALYSIS}، {@link #BROWSE}، {@link #FOREIGN}، {@link #OUTSIDE}. */
    public final String state;
    /** سببٌ قصيرٌ مُسمّى؛ يبقى فارغًا حينَ لا شيءَ يُلحَقُ بالقرارِ. */
    public final String reason;
    /** نوعُ الملفِّ الجوهريِّ، أو {@code null} إن لم يكنْ ملفًّا جوهريًّا. */
    public final String kind;
    /** مجلدُ المشروعِ المُقترَحُ (فقطَ عندَ {@link #FOREIGN})، أو {@code null}. */
    public final File projectRoot;
    /** اسمُ المشروعِ كما يُعرَضُ في الحوارِ، أو {@code null}. */
    public final String projectName;

    Decision(String state, String reason, String kind, File projectRoot, String projectName) {
      this.state = state;
      this.reason = reason == null ? "" : reason;
      this.kind = kind;
      this.projectRoot = projectRoot;
      this.projectName = projectName;
    }

    /** هل يُسلَّحُ المحرِّكُ بهذا الفتحِ؟ */
    public boolean armsAnalysis() {
      return ANALYSIS.equals(state);
    }

    /** هل يُعرَضُ حوارُ فتحِ المشروعِ؟ (مرةٌ واحدةٌ لكلِّ ملفٍّ جوهريٍّ في مشروعٍ آخرَ) */
    public boolean mayAskOpenProject() {
      return FOREIGN.equals(state) && projectRoot != null;
    }

    @Override
    public String toString() {
      return state + (kind == null ? "" : "/" + kind) + (reason.isEmpty() ? "" : " (" + reason + ")");
    }
  }

  private AnalysisTargets() {}

  /**
   * تصنيفُ مسارٍ نقرَ عليهِ المستخدمُ في متصفِّحِ الملفاتِ أو في قائمةِ المؤخّراتِ.
   *
   * @param path مسارُ الملفِّ المفتوحِ (قد يكونُ {@code null} عندَ فتْحٍ بلا مرجعٍ)
   * @param openProjectPath مجلدُ المشروعِ المفتوحِ الآنَ، أو {@code null} إن لم يُفتَحْ مشروعٌ بعدَ
   */
  public static Decision of(String path, String openProjectPath) {
    if (path == null || path.isEmpty()) return new Decision(OUTSIDE, "no_path", null, null, null);
    if (path.length() > MAX_PATH_CHARS) return new Decision(OUTSIDE, "path_too_long", null, null, null);
    File file = new File(path);
    File moduleDir = appModuleDirOf(file);
    File root = moduleDir == null ? null : projectRootOf(moduleDir);
    String kind = moduleDir == null ? null : targetKind(file, moduleDir);
    String openRoot = normalize(openProjectPath);
    String rootPath = normalize(root == null ? null : root.getAbsolutePath());

    if (kind == null) {
      // ليسَ ملفًّا جوهريًّا: لا إقلاعَ ولا حوارَ، ولو كانَ داخلَ المشروعِ.
      boolean inside = openRoot != null && rootPath != null && rootPath.equals(openRoot);
      return new Decision(inside ? BROWSE : OUTSIDE, "not_a_target_file", null, null, null);
    }
    if (root == null) {
      // ملفٌّ جوهريٌّ لكنْ لا جذرَ مشروعٍ فوقَهُ: لا مشروعَ يُفتَحُ، فلا وصايةَ بلا معنى.
      return new Decision(OUTSIDE, "no_project_root_above", kind, null, null);
    }
    if (openRoot != null && openRoot.equals(rootPath)) {
      return new Decision(ANALYSIS, "", kind, root, root.getName());
    }
    return new Decision(FOREIGN, "target_file_of_other_project", kind, root, root.getName());
  }

  /** هل هذا الملفُّ جوهريٌّ في وحدتِهِ؟ (تُستعمَلُ أيضًا لإلغاءِ تسليةِ المحرِّرِ عندَ تبديلِ التبويبِ) */
  public static boolean isTargetFile(String path) {
    if (path == null || path.isEmpty() || path.length() > MAX_PATH_CHARS) return false;
    File file = new File(path);
    File moduleDir = appModuleDirOf(file);
    return moduleDir != null && targetKind(file, moduleDir) != null;
  }

  /** نوعُ الملفِّ الجوهريِّ، أو {@code null}. الملفُّ يجبُ أن يكونَ داخلَ شجرةِ الوحدةِ المُعلَنةِ. */
  public static String targetKind(File file, File moduleDir) {
    if (file == null || moduleDir == null) return null;
    String name = file.getName();
    String filePath = normalize(file.getAbsolutePath());
    String modulePath = normalize(moduleDir.getAbsolutePath());
    if (filePath == null || modulePath == null || !filePath.startsWith(modulePath + File.separator)) {
      return null;
    }
    String relative = filePath.substring(modulePath.length() + 1).replace('\\', '/');
    if (name.equals("build.gradle") || name.equals("build.gradle.kts")) {
      return relative.indexOf('/') < 0 ? KIND_BUILD : null; // ملفُّ بناءِ الوحدةِ لا ملفَّاتٍ داخليّةٍ
    }
    if (!relative.startsWith("src/")) return null; // لا شيءَ خارجَ شجرةِ المصدرِ يُسلِّحُ الفحصَ
    if (name.equals("AndroidManifest.xml")) return KIND_MANIFEST;
    if (name.endsWith(".xml") && relative.contains("/res/")) return KIND_LAYOUT;
    if (name.endsWith(".java") || name.endsWith(".kt")) return KIND_SOURCE;
    return null;
  }

  /**
   * أقربُ جدٍّ يُسمّى {@code app} **ولهُ ملفُّ بناءٍ** — القيدُ الأخيرُ يمنعُ حزمةً تُدعى {@code
   * com.example.app} أن تُتَّخَذَ وحدةَ تطبيقٍ. الكلفةُ مقارنةُ اسمٍ ثمَّ وجودُ ملفٍّ عندَ التطابقِ فقط.
   */
  public static File appModuleDirOf(File file) {
    if (file == null) return null;
    File dir = file.isDirectory() ? file : file.getParentFile();
    for (int depth = 0; depth < MAX_WALK_DEPTH && dir != null; depth++) {
      if (APP_MODULE.equals(dir.getName()) && hasBuildFile(dir)) return dir;
      dir = dir.getParentFile();
    }
    return null;
  }

  private static boolean hasBuildFile(File dir) {
    return new File(dir, "build.gradle").isFile() || new File(dir, "build.gradle.kts").isFile();
  }

  /** مجلدُ المشروعِ الذي فوقَ الوحدةِ: لا يُقبَلُ إلا بـ{@code settings.gradle} صريحٍ. */
  public static File projectRootOf(File moduleDir) {
    File dir = moduleDir == null ? null : moduleDir.getParentFile();
    for (int depth = 0; depth < 3 && dir != null; depth++) {
      if (hasSettingsFile(dir)) return dir;
      dir = dir.getParentFile();
    }
    return null;
  }

  private static boolean hasSettingsFile(File dir) {
    return new File(dir, "settings.gradle").isFile() || new File(dir, "settings.gradle.kts").isFile();
  }

  /** مسارٌ مُوحَّدُ الفاصِلِ بلا ذيلٍ؛ {@code null} يَمرُ كما هو. */
  private static String normalize(String path) {
    if (path == null) return null;
    String p = path.replace('\\', '/');
    while (p.length() > 1 && p.endsWith("/")) p = p.substring(0, p.length() - 1);
    return p;
  }
}
