package almlk;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;

/**
 * Coalescing of the dependent re-inspection burst (W21′1): a declaration that changed in one file
 * has to be answered in the files that use it, but a burst of keystrokes must not turn into a
 * re-scan per character.
 *
 * <p>Names offered while a burst is open are merged; the sweep runs once the burst has been quiet
 * for {@link #QUIET_MS}, and continuous typing is never postponed beyond {@link #MAX_WAIT_MS} from
 * the first pending change. More than {@link #MAX_NAMES} pending names means the burst was clipped:
 * the clipped flag is reported so a caller can widen its sweep instead of pretending it saw
 * everything.
 */
public final class DeclarationWatch {

  /** Quiet after which the dependents of the changed declarations are re-checked. */
  public static final long QUIET_MS = 350;
  /** Ceiling: pending changes are swept even while the user is still typing. */
  public static final long MAX_WAIT_MS = 1200;
  /** Names kept per burst; the overflow only ever widens the sweep, it never drops a change. */
  public static final int MAX_NAMES = 128;

  private final LinkedHashSet<String> pending = new LinkedHashSet<>();
  private long firstAtMs;
  private long lastAtMs;
  private long deadlineMs;
  private boolean clipped;

  /**
   * Records changed member names.
   *
   * @return when the sweep should run ({@code now} + a delay), or 0 when {@code names} was empty.
   */
  public long offer(long now, Collection<String> names) {
    if (names == null || names.isEmpty()) return deadlineMs;
    boolean fresh = pending.isEmpty();
    for (String name : names) {
      if (name == null || name.isEmpty()) continue;
      if (pending.size() >= MAX_NAMES) {
        clipped = true;
        break;
      }
      pending.add(name);
    }
    if (pending.isEmpty()) return deadlineMs;
    if (fresh) firstAtMs = now;
    lastAtMs = now;
    deadlineMs = Math.min(firstAtMs + MAX_WAIT_MS, lastAtMs + QUIET_MS);
    return deadlineMs;
  }

  /** The delay the caller should wait before asking again (never negative). */
  public long delayFor(long now) {
    if (pending.isEmpty() || deadlineMs <= 0) return 0;
    return Math.max(0, deadlineMs - now);
  }

  /** True while a burst is open and has not been swept yet. */
  public boolean pending() {
    return !pending.isEmpty();
  }

  /** True when nothing is owed (never armed, or swept and idle again). */
  public boolean idle() {
    return pending.isEmpty();
  }

  /** Overflow of {@link #MAX_NAMES} since the last sweep — the caller widens, never ignores. */
  public boolean clipped() {
    return clipped;
  }

  /** The sweep runs only when the burst has come due; false leaves it armed for later. */
  public boolean due(long now) {
    return !pending.isEmpty() && deadlineMs > 0 && now >= deadlineMs;
  }

  /** Consumes the burst and returns its names (sorted, so a sweep order is reproducible). */
  public ArrayList<String> takeNames() {
    ArrayList<String> out = new ArrayList<>(pending);
    out.sort(null);
    pending.clear();
    firstAtMs = lastAtMs = deadlineMs = 0;
    clipped = false;
    return out;
  }

  /** Abandons the burst (project switched, editor detached) without scheduling anything. */
  public void reset() {
    pending.clear();
    firstAtMs = lastAtMs = deadlineMs = 0;
    clipped = false;
  }

  /** Removes one name (a file whose own live pass already answered it) — used while merging. */
  public void forget(Collection<String> names) {
    if (names == null) return;
    for (Iterator<String> it = pending.iterator(); it.hasNext(); ) {
      if (names.contains(it.next())) it.remove();
    }
    if (pending.isEmpty()) {
      firstAtMs = lastAtMs = deadlineMs = 0;
      clipped = false;
    }
  }
}
