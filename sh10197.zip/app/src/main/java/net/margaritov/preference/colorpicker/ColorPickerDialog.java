package net.margaritov.preference.colorpicker;

import android.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** منتقي Margaritov مع تحقق Hex صارم وتأكيد لا يُغلق الحوار عند الإدخال غير الصالح. */
public class ColorPickerDialog extends AlertDialog
    implements ColorPickerView.OnColorChangedListener,
        View.OnClickListener,
        ViewTreeObserver.OnGlobalLayoutListener {

  private static final String STATE_OLD_COLOR = "old_color";
  private static final String STATE_NEW_COLOR = "new_color";
  private static final String STATE_ALPHA_VISIBLE = "alpha_visible";
  private static final String STATE_HEX_ENABLED = "hex_enabled";

  private ColorPickerView mColorPicker;
  private ColorStateList mHexDefaultTextColor;
  private EditText mHexVal;
  private boolean mHexValueEnabled = true;
  private boolean mHexInputValid = true;
  private boolean mUpdatingHexText;
  private boolean mApplyingHexInput;
  private View mLayout;
  private OnColorChangedListener mListener;
  private ColorPickerPanelView mNewColor;
  private ColorPickerPanelView mOldColor;
  private int mOrientation;

  public interface OnColorChangedListener {
    /** يُستدعى مرة واحدة فقط من زر OK وبعد نجاح تحقق حقل Hex. */
    void onColorChanged(int color);
  }

  public ColorPickerDialog(Context context, int color) {
    super(context);
    init(color);
  }

  private void init(int color) {
    if (getWindow() != null) getWindow().setFormat(1);
    setUp(color);
    setHexValueEnabled(true);
    // تُنشأ الأزرار هنا، لكن show() يستبدل مستمع OK كي يمنع الإغلاق عند Hex غير صالح.
    setButton(BUTTON_POSITIVE, getContext().getString(R.string.ok),
        (dialog, which) -> {});
    setButton(BUTTON_NEGATIVE, getContext().getString(R.string.cancel),
        (dialog, which) -> {});
  }

  private void setUp(int color) {
    mLayout = ((LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE))
        .inflate(com.shima.demo.R.layout.dialog_color_picker, (ViewGroup) null);
    mLayout.getViewTreeObserver().addOnGlobalLayoutListener(this);
    mOrientation = getContext().getResources().getConfiguration().orientation;
    setView(mLayout);

    mColorPicker = mLayout.findViewById(com.shima.demo.R.id.color_picker_view);
    mOldColor = mLayout.findViewById(com.shima.demo.R.id.old_color_panel);
    mNewColor = mLayout.findViewById(com.shima.demo.R.id.new_color_panel);
    mHexVal = mLayout.findViewById(com.shima.demo.R.id.hex_val);
    mHexVal.setInputType(
        android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
    mHexDefaultTextColor = mHexVal.getTextColors();
    mHexVal.addTextChangedListener(
        new TextWatcher() {
          @Override
          public void beforeTextChanged(CharSequence text, int start, int count, int after) {}

          @Override
          public void onTextChanged(CharSequence text, int start, int before, int count) {
            if (!mUpdatingHexText) applyHexInput(text);
          }

          @Override
          public void afterTextChanged(Editable editable) {}
        });
    mHexVal.setOnEditorActionListener(
        (TextView textView, int actionId, KeyEvent event) -> {
          if (actionId != android.view.inputmethod.EditorInfo.IME_ACTION_DONE) return false;
          InputMethodManager keyboard =
              (InputMethodManager) textView.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
          if (keyboard != null)
            keyboard.hideSoftInputFromWindow(textView.getWindowToken(), 0);
          applyHexInput(mHexVal.getText());
          return true;
        });

    ((LinearLayout) mOldColor.getParent()).setPadding(
        Math.round(mColorPicker.getDrawingOffset()),
        0,
        Math.round(mColorPicker.getDrawingOffset()),
        0);
    mOldColor.setOnClickListener(this);
    mNewColor.setOnClickListener(this);
    mColorPicker.setOnColorChangedListener(this);
    mOldColor.setColor(color);
    mColorPicker.setColor(color, true);
  }

  @Override
  public void show() {
    super.show();
    Button positive = getButton(BUTTON_POSITIVE);
    if (positive != null) {
      positive.setOnClickListener(
          view -> {
            if (mHexValueEnabled && !validateHexInput()) return;
            if (mListener != null) mListener.onColorChanged(mNewColor.getColor());
            dismiss();
          });
    }
    updatePositiveButtonState();
  }

  private void applyHexInput(CharSequence value) {
    try {
      int color = HexColorCodec.parse(value, getAlphaSliderVisible());
      mHexInputValid = true;
      mHexVal.setTextColor(mHexDefaultTextColor);
      mApplyingHexInput = true;
      try {
        mColorPicker.setColor(color, true);
      } finally {
        mApplyingHexInput = false;
      }
    } catch (IllegalArgumentException invalid) {
      mHexInputValid = false;
      mHexVal.setTextColor(Color.RED);
    }
    updatePositiveButtonState();
  }

  private boolean validateHexInput() {
    if (!mHexValueEnabled) return true;
    applyHexInput(mHexVal.getText());
    return mHexInputValid;
  }

  private void updatePositiveButtonState() {
    Button positive = getButton(BUTTON_POSITIVE);
    if (positive != null) positive.setEnabled(!mHexValueEnabled || mHexInputValid);
  }

  private void updateHexLengthFilter() {
    int maximum = getAlphaSliderVisible() ? 9 : 7; // #AARRGGBB أو #RRGGBB.
    mHexVal.setFilters(new InputFilter[] {new InputFilter.LengthFilter(maximum)});
  }

  private void updateHexValue(int color) {
    mUpdatingHexText = true;
    try {
      String value = getAlphaSliderVisible()
          ? ColorPickerPreference.convertToARGB(color)
          : ColorPickerPreference.convertToRGB(color);
      mHexVal.setText(value.toUpperCase(Locale.US));
      mHexVal.setSelection(mHexVal.length());
      mHexVal.setTextColor(mHexDefaultTextColor);
      mHexInputValid = true;
    } finally {
      mUpdatingHexText = false;
    }
    updatePositiveButtonState();
  }

  public boolean getAlphaSliderVisible() {
    return mColorPicker.getAlphaSliderVisible();
  }

  public int getColor() {
    return mColorPicker.getColor();
  }

  public boolean getHexValueEnabled() {
    return mHexValueEnabled;
  }

  /** يفيد الاختبار والمضيف: لا يعتمد لونًا صالحًا سابقًا عند بقاء النص الحالي غير صالح. */
  public boolean isHexInputValid() {
    return !mHexValueEnabled || mHexInputValid;
  }

  @Override
  public void onClick(View view) {
    if (view == mOldColor) mColorPicker.setColor(mOldColor.getColor(), true);
  }

  @Override
  public void onColorChanged(int color) {
    mNewColor.setColor(color);
    if (mHexValueEnabled && !mApplyingHexInput) updateHexValue(color);
  }

  @Override
  public void onGlobalLayout() {
    int orientation = getContext().getResources().getConfiguration().orientation;
    if (orientation == mOrientation) return;
    // عند configChanges تبقى نافذة الحوار نفسها؛ نحفظ القيم صراحة قبل إعادة تخطيطها.
    int oldColor = mOldColor.getColor();
    int newColor = mNewColor.getColor();
    boolean alphaVisible = getAlphaSliderVisible();
    mOrientation = orientation;
    // إبقاء الشجرة الحالية أكثر أمانًا من استبدال setView بعد show؛ النظام يعيد قياسها تلقائيًا.
    mOldColor.setColor(oldColor);
    mColorPicker.setAlphaSliderVisible(alphaVisible);
    mColorPicker.setColor(newColor, true);
    updateHexLengthFilter();
  }

  @Override
  public void onRestoreInstanceState(Bundle state) {
    super.onRestoreInstanceState(state);
    setAlphaSliderVisible(state.getBoolean(STATE_ALPHA_VISIBLE, getAlphaSliderVisible()));
    setHexValueEnabled(state.getBoolean(STATE_HEX_ENABLED, mHexValueEnabled));
    mOldColor.setColor(state.getInt(STATE_OLD_COLOR, mOldColor.getColor()));
    mColorPicker.setColor(state.getInt(STATE_NEW_COLOR, mColorPicker.getColor()), true);
  }

  @Override
  public Bundle onSaveInstanceState() {
    Bundle state = super.onSaveInstanceState();
    state.putInt(STATE_OLD_COLOR, mOldColor.getColor());
    state.putInt(STATE_NEW_COLOR, mNewColor.getColor());
    state.putBoolean(STATE_ALPHA_VISIBLE, getAlphaSliderVisible());
    state.putBoolean(STATE_HEX_ENABLED, mHexValueEnabled);
    return state;
  }

  public void setAlphaSliderVisible(boolean visible) {
    mColorPicker.setAlphaSliderVisible(visible);
    if (mHexValueEnabled) {
      updateHexLengthFilter();
      updateHexValue(getColor());
    }
  }

  public void setHexValueEnabled(boolean enabled) {
    mHexValueEnabled = enabled;
    mHexVal.setVisibility(enabled ? View.VISIBLE : View.GONE);
    if (enabled) {
      updateHexLengthFilter();
      updateHexValue(getColor());
    } else {
      mHexInputValid = true;
      updatePositiveButtonState();
    }
  }

  public void setOnColorChangedListener(OnColorChangedListener listener) {
    mListener = listener;
  }
}
