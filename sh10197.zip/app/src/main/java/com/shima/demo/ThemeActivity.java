package com.shima.demo;

import almlk.AlphaCheckerPattern;
import almlk.AlphaCheckeredBar;
import almlk.EditorThemePalette;
import android.app.*;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.Map;

/**
 * شاشةُ أدوارِ الألوان: **لوحتانِ** — واحدةٌ للداكنِ وأخرى للفاتحِ — بسطورِ اللوحةِ الثلاثةَ عشرَ
 * بترتيبِها، وشريطُ تبويبٍ علويٌّ بمسافةِ الإعداداتِ نفسِها وخطِّ ترقيمٍ زجاجيَّ السطرِ المختار.
 * البناءُ بناءُ الإعداداتِ والإعداداتِ المتقدمة: عنوانٌ كبيرٌ فوقَ شريطِ اللونِ الذي يحملُ قيمتَهُ،
 * والنقرُ على السطرِ يفتحُ منتقيَ المصدر؛ والتبويبُ لا يبدّلُ نمطَ التطبيقِ بل **يبدّلُ اللوحةَ التي
 * تُحرَّر**، فلا يضيعُ ضبطُ المستخدمِ في اللوحةِ الأخرى.
 *
 * <p>الأيقاتُ والنصوصُ تتبعُ نمطَ التطبيق: فاتحٌ ⇒ أسودُ صريح، داكنٌ ⇒ عناصرِ بيضاءُ على سواد
 * ({@link ThemeConfig#foregroundFor(boolean)}).
 */
public class ThemeActivity extends LocaleAwareActivity {

  /** عنوان بديل (أدوات › تلوين الصياغة يفتح الشاشة نفسها بعنوانه). */
  public static final String EXTRA_TITLE = "title";
  private static final int MENU_RESTORE = 1, MENU_RESET_BOTH = 2, MENU_COPY = 3, MENU_IMPORT = 4,
      MENU_APPLY = 5, MENU_PANEL = 6;
  private static final int ACCENT = 0xFF23BBFF;

  private ThemeConfig theme;
  private View root;
  private LinearLayout entries;
  private TextView darkLabel, lightLabel, hint;
  private View darkAccent, lightAccent;
  private boolean editingDark = true;

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    theme = new ThemeConfig(this);
    editingDark = theme.isDark();
    setContentView(R.layout.activity_color_scheme);
    root = findViewById(R.id.colorSchemeRoot);
    entries = findViewById(R.id.colorSchemeEntries);
    hint = findViewById(R.id.colorSchemeHint);
    darkLabel = findViewById(R.id.colorSchemeDarkTabLabel);
    lightLabel = findViewById(R.id.colorSchemeLightTabLabel);
    darkAccent = findViewById(R.id.colorSchemeDarkTabAccent);
    lightAccent = findViewById(R.id.colorSchemeLightTabAccent);
    findViewById(R.id.colorSchemeDarkTab).setOnClickListener(v -> selectPanel(true));
    findViewById(R.id.colorSchemeLightTab).setOnClickListener(v -> selectPanel(false));
    ActionBar bar = getActionBar();
    if (bar != null) {
      String title = getIntent().getStringExtra(EXTRA_TITLE);
      if (title != null) bar.setTitle(title);
      else bar.setTitle(R.string.color_scheme_title);
      bar.setDisplayHomeAsUpEnabled(true);
    }
    render();
  }

  /** التبويبُ يبدّلُ اللوحةَ المُحرَّرةَ وحدها — لا لونَ في داكنةٍ يمسُّ فاتحةً. */
  private void selectPanel(boolean dark) {
    if (editingDark == dark) return;
    editingDark = dark;
    render();
  }

  private void render() {
    boolean appDark = theme.isDark();
    int background = ThemeConfig.backgroundFor(appDark);
    int foreground = ThemeConfig.foregroundFor(appDark);
    int dim = appDark ? 0xFF9E9E9E : 0xFF5F6368;
    root.setBackgroundColor(background);
    // الشريطُ وشريطَا الحالةِ والتنقُّلِ من نمطِ النشاطِ (almlk.ChromeTheme) كباقي الشاشات؛ ويبقى هنا
    // ما لا يملكُهُ نمطٌ: خلفيةُ المحتوى بلونِ اللوحةِ نفسِها، وأيقونةُ الرجوعِ بأيقاتِ النصّ الجاري.
    ActionBar bar = getActionBar();
    if (bar != null) {
      bar.setHomeAsUpIndicator(tint(R.drawable.ic_navigation_back, foreground));
    }
    // رَأْسُ القسمِ اسمُ الثيمِ المختارِ نفسِه (طلبُ الجولة)، لا كلمةُ «Dark»:
    // كلمةُ اللوحةِ تبقى هناك للّوحةِ الأساسيةِ وحدَها، لأنها لا اسمَ ثيمٍ فوقَها.
    String code = theme.activeThemeCode();
    boolean basePalette = EditorThemePalette.DEFAULT_THEME_CODE.equals(code);
    String header = basePalette ? null : themeName(code);
    darkLabel.setText(header != null ? header : getString(R.string.color_scheme_dark));
    lightLabel.setText(header != null ? header : getString(R.string.color_scheme_light));
    darkLabel.setTextColor(editingDark ? foreground : dim);
    lightLabel.setTextColor(editingDark ? dim : foreground);
    darkAccent.setVisibility(editingDark ? View.VISIBLE : View.INVISIBLE);
    lightAccent.setVisibility(editingDark ? View.INVISIBLE : View.VISIBLE);
    // كما في صورةِ المصدر: شريطُ تبويبٍ واحدٌ يملأُ العرضَ باسمِ الثيم إذا كان مُطبَّقًا؛ التبويبانِ
    // يبقيانِ مع اللوحةِ الأساسية. اللوحةُ الأخرى تظلُّ قابلةً للتحرير من القائمةِ نفسها.
    findViewById(R.id.colorSchemeDarkTab)
        .setVisibility(basePalette || editingDark ? View.VISIBLE : View.GONE);
    findViewById(R.id.colorSchemeLightTab)
        .setVisibility(basePalette || !editingDark ? View.VISIBLE : View.GONE);
    hint.setTextColor(dim);
    hint.setText(
        editingDark ? R.string.color_scheme_panel_dark : R.string.color_scheme_panel_light);

    entries.removeAllViews();
    for (Map.Entry<String, String> item : ThemeConfig.labels(this).entrySet()) {
      String role = item.getKey();
      int color = theme.color(role, editingDark);
      View row = getLayoutInflater().inflate(R.layout.color_scheme_entry, entries, false);
      TextView label = row.findViewById(R.id.colorSchemeEntryLabel);
      TextView value = row.findViewById(R.id.colorSchemeEntryValue);
      label.setText(item.getValue());
      label.setTextColor(foreground);
      value.setText(theme.hex(role, editingDark));
      // رقعةُ تعشيبٍ خلفَ اللونِ كما في الصورة: بلاها تصيرُ قيمةٌ شفّافٌ مثلَ «selected line
      // background» لا شيءَ مرئيًّا في اللوحتين، ومعها يُقرأُ الألفا رقمًا ولونًا.
      if (AlphaCheckerPattern.showsChecker(color)) {
        value.setTextColor(contrast(color));
        value.setBackground(new AlphaCheckeredBar(color));
      } else {
        value.setTextColor(dim);
        value.setBackground(null);
      }
      row.setOnClickListener(v -> editColor(role, item.getValue()));
      entries.addView(row);
    }
  }

  /** اسمُ الثيمِ المطبَّقِ — من {@link almlk.ThemeNames} وحدَه: الموردُ نفسُهُ للسطرِ والرأسِ معًا. */
  private String themeName(String code) {
    return almlk.ThemeNames.title(this, code);
  }

  private Drawable tint(int resource, int color) {
    Drawable drawable = drawableFromResource(this, resource);
    if (drawable != null) drawable.setTint(color);
    return drawable;
  }

  private Drawable drawableFromResource(Context context, int resource) {
    try {
      return androidx.core.content.ContextCompat.getDrawable(context, resource);
    } catch (Exception e) {
      return null;
    }
  }

  /** منتقي الألوان المرجعي (net.margaritov): مربع SV + شريط Hue + شريط ألفا + معاينة قديم/جديد + حقل HEX. */
  private void editColor(String role, String label) {
    net.margaritov.preference.colorpicker.ColorPickerDialog picker =
        new net.margaritov.preference.colorpicker.ColorPickerDialog(
            this, theme.color(role, editingDark));
    picker.setTitle(label);
    picker.setAlphaSliderVisible(true);
    picker.setHexValueEnabled(true);
    picker.setOnColorChangedListener(
        color -> {
          theme.setColor(role, color, editingDark);
          render();
          setResult(RESULT_OK);
        });
    picker.show();
  }

  /** لونُ النصِ فوقَ شريطِ اللون: أسودُ على الفاتح وأبيضُ على الداكن — قراءةُ القيمةِ لا تُترَكُ للعشوائية. */
  private int contrast(int color) {
    double luminance =
        (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color));
    return luminance > 150 ? Color.BLACK : Color.WHITE;
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }

  /** قائمة المرجع: استعادةُ اللوحةِ المعروضة، وإعادةُ اللوحتين، ونسخُ الإعدادات، واستيرادُها. */
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    menu.add(0, MENU_RESTORE, 0, UiStrings.get(this, "menu_restore"));
    menu.add(0, MENU_RESET_BOTH, 1, UiStrings.get(this, "menu_reset_light_dark"));
    menu.add(0, MENU_COPY, 2, UiStrings.get(this, "menu_copy_config"));
    menu.add(0, MENU_IMPORT, 3, UiStrings.get(this, "menu_import_config"));
    // اللوحةُ المُحرَّرةُ تُصبغُ نمطَ التطبيقِ منها مباشرةً (كانت في دايلوقِ الاختيارِ الملغى).
    menu.add(0, MENU_APPLY, 4, R.string.color_scheme_apply_panel);
    menu.add(0, MENU_PANEL, 5,
        editingDark ? R.string.color_scheme_edit_panel_light : R.string.color_scheme_edit_panel_dark);
    return true;
  }

  /** عنوانُ التبديلِ يبيّنُ اللوحةَ التي سيصيرُ إليها النقر — وهو منفذُ اللوحةِ المخفيّة. */
  @Override
  public boolean onPrepareOptionsMenu(Menu menu) {
    android.view.MenuItem toggle = menu.findItem(MENU_PANEL);
    if (toggle != null) {
      toggle.setTitle(editingDark ? R.string.color_scheme_edit_panel_light
          : R.string.color_scheme_edit_panel_dark);
    }
    return super.onPrepareOptionsMenu(menu);
  }

  private void changed() {
    render();
    setResult(RESULT_OK);
  }

  private void importConfig() {
    final EditText input = new EditText(this);
    input.setHint(UiStrings.get(this, "menu_import_config"));
    input.setMinLines(3);
    android.content.ClipboardManager clipboard =
        (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
    if (clipboard != null
        && clipboard.hasPrimaryClip()
        && clipboard.getPrimaryClip().getItemCount() > 0) {
      CharSequence clip = clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);
      if (clip != null) input.setText(clip);
    }
    LinearLayout box = new LinearLayout(this);
    box.setPadding(dp(20), dp(8), dp(20), 0);
    box.addView(input, new LinearLayout.LayoutParams(-1, -2));
    new AlertDialog.Builder(this)
        .setTitle(UiStrings.get(this, "menu_import_config"))
        .setView(box)
        .setNegativeButton(android.R.string.cancel, null)
        .setPositiveButton(
            UiStrings.get(this, "import_button"),
            (d, w) -> {
              try {
                int count = theme.importConfig(input.getText().toString());
                Toast.makeText(
                        this, UiStrings.format(this, "tools_config_imported", count), Toast.LENGTH_SHORT)
                    .show();
                changed();
              } catch (java.io.IOException e) {
                Toast.makeText(this, UiStrings.get(this, "tools_config_invalid"), Toast.LENGTH_SHORT)
                    .show();
              }
            })
        .show();
  }

  @Override
  public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    switch (item.getItemId()) {
      case MENU_RESTORE:
        theme.restoreDefaults(editingDark);
        changed();
        return true;
      case MENU_RESET_BOTH:
        theme.restoreDefaults(true);
        theme.restoreDefaults(false);
        changed();
        return true;
      case MENU_COPY:
        com.almlkid.ui.tools.ToolDialogs.copy(this, theme.exportConfig());
        return true;
      case MENU_IMPORT:
        importConfig();
        return true;
      case MENU_PANEL:
        // مع ثيمٍ مُطبَّقٍ لا ظاهرَ إلا شريطٌ واحد: التحريرُ في اللوحةِ الأخرى من القائمةِ نفسها.
        selectPanel(!editingDark);
        return true;
      case MENU_APPLY:
        // reset() يكتبُ SCHEME وحدَهُ: ألوانُ اللوحتينِ تبقى كما ضبطَها المستخدمُ عمدًا.
        theme.reset(editingDark);
        changed();
        return true;
      default:
        break;
    }
    return super.onOptionsItemSelected(item);
  }
}
