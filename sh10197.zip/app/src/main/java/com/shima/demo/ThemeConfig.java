package com.shima.demo;

import almlk.EditorThemePalette;
import almlk.EditorThemePresets;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * لوحةُ ألوانِ المحرّرِ والملوّحات: ثلاثةَ عشرَ دورًا بترتيبِ المصدرِ وقيمِهِ، ولكلِّ دورٍ لوحةٌ فاتحةٌ
 * وأخرى داكنة. التخزينُ **نصوصٌ سداسيّةٌ** بمفاتيحَ مشتقّةٍ من اسمِ الدورِ كما في المصدر
 * ({@code EditorThemePalette.spKey}) — لا أرقامًا معلَّقةً بأسماءٍ من اختراعِنا.
 *
 * <p>هذا المُكيِّفُ يحلُّ محلَّ لوحةٍ كانت خمسةَ عشرَ مفتاحًا بأرقامٍ في مفاتيحَ قديمة: المفاتيحُ الملغاةُ
 * ({@code function}، {@code variable}) تُطوَى إلى {@code Identifier} بهجرةٍ مرّةٍ واحدةٍ لا تُفقِدُ مستخدمًا
 * لونًا ضبطَه (تقدُّمُ {@code function} معلنٌ في {@link EditorThemePalette#LEGACY_IDENTIFIERS})،
 * و{@code type}/{@code selected_line}/{@code selected_text} تنتقلُ بأسماءِ الأدوارِ الجديدة.
 *
 * <p>اللوحةُ النشطةُ يحدِّدُها نمطُ الشاشة ({@link #isDark()})؛ والشاشةُ تكتبُ في أيِّ اللوحتينِ أرادتْ،
 * فلوحةُ الفاتحِ لا تَمسُّ لوحةَ الداكنِ إطلاقًا.
 */
public final class ThemeConfig {

  public static final String BACKGROUND = EditorThemePalette.BACKGROUND;
  public static final String PLAIN = EditorThemePalette.PLAIN;
  public static final String KEYWORD = EditorThemePalette.KEYWORD;
  public static final String IDENTIFIER = EditorThemePalette.IDENTIFIER;
  public static final String LITERAL = EditorThemePalette.LITERAL;
  public static final String OPERATOR = EditorThemePalette.OPERATOR;
  public static final String TYPE_IDENTIFIER = EditorThemePalette.TYPE_IDENTIFIER;
  public static final String NAMESPACE_IDENTIFIER = EditorThemePalette.NAMESPACE_IDENTIFIER;
  public static final String SEPARATOR = EditorThemePalette.SEPARATOR;
  public static final String COMMENT = EditorThemePalette.COMMENT;
  public static final String LINE_NUMBER = EditorThemePalette.LINE_NUMBER;
  public static final String LINE_BACKGROUND = EditorThemePalette.LINE_BACKGROUND;
  public static final String SELECTED_BACKGROUND = EditorThemePalette.SELECTED_BACKGROUND;

  private static final String PREFS = "shima_color_scheme";
  private static final String SCHEME = "scheme";
  private static final String THEME_CODE = "theme_code";
  private static final String MIGRATED = "palette13_migrated";

  /** وعاءُ النمطِ والهجرةِ ورمزِ الثيمِ النشِط — يبقى اسمُهُ التاريخيُّ محفوظًا. */
  private final SharedPreferences preferences;
  /**
   * وعاءُ ألوانِ الرمزِ النشِط: ملفٌّ لكلِّ ثيمٍ كما يفعلُ {@code HighlightUtils}، فيكونُ تخصيصُ Dracula
   * منفصلًا عن تخصيصِ GitHub. الأساسُ ({@code default}) على {@link #PREFS} نفسِه عمدًا — بياناتُ من
   * ضبطَ ألوانَهُ قبلَ المعرضِ لا تضيع.
   */
  private SharedPreferences colorStore;
  private String themeCode;
  private final Context appContext;

  public ThemeConfig(Context context) {
    appContext = context.getApplicationContext();
    preferences = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    themeCode = preferences.getString(THEME_CODE, EditorThemePalette.DEFAULT_THEME_CODE);
    reload();
    migrateLegacyKeysOnce();
  }

  /** بعدَ تبديلِ الثيمِ من المعرضِ: يُعادُ فتحُ وعاءِ الرمزِ الجديدِ على Instance نفسِهِ فلا شاشةُ ثانوية. */
  public void reload() {
    themeCode = preferences.getString(THEME_CODE, EditorThemePalette.DEFAULT_THEME_CODE);
    colorStore =
        appContext.getSharedPreferences(
            EditorThemePresets.prefsNameFor(themeCode), Context.MODE_PRIVATE);
  }

  /** رمزُ الثيمِ النشِط: {@code default} = «كاي أسود» في الداكنِ وقيمُ المرجعِ في الفاتح. */
  public String activeThemeCode() {
    return themeCode;
  }

  /**
   * اختيارُ ثيمٍ من المعرضِ **يُطبِّقُهُ** لا يصفُهُ: يكتبُ الرمزَ ويضبطُ نمطَ التطبيقِ بلوحةِ الثيمِ
   * (فاتحٌ ⇒ فاتح، داكنٌ ⇒ داكن) — فلا دايلوقَ بعدَهُ ولا خطوةً ثانية؛ والأساسُ {@code default}
   * أسودُ التعريفِ فيُعلَنُ داكنًا كما تُعلَنُ لوحاتُ الجدولِ كلُّها. ويُعيدُ {@code true} إن تبدّلَ
   * الرمزُ فعلاً.
   */
  public boolean applyTheme(String code) {
    String normalized =
        code == null || code.trim().isEmpty() ? EditorThemePalette.DEFAULT_THEME_CODE : code.trim();
    EditorThemePresets.Preset preset = EditorThemePresets.byCode(normalized);
    SharedPreferences.Editor editor = preferences.edit().putString(THEME_CODE, normalized);
    // «كاي أسود» ثيمٌ أسودُ **بالتعريف**: كانَ الرمزُ الأساسيُّ يخرجُ من هنا بلا مسٍّ لـscheme، فمَنْ
    // اختارَهُ من ثيمٍ فاتحٍ حصلَ على محرِّرٍ أسودَ داخلَ تطبيقٍ فاتح — والآنَ يُعلَنُ نمطُهُ كما يُعلَنُ
    // نمطُ أيِّ لوحةٍ أخرى في الجدول (لا استثناءَ صامتًا لمسارٍ واحد).
    if (EditorThemePalette.DEFAULT_THEME_CODE.equals(normalized)) editor.putString(SCHEME, "dark");
    else if (preset != null) editor.putString(SCHEME, preset.light ? "light" : "dark");
    editor.commit();
    boolean changed = !normalized.equals(themeCode);
    reload();
    return changed;
  }

  // ---------------- نمطُ الشاشة ----------------

  /** النمطُ النشِطُ للتطبيقِ كلِّه: داكنٌ افتراضًا، ويكتبُهُ اختيارُ ثيمٍ من المعرضِ أو من مُحرِّرِ الأدوار. */
  public boolean isDark() {
    return !"light".equals(preferences.getString(SCHEME, "dark"));
  }

  public boolean isLight() {
    return !isDark();
  }

  public String schemeName(Context context) {
    return context.getString(isDark() ? R.string.color_scheme_dark : R.string.color_scheme_light);
  }

  /** يبدّلُ النمطَ النشِطَ وحدَه؛ ألوانُ اللوحتينِ محفوظةٌ كما هي عمدًا (لا فقدانَ لضبطِ المستخدم). */
  public void reset(boolean dark) {
    preferences.edit().putString(SCHEME, dark ? "dark" : "light").commit();
  }

  // ---------------- القراءةُ والكتابة ----------------

  public int color(String role) {
    return color(role, isDark());
  }

  /** لونُ دورٍ في لوحةٍ بعينِها (داكنةٌ أم فاتحة) بصرفِ النظرِ عن النمطِ النشِط. */
  public int color(String role, boolean dark) {
    boolean light = !dark;
    if (EditorThemePalette.isResourceRole(role)) {
      // دورُ موردٍ كما عندَ المصدر: لا صَفًا في مُحرّرِ الألوانِ ولا لوحةَ ثيمٍ
      // — يُؤخَذُ من res/values/colors.xml مباشرةً (سقوطُ HighlightUtils إلى المورد).
      return EditorThemePalette.resourceColor(role, light);
    }
    String key = EditorThemePalette.spKey(role, light);
    String stored = colorStore.getString(key, null);
    Integer parsed = EditorThemePalette.parseHexOrNull(stored);
    if (parsed != null) return parsed.intValue();
    if (stored != null) {
      // نصٌّ تالفٌ من استيرادٍ خارجيٍّ لا يُبطِلُ الدور: يُحذَفُ وترجعُ الأرضيةُ الافتراضية.
      colorStore.edit().remove(key).apply();
    }
    return fallbackColor(role, light);
  }

  /** سلسلةُ الاحتياطِ الواحدة، كما في {@code Item.getColor}: override الثيمِ ← لوحةُ الثيمِ ← لوحةُ المرجع. */
  public int fallbackColor(String role, boolean light) {
    Integer fromPreset = EditorThemePresets.colorFor(themeCode, role, light);
    return fromPreset != null ? fromPreset.intValue() : EditorThemePalette.defaultColor(role, light);
  }

  public String fallbackHex(String role, boolean light) {
    String fromPreset = EditorThemePresets.hexFor(themeCode, role, light);
    return fromPreset != null ? fromPreset : EditorThemePalette.defaultHex(role, light);
  }

  public void setColor(String role, int color) {
    setColor(role, color, isDark());
  }

  /** الكتابةُ متزامنةٌ عندَ تأكيدِ المنتقي، في اللوحةِ المطلوبةِ وحدَها. */
  public void setColor(String role, int color, boolean dark) {
    colorStore
        .edit()
        .putString(EditorThemePalette.spKey(role, !dark), EditorThemePalette.formatArgb(color))
        .commit();
  }

  public void resetColor(String role) {
    preferences
        .edit()
        .remove(EditorThemePalette.spKey(role, true))
        .remove(EditorThemePalette.spKey(role, false))
        .apply();
  }

  public String hex(String role) {
    return hex(role, isDark());
  }

  /** القيمةُ كما تُعرَضُ على شريطِ اللون: النصُّ المحفوظُ أكبرًا، أو الافتراضيُّ عندَ عدمِ الضبط. */
  public String hex(String role, boolean dark) {
    if (EditorThemePalette.isResourceRole(role)) {
      return EditorThemePalette.resourceHex(role, !dark);
    }
    String stored = colorStore.getString(EditorThemePalette.spKey(role, !dark), null);
    Integer parsed = EditorThemePalette.parseHexOrNull(stored);
    return parsed == null
        ? fallbackHex(role, !dark).toUpperCase(java.util.Locale.US)
        : EditorThemePalette.formatArgb(parsed.intValue());
  }

  public int defaultColor(String role) {
    return fallbackColor(role, isLight());
  }

  /** استعادةُ لوحةٍ واحدةٍ إلى افتراضياتِها: مفتاحُ تلكِ اللوحةِ وحدَهُ يُمحى، والأخرى سالمة. */
  public void restoreDefaults(boolean dark) {
    // يُحاسَبُ وعاءُ الثيمِ النشِطِ وحدَهُ: استعادةُ GitHubِ لا تمسُّ تعديلاتِكَ في Dracula.
    SharedPreferences.Editor editor = colorStore.edit();
    for (String key : EditorThemePalette.spKeys(!dark)) editor.remove(key);
    SharedPreferences.Editor base = preferences.edit();
    // بقايا المفاتيحِ القديمةِ (أرقامٌ) تُكفَّنُ هنا أيضًا حتى لا يقرأَها أحدٌ بعدَ اليوم.
    for (String role : EditorThemePalette.ROLE_ORDER) {
      base.remove("color_" + (dark ? "dark" : "light") + "_" + EditorThemePalette.legacyKeyForRole(role));
      if (dark == isDark()) base.remove("color_" + EditorThemePalette.legacyKeyForRole(role));
    }
    editor.commit();
    base.commit();
  }

  /** نصُّ اللوحةِ للُّنسخ: ترميزُ المصدر {@code code;فاتح،داكن;…} (gzip+base64). */
  public String exportConfig() {
    LinkedHashMap<String, int[]> values = new LinkedHashMap<>();
    for (String role : EditorThemePalette.ROLE_ORDER) {
      values.put(role, new int[] {color(role, false), color(role, true)});
    }
    return EditorThemePalette.encodeTheme(EditorThemePalette.DEFAULT_THEME_CODE, values);
  }

  /** استيرادُ لوحة: يكتبُ الأدوارَ المعروفةَ في اللوحتينِ معًا ويعيدُ عددَها؛ {@code IOException} للنصِّ التالف. */
  public int importConfig(String config) throws java.io.IOException {
    EditorThemePalette.DecodedTheme theme = EditorThemePalette.decodeTheme(config);
    SharedPreferences.Editor editor = colorStore.edit();
    int count = 0;
    for (Map.Entry<String, int[]> entry : theme.roles.entrySet()) {
      if (!EditorThemePalette.isRole(entry.getKey())) continue;
      editor
          .putString(
              EditorThemePalette.spKey(entry.getKey(), true),
              EditorThemePalette.formatArgb(entry.getValue()[0]))
          .putString(
              EditorThemePalette.spKey(entry.getKey(), false),
              EditorThemePalette.formatArgb(entry.getValue()[1]));
      count++;
    }
    if (count == 0) throw new java.io.IOException("No known colors");
    editor.commit();
    return count;
  }

  /** رمزُ اللوحةِ في ترميزِ النسخ — لا مصادرَ أخرى له. */
  public String themeCode() {
    return preferences.getString("theme_code", EditorThemePalette.DEFAULT_THEME_CODE);
  }

  // ---------------- قاعدةُ الأدوارِ للاعرض ----------------

  /** عنوانُ كلِّ دورٍ بترتيبِ اللوحة — الشاشةُ تعرضُ هذا الخريطةَ ولا تعرفُ عددَ الألوان. */
  public static LinkedHashMap<String, String> labels(Context context) {
    LinkedHashMap<String, String> labels = new LinkedHashMap<>();
    for (String role : EditorThemePalette.ROLE_ORDER) labels.put(role, label(context, role));
    return labels;
  }

  public static String label(Context context, String role) {
    if (EditorThemePalette.BACKGROUND.equals(role)) return context.getString(R.string.color_scheme_background);
    if (EditorThemePalette.PLAIN.equals(role)) return context.getString(R.string.color_scheme_plain);
    if (EditorThemePalette.KEYWORD.equals(role)) return context.getString(R.string.color_scheme_keyword);
    if (EditorThemePalette.IDENTIFIER.equals(role)) return context.getString(R.string.color_scheme_identifier);
    if (EditorThemePalette.LITERAL.equals(role)) return context.getString(R.string.color_scheme_literal);
    if (EditorThemePalette.OPERATOR.equals(role)) return context.getString(R.string.color_scheme_operator);
    if (EditorThemePalette.TYPE_IDENTIFIER.equals(role)) return context.getString(R.string.color_scheme_type);
    if (EditorThemePalette.NAMESPACE_IDENTIFIER.equals(role))
      return context.getString(R.string.color_scheme_namespace);
    if (EditorThemePalette.SEPARATOR.equals(role)) return context.getString(R.string.color_scheme_separator);
    if (EditorThemePalette.COMMENT.equals(role)) return context.getString(R.string.color_scheme_comment);
    if (EditorThemePalette.LINE_NUMBER.equals(role)) return context.getString(R.string.color_scheme_line_number);
    if (EditorThemePalette.LINE_BACKGROUND.equals(role))
      return context.getString(R.string.color_scheme_selected_line);
    if (EditorThemePalette.SELECTED_BACKGROUND.equals(role))
      return context.getString(R.string.color_scheme_selected_text);
    return role;
  }

  /** تحقّقُ حقلِ hexadecimal: {@code #AARRGGBB} أو {@code #RRGGBB}؛ خطأٌ واضحٌ لغيرِهما. */
  public static int parseColor(String value) {
    Integer parsed = EditorThemePalette.parseHexOrNull(value);
    if (parsed == null) throw new IllegalArgumentException("Use #AARRGGBB");
    return parsed.intValue();
  }

  /**
   * قاعدةُ تلوينِ الواجهةِ الواحدة: الفاتحُ ⇒ أسودُ صريحٌ على بياض، والداكنُ ⇒ أبيضُ على سواد.
   * تُستعمَلُ لأيقوناتِ الشريطِ وقسمِ القائمةِ وعناوينِ الإعدادات، فلا يبقى عنصرٌ أبيضَ على أبيض.
   */
  public static int foregroundFor(boolean dark) {
    return EditorThemePalette.foregroundFor(dark);
  }

  public static int backgroundFor(boolean dark) {
    return EditorThemePalette.backgroundFor(dark);
  }

  public static int chromeFor(boolean dark) {
    return EditorThemePalette.chromeFor(dark);
  }

  // ---------------- الهجرةُ من اللوحةِ القديمة ----------------

  /**
   * مرّةً واحدةً فقط: أرقامُ المفاتيحِ القديمةِ تتحوّلُ نصوصًا سداسيةً باسمِ الدورِ الجديد، والمفاتيحُ
   * الملغاةُ تُطوَى إلى {@code Identifier} بأولويّةِ {@code function} (تُعلَنُ في اللوحة) ثم تُمحى.
   */
  private void migrateLegacyKeysOnce() {
    if (preferences.getBoolean(MIGRATED, false)) return;
    SharedPreferences.Editor editor = preferences.edit();
    for (String role : EditorThemePalette.ROLE_ORDER) {
      boolean hasLight = preferences.contains(EditorThemePalette.spKey(role, true));
      boolean hasDark = preferences.contains(EditorThemePalette.spKey(role, false));
      if (!hasLight) {
        Integer light = legacyInt("color_light_" + EditorThemePalette.legacyKeyForRole(role));
        if (light != null) editor.putString(EditorThemePalette.spKey(role, true), EditorThemePalette.formatArgb(light));
      }
      if (!hasDark) {
        Integer dark = legacyInt("color_dark_" + EditorThemePalette.legacyKeyForRole(role));
        if (dark == null) dark = legacyInt("color_" + EditorThemePalette.legacyKeyForRole(role));
        if (dark != null) editor.putString(EditorThemePalette.spKey(role, false), EditorThemePalette.formatArgb(dark));
      }
    }
    // الطيُّ: function ثم variable (من لونا، لا الاثنين، والاكتفاءُ بالافتراضي).
    if (preferences.contains(EditorThemePalette.spKey(IDENTIFIER, true))
        && preferences.contains(EditorThemePalette.spKey(IDENTIFIER, false))) {
      for (String legacy : EditorThemePalette.LEGACY_IDENTIFIERS) {
        editor.remove("color_light_" + legacy).remove("color_dark_" + legacy).remove("color_" + legacy);
      }
    } else {
      for (String legacy : EditorThemePalette.LEGACY_IDENTIFIERS) {
        Integer folded = legacyInt("color_light_" + legacy);
        if (folded != null) {
          editor.putString(EditorThemePalette.spKey(IDENTIFIER, true), EditorThemePalette.formatArgb(folded));
          break;
        }
      }
      for (String legacy : EditorThemePalette.LEGACY_IDENTIFIERS) {
        Integer folded = legacyInt("color_dark_" + legacy);
        if (folded == null) folded = legacyInt("color_" + legacy);
        if (folded != null) {
          editor.putString(EditorThemePalette.spKey(IDENTIFIER, false), EditorThemePalette.formatArgb(folded));
          break;
        }
      }
      for (String legacy : EditorThemePalette.LEGACY_IDENTIFIERS) {
        editor.remove("color_light_" + legacy).remove("color_dark_" + legacy).remove("color_" + legacy);
      }
    }
    for (String role : EditorThemePalette.ROLE_ORDER) {
      editor.remove("color_" + EditorThemePalette.legacyKeyForRole(role));
    }
    editor.putBoolean(MIGRATED, true).commit();
  }

  private Integer legacyInt(String key) {
    if (!preferences.contains(key)) return null;
    Object value = preferences.getAll().get(key);
    if (value instanceof Integer) return (Integer) value;
    Integer parsed = EditorThemePalette.parseHexOrNull(String.valueOf(value));
    return parsed;
  }
}
