package com.shima.demo;

import android.app.ActionBar;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.MenuItem;
import com.almlkid.ui.preferences.ThemeGalleryFragment;

/**
 * صفحةُ الثيماتِ — **قسمٌ معزولٌ** يُفتَحُ من سطرٍ واحدٍ في الإعداداتِ المتقدمةِ، لا سطورَ ثيماتٍ
 * مبعثرةً في شاشتينِ (طلبُ الجولةِ التاسعةِ عشرة: «أنشئ قسمَ الثيماتِ بحيثُ يكونُ قسمًا معزولًا
 * داخلَ الإعداداتِ المتقدمةِ… وتَتَخلَّصُ من تقسيمِ الثيماتِ في أماكنِ تواجُدِها الآنَ بحيثُ تكونُ في
 * قسمِ الثيماتِ فقط»).
 *
 * <p><b>شكلُها شكلُ «الإعداداتِ / الإعداداتِ المتقدمةِ» لأنَّها الآليةُ نفسُها:</b> {@code
 * ActionBar.NAVIGATION_MODE_TABS} بشريطِ تبويباتٍ تحتَ العنوانِ، وأسفلَهُ شظيتا {@code
 * PreferenceFragment} تُبدَّلانِ بالإظهارِ والإخفاءِ. الفاتحةُ تبويبٌ أوّلٌ فيُرسَمُ في أقصى اليمينِ
 * حيثُ تبدأُ القراءةُ العربيّةُ (في لقطةِ صاحبِ العملِ «الإعداداتُ» المُفعَّلةُ يمينًا)، والداكنةُ إلى
 * يسارِها — لا عمودٌ واحدٌ في الإعداداتِ ولا عمودٌ ثانٍ في المتقدمةِ.
 *
 * <p><b>ولمَ نشاطٌ لا {@code PreferenceScreen} متداخلةٌ داخلَ الإعداداتِ؟</b> لأنَّ الشاشةَ
 * المتداخلةَ ترثُ شريطَ الإعداداتِ نفسَه بلا تبويباتٍ ولا عنوانٍ مستقلٍّ — فلا «قسمٌ معزولٌ» حقيقةً؛
 * ولأنَّ مُحرِّرَ أدوارِ الألوانِ ({@link ThemeActivity}) يُفتَحُ منها نشاطًا آخرَ فلا يصحُّ أن يكونَ
 * «داخلَ» شاشةٍ أصلًا. والبوابةُ تُثبِتُ أنَّ لا سطرَ ثيمٍ بقيَ في الشاشتينِ، فهذه الصفحةُ موضعُ
 * الثيماتِ كلِّها.
 *
 * <p><b>حصانةُ المعاملاتِ</b> موروثةٌ من {@code AlmlkPreferencesActivity}: المعاملةُ التي يمررُها
 * الإطارُ إلى {@code TabListener} تُترَكُ فارغةً فلا «IllegalStateException: commit already called»،
 * والإظهارُ/الإخفاءُ بمعاملةٍ مستقلّةٍ {@code commitAllowingStateLoss}. والتبويبُ الجاري يُحفَظُ في
 * حالةِ النسخةِ ({@code onSaveInstanceState}) ليصمدَ عندَ إعادةِ بناءِ الشاشةِ بعدَ أن يقلبَ الثيمُ
 * نمطَ التطبيقِ.
 */
public class ThemeGalleryActivity extends LocaleAwareActivity implements ActionBar.TabListener {

  private static final String TAG_TAB_LIGHT = "tag_theme_tab_light";
  private static final String TAG_TAB_DARK = "tag_theme_tab_dark";
  private static final String TAG_FRAGMENT_LIGHT = "tag_theme_fragment_light";
  private static final String TAG_FRAGMENT_DARK = "tag_theme_fragment_dark";
  private static final String STATE_TAB = "theme_gallery_tab_index";

  private ThemeGalleryFragment light;
  private ThemeGalleryFragment dark;
  private int selected;

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    // أولُ تشغيلٍ = الفاتحةُ (0)؛ وعندَ إعادةِ البناءِ يبقى ما كانَ ظاهرًا — وإلا قفزَ المستخدمُ من
    // لوحتِهِ الداكنةِ إلى الفاتحةِ لمجرَّدِ أنْ قَلَبَ الثيمُ نمطَ التطبيقِ.
    selected = state == null ? 0 : Math.max(0, Math.min(1, state.getInt(STATE_TAB, 0)));
    ActionBar bar = getActionBar();
    if (bar != null) {
      bar.setDisplayHomeAsUpEnabled(true);
      bar.setTitle(R.string.theme_gallery_section_title);
      bar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
      bar.addTab(
          bar.newTab()
              .setText(R.string.theme_gallery_section_light)
              .setTag(TAG_TAB_LIGHT)
              .setTabListener(this));
      bar.addTab(
          bar.newTab()
              .setText(R.string.theme_gallery_section_dark)
              .setTag(TAG_TAB_DARK)
              .setTabListener(this));
      bar.getTabAt(selected).select();
    }
    FragmentManager manager = getFragmentManager();
    FragmentTransaction transaction = manager.beginTransaction();
    light = (ThemeGalleryFragment) manager.findFragmentByTag(TAG_FRAGMENT_LIGHT);
    if (light == null) {
      light = ThemeGalleryFragment.newInstance(false);
      transaction.add(android.R.id.content, light, TAG_FRAGMENT_LIGHT);
    }
    dark = (ThemeGalleryFragment) manager.findFragmentByTag(TAG_FRAGMENT_DARK);
    if (dark == null) {
      dark = ThemeGalleryFragment.newInstance(true);
      transaction.add(android.R.id.content, dark, TAG_FRAGMENT_DARK);
    }
    // التبويبُ فُعِّلَ قبلَ أن توجدَ الشظايا (أعلاه) فلا بلَغَها؛ والظاهرُ والمخبَّؤُ يُطبَّقُ هنا
    // بيدِنا مرةً واحدةً في المعاملةِ نفسِها التي تُضيفُهما — لا معاملةً ثانيةً تُنافِسُها.
    if (selected == 0) {
      transaction.show(light);
      transaction.hide(dark);
    } else {
      transaction.show(dark);
      transaction.hide(light);
    }
    transaction.commit();
  }

  @Override
  protected void onSaveInstanceState(Bundle outState) {
    outState.putInt(STATE_TAB, selected);
    super.onSaveInstanceState(outState);
  }

  @Override
  public void onTabSelected(ActionBar.Tab tab, FragmentTransaction transaction) {
    int next = TAG_TAB_DARK.equals(String.valueOf(tab.getTag())) ? 1 : 0;
    selected = next;
    if (light == null || dark == null) return; // التبويبُ سبقَ الشظايا في onCreate
    FragmentTransaction own = getFragmentManager().beginTransaction();
    if (next == 0) {
      own.show(light);
      own.hide(dark);
    } else {
      own.show(dark);
      own.hide(light);
    }
    own.commitAllowingStateLoss();
  }

  @Override
  public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction transaction) {}

  @Override
  public void onTabReselected(ActionBar.Tab tab, FragmentTransaction transaction) {}

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
