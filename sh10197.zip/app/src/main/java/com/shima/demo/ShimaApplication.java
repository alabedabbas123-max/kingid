package com.shima.demo;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.LocaleList;
import android.os.Process;
import android.preference.PreferenceManager;
import java.util.Locale;

/** Global last-resort crash handler. Errors are saved and opened in RecoveryActivity. */
public class ShimaApplication extends Application {
  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(localize(base));
  }

  /**
   * Wraps a context with the locale saved in app preferences.
   *
   * <p>Locale resources belong to each Context, not just to Application. Every Activity therefore
   * uses this wrapper from attachBaseContext; changing Application Resources alone left recreated
   * Activities bound to their old (Arabic) configuration.
   */
  public static Context localize(Context base) {
    String language =
        PreferenceManager.getDefaultSharedPreferences(base)
            .getString(almlk.AppSettings.KEY_LANGUAGE, "default");
    Locale selected = localeFor(language);
    Locale.setDefault(selected);
    Configuration localized = new Configuration(base.getResources().getConfiguration());
    localized.setLocale(selected);
    // The chosen locale controls text lookup only; keep all app geometry and navigation LTR.
    localized.setLayoutDirection(Locale.ENGLISH);
    return base.createConfigurationContext(localized);
  }

  /** Resolves the explicit app choice; Default follows the device locale, never an implicit Arabic. */
  private static Locale localeFor(String language) {
    String code = language == null ? "default" : language.trim().toLowerCase(Locale.ROOT);
    switch (code) {
      case "en":
        return Locale.ENGLISH;
      case "de":
        return Locale.GERMAN;
      case "ru":
        return new Locale("ru");
      case "zh":
        return new Locale("zh", "CN");
      case "ar":
        return new Locale("ar");
      case "default":
      default:
        return systemLocale();
    }
  }

  private static Locale systemLocale() {
    Configuration system = Resources.getSystem().getConfiguration();
    LocaleList locales = system.getLocales();
    return locales != null && !locales.isEmpty() ? locales.get(0) : Locale.ENGLISH;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    Thread.UncaughtExceptionHandler fallback = Thread.getDefaultUncaughtExceptionHandler();
    // W23/1 — في عمليةِ التحليلِ المنفصلةِ يُكتَفى بالسجلِّ: لا شاشةَ استرجاعٍ ولا تَطهيرَ لمهمّةٍ
    // لا ذنبَ لها. الواجهةُ تُبلَّغُ بقطعِ القناةِ (حالةُ process_died) وتُعيدُ الربطَ وحدَها.
    final boolean analyzerProcess = isAnalyzerProcess();
    Thread.setDefaultUncaughtExceptionHandler(
        (thread, error) -> {
          if (isDeadSystem(error)) {
            Process.killProcess(Process.myPid());
            return;
          }
          try {
            if (analyzerProcess) {
              CrashStore.save(this, error);
            } else if (PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean("experimental_crash_report", true)) {
              CrashStore.save(this, error);
              Intent intent =
                  new Intent(this, RecoveryActivity.class)
                      .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
              startActivity(intent);
            }
            Thread.sleep(250);
          } catch (Throwable ignored) {
            if (fallback != null) fallback.uncaughtException(thread, error);
          }
          Process.killProcess(Process.myPid());
          System.exit(10);
        });
  }

  /**
   * هل نحنُ في عمليةِ التحليلِ (‏:analyzer)؟ الاسمُ يُقرَأُ من ‏/proc/self/cmdline: لا
   * ‏Application.getProcessName()‏ لأنَّ حدَّنا الأدنى ‏26‏ وهو من ‏28، ولا حاجةَ إلى انعكاسٍ.
   */
  private boolean isAnalyzerProcess() {
    try (java.io.InputStream in = new java.io.FileInputStream("/proc/self/cmdline")) {
      byte[] raw = new byte[256];
      int read = in.read(raw);
      if (read <= 0) return false;
      return new String(raw, 0, read, "UTF-8").trim().endsWith(":analyzer");
    } catch (java.io.IOException unavailable) {
      return false;
    }
  }

  private boolean isDeadSystem(Throwable error) {
    for (Throwable current = error; current != null; current = current.getCause()) {
      String name = current.getClass().getName();
      if (name.endsWith("DeadSystemException") || name.endsWith("DeadSystemRuntimeException"))
        return true;
    }
    return false;
  }
}
