package com.shima.editor.core;

public final class SymbolLocation {
  public final String file;
  public final int offset;
  public final int end;
  public final int line;
  public final int column;

  public SymbolLocation(String file, int offset, int end, int line, int column) {
    this.file = file == null ? "" : file;
    this.offset = Math.max(0, offset);
    this.end = Math.max(this.offset + 1, end);
    this.line = Math.max(1, line);
    this.column = Math.max(1, column);
  }
}
