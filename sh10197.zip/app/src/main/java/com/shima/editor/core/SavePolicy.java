package com.shima.editor.core;

public final class SavePolicy {
  public final long debounceMs;
  public final boolean createRecoveryCopy;
  public final int maxRecoveryCopies;

  public SavePolicy(long debounceMs, boolean createRecoveryCopy, int maxRecoveryCopies) {
    this.debounceMs = Math.max(100L, debounceMs);
    this.createRecoveryCopy = createRecoveryCopy;
    this.maxRecoveryCopies = Math.max(1, maxRecoveryCopies);
  }

  public static SavePolicy editorDefault() {
    return new SavePolicy(750L, true, 5);
  }
}
