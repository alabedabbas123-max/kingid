package com.shima.editor.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Context-aware Smali completion sources with bounded, prefix-ranked results. */
public final class SmaliCompletionEngine {
  private static final List<String> DIRECTIVES = Arrays.asList(
      ".class", ".super", ".source", ".implements", ".field", ".method", ".end", ".registers",
      ".locals", ".param", ".prologue", ".line", ".annotation", ".end annotation", ".catch",
      ".catchall", ".array-data", ".packed-switch", ".sparse-switch", ".end method");
  private static final List<String> OPCODES = Arrays.asList(
      "move", "move-result", "move-result-object", "return-void", "return", "const", "const-string",
      "new-instance", "check-cast", "instance-of", "invoke-virtual", "invoke-direct", "invoke-static",
      "invoke-interface", "iget", "iput", "sget", "sput", "if-eq", "if-ne", "if-eqz", "if-nez",
      "goto", "throw", "add-int", "sub-int", "mul-int", "div-int", "array-length", "aget", "aput");

  private SmaliCompletionEngine() {}

  public static List<String> complete(CharSequence source, int cursor, int limit) {
    String text = source == null ? "" : source.toString();
    int at = Math.max(0, Math.min(cursor, text.length()));
    int start = at;
    while (start > 0 && isPrefixChar(text.charAt(start - 1))) start--;
    String prefix = text.substring(start, at);
    String before = text.substring(0, at);
    int lineStart = Math.max(0, before.lastIndexOf('\n') + 1);
    String line = before.substring(lineStart);
    Set<String> candidates = new LinkedHashSet<>();
    if (prefix.startsWith(":")) {
      for (String label : labels(text)) candidates.add(label);
    } else if (line.trim().startsWith(".")) {
      candidates.addAll(DIRECTIVES);
    } else if (prefix.startsWith("v") || prefix.startsWith("p")) {
      for (int i = 0; i < 256; i++) candidates.add(prefix.charAt(0) + Integer.toString(i));
    } else {
      candidates.addAll(OPCODES);
      for (String descriptor : descriptors(text)) candidates.add(descriptor);
    }
    ArrayList<String> result = new ArrayList<>();
    String lower = prefix.toLowerCase(Locale.US);
    for (String value : candidates) {
      if (lower.isEmpty() || value.toLowerCase(Locale.US).startsWith(lower)) result.add(value);
      if (result.size() >= Math.max(1, limit)) break;
    }
    return result;
  }

  private static List<String> labels(String text) {
    LinkedHashSet<String> values = new LinkedHashSet<>();
    for (String line : text.split("\\n")) {
      String trimmed = line.trim();
      if (trimmed.startsWith(":")) values.add(trimmed.split("\\s", 2)[0]);
    }
    return new ArrayList<>(values);
  }

  private static List<String> descriptors(String text) {
    LinkedHashSet<String> values = new LinkedHashSet<>();
    int start = -1;
    for (int i = 0; i < text.length(); i++) {
      if (text.charAt(i) == 'L') start = i;
      if (start >= 0 && text.charAt(i) == ';') {
        values.add(text.substring(start, i + 1));
        start = -1;
      }
    }
    return new ArrayList<>(values);
  }

  private static boolean isPrefixChar(char value) {
    return Character.isLetterOrDigit(value) || value == '_' || value == '$' || value == ':' || value == '.' || value == '/';
  }
}
