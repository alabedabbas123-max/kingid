package com.shima.editor.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Dependency-free Smali lexer. It returns UTF-16 ranges and never allocates styled text. */
public final class SmaliTokenizer {
  private static final Set<String> OPCODES =
      new HashSet<>(
          Arrays.asList(
              "nop", "move", "move/from16", "move/16", "move-wide", "move-object",
              "move-result", "move-result-wide", "move-result-object", "move-exception",
              "return-void", "return", "return-wide", "return-object", "const", "const/4",
              "const/16", "const/high16", "const-wide", "const-wide/16", "const-wide/32",
              "const-wide/high16", "const-string", "const-string/jumbo", "const-class",
              "monitor-enter", "monitor-exit", "check-cast", "instance-of", "array-length",
              "new-instance", "new-array", "filled-new-array", "filled-new-array/range",
              "fill-array-data", "throw", "goto", "goto/16", "goto/32", "packed-switch",
              "sparse-switch", "cmpl-float", "cmpg-float", "cmpl-double", "cmpg-double",
              "cmp-long", "if-eq", "if-ne", "if-lt", "if-ge", "if-gt", "if-le", "if-eqz",
              "if-nez", "if-ltz", "if-gez", "if-gtz", "if-lez", "aget", "aget-wide",
              "aget-object", "aget-boolean", "aget-byte", "aget-char", "aget-short", "aput",
              "aput-wide", "aput-object", "aput-boolean", "aput-byte", "aput-char", "aput-short",
              "iget", "iget-wide", "iget-object", "iget-boolean", "iget-byte", "iget-char",
              "iget-short", "iput", "iput-wide", "iput-object", "iput-boolean", "iput-byte",
              "iput-char", "iput-short", "sget", "sget-wide", "sget-object", "sget-boolean",
              "sget-byte", "sget-char", "sget-short", "sput", "sput-wide", "sput-object",
              "sput-boolean", "sput-byte", "sput-char", "sput-short", "invoke-virtual",
              "invoke-super", "invoke-direct", "invoke-static", "invoke-interface", "invoke-virtual/range",
              "invoke-super/range", "invoke-direct/range", "invoke-static/range", "invoke-interface/range",
              "add-int", "sub-int", "mul-int", "div-int", "rem-int", "and-int", "or-int",
              "xor-int", "shl-int", "shr-int", "ushr-int", "add-long", "sub-long", "mul-long",
              "div-long", "rem-long", "add-float", "sub-float", "mul-float", "div-float",
              "add-double", "sub-double", "mul-double", "div-double", "neg-int", "not-int",
              "neg-long", "not-long", "neg-float", "neg-double", "int-to-long", "int-to-float",
              "int-to-double", "long-to-int", "long-to-float", "long-to-double", "float-to-int",
              "float-to-long", "float-to-double", "double-to-int", "double-to-long", "double-to-float",
              "int-to-byte", "int-to-char", "int-to-short", "add-int/2addr", "sub-int/2addr",
              "mul-int/2addr", "div-int/2addr", "rem-int/2addr", "and-int/2addr", "or-int/2addr",
              "xor-int/2addr", "shl-int/2addr", "shr-int/2addr", "ushr-int/2addr", "add-long/2addr",
              "sub-long/2addr", "mul-long/2addr", "div-long/2addr", "rem-long/2addr", "packed-switch-payload",
              "sparse-switch-payload", "array-data-payload"));

  private SmaliTokenizer() {}

  public static List<SmaliToken> tokenize(CharSequence source) {
    ArrayList<SmaliToken> result = new ArrayList<>();
    if (source == null) return result;
    int lineStart = 0;
    for (int i = 0; i <= source.length(); i++) {
      if (i == source.length() || source.charAt(i) == '\n') {
        tokenizeLine(source, lineStart, i, result);
        lineStart = i + 1;
      }
    }
    return result;
  }

  public static List<SmaliToken> tokenizeLine(CharSequence source, int start, int end) {
    ArrayList<SmaliToken> result = new ArrayList<>();
    tokenizeLine(source, start, end, result);
    return result;
  }

  private static void tokenizeLine(CharSequence source, int start, int end, List<SmaliToken> out) {
    if (source == null) return;
    int i = Math.max(0, start);
    int limit = Math.min(source.length(), Math.max(i, end));
    while (i < limit && Character.isWhitespace(source.charAt(i))) i++;
    int firstWordStart = i;
    String directive = "";
    if (i < limit && source.charAt(i) == '.') {
      int directiveEnd = scanWord(source, i + 1, limit);
      directive = source.subSequence(i, directiveEnd).toString();
    }
    boolean methodLine = ".method".equals(directive);
    boolean fieldLine = ".field".equals(directive);
    boolean first = true;
    while (i < limit) {
      char c = source.charAt(i);
      if (c == '#') {
        out.add(new SmaliToken(i, limit, SmaliTokenKind.COMMENT));
        return;
      }
      if (Character.isWhitespace(c) || c == ',') {
        i++;
        continue;
      }
      if (c == '"' || c == '\'') {
        int tokenStart = i++;
        boolean escaped = false;
        while (i < limit) {
          char value = source.charAt(i++);
          if (escaped) {
            escaped = false;
          } else if (value == '\\') {
            escaped = true;
          } else if (value == c) {
            break;
          }
        }
        out.add(new SmaliToken(tokenStart, i, SmaliTokenKind.STRING));
        first = false;
        continue;
      }
      if (c == ':') {
        int tokenStart = i++;
        while (i < limit && isName(source.charAt(i))) i++;
        out.add(new SmaliToken(tokenStart, i, SmaliTokenKind.LABEL));
        first = false;
        continue;
      }
      if (c == '.') {
        int tokenStart = i;
        i = scanWord(source, i + 1, limit);
        out.add(new SmaliToken(tokenStart, i, SmaliTokenKind.DIRECTIVE));
        first = false;
        continue;
      }
      if (c == '@') {
        int tokenStart = i++;
        while (i < limit && (isName(source.charAt(i)) || source.charAt(i) == '/')) i++;
        out.add(new SmaliToken(tokenStart, i, SmaliTokenKind.ANNOTATION));
        first = false;
        continue;
      }
      if (c == 'L' || c == '[') {
        int descriptorEnd = descriptorEnd(source, i, limit);
        if (descriptorEnd > i && source.charAt(descriptorEnd - 1) == ';') {
          out.add(new SmaliToken(i, descriptorEnd, SmaliTokenKind.TYPE_DESCRIPTOR));
          i = descriptorEnd;
          first = false;
          continue;
        }
      }
      if (Character.isDigit(c) || ((c == '-' || c == '+') && i + 1 < limit && Character.isDigit(source.charAt(i + 1)))) {
        int tokenStart = i++;
        while (i < limit && isNumberPart(source.charAt(i))) i++;
        out.add(new SmaliToken(tokenStart, i, SmaliTokenKind.NUMBER));
        first = false;
        continue;
      }
      if (isName(c)) {
        int tokenStart = i++;
        while (i < limit && isName(source.charAt(i))) i++;
        String word = source.subSequence(tokenStart, i).toString();
        SmaliTokenKind kind;
        if ((word.charAt(0) == 'v' || word.charAt(0) == 'p') && allDigits(word, 1)) {
          kind = SmaliTokenKind.REGISTER;
        } else if (OPCODES.contains(word) || (first && word.contains("-"))) {
          kind = SmaliTokenKind.OPCODE;
        } else if (methodLine && source.charAt(i < limit ? i : limit - 1) == '(') {
          kind = SmaliTokenKind.METHOD_NAME;
        } else if (fieldLine && source.subSequence(i, limit).toString().contains(":")) {
          kind = SmaliTokenKind.FIELD_NAME;
        } else if (word.startsWith("L") && word.endsWith(";")) {
          kind = SmaliTokenKind.TYPE_DESCRIPTOR;
        } else {
          kind = SmaliTokenKind.PLAIN;
        }
        out.add(new SmaliToken(tokenStart, i, kind));
        first = false;
        continue;
      }
      i++;
      first = false;
    }
    // Keep the local for debugging and to make the method's line-boundary contract explicit.
    if (firstWordStart < 0) return;
  }

  private static int scanWord(CharSequence source, int start, int end) {
    int i = Math.max(0, start);
    while (i < end && (isName(source.charAt(i)) || source.charAt(i) == '/')) i++;
    return i;
  }

  private static int descriptorEnd(CharSequence source, int start, int end) {
    int i = start;
    if (i < end && source.charAt(i) == '[') {
      while (i < end && source.charAt(i) == '[') i++;
    }
    if (i >= end || source.charAt(i) != 'L') return -1;
    while (i < end && source.charAt(i) != ';' && source.charAt(i) != ' ' && source.charAt(i) != ',') i++;
    return i < end && source.charAt(i) == ';' ? i + 1 : i;
  }

  private static boolean isName(char c) {
    return Character.isLetterOrDigit(c) || c == '_' || c == '$' || c == '/' || c == '-' || c == '<' || c == '>';
  }

  private static boolean isNumberPart(char c) {
    return Character.isLetterOrDigit(c) || c == 'x' || c == 'X' || c == '.' || c == '_';
  }

  private static boolean allDigits(String value, int start) {
    if (start >= value.length()) return false;
    for (int i = start; i < value.length(); i++) if (!Character.isDigit(value.charAt(i))) return false;
    return true;
  }
}
