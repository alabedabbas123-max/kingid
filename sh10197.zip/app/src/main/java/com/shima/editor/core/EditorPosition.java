package com.shima.editor.core;

/** Persistent cursor and viewport state for one open document. */
public final class EditorPosition {
  public int line;
  public int column;
  public int scrollX;
  public int scrollY;
  public long selectionStart = -1L;
  public long selectionEnd = -1L;

  public EditorPosition() {}

  public EditorPosition(EditorPosition other) {
    if (other == null) return;
    line = other.line;
    column = other.column;
    scrollX = other.scrollX;
    scrollY = other.scrollY;
    selectionStart = other.selectionStart;
    selectionEnd = other.selectionEnd;
  }
}
