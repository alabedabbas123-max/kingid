package com.shima.editor.core;

import android.content.Context;
import com.shima.demo.UiStrings;
import java.nio.charset.StandardCharsets;

/** Safe DEX header/metadata reader. It parses bytes only and never loads or executes classes. */
public final class DexMetadataReader {
  private DexMetadataReader() {}

  public static String describe(Context context, String path, long availableSize, byte[] data) {
    StringBuilder result = new StringBuilder(UiStrings.get(context, "ui_dex_metadata_title"));
    result.append("\n\n")
        .append(UiStrings.get(context, "ui_binary_path"))
        .append(' ')
        .append(path == null ? "" : path);
    result.append("\n")
        .append(UiStrings.format(
            context,
            "ui_dex_declared_size",
            availableSize,
            UiStrings.get(context, "ui_byte_unit")));
    if (data == null || data.length < 112)
      return result.append("\n\n").append(UiStrings.get(context, "ui_dex_file_too_small")).toString();
    String magic = new String(data, 0, 8, StandardCharsets.US_ASCII).replace('\0', ' ');
    result.append("\nmagic: ").append(magic.trim());
    if (!(magic.startsWith("dex\\n") || magic.startsWith("dex")))
      return result.append("\n").append(UiStrings.get(context, "ui_dex_invalid_header")).toString();
    result.append("\nfile_size: ").append(u32(data, 32));
    result.append("\nheader_size: ").append(u32(data, 36));
    result.append("\nstring_ids: ").append(u32(data, 56)).append(" @ ").append(hex(u32(data, 60)));
    result.append("\ntype_ids: ").append(u32(data, 64)).append(" @ ").append(hex(u32(data, 68)));
    result.append("\nproto_ids: ").append(u32(data, 72)).append(" @ ").append(hex(u32(data, 76)));
    result.append("\nfield_ids: ").append(u32(data, 80)).append(" @ ").append(hex(u32(data, 84)));
    result.append("\nmethod_ids: ").append(u32(data, 88)).append(" @ ").append(hex(u32(data, 92)));
    result.append("\nclass_defs: ").append(u32(data, 96)).append(" @ ").append(hex(u32(data, 100)));
    result.append("\n\n").append(UiStrings.get(context, "ui_dex_preview_notice"));
    return result.toString();
  }

  private static long u32(byte[] bytes, int offset) {
    return (bytes[offset] & 255L)
        | ((bytes[offset + 1] & 255L) << 8)
        | ((bytes[offset + 2] & 255L) << 16)
        | ((bytes[offset + 3] & 255L) << 24);
  }

  private static String hex(long value) {
    return String.format(java.util.Locale.US, "0x%08X", value);
  }
}
