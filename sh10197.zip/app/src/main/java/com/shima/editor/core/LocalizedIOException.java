package com.shima.editor.core;

import java.io.IOException;

/** Resource-backed I/O failure; the UI resolves its message in the currently selected locale. */
public class LocalizedIOException extends IOException {
  private final String resourceKey;
  private final Object[] arguments;

  public LocalizedIOException(String resourceKey, Object... arguments) {
    this(resourceKey, null, arguments);
  }

  protected LocalizedIOException(String resourceKey, Throwable cause, Object[] arguments) {
    super(resourceKey, cause);
    this.resourceKey = resourceKey;
    this.arguments = arguments == null ? new Object[0] : arguments.clone();
  }

  public String resourceKey() {
    return resourceKey;
  }

  public Object[] arguments() {
    return arguments.clone();
  }
}
