package com.shima.performance;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.shima.editor.core.AtomicFileWriter;
import com.shima.editor.core.LocalizedIOException;

/**
 * One I/O boundary for the editor. All public asynchronous operations leave the main thread;
 * callers that use the blocking methods must already be on an I/O worker.
 */
public final class FileSystemRepository implements AutoCloseable {
  public interface ReadCallback {
    void completed(String reference, String text, Throwable error);
  }

  public interface WriteCallback {
    void completed(boolean success, Throwable error);
  }

  private final Context context;
  private final ContentResolver resolver;
  private final Handler main = new Handler(Looper.getMainLooper());
  private final ExecutorService io =
      Executors.newFixedThreadPool(
          2,
          runnable -> {
            Thread thread = new Thread(runnable, "shima-file-io");
            thread.setPriority(Thread.NORM_PRIORITY - 1);
            return thread;
          });
  private final FileContentCache cache = new FileContentCache(4 * 1024 * 1024);

  public FileSystemRepository(Context context) {
    this.context = context.getApplicationContext();
    resolver = this.context.getContentResolver();
  }

  public void readTextAsync(
      final String reference, final String displayName, final int maxBytes, final ReadCallback callback) {
    io.execute(
        () -> {
          String value = null;
          Throwable error = null;
          try {
            value = readTextBlocking(reference, displayName, maxBytes);
          } catch (Throwable failure) {
            error = failure;
          }
          final String result = value;
          final Throwable failure = error;
          main.post(() -> {
            if (callback != null) callback.completed(reference, result, failure);
          });
        });
  }

  /** Must be called from a worker thread, never from onDraw or the main thread. */
  public String readTextBlocking(String reference, String displayName, int maxBytes)
      throws IOException {
    if (reference == null || reference.trim().isEmpty()) throw new LocalizedIOException("ui_invalid_path");
    String cached = cache.get(reference);
    if (cached != null) return cached;
    InputStream input = openInput(reference);
    String text = EncodingManager.readUtf8(input, maxBytes);
    cache.put(reference, text);
    return text;
  }

  public void writeTextAsync(
      final String reference, final String content, final WriteCallback callback) {
    io.execute(
        () -> {
          boolean success = false;
          Throwable error = null;
          try {
            writeTextBlocking(reference, content);
            success = true;
          } catch (Throwable failure) {
            error = failure;
          }
          final boolean result = success;
          final Throwable failure = error;
          main.post(() -> {
            if (callback != null) callback.completed(result, failure);
          });
        });
  }

  /** Must be called from a worker thread. Writes are always UTF-8 and never append. */
  public void writeTextBlocking(String reference, String content) throws IOException {
    if (reference == null || reference.trim().isEmpty()) throw new LocalizedIOException("ui_invalid_path");
    OutputStream output = null;
    try {
      if (isContentUri(reference)) {
        output = resolver.openOutputStream(Uri.parse(reference), "wt");
      } else {
        // Local files use a temporary file plus replacement so a crash cannot leave a half-written
        // source file. SAF providers still use their transactional output stream below.
        AtomicFileWriter.write(new File(stripFileScheme(reference)), EncodingManager.encodeUtf8(content));
        cache.put(reference, content == null ? "" : content);
        return;
      }
      if (output == null) throw new LocalizedIOException("ui_provider_write_denied");
      output.write(EncodingManager.encodeUtf8(content));
      output.flush();
      cache.put(reference, content == null ? "" : content);
    } finally {
      if (output != null) output.close();
    }
  }

  public void invalidate(String reference) {
    cache.invalidate(reference);
  }

  public void clearCache() {
    cache.clear();
  }

  public static String referenceForFile(File file) {
    return file == null ? "" : file.getAbsolutePath();
  }

  public static String referenceForUri(Uri uri) {
    return uri == null ? "" : uri.toString();
  }

  private InputStream openInput(String reference) throws IOException {
    if (isContentUri(reference)) {
      InputStream input = resolver.openInputStream(Uri.parse(reference));
      if (input == null) throw new LocalizedIOException("ui_error_open_file");
      return input;
    }
    return new FileInputStream(new File(stripFileScheme(reference)));
  }

  private boolean isContentUri(String reference) {
    return reference.startsWith("content://");
  }

  private String stripFileScheme(String reference) {
    return reference.startsWith("file://") ? Uri.parse(reference).getPath() : reference;
  }

  @Override
  public void close() {
    io.shutdownNow();
  }
}
