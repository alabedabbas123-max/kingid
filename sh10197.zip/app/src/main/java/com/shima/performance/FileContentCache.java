package com.shima.performance;

import android.util.LruCache;

/** Thread-safe weighted LRU cache. The weight is UTF-16 bytes, not number of entries. */
public final class FileContentCache {
  private final LruCache<String, String> cache;

  public FileContentCache(int maxBytes) {
    final int budget = Math.max(64 * 1024, maxBytes);
    cache =
        new LruCache<String, String>(budget) {
          @Override
          protected int sizeOf(String key, String value) {
            if (value == null) return 0;
            long bytes = (long) value.length() * 2L;
            return (int) Math.min(Integer.MAX_VALUE, Math.max(1L, bytes));
          }
        };
  }

  public synchronized String get(String reference) {
    return reference == null ? null : cache.get(reference);
  }

  public synchronized void put(String reference, String content) {
    if (reference == null || content == null) return;
    // A single giant file must not evict the entire working set.
    if ((long) content.length() * 2L > cache.maxSize()) return;
    cache.put(reference, content);
  }

  public synchronized void invalidate(String reference) {
    if (reference != null) cache.remove(reference);
  }

  public synchronized void clear() {
    cache.evictAll();
  }

  public synchronized int sizeBytes() {
    return cache.size();
  }
}
