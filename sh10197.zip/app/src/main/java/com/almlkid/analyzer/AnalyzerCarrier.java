package com.almlkid.analyzer;

import almlk.AnalyzerProtocol;
import android.os.Bundle;
import android.os.Message;

/**
 * حِزمُ الحِملِ على رسالةٍ بينَ العمليّاتِ وفكُّهُ (عطلُ ‏1.0.177 على الجهازِ؛ الفصلُ في ورقةِ ‏W27/1).
 *
 * <p>القاعدةُ واحدةٌ للطرفَينِ: ما يَسكُنُ {@code Message.obj} لا يكونُ إلّا {@code Parcelable} أو {@code
 * null} — ومن‏ Android 13 فصاعدًا يَرمِي {@code Message#writeToParcel} على ما سواهُ {@code
 * RuntimeException: Can't marshal non-Parcelable objects across processes.} قبلَ أن تُغادِرَ الرسالةُ
 * العمليةَ. والحِملُ عندَنا سلسلةٌ من طبقةٍ صافيةٍ ({@code almlk.AnalyzerProtocol})، فصارَ مَوضِعُها {@code
 * Message.data}: حزمةُ مفاتيحَ مُجرَّأةٌ بطبعِها، تَحمِلُ سطرًا واحدًا مُهرَّبًا. سياسةُ القناةِ مُعلَنةٌ عندَ
 * {@link AnalyzerProtocol#carrierFor(Object)} لا هنا، فتُختَبَرُ على المضيفِ حيثُ لا ‏android.
 *
 * <p>ولا يَكتَفي الحاملُ بالوضعِ في {@code data}: {@link #payload(Message)} يَقرَأُ {@code obj} أيضًا
 * احتياطًا — عمليةُ تحليلٍ قديمةٌ ظلَّتْ حيّةً لحظةَ التحديثِ ترسِلُ كما كانتْ، والمُرسِلُ الجديدُ لا يَفقِدُ
 * جوابَها. {@link #sendable(Message)} هو الحارسُ الأخيرُ قبلَ {@code Messenger#send}: إن انزلَقَ يومًا
 * حِملٌ إلى {@code obj} رُفِضَ الإرسالُ في السجلِّ، لا في خيطِ الواجهةِ.
 */
public final class AnalyzerCarrier {

  private AnalyzerCarrier() {}

  /** يَحمِلُ الحِملَ في {@code data} ويَدَعُ {@code obj} فارغًا. */
  public static void attach(Message msg, String wire) {
    if (msg == null) return;
    Bundle data = new Bundle();
    data.putString(AnalyzerProtocol.KEY_WIRE, wire == null ? "" : wire);
    msg.setData(data);
    msg.obj = null;
  }

  /** رسالةُ ما+حِملٌ؛ ما يُستَعمَلُ في الاتجاهَينِ فلا يَنفَلِتُ قناةٌ منَ القاعدةِ. */
  public static Message obtain(int what, String wire) {
    Message msg = Message.obtain(null, what);
    attach(msg, wire);
    return msg;
  }

  /** الحِملُ كما وُضِعَ: من {@code data} أولًا، ومن {@code obj} احتياطًا؛ والفراغُ سلسلةٌ فارغةٌ لا {@code null}. */
  public static String payload(Message msg) {
    if (msg == null) return "";
    Bundle data = msg.getData();
    if (data != null && data.containsKey(AnalyzerProtocol.KEY_WIRE)) {
      String value = data.getString(AnalyzerProtocol.KEY_WIRE);
      if (value != null) return value;
    }
    Object legacy = msg.obj;
    return legacy instanceof String ? (String) legacy : "";
  }

  /** ما يجوزُ إرسالُهُ: لا قيمةَ في {@code obj} غيرَ قابلةٍ للتجزئةِ. */
  public static boolean sendable(Message msg) {
    return msg == null || AnalyzerProtocol.allowedInMessageObj(msg.obj);
  }
}
