package com.almlkid.analyzer;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import almlk.AnalyzerProtocol;
import com.almlkid.kay.ui.CodeLanguageTools;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * عمليةُ التحليلِ المنفصلةُ (المرحلةُ ١ من عزلِ المُحرِّكِ، ‏W23): ما كانَ المحرِّرُ يَفحصُهُ في خيطٍ خلفيٍّ
 * داخلَ عمليةِ الواجهةِ صارَ هنا، فتَخرُجُ من حسابِ الواجهةِ القراءةَ والتحليلَ والاستنتاجَ، ويَخرُجُ معها
 * احتمالُ {@code OutOfMemory} الذي كانَ يَقتلُ التطبيقَ كلَّهُ.
 *
 * <p>البنيةُ مأخوذةٌ من دراسةِ المرجعِ (ورقةُ الدراسةِ ‏W23، البنودُ ‏1 و‏2 و‏3)، وأسلوبُنا الصافيُ فيها:
 *
 * <ul>
 *   <li>{@code android:process=":analyzer"} مع {@code exported=false} — كما عندَهم {@code :EngineService}؛ ولا
 *       إشعارَ ولا {@code foregroundServiceType}: جلسةُ تحليلٍ مرتبطةٌ بمحرِّرٍ حيٍّ لا تحتاجُ بقاءً بلا واجهةٍ.
 *   <li><b>قناةٌ واحدةٌ {@code Messenger}</b>: المرجعُ {@code AIDL} بـ‏59 رمزَ معاملةٍ؛ عندَنا رمزٌ في
 *       {@code what} وحِملٌ سِلكيٌّ في {@code data} — لا في {@code obj}، لأنَّ السلسلةَ ليست {@code Parcelable}
 *       فتَرفُضُها {@code Message#writeToParcel} منذُ Android 13؛ والحِملُ سلسلةٌ من طبقةٍ صافيةٍ مُختبَرةٍ لا
 *       {@code Parcel} مُولَّدًا. القناةُ كلُّها في {@link AnalyzerCarrier}.
 *   <li><b>خيطُ عملٍ واحدٌ بمكدَّسٍ واسعٍ</b> (‏4 ميجابايتٍ): المُحلِّلُ يَنحدُّ داخلَ تراكيبَ متداخلةٍ، وخيطٌ
 *       واحدٌ يعني أنَّ التحليلاتِ لا تتراكمُ (نفسُ سببِ {@code newSingleThreadExecutor} في المحرِّرِ سابقًا).
 *   <li><b>لا انهيارَ يُعدي الواجهةَ</b>: كلُّ إرسالٍ داخلَ ‏{@code try/catch}، وكلُّ تحليلٍ مُلفوفٌ؛ وعندَ ضغطِ
 *       الذاكرةِ تُعلَنِ {@code memory_pressure} وتُخلَى الجلساتُ — ولا نَقتلُ أنفسَنا كما يفعلُ {@code
 *       abcd.C0068d} لأنَّ عملَنا يُستَأنَفُ بلا إعادةِ تحميلِ نواةٍ أصليّةٍ.
 * </ul>
 *
 * <p>الجلسةُ مفتاحُها اسمُ الملفِّ: يصلُ رأسُ الطلبِ {@code CODE_BEGIN} بحجمِهِ وعددِ قِطَعِهِ، فالقِطَعُ،
 * ثمَّ {@code CODE_END} وعندَهُ فقط يُنفَّذُ العملُ — فلا تحليلَ لنصفِ ملفٍّ ولا سباقَ بينَ قِطَعِ طلبينِ.
 * ولا صلاحيةَ للردِّ تُقرَّرُ هنا: الواجهةُ تَعرِفُ جيلَها الحاليَّ، فتردُّ ما بَطلَ ({@code stale}) بصمتٍ محسوبٍ.
 */
public final class AnalyzerService extends Service {

  /** أقصى عددُ جلساتٍ مُتزامنةٍ (محرِّرٌ حيٌّ = جلسةٌ؛ ما زادَ يُرفَضُ أقدمُها لا أحدثُها). */
  private static final int MAX_SESSIONS = 8;

  private static final String TAG = "AlmlkAnalyzer";

  /** حالةُ ملفٍّ واحدٍ بينَ رأسِ الطلبِ وتنفيذِهِ. */
  private static final class Session {
    final String file;
    final StringBuilder text = new StringBuilder();
    long generation;
    int expectedParts;
    int receivedParts;
    int totalChars;
    Messenger replyTo;

    Session(String file) {
      this.file = file;
    }
  }

  private final Map<String, Session> sessions = new LinkedHashMap<>(MAX_SESSIONS, 0.75f, true);
  private final Handler main = new Handler(Looper.getMainLooper());
  private final Messenger messenger = new Messenger(new Inbound(main));
  private Messenger replyTarget;
  /** يُعادُ إنشاؤهُ إن أُغلِقَ (كما يعيدُ المحرِّرُ عاملَهُ بعدَ انفصالٍ): لا موتٌ دائمٌ للتحليلِ. */
  private ExecutorService worker = newWorker();

  private static ExecutorService newWorker() {
    return Executors.newSingleThreadExecutor(
        task -> {
          Thread thread = new Thread(null, task, "almlk-analyzer", 4L << 20);
          thread.setDaemon(true);
          return thread;
        });
  }

  @Override
  public IBinder onBind(Intent intent) {
    return messenger.getBinder();
  }

  @Override
  public void onDestroy() {
    synchronized (sessions) {
      sessions.clear();
    }
    replyTarget = null;
    worker.shutdownNow();
    try {
      worker.awaitTermination(400L, TimeUnit.MILLISECONDS);
    } catch (InterruptedException interrupted) {
      Thread.currentThread().interrupt();
    }
    super.onDestroy();
  }

  /** ضغطُ ذاكرةٍ: تُخلَى الجلساتُ وتُعلَنِ الحالةُ، فلا تُترَكُ الواجهةُ تَنتظِرُ ردًّا لن يأتيَ. */
  @Override
  public void onTrimMemory(int level) {
    super.onTrimMemory(level);
    int released;
    synchronized (sessions) {
      released = sessions.size();
      sessions.clear();
    }
    if (released == 0) return;
    send(AnalyzerProtocol.CODE_STATE, AnalyzerProtocol.encodeState(
        AnalyzerProtocol.STATE_MEMORY_PRESSURE, "trim level " + level + ", sessions released: " + released));
    Log.w(TAG, "memory pressure: " + released + " session(s) released");
  }

  // ─────────────────────────── الواردُ ───────────────────────────

  /** يستقبِلُ على خيطِ العمليةِ الرئيسيِّ: لا عملَ هنا إلَّا التجميعُ والتسليمُ للعاملِ. */
  private final class Inbound extends Handler {
    Inbound(Handler source) {
      super(source.getLooper());
    }

    @Override
    public void handleMessage(Message msg) {
      try {
        if (msg.replyTo != null) replyTarget = msg.replyTo;
        switch (msg.what) {
          case AnalyzerProtocol.CODE_PING:
            send(AnalyzerProtocol.CODE_STATE,
                AnalyzerProtocol.encodeState(AnalyzerProtocol.STATE_OK, "alive"));
            return;
          case AnalyzerProtocol.CODE_BEGIN:
            begin(AnalyzerCarrier.payload(msg), msg.replyTo);
            return;
          case AnalyzerProtocol.CODE_PART:
            part(AnalyzerCarrier.payload(msg));
            return;
          case AnalyzerProtocol.CODE_END:
            end(AnalyzerCarrier.payload(msg));
            return;
          case AnalyzerProtocol.CODE_CANCEL:
            cancel(AnalyzerCarrier.payload(msg));
            return;
          default:
            send(AnalyzerProtocol.CODE_STATE, AnalyzerProtocol.encodeState(
                AnalyzerProtocol.STATE_REFUSED, "unknown code " + msg.what));
        }
      } catch (RuntimeException unexpected) {
        // لا يَقتلُ الانحرافُ عمليةَ التحليلِ: الواجهةُ تستحقُّ حالةً مُسمّاةً لا صمتًا.
        Log.w(TAG, "inbound failed", unexpected);
        send(AnalyzerProtocol.CODE_STATE,
            AnalyzerProtocol.encodeState(AnalyzerProtocol.STATE_REFUSED, String.valueOf(unexpected)));
      }
    }
  }

  private void begin(String wire, Messenger replyTo) {
    AnalyzerProtocol.Request head = AnalyzerProtocol.decodeRequest(wire);
    if (head == null || head.file.isEmpty()) {
      send(AnalyzerProtocol.CODE_STATE,
          AnalyzerProtocol.encodeState(AnalyzerProtocol.STATE_REFUSED, "malformed request"));
      return;
    }
    if (!AnalyzerProtocol.acceptsRequest(head.totalChars)) {
      send(AnalyzerProtocol.CODE_STATE, AnalyzerProtocol.encodeState(
          AnalyzerProtocol.STATE_TOO_LARGE, head.totalChars + " > " + AnalyzerProtocol.MAX_REQUEST_CHARS));
      return;
    }
    synchronized (sessions) {
      while (sessions.size() >= MAX_SESSIONS) {
        Iterator<String> keys = sessions.keySet().iterator();
        if (!keys.hasNext()) break;
        String eldest = keys.next();
        keys.remove();
        send(AnalyzerProtocol.CODE_STATE,
            AnalyzerProtocol.encodeState(AnalyzerProtocol.STATE_REFUSED, "session evicted: " + eldest));
      }
      Session session = sessions.get(head.file);
      if (session == null) sessions.put(head.file, session = new Session(head.file));
      session.text.setLength(0);
      session.generation = head.generation;
      session.expectedParts = head.partCount;
      session.receivedParts = 0;
      session.totalChars = head.totalChars;
      session.replyTo = replyTo;
    }
  }

  private void part(String wire) {
    AnalyzerProtocol.Part chunk = AnalyzerProtocol.decodePart(wire);
    if (chunk == null || chunk.file.isEmpty()) return;
    synchronized (sessions) {
      Session session = sessions.get(chunk.file);
      if (session == null || session.generation != chunk.generation) return;
      if (session.text.length() + chunk.text.length() > AnalyzerProtocol.MAX_REQUEST_CHARS) {
        sessions.remove(session.file);
        send(AnalyzerProtocol.CODE_STATE, AnalyzerProtocol.encodeState(
            AnalyzerProtocol.STATE_TOO_LARGE, "stream exceeded " + AnalyzerProtocol.MAX_REQUEST_CHARS));
        return;
      }
      session.text.append(chunk.text);
      session.receivedParts++;
    }
  }

  private void end(String wire) {
    AnalyzerProtocol.Request head = AnalyzerProtocol.decodeRequest(wire);
    if (head == null) return;
    final String file;
    final String text;
    final long generation;
    final Messenger replyTo;
    int received;
    int expected;
    synchronized (sessions) {
      Session session = sessions.remove(head.file);
      if (session == null || session.generation != head.generation) return;
      file = session.file;
      text = session.text.toString();
      generation = session.generation;
      replyTo = session.replyTo == null ? replyTarget : session.replyTo;
      received = session.receivedParts;
      expected = session.expectedParts;
    }
    if (received != expected) {
      send(AnalyzerProtocol.CODE_STATE, AnalyzerProtocol.encodeState(
          AnalyzerProtocol.STATE_REFUSED, "parts " + received + " of " + expected));
      return;
    }
    if (worker.isShutdown()) worker = newWorker();
    try {
      worker.execute(
          () -> {
            AnalyzerProtocol.Reply reply = analyze(generation, file, text);
            Message out = AnalyzerCarrier.obtain(
                AnalyzerProtocol.CODE_RESULT, AnalyzerProtocol.encode(reply));
            main.post(() -> deliver(replyTo, out, generation));
          });
    } catch (RejectedExecutionException busy) {
      send(AnalyzerProtocol.CODE_STATE,
          AnalyzerProtocol.encodeState(AnalyzerProtocol.STATE_REFUSED, "worker stopped"));
    }
  }

  /** إلغاءُ ملفٍّ: يُخلِي ما جُمِعَ لهُ فقط؛ والردُّ اللاحقُ تَردُّهُ الواجهةُ بوصفِهِ بائتًا. */
  private void cancel(String wire) {
    AnalyzerProtocol.Request head = AnalyzerProtocol.decodeRequest(wire);
    if (head == null || head.file.isEmpty()) return;
    synchronized (sessions) {
      Session session = sessions.get(head.file);
      if (session != null && session.generation == head.generation) sessions.remove(head.file);
    }
  }

  // ─────────────────────────── العملُ والردُّ ───────────────────────────

  /**
   * التحليلُ نفسُهُ الذي كانَ على خيطِ المحرِّرِ الخلفيِّ: {@code CodeLanguageTools.inspect} وحدهُ، بلا لمسِ
   * حالةِ واجهةٍ — والفهرسُ لا يُعدَّلُ هنا: ما يَقرَأُهُ الفاحصُ من مُعرِّفاتٍ حيّةٍ يُرسَلُ معَ الردِّ
   * ليُطبَّقَ في عمليةِ الواجهةِ حيثُ يسكُنُ الفهرسُ (بوصلةٌ واحدةٌ لا نسختانِ تتباعدانِ).
   */
  private AnalyzerProtocol.Reply analyze(long generation, String file, String text) {
    AnalyzerProtocol.Builder builder = new AnalyzerProtocol.Builder(generation, file);
    try {
      // الترتيبُ كما كانَ على خيطِ الفحصِ: تُقرَأُ المُعرِّفاتُ الحيّةُ أولًا ثمَّ يُفحَصُ، فلا تسبقُ
      // دورةُ إبلاغٍ نتيجةَ الفحصِ نفسِها (فارقُ التوقيتِ هنا صفرٌ، لكنَّ الحدَّ مُعلَنٌ لا مُستَنتَجٌ).
      AnalyzerProtocol.Members members = ProjectSymbolIndex.liveMembersOf(file, text);
      List<CodeLanguageTools.Diagnostic> found = CodeLanguageTools.inspect(file, text);
      // W23/2: التوسيعُ هنا لا في المُحرِّرِ — النصُّ الكاملُ الطازجُ عندَنا وحدَنا، والمُحرِّرُ يَرسُمُ ما يَصلُهُ.
      for (AnalyzerProtocol.Finding finding : AnalyzerWire.withOccurrences(text, AnalyzerWire.encode(found))) {
        builder.add(finding);
      }
      builder.members(members);
    } catch (Throwable failure) {
      // لا نصفُ نتيجةٍ ولا تعليقُ الواجهةِ: حالةٌ مُسمّاةٌ وسِجلٌّ، ثمَّ ردٌّ بلا تشخيصٍ.
      Log.w(TAG, "analyze failed for " + file, failure);
      builder.state(AnalyzerProtocol.STATE_REFUSED);
      builder.members(AnalyzerProtocol.Members.empty());
    }
    return builder.build();
  }

  private void deliver(Messenger target, Message out, long generation) {
    if (target == null) return;
    if (!AnalyzerCarrier.sendable(out)) {
      Log.w(TAG, "reply refused: " + AnalyzerProtocol.explainCarrier(out.obj));
      return;
    }
    try {
      target.send(out);
    } catch (RemoteException gone) {
      Log.w(TAG, "reply lost (generation " + generation + "): client gone");
    } catch (IllegalStateException overflowed) {
      // سقفُ النقلِ: تُعلَنِ الحالةُ بدلَ رميِ الاستثناءِ في خيطٍ آخرَ.
      Log.w(TAG, "reply too large (generation " + generation + ")", overflowed);
      send(AnalyzerProtocol.CODE_STATE, AnalyzerProtocol.encodeState(
          AnalyzerProtocol.STATE_TOO_LARGE, "reply exceeds the binder budget"));
    } catch (RuntimeException unmashalled) {
      // السلسلةُ نفسُها التي كانتْ تُسقِطُ الواجهةَ: هنا خيطُ التحليلِ، فلا يَخرُجُ الانهيارُ من العمليةِ.
      Log.w(TAG, "reply unmashalable (generation " + generation + ")", unmashalled);
    }
  }

  private void send(int what, String wire) {
    final Messenger target = replyTarget;
    if (target == null) return;
    final Message out = AnalyzerCarrier.obtain(what, wire);
    if (Looper.myLooper() == main.getLooper()) {
      try {
        target.send(out);
      } catch (RemoteException | RuntimeException ignored) {
        // حالةٌ ضاعت: لا تُعادُ على حسابِ خيطٍ غيرِ خيطِ الردودِ، ولا يَخرُجُ منها عطلُ نقلٍ.
      }
      return;
    }
    main.post(
        () -> {
          try {
            target.send(out);
          } catch (RemoteException | RuntimeException ignored) {
          }
        });
  }

  /** عددُ الجلساتِ الحيّةِ — للقياسِ في الاختبارِ وعلى شاشةِ السجلِّ. */
  public int sessionCount() {
    synchronized (sessions) {
      return sessions.size();
    }
  }

  /** أسماءُ الجلساتِ المُفتوحةِ (مُقيَّدةٌ بعددِها): تُطبعُ عندَ التشخيصِ عن بُعدٍ. */
  public List<String> sessionFiles() {
    synchronized (sessions) {
      return new ArrayList<>(sessions.keySet());
    }
  }
}
