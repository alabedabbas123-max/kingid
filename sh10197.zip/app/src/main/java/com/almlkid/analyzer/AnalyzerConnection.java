package com.almlkid.analyzer;

import almlk.AnalyzerProtocol;
import almlk.AnalyzerQueue;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import com.almlkid.kay.ui.CodeLanguageTools;
import java.util.List;

/**
 * جسرُ المحرِّرِ إلى عمليةِ التحليلِ (المرحلةُ ١ من عزلِ المُحرِّكِ، ‏W23): نسخةٌ لكلِّ محرِّرٍ حيٍّ، تحملُ
 * طابورَها وجيلَها، وتُغني عن خيطِ {@code diagnosticsWorker} الذي كانَ يعملُ داخلَ عمليةِ الواجهةِ.
 *
 * <p>قواعدُ المرجعِ مأخوذةٌ بحذافيرِها، واثنتانِ مُستبدَلتانِ بما هو أصلحُ لسياقِنا:
 *
 * <ul>
 *   <li><b>طابورٌ معلَّقٌ يُصرَّفُ عندَ الاتصالِ</b> — كما في {@code ServiceConnectionC0053S}: {@code while
 *       (!queue.isEmpty()) queue.poll().run();}، وعندَنا {@code for (Job job : queue.noteBound()) send(job);}.
 *   <li><b>تصفيرُ الوكيلِ عندَ القطعِ</b> — {@code X.j6(this, null)} هناك؛ وهنا {@code service = null} مع
 *       {@code noteUnbound()} فيرتفعُ العصرُ ويبطُلُ كلُّ ما كانَ في الطريقِ.
 *   <li><b>الإرسالُ بلا وكيلٍ عندَنا لا يُسقَطُ</b> — المرجعُ يكتفي بـ{@code if (proxy == null) return;} فتضيعُ
 *       طلبياتُ ما قبلَ إعادةِ الربطِ؛ عندَنا يبقى الطلبُ في الطابورِ ويَخرُجُ متى عادَتِ العمليةُ (بندُ
 *       «الطلباتُ لا تُسقَطُ بلا وكيلٍ» في ورقةِ الدراسةِ).
 *   <li><b>الفحصُ لا البناءَ</b>: ما يُرسَلُ نصُّ الملفِّ وحدَهُ، وما يعودُ تشخيصاتٌ بمفاتيحِها وإصلاحاتُها
 *       ومُعرِّفاتٌ حيّةٌ؛ ولا شيءُ في الاتجاهينِ يَلمُسُ مؤشرًا أو منظرًا أو ملفًّا على القرصِ.
 * </ul>
 *
 * <p>الإرسالُ على خيطِ الواجهةِ (عمليةُ {@code Messenger} نصُّها)، والقبضُ على خيطِ التحليلِ؛ ولا {@code wait}
 * ولا {@code sleep} هنا: مَن أرادَ نتيجةً انتظرَ ردَّها، وإن لم يَرجِعْ جاءَت حالةٌ مُسمّاةٌ.
 */
public final class AnalyzerConnection {

  private static final String TAG = "AlmlkAnalyzer";

  /** ما يَفعَلُهُ المحرِّرُ عندَ وصولِ نتيجةٍ أو إعلانِ حالةٍ. */
  public interface Sink {
    /** نتيجةٌ صالحةٌ لملفٍّ: تُطبَّقُ كما كانَ يُطبَّقُ ردُّ الخيطِ الخلفيِّ السابقِ. */
    void applied(
        String file,
        List<CodeLanguageTools.Diagnostic> found,
        AnalyzerProtocol.Members members,
        AnalyzerProtocol.Reply reply);

    /** حالةٌ من العمليةِ الأخرى أو من القناةِ: سطرُ سجلٍّ، لا نافذةَ ولا انتظَارَ. */
    default void state(String state, String detail) {}
  }

  private final AnalyzerQueue queue = new AnalyzerQueue();
  private final Handler main = new Handler(Looper.getMainLooper());
  private final Sink sink;
  private final Messenger replies = new Messenger(new Handler(main.getLooper()) {
    @Override
    public void handleMessage(Message msg) {
      onReply(msg);
    }
  });
  private Context appContext;
  private volatile Messenger service;
  private boolean binding;
  private AnalyzerQueue.Job inFlight;

  public AnalyzerConnection(Sink sink) {
    this.sink = sink;
  }

  /** طابورُ هذه الجلسةِ: للاختبارِ والقياسِ لا للتعديةِ على المحرِّرِ. */
  public AnalyzerQueue queue() {
    return queue;
  }

  /** هل هناك طلبٌ في الطريقِ؟ يَقرَرُ إعادةَ الجدولةِ عندَ الحركةِ، فلا تُكرَّرُ القراءةُ من القرصِ. */
  public boolean isBusy() {
    synchronized (this) {
      return queue.isBusy();
    }
  }

  // ─────────────────────────── الربطُ والقطعُ ───────────────────────────

  /** يُنادى عندَ اتصالِ المحرِّرِ بالنافذةِ: ارتباطٌ واحدٌ لكلِّ جلسةٍ، ولا يُكرَّرُ إن كانَ قائمًا. */
  public synchronized void attach(Context context) {
    if (context == null || appContext != null) return;
    appContext = context.getApplicationContext();
    bindLocked();
  }

  /** يُنادى عندَ انفصالِ المحرِّرِ: يُلغى الجاريُ، ويفصُلُ الارتباطُ، ويُمحَصُ الطابورُ. */
  public synchronized void detach() {
    if (appContext == null) return;
    AnalyzerQueue.Job flight = inFlight;
    inFlight = null;
    if (flight != null) {
      sendLocked(AnalyzerProtocol.CODE_CANCEL,
          AnalyzerProtocol.encodeRequest(new AnalyzerProtocol.Request(flight.generation, flight.file, 0, 0)));
    }
    // ما تَرَكَهُ المحرِّرُ من أعمالٍ لا تُنسَبُ إلى لا أحدٍ: سطرٌ بالعددِ قبلَ المَحصِ (الطابورُ يُمحَصُ
    // لأنَّ لا أحدَ بعدَ اليومِ يَقرَأُ نتائجَهُ، لا لأنَّ العملَ كانَ قليلًا).
    if (queue.size() > 0 || queue.droppedCount() > 0) {
      Log.i(TAG, "detach with queued: " + queue.size() + ", dropped: " + queue.droppedCount());
    }
    queue.clear();
    try {
      appContext.unbindService(connection);
    } catch (RuntimeException wasNotBound) {
      Log.w(TAG, "unbind on detach: " + wasNotBound);
    }
    service = null;
    binding = false;
    appContext = null;
  }

  private void bindLocked() {
    if (appContext == null || binding || service != null) return;
    binding = true;
    boolean accepted;
    try {
      accepted = appContext.bindService(new Intent(appContext, AnalyzerService.class), connection,
          Context.BIND_AUTO_CREATE);
    } catch (RuntimeException refused) {
      binding = false;
      // الرفضُ حالةٌ لا كارثةٌ: الطلبُ باقٍ في الطابورِ، وأولُ اتصالٍ لاحقٍ يَصرِفُهُ.
      note(AnalyzerProtocol.STATE_REFUSED, String.valueOf(refused.getMessage()));
      return;
    }
    if (!accepted) note(AnalyzerProtocol.STATE_NOT_BOUND, "bindService returned false");
  }

  private final ServiceConnection connection = new ServiceConnection() {
    @Override
    public void onServiceConnected(ComponentName name, IBinder binder) {
      main.post(
          () -> {
            synchronized (AnalyzerConnection.this) {
              binding = false;
              service = new Messenger(binder);
              // عصرٌ جديدٌ يُبطِلُ ما كانَ في الطريقِ، ثمَّ تصريفُ الطابورِ بترتيبِهِ عبرَ {@code ready()}:
              // مسارٌ واحدٌ للإرسالِ، فلا يُقفَزُ على سقفِ «طلبٌ جارٍ واحدٌ» عندَ إعادةِ الربطِ.
              queue.noteBound();
              pumpLocked();
            }
          });
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
      main.post(
          () -> {
            synchronized (AnalyzerConnection.this) {
              service = null;
              binding = false;
              inFlight = null;
              queue.noteUnbound();
              note(AnalyzerProtocol.STATE_PROCESS_DIED, "analyzer process disconnected");
              // إعادةُ الربطِ فورًا إن بقيَتِ الجلسةُ حيّةً: الطلبُ المُعلَّقُ لا ينتظرُ حركةَ مُستخدِمٍ.
              if (appContext != null) bindLocked();
            }
          });
    }
  };

  // ─────────────────────────── الطلبُ ───────────────────────────

  /**
   * يَطلُبُ فحصَ لقطةٍ من ملفٍّ: يُدمَجُ معَ آخرِ لقطةٍ لنفسِ الملفِّ في الطابورِ، ثمَّ يُرسَلُ إن فرغَ
   * الطريقُ. ما لم يُرسَلْ لا يضيعُ: يأتيهِ دورهُ عندَ الاتصالِ أو عندَ فراغِ العاملِ.
   */
  public synchronized void request(String file, String text) {
    if (file == null || file.isEmpty() || appContext == null) return;
    if (service == null && !binding) bindLocked();
    int length = text == null ? 0 : text.length();
    if (!AnalyzerProtocol.acceptsRequest(length)) {
      note(AnalyzerProtocol.STATE_TOO_LARGE, length + " chars");
      return;
    }
    queue.submit(file, text);
    pumpLocked();
  }

  private void pumpLocked() {
    AnalyzerQueue.Job next = queue.ready();
    if (next != null) sendLocked(next);
  }

  /** رأسُ الطلبِ فقِطَعُهُ فنهایتَهُ؛ وأيُّ عطلٍ في النقلِ يعيدُ الطلبَ إلى الطابورِ لا إلى النسيانِ. */
  private void sendLocked(AnalyzerQueue.Job job) {
    if (job == null) return;
    String[] chunks = AnalyzerProtocol.splitChunks(job.text);
    if (chunks.length == 0) chunks = new String[] {""};
    String head = AnalyzerProtocol.encodeRequest(
        new AnalyzerProtocol.Request(job.generation, job.file, job.totalChars, chunks.length));
    queue.noteSent(job);
    inFlight = job;
    if (!sendLocked(AnalyzerProtocol.CODE_BEGIN, head)) {
      queue.requeue(job);
      return;
    }
    for (int i = 0; i < chunks.length; i++) {
      String part =
          AnalyzerProtocol.encodePart(new AnalyzerProtocol.Part(job.generation, i, job.file, chunks[i]));
      if (!sendLocked(AnalyzerProtocol.CODE_PART, part)) {
        queue.requeue(job);
        return;
      }
    }
    if (!sendLocked(AnalyzerProtocol.CODE_END, head)) {
      queue.requeue(job);
      return;
    }
  }

  private boolean sendLocked(int what, String wire) {
    Messenger target = service;
    if (target == null) return false;
    // الحِملُ في {@code data} لا في {@code obj} — قاعدةُ Android 13+؛ والشرحُ في AnalyzerCarrier.
    Message out = AnalyzerCarrier.obtain(what, wire);
    out.replyTo = replies;
    if (!AnalyzerCarrier.sendable(out)) {
      note(AnalyzerProtocol.STATE_REFUSED, AnalyzerProtocol.explainCarrier(out.obj));
      return false;
    }
    try {
      target.send(out);
      return true;
    } catch (RemoteException gone) {
      service = null;
      inFlight = null;
      queue.noteUnbound();
      note(AnalyzerProtocol.STATE_PROCESS_DIED, "send failed: " + gone);
      if (appContext != null) bindLocked();
      return false;
    } catch (IllegalStateException overflowed) {
      note(AnalyzerProtocol.STATE_TOO_LARGE, String.valueOf(overflowed.getMessage()));
      return false;
    } catch (RuntimeException unmashalled) {
      // «Can't marshal non-Parcelable objects across processes» كانَ يَخرُجُ من هنا إلى خيطِ الواجهةِ
      // فيُقعِدُ التطبيقَ كلَّهُ. الآنَ حالةٌ مُسمّاةٌ، والطلبُ يعودُ إلى الطابورِ كما يعودُ عندَ موتِ العمليةِ.
      note(AnalyzerProtocol.stateForSendFailure(unmashalled),
          AnalyzerProtocol.explainCarrier(out.obj) + " / " + unmashalled);
      return false;
    }
  }

  // ─────────────────────────── الردُّ ───────────────────────────

  /** على خيطِ الواجهةِ: فكُّ الحِملِ، ثمَّ قياسُ الجيلِ، ثمَّ تسليمُ ما صلُحَ للمحرِّرِ، فطلبُ الدورِ التاليِ. */
  private void onReply(Message msg) {
    String wire = AnalyzerCarrier.payload(msg);
    if (msg.what == AnalyzerProtocol.CODE_STATE) {
      String[] fields = AnalyzerProtocol.stateFields(wire);
      note(fields[0], fields[1]);
      return;
    }
    if (msg.what != AnalyzerProtocol.CODE_RESULT) return;
    AnalyzerProtocol.Reply reply = AnalyzerProtocol.decode(wire);
    if (reply == null) {
      note(AnalyzerProtocol.STATE_REFUSED, "malformed reply");
      return;
    }
    AnalyzerQueue.Job flight;
    boolean usable;
    synchronized (this) {
      flight = inFlight;
      // الطلبُ الجاري يُغلَقُ في الطابورِ أولًا: لا حالةُ انتظارٍ تُترَكُ معلَّقةً على أيِّ مسارٍ.
      
      usable = queue.answers(reply.generation, reply.file);
      if (flight == null) {
        // لا طلبَ في الطريقِ: لا شيءَ يُطبَّقُ ولا يُنسَبُ إلى أحدٍ — الحالةُ تُسجَّلُ فقط.
        note(AnalyzerProtocol.STATE_STALE, "reply without a request: " + reply.file);
        return;
      }
      if (!usable) {
        queue.noteStale();
        inFlight = null;
        note(AnalyzerProtocol.STATE_STALE, "generation " + reply.generation + " for " + reply.file);
      }
    }
    if (!usable) {
      pump();
      return;
    }
    List<CodeLanguageTools.Diagnostic> found = AnalyzerWire.decode(reply.findings);
    queue.noteApplied(flight);
    inFlight = null;
    if (sink != null) sink.applied(reply.file, found, reply.members, reply);
    if (sink != null && (!reply.state.equals(AnalyzerProtocol.STATE_OK) || reply.isTruncated())) {
      // السقفُ المُعلَنُ في الردِّ نفسِهِ يُبلَّغُ كما تُبلَّغُ حالةُ القناةِ: عددٌ لا نصٌّ مكرَّرٌ في الواجهةِ.
      sink.state(reply.state,
          "findings: " + reply.findings.length + (reply.isTruncated() ? ", dropped: " + reply.dropped : "")
              + (reply.problems.isEmpty() ? "" : ", " + reply.problems.get(0)));
    }
    pump();
  }

  private void pump() {
    synchronized (this) {
      pumpLocked();
    }
  }

  private void note(String state, String detail) {
    if (sink != null) sink.state(state, detail);
    Log.i(TAG, state + (detail == null || detail.isEmpty() ? "" : ": " + detail));
  }
}
