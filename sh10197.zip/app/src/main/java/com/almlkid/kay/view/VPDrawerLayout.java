package com.almlkid.kay.view;

import android.content.Context;
import androidx.drawerlayout.widget.DrawerLayout;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;

/**
 * Drawer implementation used by the original main_drawer.xml. The original resource declares the
 * browser pane match_parent; the proprietary widget reserved a 60dp dark strip. This replacement
 * preserves that behavior.
 */
public class VPDrawerLayout extends DrawerLayout {
  public VPDrawerLayout(Context c) {
    super(c);
  }

  public VPDrawerLayout(Context c, AttributeSet a) {
    super(c, a);
  }

  public VPDrawerLayout(Context c, AttributeSet a, int s) {
    super(c, a, s);
  }

  @Override
  protected void onMeasure(int widthSpec, int heightSpec) {
    int width = MeasureSpec.getSize(widthSpec);
    if (getChildCount() > 1) {
      View drawer = getChildAt(1);
      ViewGroup.LayoutParams p = drawer.getLayoutParams();
      int target = Math.max(1, width - dp(60));
      if (p.width != target) {
        p.width = target;
        drawer.setLayoutParams(p);
      }
    }
    super.onMeasure(widthSpec, heightSpec);
  }

  public interface HorizontalSwipeListener {
    /** Called for a left swipe while the file drawer is already open. */
    void onDrawerSwipeLeft();

    /**
     * Called for a right swipe. Returning false leaves the gesture to DrawerLayout, which closes
     * the drawer when the user is already on the first page.
     */
    default boolean onDrawerSwipeRight() {
      return false;
    }
  }

  private HorizontalSwipeListener horizontalSwipeListener;
  private float downX, downY;
  private boolean leftSwipeConsumed;
  private final int touchSlop;

  {
    touchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
  }

  public void setHorizontalSwipeListener(HorizontalSwipeListener listener) {
    horizontalSwipeListener = listener;
  }

  @Override
  public boolean onInterceptTouchEvent(MotionEvent event) {
    if (event == null) return super.onInterceptTouchEvent(event);
    switch (event.getActionMasked()) {
      case MotionEvent.ACTION_DOWN:
        downX = event.getX();
        downY = event.getY();
        leftSwipeConsumed = false;
        break;
      case MotionEvent.ACTION_MOVE:
        if (!leftSwipeConsumed && isDrawerOpen(Gravity.START)) {
          float dx = event.getX() - downX;
          float dy = event.getY() - downY;
          if (Math.abs(dx) > touchSlop && Math.abs(dx) > Math.abs(dy) * 1.15f) {
            boolean rtl = getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
            boolean swipeTowardDrawerEdge = rtl ? dx > 0 : dx < 0;
            if (swipeTowardDrawerEdge) {
              leftSwipeConsumed = true;
              if (horizontalSwipeListener != null) horizontalSwipeListener.onDrawerSwipeLeft();
              // Consume this gesture so DrawerLayout cannot interpret it as a close animation.
              return true;
            }
            if (horizontalSwipeListener != null && horizontalSwipeListener.onDrawerSwipeRight()) {
              leftSwipeConsumed = true;
              // An inward-to-outward swipe on a tool page is a pager transition, not a close.
              return true;
            }
          }
        }
        break;
      case MotionEvent.ACTION_UP:
      case MotionEvent.ACTION_CANCEL:
        // Keep ownership through UP/CANCEL; onTouchEvent releases it after the gesture ends.
        if (leftSwipeConsumed) return true;
        break;
    }
    return leftSwipeConsumed || super.onInterceptTouchEvent(event);
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (leftSwipeConsumed) {
      if (event != null && (event.getActionMasked() == MotionEvent.ACTION_UP
          || event.getActionMasked() == MotionEvent.ACTION_CANCEL)) leftSwipeConsumed = false;
      return true;
    }
    return super.onTouchEvent(event);
  }

  int dp(int n) {
    return (int) (n * getResources().getDisplayMetrics().density + .5f);
  }
}
