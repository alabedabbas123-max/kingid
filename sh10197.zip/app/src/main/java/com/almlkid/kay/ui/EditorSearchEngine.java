package com.almlkid.kay.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Fast, allocation-bounded search primitives for the active editor document.
 *
 * <p>ProjectSearchEngine owns multi-file searches. This class is intentionally local to one
 * document so find-next and replace-all never trigger a project scan or touch the UI thread with
 * regular-expression compilation for every match.
 */
public final class EditorSearchEngine {
  private EditorSearchEngine() {}

  public static final class Query {
    public final String text;
    public final boolean caseSensitive, wholeWord, regularExpression;

    public Query(String value, boolean sensitive, boolean whole, boolean regex) {
      text = value == null ? "" : value;
      caseSensitive = sensitive;
      wholeWord = whole;
      regularExpression = regex;
    }

    public boolean isEmpty() {
      return text.isEmpty();
    }
  }

  public static final class Match {
    public final int start, end;

    Match(int from, int to) {
      start = from;
      end = to;
    }
  }

  public static int findNext(String source, Query query, int from, boolean wrap) {
    if (source == null || query == null || query.isEmpty()) return -1;
    int start = Math.max(0, Math.min(from, source.length()));
    int result = findInRange(source, query, start, source.length());
    if (result >= 0 || !wrap || start == 0) return result;
    return findInRange(source, query, 0, start);
  }

  public static int findPrevious(String source, Query query, int before, boolean wrap) {
    if (source == null || query == null || query.isEmpty()) return -1;
    int end = Math.max(0, Math.min(before, source.length()));
    List<Match> matches = findAll(source, query, 20000);
    int found = -1;
    for (Match match : matches) {
      if (match.start < end) found = match.start;
      else break;
    }
    if (found >= 0 || !wrap) return found;
    for (int i = matches.size() - 1; i >= 0; i--)
      if (matches.get(i).start < source.length()) return matches.get(i).start;
    return -1;
  }

  public static List<Match> findAll(String source, Query query, int maxResults) {
    if (source == null || query == null || query.isEmpty() || maxResults <= 0)
      return Collections.emptyList();
    int limit = Math.min(50000, maxResults);
    ArrayList<Match> result = new ArrayList<>();
    if (query.regularExpression) {
      Pattern pattern = compile(query);
      if (pattern == null) return result;
      Matcher matcher = pattern.matcher(source);
      while (matcher.find() && result.size() < limit) {
        if (!query.wholeWord || isWholeWord(source, matcher.start(), matcher.end()))
          result.add(new Match(matcher.start(), matcher.end()));
      }
      return result;
    }
    String haystack = query.caseSensitive ? source : source.toLowerCase(Locale.ROOT);
    String needle = query.caseSensitive ? query.text : query.text.toLowerCase(Locale.ROOT);
    int cursor = 0;
    while (cursor <= haystack.length() - needle.length() && result.size() < limit) {
      int at = haystack.indexOf(needle, cursor);
      if (at < 0) break;
      int end = at + needle.length();
      if (!query.wholeWord || isWholeWord(source, at, end)) result.add(new Match(at, end));
      cursor = Math.max(at + 1, end);
    }
    return result;
  }

  public static String replaceAll(String source, Query query, String replacement) {
    if (source == null || query == null || query.isEmpty()) return source == null ? "" : source;
    String value = replacement == null ? "" : replacement;
    if (query.regularExpression) {
      Pattern pattern = compile(query);
      if (pattern == null) return source;
      Matcher matcher = pattern.matcher(source);
      StringBuffer output = new StringBuffer();
      while (matcher.find()) {
        if (query.wholeWord && !isWholeWord(source, matcher.start(), matcher.end())) continue;
        matcher.appendReplacement(output, Matcher.quoteReplacement(value));
      }
      matcher.appendTail(output);
      return output.toString();
    }
    List<Match> matches = findAll(source, query, 50000);
    if (matches.isEmpty()) return source;
    StringBuilder output = new StringBuilder(source.length());
    int cursor = 0;
    for (Match match : matches) {
      output.append(source, cursor, match.start);
      output.append(value);
      cursor = match.end;
    }
    output.append(source, cursor, source.length());
    return output.toString();
  }

  private static int findInRange(String source, Query query, int from, int to) {
    if (query.regularExpression) {
      Pattern pattern = compile(query);
      if (pattern == null) return -1;
      Matcher matcher = pattern.matcher(source);
      matcher.region(from, to);
      while (matcher.find())
        if (!query.wholeWord || isWholeWord(source, matcher.start(), matcher.end()))
          return matcher.start();
      return -1;
    }
    String haystack = query.caseSensitive ? source : source.toLowerCase(Locale.ROOT);
    String needle = query.caseSensitive ? query.text : query.text.toLowerCase(Locale.ROOT);
    int at = haystack.indexOf(needle, from);
    while (at >= 0 && at + needle.length() <= to) {
      if (!query.wholeWord || isWholeWord(source, at, at + needle.length())) return at;
      at = haystack.indexOf(needle, at + 1);
    }
    return -1;
  }

  private static Pattern compile(Query query) {
    try {
      return Pattern.compile(query.text, query.caseSensitive ? 0 : Pattern.CASE_INSENSITIVE);
    } catch (PatternSyntaxException ignored) {
      return null;
    }
  }

  private static boolean isWholeWord(String source, int start, int end) {
    boolean left = start > 0 && Character.isJavaIdentifierPart(source.charAt(start - 1));
    boolean right = end < source.length() && Character.isJavaIdentifierPart(source.charAt(end));
    return !left && !right;
  }
}
