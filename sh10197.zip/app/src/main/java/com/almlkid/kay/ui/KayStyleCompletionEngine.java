package com.almlkid.kay.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The single completion pipeline of the editor. Each file kind has one provider; all of them
 * return the same typed rows, so Java, XML and build files look and behave alike:
 *
 * <ul>
 *   <li>Java (and unknown text) → {@link almlk.JavaCompletionProvider}
 *   <li>XML → {@link almlk.XmlCompletionEngine}
 *   <li>Gradle → {@link almlk.GradleCompletionProvider}
 *   <li>Smali → {@link com.shima.editor.core.SmaliCompletionEngine}
 * </ul>
 *
 * <p>No provider performs I/O on the calling thread beyond the one-time lazy load of the
 * platform index, which the editor warms up in the background when it opens.
 */
public final class KayStyleCompletionEngine {
  private static final int MAX_RESULTS = 40;

  private KayStyleCompletionEngine() {}

  public static List<ProjectSymbolIndex.CompletionItem> complete(
      String fileName, String source, int cursorOffset) {
    String text = source == null ? "" : source;
    String lower = fileName == null ? "" : fileName.toLowerCase(Locale.US);
    if (lower.endsWith(".smali")) return smaliSuggestions(text, cursorOffset);
    if (lower.endsWith(".xml")) return almlk.XmlCompletionEngine.completeItems(fileName, text, cursorOffset);
    if (lower.endsWith(".gradle") || lower.endsWith(".gradle.kts"))
      return almlk.GradleCompletionProvider.complete(text, cursorOffset);
    return almlk.JavaCompletionProvider.complete(text, cursorOffset);
  }

  private static List<ProjectSymbolIndex.CompletionItem> smaliSuggestions(
      String source, int cursorOffset) {
    ArrayList<ProjectSymbolIndex.CompletionItem> result = new ArrayList<>();
    for (String value : com.shima.editor.core.SmaliCompletionEngine.complete(source, cursorOffset, MAX_RESULTS)) {
      int kind = value.startsWith(".") ? ProjectSymbolIndex.CompletionItem.KEYWORD
          : value.startsWith(":") ? ProjectSymbolIndex.CompletionItem.VARIABLE
          : value.startsWith("L") ? ProjectSymbolIndex.CompletionItem.CLASS
          : ProjectSymbolIndex.CompletionItem.METHOD;
      ProjectSymbolIndex.CompletionItem item =
          new ProjectSymbolIndex.CompletionItem(kind, value, value, "");
      result.add(item);
    }
    return result;
  }
}
