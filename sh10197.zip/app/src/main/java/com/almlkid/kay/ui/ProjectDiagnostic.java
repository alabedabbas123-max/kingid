package com.almlkid.kay.ui;

import java.util.Locale;

/** A language diagnostic plus the project file that owns it and an optional safe quick fix. */
public final class ProjectDiagnostic {
  public final String fileName;
  public final String reference;
  public final String preview;
  public final String symbol;
  public final int endColumn;
  public final CodeLanguageTools.Diagnostic diagnostic;
  public final boolean fromBuild;

  private ProjectDiagnostic(
      String fileName,
      String reference,
      String preview,
      String symbol,
      int endColumn,
      CodeLanguageTools.Diagnostic diagnostic,
      boolean fromBuild) {
    this.fileName = fileName == null ? "" : fileName;
    this.reference = reference == null ? "" : reference;
    this.preview = preview == null ? "" : preview;
    this.symbol = symbol == null ? "" : symbol;
    this.endColumn = Math.max(diagnostic == null ? 1 : diagnostic.column + 1, endColumn);
    this.diagnostic = diagnostic;
    this.fromBuild = fromBuild;
  }

  /** R6: a source diagnostic restored from the persisted snapshot shown when a project opens. */
  public static ProjectDiagnostic restored(String fileName, String reference, String preview,
      String symbol, int endColumn, CodeLanguageTools.Diagnostic diagnostic) {
    if (diagnostic == null) return null;
    return new ProjectDiagnostic(fileName, reference, preview, symbol, endColumn, diagnostic, false);
  }

  /**
   * W22/4ب٢‑ب٣: حالةُ وحدةٍ مرتبطةٍ لا تُحَلُّ — سطرٌ في ملفِّ إعلانٍ بلا ترجمةٍ جرتْ.
   *
   * <p>تحذيرٌ لا خطأُ ترجمةٍ: لا ‏{@code Severity.ERROR} هنا، فلا الشارةُ ولا بانرُ
   * البناءِ يتحوّلانِ إلى «فشلٍ» لأنَّ مشروعًا أشارَ إلى وحدةٍ خارجَ المتناولِ؛ ولا
   * مفتاحَ موردٍ للرسالةِ إذ لا نصَّ مُسجَّلًا لـ«بناءٍ» لم يجرِ — تعرضُ الرسالةُ نفسُها.
   * والنقرُ يسلكُ مسارَ ‏{@code fromBuild}: إن لم يجدِ المتصفّحُ مُدخَلًا للملفِّ يُنبَّهُ
   * المستخدمُ ولا يُنقَلْ نقلًا أعمى.
   */
  public static ProjectDiagnostic fromIssue(String fileName, String reference, int line,
      int column, String sourceLine, String message) {
    CodeLanguageTools.Diagnostic diagnostic =
        CodeLanguageTools.Diagnostic.localized(
            0,
            1,
            Math.max(1, line),
            Math.max(1, column),
            CodeLanguageTools.Diagnostic.Severity.WARNING,
            "MODULE",
            null,
            message == null ? "" : message);
    if (diagnostic == null) return null;
    String preview = sourceLine == null ? "" : sourceLine.trim();
    return new ProjectDiagnostic(fileName, reference, preview, "",
        Math.max(1, column) + Math.max(1, preview.length()), diagnostic, true);
  }

  /**
   * W22/4ب٢‑ب٣: صفوفُ حالةِ الوحداتِ المرتبطةِ من خريطةِ الاعتماداتِ — تحذيرٌ لكلِّ سطرِ
   * إعلانٍ لا يُحَلُّ. تُبنى مما حُمِلَ وقتَ الحلِّ (الملفُ والسطرُ ونصُّهُ) فلا قرصَ في
   * خيطِ الواجهةِ؛ وصانعُها هنا لا في النشاطِ: الطبقةُ العليا لا تحتاجُ أن تُسمّيَ طبقةَ
   * النموذجِ الصافيةَ لكي تعرضَ حالتَها، ولا أن تُضيفَ على «خطأِ بناءٍ» شيئًا لم يبنِهِ أحدٌ.
   */
  public static java.util.List<ProjectDiagnostic> fromModuleIssues(
      almlk.GradleProjectModules modules) {
    java.util.ArrayList<ProjectDiagnostic> out = new java.util.ArrayList<>();
    if (modules == null) return out;
    for (almlk.GradleProjectModules.Issue issue : modules.issues()) {
      if (issue == null || issue.file == null) continue;
      ProjectDiagnostic item =
          fromIssue(
              issue.file.getName(),
              issue.file.getAbsolutePath(),
              issue.line,
              issue.column,
              issue.lineText,
              issue.toString());
      if (item != null) out.add(item);
    }
    return out;
  }

  /**
   * W22/4ب٢‑ب٤: مكوّنٌ في ‏`AndroidManifest.xml` يدّعي صنفًا من المشروعِ وصنفُ المشروعِ
   * لا يعرفُهُ — سطرٌ في المانيفستِ وحدَهُ، تحذيرًا لا خطأً.
   *
   * <p>لا عملَ قرصيًّا هنا ولا مسارَ بناءٍ: النصُّ والقدرةُ على معرفةِ الصنفِ يُسلَّمانِ
   * من صاحبِ الفهرسِ. والاسمُ المطلقُ الذي لا يبدأُ بحزمةِ المانيفستِ لا يُسأَلُ عنهُ
   * أبدًا: قد يكونُ صنفًا في منصّةٍ أو مكتبةٍ لا نراهما من هنا، والباطلُ أن نَدَّعِيَ
   * غيابَ ما لم نَفْحَصْ. والاسمُ النسبيُّ (‏`.MainActivity`) يُحَوَّلُ أوّلًا بحزمةِ
   * المانيفستِ — بلا تحويلٍ يكونُ كلُّ مكوّنٍ مفقودًا كذبًا.
   */
  public static java.util.List<ProjectDiagnostic> fromManifestComponents(
      String fileName,
      String reference,
      String manifestText,
      java.util.function.Predicate<String> classKnown) {
    java.util.ArrayList<ProjectDiagnostic> out = new java.util.ArrayList<>();
    String text = manifestText == null ? "" : manifestText;
    if (text.isEmpty() || classKnown == null) return out;
    String pkg = almlk.AndroidManifestModel.packageOf(text);
    if (pkg.isEmpty()) return out; // لا حزمةَ في المانيفستِ: لا تحويلَ، فلا حُكمَ
    for (almlk.AndroidManifestModel.Component component : almlk.AndroidManifestModel.componentsOf(text)) {
      if (component == null || component.name.isEmpty()) continue;
      boolean mine = component.relative || component.name.startsWith(pkg + ".");
      if (!mine) continue;
      String full = almlk.AndroidManifestModel.resolve(component.name, pkg);
      int dot = full.lastIndexOf('.');
      if (dot <= 0 || dot + 1 >= full.length()) continue; // اسمٌ لا يصلحُ أن يكونَ صنفًا
      if (almlk.AndroidApiIndex.isKnownPackage(full.substring(0, dot))) continue;
      if (classKnown.test(full)) continue;
      CodeLanguageTools.Diagnostic diagnostic =
          CodeLanguageTools.Diagnostic.localized(
              0,
              1,
              Math.max(1, component.line),
              1,
              CodeLanguageTools.Diagnostic.Severity.WARNING,
              "MANIFEST",
              null,
              component.tag + " " + component.name + " — no class " + full + " in this project");
      if (diagnostic == null) continue;
      String preview = lineText(text, component.line);
      out.add(new ProjectDiagnostic(fileName, reference, preview.isEmpty() ? component.name : preview,
          "", Math.max(2, preview.length() + 1), diagnostic, true));
    }
    return out;
  }

  /** Wraps an editor/language error and preserves its exact source range. */
  public static ProjectDiagnostic fromSource(
      String fileName,
      String reference,
      String source,
      CodeLanguageTools.Diagnostic diagnostic) {
    if (diagnostic == null) return null;
    String text = source == null ? "" : source;
    String symbol = tokenForRange(text, diagnostic.offset, diagnostic.end);
    // Stage 4: a source diagnostic already carries its quick fixes (JavaCodeAnalyzer).
    return new ProjectDiagnostic(
        fileName,
        reference,
        lineText(text, diagnostic.line),
        symbol,
        diagnostic.column + Math.max(1, diagnostic.end - diagnostic.offset),
        diagnostic,
        false);
  }

  /** Converts a compiler/build location into a source-aware diagnostic after the file is loaded. */
  public static ProjectDiagnostic fromBuild(
      String fileName,
      String reference,
      String source,
      BuildDiagnosticsParser.BuildError error) {
    if (error == null) return null;
    String text = source == null ? "" : source;
    int line = Math.max(1, error.line);
    int column = Math.max(1, error.column);
    int offset = offsetForLineColumn(text, line, column);
    int lineStart = lineStartOffset(text, line);
    int lineEnd = lineEndOffset(text, line);
    if (!error.symbol.isEmpty()) {
      int symbolAt = text.indexOf(error.symbol, lineStart);
      if (symbolAt >= 0 && symbolAt < lineEnd) offset = symbolAt;
    }
    int[] range = identifierRange(text, offset);
    int start = range[0];
    int end = range[1];
    int actualColumn = Math.max(1, start - lineStart + 1);
    CodeLanguageTools.Diagnostic diagnostic =
        CodeLanguageTools.Diagnostic.localized(
            start,
            Math.max(start + 1, end),
            line,
            actualColumn,
            error.warning
                ? CodeLanguageTools.Diagnostic.Severity.WARNING
                : CodeLanguageTools.Diagnostic.Severity.ERROR,
            error.code,
            "ui_diagnostic_build_error",
            "Build: %1$s",
            error.message);
    String symbol = tokenForRange(text, start, end);
    // A compiler "cannot find symbol" at a call the semantic checker also proves missing gets the
    // same "create method/field" fix as the live diagnostic.
    if (!symbol.isEmpty() && fileName != null && fileName.toLowerCase(Locale.US).endsWith(".java"))
      diagnostic =
          diagnostic.withQuickFixes(almlk.JavaCodeAnalyzer.quickFixesAt(fileName, text, start, end));
    return new ProjectDiagnostic(
        fileName,
        reference,
        lineText(text, line).isEmpty() ? error.sourceLine : lineText(text, line),
        symbol,
        actualColumn + Math.max(1, Math.max(start + 1, end) - start),
        diagnostic,
        true);
  }

  private static int[] identifierRange(String source, int offset) {
    int at = Math.max(0, Math.min(offset, source.length()));
    if (at == source.length() && at > 0) at--;
    if (at < source.length() && !Character.isJavaIdentifierPart(source.charAt(at)) && at > 0)
      at--;
    int start = at;
    int end = at;
    while (start > 0 && Character.isJavaIdentifierPart(source.charAt(start - 1))) start--;
    while (end < source.length() && Character.isJavaIdentifierPart(source.charAt(end))) end++;
    if (start == end) return new int[] {Math.max(0, Math.min(offset, source.length())),
        Math.max(0, Math.min(offset, source.length()))};
    return new int[] {start, end};
  }

  private static String tokenForRange(String source, int start, int end) {
    if (source == null || source.isEmpty()) return "";
    int left = Math.max(0, Math.min(start, source.length()));
    int right = Math.max(left, Math.min(end, source.length()));
    if (left == right) {
      int[] range = identifierRange(source, left);
      left = range[0];
      right = range[1];
    }
    if (left >= right) return "";
    String candidate = source.substring(left, right);
    if (candidate.isEmpty()) return "";
    for (int i = 0; i < candidate.length(); i++)
      if (!Character.isJavaIdentifierPart(candidate.charAt(i))) return "";
    return candidate;
  }

  public static int offsetForLineColumn(String source, int line, int column) {
    return Math.max(0, Math.min(source == null ? 0 : source.length(),
        lineStartOffset(source == null ? "" : source, line) + Math.max(0, column - 1)));
  }

  private static int lineStartOffset(String source, int requestedLine) {
    int line = 1;
    int offset = 0;
    while (line < requestedLine && offset < source.length()) {
      int next = source.indexOf('\n', offset);
      if (next < 0) return source.length();
      offset = next + 1;
      line++;
    }
    return offset;
  }

  private static int lineEndOffset(String source, int requestedLine) {
    int start = lineStartOffset(source, requestedLine);
    int end = source.indexOf('\n', start);
    return end < 0 ? source.length() : end;
  }

  private static String lineText(String source, int requestedLine) {
    if (source == null || source.isEmpty() || requestedLine < 1) return "";
    int start = lineStartOffset(source, requestedLine);
    if (start >= source.length()) return "";
    int end = lineEndOffset(source, requestedLine);
    return source.substring(start, end).trim();
  }

  /** Stable key for merging editor, project-scan, and compiler diagnostics without duplicates. */
  public String key() {
    String owner = reference.isEmpty() ? fileName : reference;
    return owner + "|" + diagnostic.line + "|" + diagnostic.column + "|"
        + diagnostic.code + "|" + String.valueOf(diagnostic.message);
  }

  public String groupKey() {
    return reference.isEmpty() ? fileName : reference;
  }

  public String displayName() {
    if (!reference.isEmpty() && reference.startsWith("/")) {
      String normalized = reference.replace('\\', '/');
      int slash = normalized.lastIndexOf('/');
      if (slash >= 0 && slash + 1 < normalized.length()) return normalized.substring(slash + 1);
    }
    if (fileName == null || fileName.isEmpty()) return "Build";
    int slash = Math.max(fileName.lastIndexOf('/'), fileName.lastIndexOf('\\'));
    return slash < 0 ? fileName : fileName.substring(slash + 1);
  }

  public String extension() {
    String value = fileName.toLowerCase(Locale.US);
    int slash = Math.max(value.lastIndexOf('/'), value.lastIndexOf('\\'));
    return value.substring(slash + 1);
  }
}
