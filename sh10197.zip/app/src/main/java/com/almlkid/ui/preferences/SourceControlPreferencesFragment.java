package com.almlkid.ui.preferences;

import android.os.Bundle;
import com.shima.demo.R;

/** قسم Git Source Control — هوية المستخدم ومسار SSH وخيار إنشاء المستودعات. */
public class SourceControlPreferencesFragment extends BasePreferenceFragment {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    addPreferencesFromResource(R.xml.preferences_sourcecontrol);
  }
}
