package com.almlkid.ui.preferences;

import android.app.AlertDialog;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceScreen;
import android.view.KeyEvent;
import android.widget.TextView;
import almlk.AppSettings;
import com.shima.demo.UiStrings;

/**
 * قسم Keybindings — محرر اختصاطات مبني برمجيًا: لكل أمر سطر يعرض ربطه الحالي،
 والنقر يفتح حوار التقاط مفاتيح يُخزَّن في التفضيلات (استهلاكه في المحرر مرحلة 3).
 */
public class KeyBindingsPreferencesFragment extends BasePreferenceFragment {

  private static final String[][] ACTIONS = {
    {"save", "command_save"},
    {"undo", "command_undo"},
    {"redo", "command_redo"},
    {"find", "command_find"},
    {"format", "command_format"},
    {"run", "command_run"},
  };

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    PreferenceScreen root = getPreferenceManager().createPreferenceScreen(getActivity());
    for (String[] action : ACTIONS) {
      String id = action[0];
      Preference preference = new Preference(getActivity());
      preference.setKey("keybind_" + id);
      preference.setTitle(UiStrings.get(getActivity(), action[1]));
      preference.setSummary(currentBinding(id));
      preference.setOnPreferenceClickListener(p -> { capture(id, p); return true; });
      root.addPreference(preference);
    }
    setPreferenceScreen(root);
  }

  private String currentBinding(String id) {
    String stored = AppSettings.prefs(getActivity()).getString("keybind_" + id, null);
    return stored == null ? almlk.Keybinds.defaultLabel(id) : stored;
  }

  /** حوار التقاط: أي ضغطة مفتاح (عدا الرجوع) تُسجَّل ربطًا جديدًا. */
  private void capture(String id, Preference preference) {
    TextView hint = new TextView(getActivity());
    hint.setText(UiStrings.get(getActivity(), "ui_keybinding_capture_hint"));
    hint.setPadding(48, 32, 48, 8);
    AlertDialog dialog =
        new AlertDialog.Builder(getActivity())
            .setTitle(preference.getTitle())
            .setView(hint)
            .setNegativeButton(UiStrings.get(getActivity(), "dialog_cancel"), null)
            .create();
    dialog.setOnKeyListener(
        (d, keyCode, event) -> {
          if (event.getAction() != KeyEvent.ACTION_DOWN) return true;
          if (keyCode == KeyEvent.KEYCODE_BACK) return false;
          String label = labelOf(event);
          AppSettings.prefs(getActivity()).edit().putString("keybind_" + id, label).apply();
          preference.setSummary(label);
          d.dismiss();
          return true;
        });
    dialog.show();
  }

  private static String labelOf(KeyEvent event) {
    StringBuilder label = new StringBuilder();
    int meta = event.getMetaState();
    if ((meta & KeyEvent.META_CTRL_ON) != 0) label.append("CTRL+");
    if ((meta & KeyEvent.META_ALT_ON) != 0) label.append("ALT+");
    if ((meta & KeyEvent.META_SHIFT_ON) != 0) label.append("SHIFT+");
    label.append(KeyEvent.keyCodeToString(event.getKeyCode()).replace("KEYCODE_", ""));
    return label.toString();
  }
}
