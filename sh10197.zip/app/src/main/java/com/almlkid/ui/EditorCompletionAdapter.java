package com.almlkid.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.almlkid.kay.ui.ProjectSymbolIndex;
import com.shima.demo.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Completion rows drawn like the reference (completion_list_entry): kind icon, name with the typed
 * part in the accent colour, grey signature/type/package suffix, and the grey "Added in API level"
 * line. Keywords and XML values are bold and have no icon.
 */
public final class EditorCompletionAdapter extends BaseAdapter {
  private final LayoutInflater inflater;
  private final ArrayList<ProjectSymbolIndex.CompletionItem> items = new ArrayList<>();
  private final int accent;
  private final int gray;
  private String prefix = "";

  public EditorCompletionAdapter(Context context) {
    inflater = LayoutInflater.from(context);
    accent = themeColor(context, android.R.attr.colorAccent, 0xFF33B5E5);
    gray = themeColor(context, R.attr.color_browser_label_gray, 0xFF999999);
  }

  private static int themeColor(Context context, int attr, int fallback) {
    TypedArray values = context.obtainStyledAttributes(new int[] {attr});
    try {
      return values.getColor(0, fallback);
    } finally {
      values.recycle();
    }
  }

  public void setItems(List<ProjectSymbolIndex.CompletionItem> values) {
    setItems(values, "");
  }

  /** Replaces the rows; {@code typed} is the prefix painted in the accent colour. */
  public void setItems(List<ProjectSymbolIndex.CompletionItem> values, String typed) {
    items.clear();
    if (values != null) items.addAll(values);
    prefix = typed == null ? "" : typed;
    notifyDataSetChanged();
  }

  public List<ProjectSymbolIndex.CompletionItem> snapshot() {
    return Collections.unmodifiableList(new ArrayList<>(items));
  }

  @Override
  public int getCount() {
    return items.size();
  }

  @Override
  public ProjectSymbolIndex.CompletionItem getItem(int position) {
    return items.get(position);
  }

  @Override
  public long getItemId(int position) {
    return position;
  }

  @Override
  public View getView(int position, View reusable, ViewGroup parent) {
    View row = reusable == null
        ? inflater.inflate(R.layout.completion_list_entry, parent, false)
        : reusable;
    ProjectSymbolIndex.CompletionItem item = getItem(position);
    ImageView icon = row.findViewById(R.id.completionEntryImage);
    TextView name = row.findViewById(R.id.completionEntryName);
    row.findViewById(R.id.completionHelpButton).setVisibility(View.GONE);
    View translation = row.findViewById(R.id.translation);
    if (translation != null) translation.setVisibility(View.GONE);

    int iconRes = iconFor(item);
    if (iconRes == 0) {
      icon.setImageDrawable(null);
      icon.setVisibility(View.INVISIBLE); // keeps the column aligned, like browser_empty
    } else {
      icon.setImageResource(iconRes);
      icon.setVisibility(View.VISIBLE);
    }

    String label = item.label == null ? "" : item.label;
    String suffix = item.suffix == null ? "" : item.suffix;
    SpannableString text = new SpannableString(label + suffix);
    boolean bold = item.kind == ProjectSymbolIndex.CompletionItem.KEYWORD
        || item.kind == ProjectSymbolIndex.CompletionItem.VALUE;
    if (bold) text.setSpan(new StyleSpan(Typeface.BOLD), 0, label.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    if (!suffix.isEmpty())
      text.setSpan(new ForegroundColorSpan(gray), label.length(), text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    int[] matched = almlk.CompletionMatcher.highlight(label, prefix);
    if (matched != null) {
      int i = 0;
      while (i < matched.length) {
        int j = i;
        while (j + 1 < matched.length && matched[j + 1] == matched[j] + 1) j++;
        text.setSpan(new ForegroundColorSpan(accent), matched[i], matched[j] + 1,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        i = j + 1;
      }
    }
    name.setText(text);
    int flags = name.getPaintFlags();
    name.setPaintFlags(item.removed ? flags | Paint.STRIKE_THRU_TEXT_FLAG : flags & ~Paint.STRIKE_THRU_TEXT_FLAG);

    View apiRow = row.findViewById(R.id.apiInfoView);
    TextView api = row.findViewById(R.id.apiInfo);
    boolean hasApi = item.apiInfo != null && !item.apiInfo.isEmpty() && almlk.AppSettings.showApiInfo(row.getContext());
    apiRow.setVisibility(hasApi ? View.VISIBLE : View.GONE);
    api.setText(hasApi ? item.apiInfo : "");
    return row;
  }

  /** Kind icons of the reference: red cube = method, blue cube = field/variable, shapes = class. */
  static int iconFor(ProjectSymbolIndex.CompletionItem item) {
    switch (item.kind) {
      case ProjectSymbolIndex.CompletionItem.METHOD:
        return item.secondary ? R.drawable.completion_method_light : R.drawable.completion_method;
      case ProjectSymbolIndex.CompletionItem.VARIABLE:
        return item.secondary ? R.drawable.completion_variable_light : R.drawable.completion_variable;
      case ProjectSymbolIndex.CompletionItem.CLASS:
        return item.secondary ? R.drawable.completion_class_light : R.drawable.completion_class;
      case ProjectSymbolIndex.CompletionItem.PACKAGE:
        return R.drawable.completion_package;
      case ProjectSymbolIndex.CompletionItem.XML:
        return R.drawable.completion_variable;
      case ProjectSymbolIndex.CompletionItem.BUILD:
        return R.drawable.completion_method;
      default:
        return 0; // KEYWORD, VALUE
    }
  }
}
