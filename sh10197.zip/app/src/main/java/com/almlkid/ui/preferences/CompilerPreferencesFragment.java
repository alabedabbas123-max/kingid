package com.almlkid.ui.preferences;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import almlk.AppSettings;
import com.shima.demo.R;

/** قسم Build & Run — مفاتيح البناء + معالجات keystore/maven/ndk. */
public class CompilerPreferencesFragment extends BasePreferenceFragment {
  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    addPreferencesFromResource(R.xml.preferences_compiler);
    click("generate_keystore", p -> { generateKeystore(); return true; });
    click("refresh_maven_repository", p -> {
      BuildActions.Delegate d = BuildActions.delegate;
      if (d != null) d.refreshMaven();
      else Toast.makeText(getActivity(), com.shima.demo.UiStrings.get(getActivity(), "ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
      return true;
    });
    click("install_uninstall_ndksupport", p -> {
      BuildActions.Delegate d = BuildActions.delegate;
      if (d != null) d.ndkToggle();
      else Toast.makeText(getActivity(), com.shima.demo.UiStrings.get(getActivity(), "ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
      return true;
    });
  }

  /** توليد مخزن مفاتيح PKCS12 فارغ محمي بكلمة مرور، ثم اعتماده للتوقيع. */
  private void generateKeystore() {
    LinearLayout layout = new LinearLayout(getActivity());
    layout.setOrientation(LinearLayout.VERTICAL);
    layout.setPadding(48, 24, 48, 8);
    EditText path = field(layout, "/sdcard/my-release.p12", false);
    EditText storePass = field(layout, com.shima.demo.UiStrings.get(getActivity(), "ui_keystore_password_hint"), true);
    EditText alias = field(layout, com.shima.demo.UiStrings.get(getActivity(), "ui_key_alias_hint"), false);
    EditText keyPass = field(layout, com.shima.demo.UiStrings.get(getActivity(), "ui_key_password_hint"), true);
    new AlertDialog.Builder(getActivity())
        .setTitle(R.string.preference_title_create_keystore)
        .setView(layout)
        .setPositiveButton(com.shima.demo.UiStrings.get(getActivity(), "ui_generate_keystore"), (d, w) -> create(path.getText().toString().trim(),
            storePass.getText().toString(), alias.getText().toString().trim(),
            keyPass.getText().toString()))
        .setNegativeButton(com.shima.demo.UiStrings.get(getActivity(), "dialog_cancel"), null)
        .show();
  }

  private EditText field(LinearLayout parent, String hint, boolean password) {
    EditText edit = new EditText(getActivity());
    edit.setHint(hint);
    if (password) edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    parent.addView(edit);
    return edit;
  }

  private void create(String path, String storePass, String alias, String keyPass) {
    if (path.isEmpty() || storePass.isEmpty() || alias.isEmpty()) {
      Toast.makeText(getActivity(), com.shima.demo.UiStrings.get(getActivity(), "ui_complete_keystore_fields"), Toast.LENGTH_SHORT).show();
      return;
    }
    try {
      java.security.KeyStore keyStore = java.security.KeyStore.getInstance("PKCS12");
      keyStore.load(null, storePass.toCharArray());
      try (java.io.FileOutputStream out = new java.io.FileOutputStream(path)) {
        keyStore.store(out, storePass.toCharArray());
      }
      AppSettings.prefs(getActivity())
          .edit()
          .putString("user_keystore", path)
          .putBoolean("use_user_keystore", true)
          .apply();
      Toast.makeText(getActivity(), com.shima.demo.UiStrings.format(getActivity(), "ui_keystore_created", path), Toast.LENGTH_LONG).show();
    } catch (Exception error) {
      Toast.makeText(getActivity(), com.shima.demo.UiStrings.format(getActivity(), "ui_keystore_create_failed", error.getMessage()),
          Toast.LENGTH_LONG).show();
    }
  }
}
