package com.almlkid.ui.tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import almlk.BatchReplacer;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * أدوات › أخرى › استبدال جماعي: المسار (افتراضيًا src/main للوحدة)، والقديم، والجديد، ومرشّح
 * اللواحق، والمجلدات الفرعية. التنفيذ في الخلفية، ثم ملخص بالملفات مع زر نسخ، وتُبلَّغ الواجهة
 * بالمحتوى الجديد لتحديث التبويبات المفتوحة.
 */
public final class BatchReplaceDialog {

  private BatchReplaceDialog() {}

  public static void show(final Activity activity, File defaultTarget, final Consumer<Map<String, String>> rewritten) {
    LinearLayout box = ToolDialogs.column(activity);
    final EditText path = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_batch_path"),
        defaultTarget == null ? "" : defaultTarget.getAbsolutePath(), false);
    final EditText oldText = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_batch_old"), null, false);
    final EditText newText = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_batch_new"), null, false);
    final EditText filter = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_batch_filter"), ".java|.xml", false);
    final CheckBox subdirs = new CheckBox(activity);
    subdirs.setText(ToolDialogs.ui(activity, "tools_batch_subdirs"));
    subdirs.setChecked(true);
    box.addView(path, new LinearLayout.LayoutParams(-1, -2));
    box.addView(oldText, new LinearLayout.LayoutParams(-1, -2));
    box.addView(newText, new LinearLayout.LayoutParams(-1, -2));
    box.addView(filter, new LinearLayout.LayoutParams(-1, -2));
    box.addView(subdirs);
    ScrollView scroll = new ScrollView(activity);
    scroll.addView(box);
    final AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle(ToolDialogs.ui(activity, "tools_batch_title"))
            .setView(scroll)
            .setPositiveButton(ToolDialogs.ui(activity, "tools_replace"), null)
            .setNegativeButton(android.R.string.cancel, null)
            .create();
    dialog.show();
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
      final File target = new File(path.getText().toString().trim());
      if (path.getText().toString().trim().isEmpty() || !target.exists()) {
        path.setError(ToolDialogs.ui(activity, "tools_batch_missing_path"));
        return;
      }
      final String from = oldText.getText().toString();
      if (from.isEmpty()) {
        oldText.setError(ToolDialogs.ui(activity, "tools_batch_missing_old"));
        return;
      }
      dialog.dismiss();
      run(activity, target, from, newText.getText().toString(), filter.getText().toString(),
          subdirs.isChecked(), rewritten);
    });
  }

  private static void run(final Activity activity, final File target, final String from, final String to,
      final String filter, final boolean subdirs, final Consumer<Map<String, String>> rewritten) {
    final ProgressDialog progress = new ProgressDialog(activity);
    progress.setMessage(ToolDialogs.ui(activity, "tools_batch_running"));
    progress.setCancelable(false);
    progress.show();
    new Thread(() -> {
      BatchReplacer.Result result = null;
      Exception failure = null;
      try {
        result = BatchReplacer.replace(target, from, to, filter, subdirs);
      } catch (Exception e) {
        failure = e;
      }
      final BatchReplacer.Result done = result;
      final Exception error = failure;
      activity.runOnUiThread(() -> {
        if (activity.isFinishing()) return;
        progress.dismiss();
        if (done == null) {
          Toast.makeText(activity, ToolDialogs.uiFormat(activity, "tools_batch_failed",
              error == null ? "" : String.valueOf(error.getMessage())), Toast.LENGTH_LONG).show();
          return;
        }
        LinkedHashMap<String, String> changed = new LinkedHashMap<>();
        StringBuilder report = new StringBuilder();
        report.append(ToolDialogs.uiFormat(activity, "tools_batch_summary",
            done.occurrences, done.changed.size(), done.scanned, done.millis));
        for (Map.Entry<File, String> e : done.changed.entrySet()) {
          changed.put(e.getKey().getAbsolutePath(), e.getValue());
          report.append("\n\nFile:").append(e.getKey().getAbsolutePath());
        }
        for (String f : done.failures) report.append("\n\n! ").append(f);
        if (!changed.isEmpty() && rewritten != null) rewritten.accept(changed);
        final String text = report.toString();
        new AlertDialog.Builder(activity)
            .setTitle(ToolDialogs.ui(activity, "tools_batch_done"))
            .setMessage(text)
            .setPositiveButton(ToolDialogs.ui(activity, "command_copy"), (d, w) -> ToolDialogs.copy(activity, text))
            .setNegativeButton(android.R.string.cancel, null)
            .show();
      });
    }, "BatchReplace").start();
  }
}
