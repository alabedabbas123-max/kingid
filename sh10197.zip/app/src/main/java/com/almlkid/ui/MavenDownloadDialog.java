package com.almlkid.ui;

import almlk.MavenResolver;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.shima.demo.R;
import com.shima.demo.UiStrings;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * حوار «Downloading Maven Libraries» (M2) كالمرجع: دوّار + «الاسم (NN%)» + شريط أفقي، وزرّا
 * CANCEL (يوقف العمل) وHIDE (يخفي الحوار ويبقى العمل). الحلّ في خيط خلفي، والنتيجة على خيط الواجهة.
 * تشغيل واحد في كل مرة: طلب جديد أثناء العمل يعيد إظهار الحوار القائم.
 */
public final class MavenDownloadDialog {

  public interface Callback {
    void onFinished(MavenResolver.Result result);
  }

  private static MavenDownloadDialog active;

  private final Activity activity;
  private final Handler main = new Handler(Looper.getMainLooper());
  private final AtomicBoolean cancel = new AtomicBoolean();
  private AlertDialog dialog;
  private TextView label;
  private ProgressBar bar;

  private MavenDownloadDialog(Activity activity) {
    this.activity = activity;
  }

  /** يبدأ الحلّ والتنزيل مع الحوار؛ يعيد null إن كان تشغيل سابق جاريًا (ويُظهر حواره). */
  public static MavenDownloadDialog start(Activity activity, final MavenResolver resolver,
      final List<MavenResolver.Request> requests, final boolean refresh, final Callback callback) {
    if (active != null) {
      active.show();
      return null;
    }
    final MavenDownloadDialog run = new MavenDownloadDialog(activity);
    active = run;
    run.show();
    Thread worker = new Thread(() -> {
      MavenResolver.Result result;
      try {
        result = resolver.resolve(requests, refresh, run::post, run.cancel);
      } catch (Throwable unexpected) {
        // أي عطل (حتى Error) يُنهي التشغيل؛ وإلا بقي «جارٍ» إلى الأبد فلا تُنزَّل المكتبات أبدًا.
        result = new MavenResolver.Result();
        result.cancelled = true;
      }
      final MavenResolver.Result done = result;
      run.main.post(() -> run.finish(done, callback));
    }, "maven-resolver");
    worker.setDaemon(true);
    worker.start();
    return run;
  }

  public static boolean isRunning() {
    return active != null;
  }

  /** يعيد إظهار حوار التشغيل الجاري (بعد HIDE) إن وُجد. */
  public static void showActive() {
    if (active != null) active.show();
  }

  /** CANCEL برمجيًا (عند إغلاق المشروع). */
  public static void cancelActive() {
    if (active != null) active.cancel.set(true);
  }

  private void show() {
    if (activity.isFinishing()) return;
    if (dialog == null) {
      View view = activity.getLayoutInflater().inflate(R.layout.progressdialog, null);
      label = view.findViewById(R.id.progressdialogLabel);
      bar = view.findViewById(R.id.progressdialogProgress);
      label.setText("");
      bar.setMax(100);
      dialog = new AlertDialog.Builder(activity)
          .setTitle(UiStrings.get(activity, "dialog_title_downloading_maven"))
          .setView(view)
          .setCancelable(false)
          .setNegativeButton(UiStrings.get(activity, "dialog_cancel"), (d, w) -> cancel.set(true))
          .setNeutralButton(UiStrings.get(activity, "dialog_bt_hide"), (d, w) -> d.dismiss())
          .create();
    }
    if (!dialog.isShowing()) dialog.show();
  }

  private void post(final String name, final int percent) {
    main.post(() -> {
      if (label == null) return;
      label.setText(name.isEmpty() ? percent + "%" : name + " (" + percent + "%)");
      bar.setProgress(percent);
    });
  }

  private void finish(MavenResolver.Result result, Callback callback) {
    active = null;
    if (dialog != null && dialog.isShowing()) {
      try {
        dialog.dismiss();
      } catch (RuntimeException detached) {
        // النشاط أُغلق أثناء العمل.
      }
    }
    if (callback != null) callback.onFinished(result);
  }

  /** ملخّص نتيجة طلب المستخدم (تفاعلي). */
  public static void showOutcome(Activity activity, MavenResolver.Result result) {
    showOutcome(activity, result, true);
  }

  /**
   * ملخّص النتيجة: إلغاء، أو قائمة «Could not resolve …» (تفاعلي فقط — عند الفتح التلقائي تكفي رسالة
   * قصيرة والأسطر معلَّمة، بلا حوار خطأ مزعج عند غياب الشبكة)، أو عدد المكتبات الجاهزة.
   */
  public static void showOutcome(Activity activity, MavenResolver.Result result, boolean interactive) {
    if (activity.isFinishing()) return;
    if (result.cancelled) {
      Toast.makeText(activity, UiStrings.get(activity, "ui_maven_cancelled"), Toast.LENGTH_SHORT).show();
      return;
    }
    if (!interactive) {
      if (!result.failures.isEmpty()) {
        Toast.makeText(activity, UiStrings.format(activity, "ui_maven_unresolved_count", result.failures.size()),
            Toast.LENGTH_LONG).show();
      } else if (result.downloaded > 0) {
        Toast.makeText(activity, outcomeLine(activity, result), Toast.LENGTH_SHORT).show();
      }
      return;
    }
    if (!result.failures.isEmpty()) {
      StringBuilder text = new StringBuilder();
      for (MavenResolver.Failure failure : result.failures) {
        if (text.length() > 0) text.append('\n');
        text.append(failure.message());
      }
      new AlertDialog.Builder(activity)
          .setTitle(UiStrings.get(activity, "ui_maven_failures_title"))
          .setMessage(text)
          .setPositiveButton(android.R.string.ok, null)
          .show();
      return;
    }
    Toast.makeText(activity, outcomeLine(activity, result), Toast.LENGTH_SHORT).show();
  }

  /**
   * W21′3: العددُ المعلنُ عددُ ما ثُبِّتَ فعلًا (`readyCount()` لا حجمُ قائمةِ الأدواتِ): ملفٌّ مقطوعٌ
   * أو صفحةُ خطأٍ باسمِ المكتبةِ لا تُحسَبُ «جاهزةً». وما صَحَّ ملفُّهُ ولا أصنافَ فيهِ يُقالُ صراحةً،
   * فلا يُترَكَ القارئُ يَحسَبُ عشرينَ سطرًا مكتبةً كاملةً.
   */
  private static String outcomeLine(Activity activity, MavenResolver.Result result) {
    String line = UiStrings.format(activity, "ui_maven_resolved", result.readyCount(), result.downloaded);
    // W22/4ب: ما في `libs/` من الوحدةٍ يُذكرُ هنا — معدُودٌ منْ قرصٍ لا منْ سُوقٍ،
    // وما لم يكنْ في ملفٍ البناءِ يُقالُ صراحةً (يُعرَفُ في الإكمالِ، لا في البناءِ).
    almlk.LocalLibraries.Finding local = DependencyCycle.state().localFinding();
    if (!local.isEmpty()) {
      line = line + "\n" + UiStrings.format(activity, "ui_maven_local_libs", local.classpath.size(),
          local.unlisted, local.ignored);
    }
    // W32: لا «تُُرِكَ ١» وحدَهُ — المَرفوضُ يُسمَّى. مصدرُهُ دورةُ الرصدِ أو الفهرسُ (عقدةٌ فُكَّتْ
    // سالمةً ثمَّ بُتِرَ أرشيفُها)، والمِصباحُ واحدٌ: رسالةُ «الملفُّ تحتَ الاسمِ ليسَ أرشيفًا مُستعملًا».
    java.util.LinkedHashSet<String> refusedSet = new java.util.LinkedHashSet<String>(local.integrity);
    refusedSet.addAll(almlk.LibraryClassIndex.problems());
    java.util.List<String> refused = new java.util.ArrayList<String>(refusedSet);
    for (int i = 0; i < refused.size() && i < 3; i++) {
      line = line + "\n" + UiStrings.format(activity, "ui_maven_incomplete_install", refused.get(i));
    }
    if (refused.size() > 3) line = line + " …+" + (refused.size() - 3);
    int silent = result.withoutClassesCount();
    if (silent > 0) {
      line = line + "\n" + UiStrings.format(activity, "ui_maven_without_classes", silent,
          String.join(", ", result.withoutClasses()));
    }
    return line;
  }
}
