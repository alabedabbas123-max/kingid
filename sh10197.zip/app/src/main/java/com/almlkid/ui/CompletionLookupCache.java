package com.almlkid.ui;

import com.almlkid.kay.ui.ProjectSymbolIndex;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Worker-side bounded cache for the context-first KayStyle completion pipeline. */
public final class CompletionLookupCache {
  /** Lists at least this long may be capped by a provider and are never narrowed. */
  private static final int REUSABLE_LIMIT = 60;
  private String file = "";
  private String prefix = "";
  private String context = "";
  private int afterHash;
  private int afterLength;
  private int stableSourceHash;
  private boolean populated;
  private List<ProjectSymbolIndex.CompletionItem> items = Collections.emptyList();

  public synchronized List<ProjectSymbolIndex.CompletionItem> lookup(
      String requestedFile,
      String requestedPrefix,
      String requestedContext,
      String after,
      int requestedStableSourceHash) {
    if (!populated
        || !safeEquals(file, requestedFile)
        || requestedPrefix == null
        || !requestedPrefix.startsWith(prefix)
        || !safeEquals(context, requestedContext)
        || after == null
        || after.length() != afterLength
        || after.hashCode() != afterHash
        || stableSourceHash != requestedStableSourceHash) return null;

    // A base list that may have been truncated cannot be narrowed: rows beyond the cap would be
    // missing for the longer prefix, so such requests are recomputed.
    if (items.size() >= REUSABLE_LIMIT || prefix.isEmpty()) return null;
    ArrayList<ProjectSymbolIndex.CompletionItem> filtered = new ArrayList<>();
    for (ProjectSymbolIndex.CompletionItem item : items) {
      if (almlk.CompletionMatcher.matches(item.label, requestedPrefix)) filtered.add(item);
    }
    return filtered;
  }

  public synchronized void store(
      String requestedFile,
      String requestedPrefix,
      String requestedContext,
      String after,
      int requestedStableSourceHash,
      List<ProjectSymbolIndex.CompletionItem> values) {
    file = requestedFile == null ? "" : requestedFile;
    prefix = requestedPrefix == null ? "" : requestedPrefix;
    context = requestedContext == null ? "" : requestedContext;
    afterLength = after == null ? 0 : after.length();
    afterHash = after == null ? 0 : after.hashCode();
    stableSourceHash = requestedStableSourceHash;
    items = values == null
        ? Collections.emptyList()
        : Collections.unmodifiableList(new ArrayList<>(values));
    populated = true;
  }

  public synchronized void clear() {
    populated = false;
    items = Collections.emptyList();
    file = "";
    prefix = "";
    context = "";
    afterHash = 0;
    afterLength = 0;
    stableSourceHash = 0;
  }

  private boolean safeEquals(String left, String right) {
    return left.equals(right == null ? "" : right);
  }
}
