package com.almlkid.ui.preferences;

import android.app.AlertDialog;
import android.view.Gravity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import almlk.AppSettings;
import almlk.ThemeNames;
import com.almlkid.ui.DependencyCycle;
import almlk.MavenStore;
import com.shima.demo.MainActivity;
import com.shima.demo.R;
import com.shima.demo.ThemeActivity;
import com.shima.demo.ThemeConfig;
import com.shima.demo.ThemeGalleryActivity;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import org.json.JSONObject;

/**
 * تبويب Advanced Settings — المرحلة 4: الشاشات الثمان كما اللقطة، وكل أمر بمعالج حي:
 * ثيم/رموز سريعة/خط/خلفية (تُطبق فورًا)، ملفات gradle/proguard، نسخ/استعادة،
 * تحديث/جهات (حوارات محلية صادقة).
 */
public class AdvancedSettingsFragment extends BasePreferenceFragment {

  private static final int REQUEST_BG_IMAGE = 100;

  private String ui(String key) {
    return com.shima.demo.UiStrings.get(getActivity(), key);
  }

  private String uiFormat(String key, Object... values) {
    return com.shima.demo.UiStrings.format(getActivity(), key, values);
  }

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    SharedPreferences sp = AppSettings.prefs(getActivity());
    String home = sp.getString("project_home", null);
    if (home == null || !home.startsWith("/"))
      sp.edit().putString("project_home", "/sdcard/AppProject").apply();

    addPreferencesFromResource(R.xml.preferences_advanced_setting);
    // الثيماتُ صارتْ قسمًا معزولًا (طلبُ الجولةِ التاسعةِ عشرة): لا أسطرَ لوحاتٍ هنا ولا في شاشةِ
    // الإعداداتِ — سطرٌ واحدٌ يفتحُ صفحةً بتبويبينِ (فاتحةٌ يمينًا، داكنةٌ يسارًا) فيها الجدولُ كلُّهُ،
    // وسطرُ مُحرِّرِ الأدوارِ (preference_highlight) تحتَها كما كانَ، لئلّا تضيعَ قدرةُ تحريرِ الأدوارِ.
    click("theme_gallery_page", p -> {
      startActivity(new Intent(getActivity(), ThemeGalleryActivity.class));
      return true;
    });
    click("preference_highlight", p -> {
      startActivity(new Intent(getActivity(), ThemeActivity.class));
      return true;
    });
    click("preference_quick_key", p -> { promptQuickKey(); return true; });
    change("disable_quickkeybar", (p, v) -> { visual(); return true; });
    change("advanced_setting_editor_font", (p, v) -> { visual(); return true; });
    change("advanced_setting_editor_bg", (p, v) -> { visual(); return true; });
    click("choose_bg_image", p -> {
      Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
      intent.setType("image/*");
      try {
        startActivityForResult(intent, REQUEST_BG_IMAGE);
      } catch (Exception e) {
        Toast.makeText(getActivity(), ui("ui_preferences_no_file_picker"), Toast.LENGTH_SHORT).show();
      }
      return true;
    });
    click("advanced_setting_pref_gradle_config", p -> {
      BuildActions.Delegate d = BuildActions.delegate;
      if (d != null) d.configureGradle();
      return true;
    });
    click("add_proguard_config", p -> {
      BuildActions.Delegate d = BuildActions.delegate;
      if (d != null) d.writeProguardConfig();
      return true;
    });
    // «Gradle completion — One rule per line» كما في المرجعِ: يفتحُ ملفَّ القواعدِ نفسَهُ (يُنشَأُ
    // برأسٍ معلَّقٍ إن غابَ) فلا يبقى الصفُّ رسالةً تعريفيةً؛ والقواعدُ تُطبَّقُ فورَ الحفظِ عبرَ
    // BuildActions.Delegate#openGradleRules ثمَّ AppSettings#applyGradleCompletionRules.
    click("gradle_comple", p -> {
      BuildActions.Delegate d = BuildActions.delegate;
      if (d != null) d.openGradleRules();
      else Toast.makeText(getActivity(), ui("ui_error_open_project_first"), Toast.LENGTH_SHORT).show();
      return true;
    });
    // M1: فئة Maven — المجلد الفعلي في الملخّص، وتحذير عند مجلد غير قابل للكتابة، ومسح المكتبات.
    change(MavenStore.KEY_ENABLE_CUSTOM_DIR, (p, v) -> {
      refreshMavenSummary(Boolean.TRUE.equals(v), null, true);
      return true;
    });
    change(MavenStore.KEY_CUSTOM_DIR, (p, v) -> {
      refreshMavenSummary(null, v == null ? "" : String.valueOf(v), true);
      return true;
    });
    click("shima_clear_maven", p -> { confirmClearMaven(); return true; });
    refreshMavenSummary(null, null, false);
    click("shima_backup", p -> { backup(); return true; });
    click("shima_restore", p -> { restore(); return true; });

    Preference log = findPreference("shima_update_log");
    if (log != null) {
      String detected = "";
      try {
        detected = getActivity().getPackageManager()
            .getPackageInfo(getActivity().getPackageName(), 0).versionName;
      } catch (Exception ignored) {
        // بلا معلومات إصدار
      }
      final String version = detected;
      log.setSummary(version == null ? "" : version);
      log.setOnPreferenceClickListener(p -> {
        info(ui("ui_update_log_title"), uiFormat("ui_update_log_message", version));
        return true;
      });
    }
    click("shima_check_update", p -> {
      info(ui("ui_check_updates_title"), ui("ui_check_updates_message"));
      return true;
    });
    click("aidero_sponsor", p -> {
      info(ui("ui_sponsor_title"), ui("ui_sponsor_message"));
      return true;
    });
  }

  @Override
  public void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (request != REQUEST_BG_IMAGE || result != -1 || data == null || data.getData() == null)
      return;
    String path = data.getData().getPath();
    if (path == null) {
      Toast.makeText(getActivity(), ui("ui_path_set_invalid"), Toast.LENGTH_SHORT).show();
      return;
    }
    AppSettings.prefs(getActivity()).edit().putString("advanced_setting_editor_bg", path).apply();
    Toast.makeText(getActivity(), uiFormat("ui_background_set", path), Toast.LENGTH_SHORT).show();
    visual();
  }

  /** القيم الممرَّرة (غير null) هي الجديدة قبل حفظها؛ وإلا تُقرأ المحفوظة. */
  private void refreshMavenSummary(Boolean enabledValue, String dirValue, boolean warn) {
    SharedPreferences sp = AppSettings.prefs(getActivity());
    boolean enabled = enabledValue != null ? enabledValue : sp.getBoolean(MavenStore.KEY_ENABLE_CUSTOM_DIR, false);
    String dir = dirValue != null ? dirValue : sp.getString(MavenStore.KEY_CUSTOM_DIR, "");
    File noBackup = getActivity().getNoBackupFilesDir();
    File effective = MavenStore.chooseDownloadDir(noBackup, enabled, dir);
    Preference folder = findPreference(MavenStore.KEY_CUSTOM_DIR);
    if (folder != null) folder.setSummary(uiFormat("ui_maven_download_dir_summary", effective.getAbsolutePath()));
    boolean rejected = enabled && dir != null && !dir.trim().isEmpty()
        && effective.equals(MavenStore.defaultDownloadDir(noBackup));
    if (warn && rejected) {
      Toast.makeText(getActivity(), uiFormat("ui_maven_download_dir_invalid", effective.getAbsolutePath()),
          Toast.LENGTH_LONG).show();
    }
    updateMavenSize(effective);
  }

  /**
   * حجم مكتبات المشروع المفتوح وحده (لا المخزن كله)، محسوبًا خارج خيط الواجهة. يُستدعى بمجلد
   * التنزيل الفعلي بعد تغيير الإعداد.
   */
  private void updateMavenSize(final File dir) {
    final Preference clear = findPreference("shima_clear_maven");
    if (clear == null) return;
    final java.util.List<MavenStore.Coordinate> owned = DependencyCycle.state().artifacts();
    new Thread(() -> {
      final long size = owned.isEmpty() ? 0 : new MavenStore(dir, null).sizeOf(owned);
      final android.app.Activity activity = getActivity();
      if (activity == null) return;
      activity.runOnUiThread(() -> {
        if (getActivity() == null) return;
        clear.setSummary(size == 0 ? ui("ui_clear_maven_none")
            : uiFormat("ui_clear_maven_summary", MavenStore.formatSize(size)));
      });
    }, "maven-size").start();
  }

  /**
   * يحذف مكتبات المشروع المفتوح فقط (مجلدات إصدارات أدواته في مجلد التنزيل)؛ مكتبات المشاريع الأخرى
   * والمستودعات المحلية للمستخدم لا تُمسّ. يُعاد حلّ المشروع وتنزيل المفقود عند العودة للمحرر.
   */
  private void confirmClearMaven() {
    final MavenStore store = AppSettings.mavenStore(getActivity());
    final java.util.List<MavenStore.Coordinate> owned = DependencyCycle.state().artifacts();
    if (owned.isEmpty()) {
      Toast.makeText(getActivity(), ui("ui_clear_maven_none"), Toast.LENGTH_SHORT).show();
      return;
    }
    new AlertDialog.Builder(getActivity())
        .setTitle(ui("ui_clear_maven_title"))
        .setMessage(ui("ui_clear_maven_confirm"))
        .setPositiveButton(ui("ui_action_ok"), (d, w) -> new Thread(() -> {
          final int deleted = store.deleteArtifacts(owned);
          DependencyCycle.librariesDeleted();
          final android.app.Activity activity = getActivity();
          if (activity == null) return;
          activity.runOnUiThread(() -> {
            if (getActivity() == null) return;
            Toast.makeText(getActivity(), uiFormat("ui_clear_maven_done", deleted), Toast.LENGTH_SHORT).show();
            updateMavenSize(store.downloadDir());
          });
        }, "maven-clear").start())
        .setNegativeButton(ui("dialog_cancel"), null)
        .show();
  }

  private void visual() {
    BuildActions.Delegate d = BuildActions.delegate;
    if (d != null) d.applyEditorVisual();
  }

  /**
   * أدواتُ الشريطِ السريع: لكلِّ نوعِ ملفٍ سلسلةٌ سطرٌ لكلِّ أداة، كما في المصدر — مُختارُ النوعِ ثم محرِّرٌ
   * متعددُ الأسطر، مع «الافتراضي» الذي يستعيدُ سلسلةَ النوعِ و«حفظ» الذي يعيدُ بناءَ الشريطِ من فوْرِه.
   */
  private void promptQuickKey() {
    migrateLegacyQuickKeySymbols();
    final String[] types = almlk.QuickKeySequences.EDITOR_TYPES;
    new AlertDialog.Builder(getActivity())
        .setTitle(ui("ui_quick_key_choose_title"))
        .setItems(types, (dialog, which) -> editQuickKeySequenceFor(types[which]))
        .setNegativeButton(ui("dialog_cancel"), null)
        .show();
  }

  private void editQuickKeySequenceFor(final String type) {
    final SharedPreferences prefs = AppSettings.prefs(getActivity());
    ScrollView scroll = new ScrollView(getActivity());
    LinearLayout box = new LinearLayout(getActivity());
    box.setOrientation(LinearLayout.VERTICAL);
    int side = (int) (24 * getResources().getDisplayMetrics().density);
    box.setPadding(side, 0, side, 0);
    final EditText edit = new EditText(getActivity());
    edit.setMinLines(5);
    edit.setGravity(Gravity.TOP | Gravity.START);
    edit.setHint(ui("ui_quick_key_line_hint"));
    edit.setText(prefs.getString(type, almlk.QuickKeySequences.defaultSequence(type)));
    box.addView(edit, new LinearLayout.LayoutParams(-1, -2));
    scroll.addView(box, new ScrollView.LayoutParams(-1, -2));
    new AlertDialog.Builder(getActivity())
        .setTitle(ui("ui_quick_key_modify_title") + "(" + type + ")")
        .setView(scroll)
        .setNeutralButton(
            ui("ui_action_default"),
            (dialog, which) -> {
              prefs.edit()
                  .putString(type, almlk.QuickKeySequences.defaultSequence(type))
                  .apply();
              visual();
            })
        .setPositiveButton(
            ui("ui_action_save"),
            (dialog, which) -> {
              prefs.edit().putString(type, edit.getText().toString()).apply();
              visual();
            })
        .setNegativeButton(ui("dialog_cancel"), null)
        .show();
  }

  /** إعدادٌ قديمٌ كان يحفظُ الرموزَ حروفًا متّصلة: تُهاجَرُ مرّةً إلى سطرِ {@code .java} ثم تزول. */
  private void migrateLegacyQuickKeySymbols() {
    SharedPreferences prefs = AppSettings.prefs(getActivity());
    String legacy = prefs.getString("quick_key_symbol", "");
    if (legacy == null || legacy.trim().isEmpty()) return;
    SharedPreferences.Editor editor = prefs.edit();
    for (String type : almlk.QuickKeySequences.EDITOR_TYPES) {
      if (prefs.contains(type)) {
        editor.remove("quick_key_symbol").apply();
        return;
      }
    }
    editor
        .putString(".java", almlk.QuickKeySequences.migrateLegacyCharacters(legacy))
        .remove("quick_key_symbol")
        .apply();
  }

  private void info(String title, String message) {
    new AlertDialog.Builder(getActivity())
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(ui("ui_action_ok"), null)
        .show();
  }

  private File backupFile() {
    return new File(getActivity().getExternalFilesDir(null), "shima_backup.json");
  }

  /** تصدير كل التفضيلات JSON بوسوم أنواع — ملف واحد في مجلد التطبيق الخارجي. */
  private void backup() {
    try {
      Map<String, ?> all = AppSettings.prefs(getActivity()).getAll();
      JSONObject root = new JSONObject();
      for (Map.Entry<String, ?> entry : all.entrySet()) {
        Object value = entry.getValue();
        if (value instanceof Boolean) root.put(entry.getKey(), "B|" + value);
        else if (value instanceof Integer) root.put(entry.getKey(), "I|" + value);
        else if (value instanceof Long) root.put(entry.getKey(), "L|" + value);
        else if (value instanceof Float) root.put(entry.getKey(), "F|" + value);
        else root.put(entry.getKey(), "S|" + value);
      }
      FileOutputStream out = new FileOutputStream(backupFile());
      out.write(root.toString().getBytes("UTF-8"));
      out.close();
      Toast.makeText(getActivity(), uiFormat("ui_backup_created", backupFile().getAbsolutePath()),
          Toast.LENGTH_LONG).show();
    } catch (Exception error) {
      Toast.makeText(getActivity(), ui("ui_backup_failed"), Toast.LENGTH_SHORT).show();
    }
  }

  /** استيراد من ملف النسخة — يُعيد كل مفتاح بنوعه. */
  private void restore() {
    File file = backupFile();
    if (!file.isFile()) {
      Toast.makeText(getActivity(), ui("ui_no_backup_yet"), Toast.LENGTH_SHORT).show();
      return;
    }
    try {
      FileInputStream in = new FileInputStream(file);
      byte[] buffer = new byte[(int) file.length()];
      in.read(buffer);
      in.close();
      JSONObject root = new JSONObject(new String(buffer, "UTF-8"));
      SharedPreferences.Editor editor = AppSettings.prefs(getActivity()).edit();
      java.util.Iterator<String> keys = root.keys();
      if (!keys.hasNext()) throw new Exception("فارغ");
      while (keys.hasNext()) {
        String key = keys.next();
        String tagged = root.getString(key);
        int bar = tagged.indexOf('|');
        if (bar < 1) continue;
        String type = tagged.substring(0, bar);
        String value = tagged.substring(bar + 1);
        if ("B".equals(type)) editor.putBoolean(key, Boolean.parseBoolean(value));
        else if ("I".equals(type)) editor.putInt(key, Integer.parseInt(value));
        else if ("L".equals(type)) editor.putLong(key, Long.parseLong(value));
        else if ("F".equals(type)) editor.putFloat(key, Float.parseFloat(value));
        else editor.putString(key, value);
      }
      editor.apply();
      Toast.makeText(getActivity(), ui("ui_preferences_restored"), Toast.LENGTH_LONG).show();
      visual();
    } catch (Exception error) {
      Toast.makeText(getActivity(), ui("ui_restore_invalid_backup"), Toast.LENGTH_SHORT).show();
    }
  }
  /** سطرُ القسمِ المعزولِ يحملُ الثيمَ الجاريَ نفسَهُ: اسمُهُ ولوحةُ نمطِهِ، ليعرفَ ما سيُغلِقُهُ الرجوعُ. */
  @Override
  public void onResume() {
    super.onResume();
    Preference entry = findPreference("theme_gallery_page");
    if (entry != null && getActivity() != null) {
      ThemeConfig theme = new ThemeConfig(getActivity());
      entry.setSummary(
          getString(
              R.string.theme_gallery_row_summary,
              ThemeNames.title(getActivity(), theme.themeCode()),
              theme.schemeName(getActivity())));
    }
  }

}
