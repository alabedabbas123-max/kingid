package com.almlkid.ui.preferences;

import android.app.Activity;
import android.os.Bundle;
import android.preference.ListPreference;
import android.view.View;
import almlk.AppSettings;
import com.shima.demo.R;

/**
 * قسم Application — اللغة والتبويبات والسحب والتحليلات. والثيمُ لم يعُدْ هنا: صارَ قسمًا معزولًا في
 * الإعداداتِ المتقدمةِ يفتحُ صفحةَ الثيماتِ بتبويبينِ (طلبُ الجولةِ التاسعةِ عشرة)، فلا سطرَ ثيمٍ
 * يُكرِّرُ نفسَهُ في شاشتَينِ.
 */
public class ApplicationPreferencesFragment extends BasePreferenceFragment {

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    addPreferencesFromResource(R.xml.preferences_application);
    ListPreference language = (ListPreference) findPreference(AppSettings.KEY_LANGUAGE);
    if (language != null) {
      language.setOnPreferenceChangeListener(
          (preference, value) -> {
            Activity host = getActivity();
            if (host == null || value == null) return true;
            // Let ListPreference persist the selected value first, then recreate the Activity.
            // Its attachBaseContext wrapper will build a fresh resource context for that locale.
            View anchor = getView();
            if (anchor == null) anchor = host.getWindow().getDecorView();
            anchor.post(
                () -> {
                  if (!host.isFinishing()) host.recreate();
                });
            return true;
          });
    }
  }
}
