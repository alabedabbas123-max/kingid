package com.almlkid.ui.tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Toast;
import almlk.JsonBeanGenerator;
import almlk.JsonText;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * أدوات › أخرى › Json2Bean: الحزمة (من المشروع) واسم الصنف ونص JSON؛ «توليد» (تصدير إلى ملف
 * Java، أو إضافة إلى المحرر، أو معاينة)، و«تنسيق» (ضغط/تنسيق)، و«إعداد» بالخيارات السبعة المحفوظة.
 */
public final class JsonBeanDialog {

  /** ما تحتاجه الأداة من الشاشة الرئيسية. */
  public interface Host {
    /** يُدرج النص عند المؤشر في المحرر الحالي؛ false إن لم يكن هناك ملف قابل للكتابة. */
    boolean insertIntoEditor(String text);

    /** يُبلَّغ بملف أُنشئ (لفتحه وتحديث المتصفح). */
    void fileCreated(File file);
  }

  private static final String PREFS = "json2bean";
  private static final String[] OPTION_KEYS = {"set", "get", "sort", "public", "array", "integer", "tostring"};
  private static final String[] OPTION_LABELS = {
    "tools_json_opt_set", "tools_json_opt_get", "tools_json_opt_sort", "tools_json_opt_public",
    "tools_json_opt_array", "tools_json_opt_integer", "tools_json_opt_tostring"
  };
  private static final boolean[] OPTION_DEFAULTS = {true, true, false, false, false, false, false};

  private JsonBeanDialog() {}

  public static void show(final Activity activity, String packageName, final File javaRoot, final Host host) {
    LinearLayout box = ToolDialogs.column(activity);
    final EditText pkg = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_json_package"), packageName, false);
    final EditText cls = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_json_class"), null, false);
    final EditText json = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_json_hint"), null, true);
    box.addView(pkg, new LinearLayout.LayoutParams(-1, -2));
    box.addView(cls, new LinearLayout.LayoutParams(-1, -2));
    box.addView(json, new LinearLayout.LayoutParams(-1, -2));
    ScrollView scroll = new ScrollView(activity);
    scroll.addView(box);
    final AlertDialog dialog =
        new AlertDialog.Builder(activity)
            .setTitle("Json2Bean")
            .setView(scroll)
            .setPositiveButton(ToolDialogs.ui(activity, "tools_json_generate"), null)
            .setNegativeButton(ToolDialogs.ui(activity, "tools_json_format"), null)
            .setNeutralButton(ToolDialogs.ui(activity, "tools_json_configure"), null)
            .create();
    dialog.show();
    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> configure(activity));
    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
      PopupMenu menu = new PopupMenu(activity, v);
      menu.getMenu().add(0, 1, 0, ToolDialogs.ui(activity, "tools_json_compress"));
      menu.getMenu().add(0, 2, 1, ToolDialogs.ui(activity, "tools_json_pretty"));
      menu.setOnMenuItemClickListener(item -> {
        try {
          String text = json.getText().toString();
          json.setText(item.getItemId() == 1 ? JsonText.compact(text) : JsonText.pretty(text, 2));
        } catch (JsonText.SyntaxError e) {
          json.setError(ToolDialogs.uiFormat(activity, "tools_json_error", e.getMessage()));
        }
        return true;
      });
      menu.show();
    });
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
      final String className = cls.getText().toString().trim();
      final String source = generate(activity, json, pkg.getText().toString().trim(), className);
      if (source == null) return;
      PopupMenu menu = new PopupMenu(activity, v);
      menu.getMenu().add(0, 1, 0, ToolDialogs.ui(activity, "tools_json_export"));
      menu.getMenu().add(0, 2, 1, ToolDialogs.ui(activity, "tools_json_add_editor"));
      menu.getMenu().add(0, 3, 2, ToolDialogs.ui(activity, "tools_json_preview"));
      menu.getMenu().findItem(1).setEnabled(!className.isEmpty());
      menu.setOnMenuItemClickListener(item -> {
        if (item.getItemId() == 1) {
          export(activity, javaRoot, pkg.getText().toString().trim(), className, source, host);
        } else if (item.getItemId() == 2) {
          if (host.insertIntoEditor(source)) dialog.dismiss();
          else Toast.makeText(activity, ToolDialogs.ui(activity, "ui_open_file_first"), Toast.LENGTH_SHORT).show();
        } else {
          ToolDialogs.showText(activity, ToolDialogs.ui(activity, "tools_json_preview"), source);
        }
        return true;
      });
      menu.show();
    });
  }

  private static String generate(Activity activity, EditText json, String pkg, String className) {
    JsonBeanGenerator.Options options = options(activity);
    options.packageName = pkg.isEmpty() ? null : pkg;
    options.className = className.isEmpty() ? null : className;
    try {
      return JsonBeanGenerator.generate(json.getText().toString(), options);
    } catch (JsonText.SyntaxError e) {
      json.setError(ToolDialogs.uiFormat(activity, "tools_json_error", e.getMessage()));
    } catch (IllegalArgumentException e) {
      json.setError(ToolDialogs.uiFormat(activity, "tools_json_error", e.getMessage()));
    }
    return null;
  }

  static JsonBeanGenerator.Options options(Context context) {
    SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    JsonBeanGenerator.Options o = new JsonBeanGenerator.Options();
    o.setters = p.getBoolean("set", true);
    o.getters = p.getBoolean("get", true);
    o.sortMethods = p.getBoolean("sort", false);
    o.publicFields = p.getBoolean("public", false);
    o.useArrays = p.getBoolean("array", false);
    o.useInteger = p.getBoolean("integer", false);
    o.toString = p.getBoolean("tostring", false);
    return o;
  }

  private static void configure(final Activity activity) {
    final SharedPreferences p = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    String[] labels = new String[OPTION_KEYS.length];
    final boolean[] checked = new boolean[OPTION_KEYS.length];
    for (int i = 0; i < labels.length; i++) {
      labels[i] = ToolDialogs.ui(activity, OPTION_LABELS[i]);
      checked[i] = p.getBoolean(OPTION_KEYS[i], OPTION_DEFAULTS[i]);
    }
    new AlertDialog.Builder(activity)
        .setTitle(ToolDialogs.ui(activity, "tools_json_configure"))
        .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
        .setPositiveButton(android.R.string.ok, (d, w) -> {
          SharedPreferences.Editor e = p.edit();
          for (int i = 0; i < OPTION_KEYS.length; i++) e.putBoolean(OPTION_KEYS[i], checked[i]);
          e.apply();
        })
        .setNegativeButton(android.R.string.cancel, null)
        .show();
  }

  private static void export(final Activity activity, File javaRoot, String pkg, String className,
      final String source, final Host host) {
    File base = javaRoot != null ? javaRoot : activity.getExternalFilesDir(null);
    File dir = pkg.isEmpty() || javaRoot == null ? base : new File(base, pkg.replace('.', '/'));
    LinearLayout box = ToolDialogs.column(activity);
    final EditText name = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_json_file_name"), className + ".java", false);
    final EditText path = ToolDialogs.field(activity, ToolDialogs.ui(activity, "tools_json_path"),
        dir == null ? "" : dir.getAbsolutePath(), false);
    box.addView(name, new LinearLayout.LayoutParams(-1, -2));
    box.addView(path, new LinearLayout.LayoutParams(-1, -2));
    box.addView(ToolDialogs.button(activity, ToolDialogs.ui(activity, "tools_json_select_path"),
        (View v) -> ToolDialogs.pickFolder(activity, new File(path.getText().toString()),
            chosen -> path.setText(chosen.getAbsolutePath()))));
    new AlertDialog.Builder(activity)
        .setTitle(ToolDialogs.ui(activity, "tools_json_export"))
        .setView(box)
        .setPositiveButton(android.R.string.ok, (d, w) -> {
          String fileName = name.getText().toString().trim();
          if (fileName.isEmpty()) return;
          if (!fileName.endsWith(".java")) fileName += ".java";
          final File target = new File(path.getText().toString().trim(), fileName);
          Runnable write = () -> {
            try {
              File parent = target.getParentFile();
              if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new java.io.IOException(parent.getPath());
              Files.write(target.toPath(), source.getBytes(StandardCharsets.UTF_8));
              Toast.makeText(activity, ToolDialogs.uiFormat(activity, "tools_json_exported", target.getAbsolutePath()),
                  Toast.LENGTH_LONG).show();
              host.fileCreated(target);
            } catch (java.io.IOException e) {
              Toast.makeText(activity, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
            }
          };
          if (target.exists()) {
            new AlertDialog.Builder(activity)
                .setMessage(ToolDialogs.uiFormat(activity, "tools_overwrite_confirm", target.getName()))
                .setPositiveButton(android.R.string.ok, (d2, w2) -> write.run())
                .setNegativeButton(android.R.string.cancel, null)
                .show();
          } else {
            write.run();
          }
        })
        .setNegativeButton(android.R.string.cancel, null)
        .show();
  }
}
