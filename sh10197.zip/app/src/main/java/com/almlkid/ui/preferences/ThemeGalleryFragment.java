package com.almlkid.ui.preferences;

import almlk.EditorThemePresets;
import android.os.Bundle;
import android.preference.PreferenceCategory;
import com.shima.demo.R;

/**
 * شظيةُ تبويبٍ واحدٍ من صفحةِ الثيماتِ ({@link com.shima.demo.ThemeGalleryActivity}): فاتحةٌ أو
 * داكنةٌ — **شظيةٌ واحدةٌ للوحتينِ** بوسيطٍ، لا صنفانِ يتكرَّرُ فيهما التضخيمُ والملءُ والتحديثُ،
 * فمسارُ الثيماتِ واحدٌ كما هو مطلبُ البندِ الرابعِ من اتفاقِ العملِ.
 *
 * <p>الأسطرُ من {@link EditorThemePresets} وحدَهُ ({@link ThemePresetSection#fill}) فتُولَّدُ لا
 * تُنسَخ: لا عددَ مكتوبًا في الشيفرةِ ولا ثيمًا منسيًّا، والنقرُ يُطبِّقُ فورًا. والمجموعةُ مُعلَنةٌ في
 * XML — كما في الإعداداتِ كلِّها — فيكونُ **مكانُها** في التخطيطِ لا في الكودِ، وتصلُ إلى مديرِ
 * التفضيلاتِ مع تضخيمِ الشاشةِ قبلَ أن نُلحِقَ بها سطرًا (وهو ما يُغلِقُ علّةَ 1.0.140 هنا أيضًا).
 */
public class ThemeGalleryFragment extends BasePreferenceFragment {

  /** {@code true} للوحةٍ داكنةٍ؛ والافتراضيُّ (بلا وسائطَ) فاتحةٌ — أولُ تبويبٍ في الصفحةِ. */
  private static final String ARG_DARK = "theme_gallery_panel_dark";

  private ThemePresetSection.Handle section;

  public static ThemeGalleryFragment newInstance(boolean dark) {
    ThemeGalleryFragment fragment = new ThemeGalleryFragment();
    Bundle args = new Bundle(1);
    args.putBoolean(ARG_DARK, dark);
    fragment.setArguments(args);
    return fragment;
  }

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    boolean dark = getArguments() != null && getArguments().getBoolean(ARG_DARK);
    addPreferencesFromResource(
        dark ? R.xml.preferences_theme_dark : R.xml.preferences_theme_light);
    PreferenceCategory category =
        (PreferenceCategory) findPreference(dark ? "theme_section_dark" : "theme_section_light");
    if (category != null) {
      section =
          ThemePresetSection.fill(
              category,
              getActivity(),
              dark ? EditorThemePresets.DARK : EditorThemePresets.LIGHT);
    }
  }

  /** «المُطبَّقُ» وشريطُ كلِّ ثيمٍ يتحدّثانِ عندَ كلِّ رجوعٍ من مُحرِّرِ الأدوارِ لا عندَ البناءِ وحدَهُ. */
  @Override
  public void onResume() {
    super.onResume();
    if (section != null) section.refresh();
  }
}
