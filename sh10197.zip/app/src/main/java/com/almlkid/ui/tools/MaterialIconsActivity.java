package com.almlkid.ui.tools;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.LruCache;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import almlk.MaterialIconCatalog;
import almlk.MavenDownloader;
import almlk.MavenResolver;
import almlk.SvgPathParser;
import com.shima.demo.LocaleAwareActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * أدوات › Material Icons: تنزيل أرشيف الأيقونات مرة واحدة، وشبكة بحث (الاسم والأسماء البديلة)،
 * وفئات، وإضافة الأيقونة إلى المشروع أو تصديرها PNG/Vector/SVG، وتحويلها نصًا. الرسم بمحلّل
 * مسارات SVG الخاص بنا إلى {@link Path} مباشرة (بلا مكتبة SVG وبلا صور وسيطة).
 */
public final class MaterialIconsActivity extends LocaleAwareActivity {

  /** مجلد res لوحدة المشروع الحالية (اختياري؛ بدونه تُعطَّل «إضافة إلى المشروع»). */
  public static final String EXTRA_RES_DIR = "res_dir";
  private static final int MENU_CATEGORY = 1;
  private static final int[] SIZES = {48, 72, 96, 144, 192, 512};
  private static final String[] DENSITIES = {"mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"};
  private static final float[] DENSITY_SCALE = {0.25f, 0.375f, 0.5f, 0.75f, 1f};

  private MaterialIconCatalog catalog;
  private String category = MaterialIconCatalog.ALL;
  private List<MaterialIconCatalog.Icon> shown = Collections.emptyList();
  private final LruCache<String, Path> paths = new LruCache<>(800);
  private EditText search;
  private GridView grid;
  private TextView empty;
  private LinearLayout status;
  private TextView statusText;
  private ProgressBar statusBar;
  private Button retry;
  private File resDir;
  private int tint;
  private int highlight;
  private volatile boolean destroyed;
  private final IconAdapter adapter = new IconAdapter();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    String res = getIntent().getStringExtra(EXTRA_RES_DIR);
    resDir = res == null ? null : new File(res);
    setTitle(ToolDialogs.ui(this, "tools_icons_title"));
    if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
    TypedArray a = obtainStyledAttributes(new int[] {android.R.attr.textColorPrimary, android.R.attr.colorAccent});
    tint = a.getColor(0, Color.WHITE);
    highlight = a.getColor(1, 0xFF2196F3);
    a.recycle();

    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    search = new EditText(this);
    search.setSingleLine(true);
    search.setEnabled(false);
    search.setHint(ToolDialogs.ui(this, "tools_icons_loading"));
    int pad = ToolDialogs.dp(this, 8);
    LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, -2);
    searchParams.setMargins(pad, pad / 2, pad, 0);
    root.addView(search, searchParams);
    FrameLayout frame = new FrameLayout(this);
    grid = new GridView(this);
    grid.setColumnWidth(ToolDialogs.dp(this, 84));
    grid.setNumColumns(GridView.AUTO_FIT);
    grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
    grid.setVerticalSpacing(ToolDialogs.dp(this, 4));
    grid.setFastScrollEnabled(true);
    grid.setPadding(pad, pad, pad, pad);
    grid.setClipToPadding(false);
    grid.setAdapter(adapter);
    frame.addView(grid, new FrameLayout.LayoutParams(-1, -1));
    empty = new TextView(this);
    empty.setText(ToolDialogs.ui(this, "tools_icons_empty"));
    empty.setGravity(Gravity.CENTER);
    empty.setPadding(pad * 3, 0, pad * 3, 0);
    empty.setVisibility(View.GONE);
    frame.addView(empty, new FrameLayout.LayoutParams(-1, -1));
    status = new LinearLayout(this);
    status.setOrientation(LinearLayout.VERTICAL);
    status.setGravity(Gravity.CENTER);
    statusBar = new ProgressBar(this);
    statusText = new TextView(this);
    statusText.setGravity(Gravity.CENTER);
    statusText.setPadding(pad * 3, pad, pad * 3, pad);
    retry = ToolDialogs.button(this, ToolDialogs.ui(this, "tools_icons_retry"), v -> load());
    retry.setVisibility(View.GONE);
    status.addView(statusBar);
    status.addView(statusText);
    status.addView(retry);
    frame.addView(status, new FrameLayout.LayoutParams(-1, -1));
    root.addView(frame, new LinearLayout.LayoutParams(-1, 0, 1));
    setContentView(root);

    search.addTextChangedListener(new TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int a1, int a2, int a3) {}
      @Override public void onTextChanged(CharSequence s, int a1, int a2, int a3) {}
      @Override public void afterTextChanged(Editable s) {
        refresh();
      }
    });
    grid.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) ->
        showActions(view, shown.get(position)));
    load();
  }

  private File archive() {
    return new File(getFilesDir(), "material_icons.zip");
  }

  private void load() {
    retry.setVisibility(View.GONE);
    statusBar.setVisibility(View.VISIBLE);
    status.setVisibility(View.VISIBLE);
    statusText.setText(ToolDialogs.ui(this, "tools_icons_loading"));
    new Thread(() -> {
      File file = archive();
      MaterialIconCatalog opened = null;
      String error = null;
      try {
        if (file.isFile()) {
          try {
            opened = MaterialIconCatalog.open(file);
          } catch (IOException damaged) {
            file.delete();
          }
        }
        if (opened == null) {
          new MavenDownloader(15000, 30000, 2).fetch(MaterialIconCatalog.ARCHIVE_URL, file, false,
              new MavenResolver.Progress() {
                long lastShown = -1;

                @Override
                public void bytes(long done, long total) {
                  long percent = total > 0 ? done * 100 / total : -1;
                  if (percent == lastShown) return;
                  lastShown = percent;
                  final String text = percent >= 0
                      ? ToolDialogs.uiFormat(MaterialIconsActivity.this, "tools_icons_downloading", (int) percent)
                      : ToolDialogs.uiFormat(MaterialIconsActivity.this, "tools_icons_downloading_bytes", done / 1024);
                  runOnUiThread(() -> statusText.setText(text));
                }

                @Override
                public boolean cancelled() {
                  return destroyed;
                }
              });
          if (!file.isFile()) throw new IOException("HTTP 404");
          opened = MaterialIconCatalog.open(file);
        }
      } catch (Exception e) {
        error = String.valueOf(e.getMessage());
      }
      final MaterialIconCatalog result = opened;
      final String failure = error;
      runOnUiThread(() -> {
        if (destroyed) {
          closeQuietly(result);
          return;
        }
        if (result == null) {
          statusBar.setVisibility(View.GONE);
          statusText.setText(ToolDialogs.uiFormat(this, "tools_icons_download_failed", failure));
          retry.setVisibility(View.VISIBLE);
          return;
        }
        catalog = result;
        status.setVisibility(View.GONE);
        search.setEnabled(true);
        search.setHint(ToolDialogs.uiFormat(this, "tools_icons_search", catalog.icons().size()));
        refresh();
        invalidateOptionsMenu();
      });
    }, "MaterialIcons").start();
  }

  private static void closeQuietly(MaterialIconCatalog c) {
    if (c == null) return;
    try {
      c.close();
    } catch (IOException ignored) {
      // لا شيء.
    }
  }

  private void refresh() {
    if (catalog == null) return;
    shown = catalog.filter(category, search.getText().toString());
    adapter.notifyDataSetChanged();
    empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
    if (getActionBar() != null) getActionBar().setSubtitle(MaterialIconCatalog.ALL.equals(category) ? null : label(category));
  }

  private String label(String c) {
    if (MaterialIconCatalog.ALL.equals(c)) return ToolDialogs.ui(this, "tools_icons_all");
    if (MaterialIconCatalog.OTHER.equals(c)) return ToolDialogs.ui(this, "tools_icons_other");
    return c;
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuItem item = menu.add(0, MENU_CATEGORY, 0, ToolDialogs.ui(this, "tools_icons_category"));
    item.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
    item.setEnabled(catalog != null);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      finish();
      return true;
    }
    if (item.getItemId() == MENU_CATEGORY && catalog != null) {
      final List<String> categories = catalog.categories();
      String[] labels = new String[categories.size()];
      for (int i = 0; i < labels.length; i++) labels[i] = label(categories.get(i));
      new AlertDialog.Builder(this)
          .setTitle(ToolDialogs.ui(this, "tools_icons_category"))
          .setSingleChoiceItems(labels, Math.max(0, categories.indexOf(category)), (d, which) -> {
            category = categories.get(which);
            d.dismiss();
            refresh();
          })
          .show();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  protected void onDestroy() {
    destroyed = true;
    closeQuietly(catalog);
    catalog = null;
    super.onDestroy();
  }

  /** مسار الأيقونة (24×24) من الذاكرة المؤقتة أو بتحليل بيانات SVG. */
  Path path(MaterialIconCatalog.Icon icon) {
    Path cached = paths.get(icon.name);
    if (cached != null) return cached;
    final Path path = new Path();
    try {
      SvgPathParser.parse(catalog.pathData(icon), new SvgPathParser.Sink() {
        @Override public void moveTo(float x, float y) { path.moveTo(x, y); }
        @Override public void lineTo(float x, float y) { path.lineTo(x, y); }
        @Override public void quadTo(float x1, float y1, float x, float y) { path.quadTo(x1, y1, x, y); }
        @Override public void cubicTo(float x1, float y1, float x2, float y2, float x, float y) {
          path.cubicTo(x1, y1, x2, y2, x, y);
        }
        @Override public void close() { path.close(); }
      });
    } catch (IOException | SvgPathParser.PathError broken) {
      path.reset();
    }
    paths.put(icon.name, path);
    return path;
  }

  /** رسم مسار 24×24 بحجم الحدود ولون واحد. */
  static final class IconDrawable extends Drawable {
    private final Path path;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    IconDrawable(Path path, int color) {
      this.path = path;
      paint.setColor(color);
      paint.setStyle(Paint.Style.FILL);
    }

    @Override
    public void draw(Canvas canvas) {
      int save = canvas.save();
      canvas.translate(getBounds().left, getBounds().top);
      canvas.scale(getBounds().width() / 24f, getBounds().height() / 24f);
      canvas.drawPath(path, paint);
      canvas.restoreToCount(save);
    }

    @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
    @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
  }

  private final class IconAdapter extends BaseAdapter {
    @Override public int getCount() { return shown.size(); }
    @Override public Object getItem(int position) { return shown.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      LinearLayout cell = (LinearLayout) convertView;
      if (cell == null) {
        Context c = MaterialIconsActivity.this;
        cell = new LinearLayout(c);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = ToolDialogs.dp(c, 6);
        cell.setPadding(pad, pad, pad, pad);
        ImageView image = new ImageView(c);
        int size = ToolDialogs.dp(c, 32);
        cell.addView(image, new LinearLayout.LayoutParams(size, size));
        TextView name = new TextView(c);
        name.setTextSize(13);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        name.setPadding(0, pad / 2, 0, 0);
        cell.addView(name, new LinearLayout.LayoutParams(-1, -2));
      }
      MaterialIconCatalog.Icon icon = shown.get(position);
      ((ImageView) cell.getChildAt(0)).setImageDrawable(new IconDrawable(path(icon), tint));
      ((TextView) cell.getChildAt(1)).setText(highlighted(icon));
      return cell;
    }
  }

  private CharSequence highlighted(MaterialIconCatalog.Icon icon) {
    MaterialIconCatalog.Match m = MaterialIconCatalog.match(icon, search.getText().toString());
    if (m == null) return icon.name;
    String text = m.alias < 0 ? icon.name : icon.name + "\n(" + icon.aliases.get(m.alias) + ")";
    int offset = m.alias < 0 ? 0 : icon.name.length() + 2;
    SpannableString span = new SpannableString(text);
    span.setSpan(new ForegroundColorSpan(highlight), offset + m.start, offset + m.end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    return span;
  }

  // ---- الإجراءات ----

  private void showActions(View anchor, final MaterialIconCatalog.Icon icon) {
    PopupMenu popup = new PopupMenu(this, anchor);
    Menu menu = popup.getMenu();
    boolean canAdd = resDir != null && resDir.isDirectory();
    SubMenu add = menu.addSubMenu(0, 0, 0, ToolDialogs.ui(this, "tools_icons_add"));
    add.add(0, 11, 0, "PNG").setEnabled(canAdd);
    add.add(0, 12, 1, "Vector").setEnabled(canAdd);
    add.getItem().setEnabled(canAdd);
    SubMenu export = menu.addSubMenu(0, 0, 1, ToolDialogs.ui(this, "tools_icons_export"));
    export.add(0, 21, 0, "PNG");
    export.add(0, 22, 1, "Vector");
    export.add(0, 23, 2, "SVG");
    menu.add(0, 31, 2, ToolDialogs.ui(this, "tools_icons_to_svg"));
    menu.add(0, 32, 3, ToolDialogs.ui(this, "tools_icons_to_vector"));
    popup.setOnMenuItemClickListener(item -> {
      try {
        switch (item.getItemId()) {
          case 11: pngDialog(icon, true); break;
          case 12: vectorDialog(icon, true); break;
          case 21: pngDialog(icon, false); break;
          case 22: vectorDialog(icon, false); break;
          case 23: {
            File out = new File(exportDir("svg"), icon.name + ".svg");
            write(out, MaterialIconCatalog.svg(catalog.pathData(icon)));
            toast("tools_icons_exported", out.getAbsolutePath());
            break;
          }
          case 31:
            ToolDialogs.showText(this, icon.name + ".svg", MaterialIconCatalog.svg(catalog.pathData(icon)));
            break;
          case 32:
            ToolDialogs.showText(this, MaterialIconCatalog.resourceName(icon.name) + ".xml",
                MaterialIconCatalog.vectorXml(catalog.pathData(icon), 0xFF000000, 24));
            break;
          default:
            return false;
        }
      } catch (IOException e) {
        Toast.makeText(this, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
      }
      return true;
    });
    popup.show();
  }

  /** مجلد التصدير Pictures/Icon/&lt;kind&gt; (أو مجلد التطبيق الخارجي إن تعذّر). */
  private File exportDir(String kind) throws IOException {
    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Icon/" + kind);
    if (dir.isDirectory() || dir.mkdirs()) return dir;
    File fallback = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Icon/" + kind);
    if (fallback.isDirectory() || fallback.mkdirs()) return fallback;
    throw new IOException(dir.getPath());
  }

  private static void write(File file, String text) throws IOException {
    File parent = file.getParentFile();
    if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException(parent.getPath());
    Files.write(file.toPath(), text.getBytes(StandardCharsets.UTF_8));
  }

  private void toast(String key, String path) {
    Toast.makeText(this, ToolDialogs.uiFormat(this, key, path), Toast.LENGTH_LONG).show();
  }

  private void added(File file) {
    toast("tools_icons_added", file.getAbsolutePath());
    setResult(RESULT_OK, new Intent().putExtra("file", file.getAbsolutePath()));
  }

  private static boolean validName(String name) {
    return name.matches("[a-z][a-z0-9_]*");
  }

  private void vectorDialog(final MaterialIconCatalog.Icon icon, final boolean toProject) {
    LinearLayout box = ToolDialogs.column(this);
    final EditText name = ToolDialogs.field(this, ToolDialogs.ui(this, "icon_name_label"),
        MaterialIconCatalog.resourceName(icon.name), false);
    box.addView(name, new LinearLayout.LayoutParams(-1, -2));
    final AlertDialog dialog = new AlertDialog.Builder(this)
        .setTitle("Vector")
        .setView(box)
        .setPositiveButton(android.R.string.ok, null)
        .setNegativeButton(android.R.string.cancel, null)
        .create();
    dialog.show();
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
      String n = name.getText().toString().trim();
      if (n.endsWith(".xml")) n = n.substring(0, n.length() - 4);
      if (!validName(n)) {
        name.setError(ToolDialogs.ui(this, "tools_icons_bad_name"));
        return;
      }
      try {
        String xml = MaterialIconCatalog.vectorXml(catalog.pathData(icon), 0xFF000000, 24);
        File out = toProject ? new File(resDir, "drawable/" + n + ".xml") : new File(exportDir("vector"), n + ".xml");
        write(out, xml);
        dialog.dismiss();
        if (toProject) added(out);
        else toast("tools_icons_exported", out.getAbsolutePath());
      } catch (IOException e) {
        Toast.makeText(this, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
      }
    });
  }

  private void pngDialog(final MaterialIconCatalog.Icon icon, final boolean toProject) {
    LinearLayout box = ToolDialogs.column(this);
    final EditText name = ToolDialogs.field(this, ToolDialogs.ui(this, "icon_name_label"),
        MaterialIconCatalog.resourceName(icon.name) + ".png", false);
    box.addView(name, new LinearLayout.LayoutParams(-1, -2));
    final int[] color = {0xFF757575};
    final Button colorButton = new Button(this);
    colorButton.setAllCaps(false);
    final Runnable paintButton = () -> {
      colorButton.setText(ToolDialogs.ui(this, "tools_icons_color") + "  " + String.format("#%08X", color[0]));
      colorButton.setCompoundDrawablesRelativeWithIntrinsicBounds(swatch(color[0]), null, null, null);
    };
    paintButton.run();
    colorButton.setOnClickListener(v -> {
      net.margaritov.preference.colorpicker.ColorPickerDialog picker =
          new net.margaritov.preference.colorpicker.ColorPickerDialog(this, color[0]);
      picker.setTitle(ToolDialogs.ui(this, "tools_icons_color"));
      picker.setAlphaSliderVisible(true);
      picker.setHexValueEnabled(true);
      picker.setOnColorChangedListener(c -> {
        color[0] = c;
        paintButton.run();
      });
      picker.show();
    });
    box.addView(colorButton, new LinearLayout.LayoutParams(-1, -2));
    TextView sizeLabel = new TextView(this);
    sizeLabel.setText(ToolDialogs.ui(this, "tools_icons_size"));
    sizeLabel.setPadding(0, ToolDialogs.dp(this, 8), 0, 0);
    box.addView(sizeLabel);
    List<String> sizes = new ArrayList<>();
    for (int s : SIZES) sizes.add(s + " × " + s);
    sizes.add(ToolDialogs.ui(this, "tools_icons_custom"));
    final Spinner size = new Spinner(this);
    size.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sizes));
    size.setSelection(2);
    box.addView(size, new LinearLayout.LayoutParams(-1, -2));
    final EditText custom = ToolDialogs.field(this, "px", "256", false);
    custom.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
    custom.setVisibility(View.GONE);
    box.addView(custom, new LinearLayout.LayoutParams(-1, -2));
    size.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
      @Override public void onItemSelected(AdapterView<?> p, View v, int position, long id) {
        custom.setVisibility(position == SIZES.length ? View.VISIBLE : View.GONE);
      }
      @Override public void onNothingSelected(AdapterView<?> p) {}
    });
    final CheckBox adaptive = new CheckBox(this);
    adaptive.setText(ToolDialogs.ui(this, "tools_icons_adaptive"));
    box.addView(adaptive);
    android.widget.ScrollView scroll = new android.widget.ScrollView(this);
    scroll.addView(box);
    final AlertDialog dialog = new AlertDialog.Builder(this)
        .setTitle("PNG")
        .setView(scroll)
        .setPositiveButton(android.R.string.ok, null)
        .setNegativeButton(android.R.string.cancel, null)
        .create();
    dialog.show();
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
      String n = name.getText().toString().trim();
      if (n.endsWith(".png")) n = n.substring(0, n.length() - 4);
      if (!validName(n)) {
        name.setError(ToolDialogs.ui(this, "tools_icons_bad_name"));
        return;
      }
      int px;
      if (size.getSelectedItemPosition() < SIZES.length) {
        px = SIZES[size.getSelectedItemPosition()];
      } else {
        try {
          px = Integer.parseInt(custom.getText().toString().trim());
        } catch (NumberFormatException e) {
          px = -1;
        }
        if (px < 1 || px > 2048) {
          custom.setError(ToolDialogs.ui(this, "tools_icons_bad_size"));
          return;
        }
      }
      try {
        Path path = path(icon);
        File base = toProject ? resDir : exportDir("png");
        File last;
        if (adaptive.isChecked()) {
          last = null;
          for (int i = 0; i < DENSITIES.length; i++) {
            int s = Math.max(1, Math.round(px * DENSITY_SCALE[i]));
            last = new File(base, "drawable-" + DENSITIES[i] + "/" + n + ".png");
            savePng(path, color[0], s, last);
          }
        } else {
          last = new File(toProject ? new File(base, "drawable") : base, n + ".png");
          savePng(path, color[0], px, last);
        }
        dialog.dismiss();
        if (toProject) added(adaptive.isChecked() ? last.getParentFile().getParentFile() : last);
        else toast("tools_icons_exported", adaptive.isChecked() ? base.getAbsolutePath() : last.getAbsolutePath());
      } catch (IOException e) {
        Toast.makeText(this, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
      }
    });
  }

  private Drawable swatch(int color) {
    android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
    d.setColor(color);
    d.setStroke(ToolDialogs.dp(this, 1), 0x80808080);
    int s = ToolDialogs.dp(this, 20);
    d.setSize(s, s);
    d.setBounds(0, 0, s, s);
    return d;
  }

  private static void savePng(Path path, int color, int size, File out) throws IOException {
    Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
    IconDrawable drawable = new IconDrawable(path, color);
    drawable.setBounds(0, 0, size, size);
    drawable.draw(new Canvas(bitmap));
    File parent = out.getParentFile();
    if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException(parent.getPath());
    try (FileOutputStream stream = new FileOutputStream(out)) {
      if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw new IOException(out.getPath());
    } finally {
      bitmap.recycle();
    }
  }
}
