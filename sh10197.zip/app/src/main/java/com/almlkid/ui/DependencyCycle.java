package com.almlkid.ui;

import almlk.AppSettings;
import almlk.GradleBuildModel;
import almlk.MavenDownloader;
import almlk.MavenResolver;
import almlk.MavenStore;
import almlk.ProjectLibraries;
import android.app.Activity;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * دورة مكتبات المشروع (M3) كالمرجع: عند الفتح وعند حفظ ملف بناء — فحص محلي بلا شبكة؛ إن وُجد كل شيء
 * يُحقن بصمت بلا أي حوار، وإلا يبدأ حوار التنزيل تلقائيًا وتبقى الأسطر المفقودة بتموّج أحمر حتى
 * النجاح. الفشل أو الإلغاء يُبقي التموّج برسالة سببه. التحديث (الإعدادات) وRefresh Build تفاعليان.
 */
public final class DependencyCycle {

  public enum Mode {
    /** فتح المشروع: صامت إن وُجد كل شيء. */
    OPEN,
    /** حفظ ملف بناء: كالفتح، ولا عمل إن لم تتغيّر البصمة. */
    SAVE,
    /** الإعدادات › تحديث مستودع Maven: إعادة تنزيل كل الملفات. */
    REFRESH,
    /** Project › Refresh Build: إعادة الحلّ وجلب metadata للإصدارات الديناميكية. */
    REFRESH_BUILD
  }

  public interface Host {
    /** نص ملف الوحدة الحي إن كان مفتوحًا في المحرر، وإلا null (يُقرأ من القرص). */
    String liveText(File buildFile);

    /** يستبدل علامات أسطر الاعتماد للملف (على خيط الواجهة). markers فارغة = لا أخطاء. */
    void publishDependencyMarkers(File buildFile, String text, List<ProjectLibraries.Marker> markers);

    /** اكتمل حلّ (ولو جزئيًا): إعادة الفهرسة والفحص. */
    void onLibrariesResolved();
  }

  private static final ProjectLibraries STATE = new ProjectLibraries();
  private static final long LIVE_DELAY_MS = 450;

  private final Activity activity;
  private final Host host;
  private final Handler main = new Handler(Looper.getMainLooper());
  private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
    Thread thread = new Thread(r, "dependency-cycle");
    thread.setDaemon(true);
    return thread;
  });
  private File root;
  private GradleBuildModel model;
  private int generation;
  /** طلب دورة أثناء تنزيل جارٍ: تُعاد بعد انتهائه. */
  private Mode rerun;

  public DependencyCycle(Activity activity, Host host) {
    this.activity = activity;
    this.host = host;
  }

  /** طُلب من الإعدادات حذف مكتبات المشروع المفتوح: يُعاد الحلّ عند العودة للمحرر. */
  private static volatile boolean recheck;

  /** مكتبات المشروع المفتوح حُذفت من المخزن (الإعدادات): تسقط حالتها ويُعاد فحصها عند العودة. */
  public static void librariesDeleted() {
    STATE.invalidate();
    almlk.LibraryClassIndex.clear();
    MavenStore.publishInstalled(java.util.Collections.<String, List<String>>emptyMap());
    recheck = true;
  }

  /** يستهلك طلب إعادة الفحص (مرة واحدة). */
  public static boolean consumeRecheck() {
    boolean pending = recheck;
    recheck = false;
    return pending;
  }

  /** حالة المكتبات المحقونة للمشروع الحالي (classpath للتحليل والإكمال). */
  public static ProjectLibraries state() {
    return STATE;
  }

  /** نموذج الوحدة المحمَّل للمشروع الحالي (أو null). */
  public GradleBuildModel model() {
    return model;
  }

  /** إغلاق المشروع: إلغاء أي تنزيل وإسقاط الحالة والعلامات. */
  public void reset() {
    generation++;
    rerun = null;
    MavenDownloadDialog.cancelActive();
    STATE.clear();
    almlk.LibraryClassIndex.clear();
    if (model != null) host.publishDependencyMarkers(model.buildFile, model.text, java.util.Collections.<ProjectLibraries.Marker>emptyList());
    model = null;
    root = null;
  }

  public void start(File projectRoot, Mode mode) {
    if (projectRoot == null) return;
    if (root != null && !root.equals(projectRoot)) reset();
    root = projectRoot;
    if (MavenDownloadDialog.isRunning()) {
      // تنزيل جارٍ لهذا المشروع: يكتمل أولًا ثم تُعاد الدورة بالملفات الجديدة.
      rerun = mode == Mode.REFRESH || rerun == Mode.REFRESH ? Mode.REFRESH
          : mode == Mode.REFRESH_BUILD || rerun == Mode.REFRESH_BUILD ? Mode.REFRESH_BUILD : Mode.SAVE;
      MavenDownloadDialog.showActive();
      return;
    }
    final int run = ++generation;
    final File target = projectRoot;
    worker.execute(() -> {
      final GradleBuildModel loaded = GradleBuildModel.load(target);
      if (loaded == null) {
        main.post(() -> {
          if (run != generation) return;
          if (model != null) host.publishDependencyMarkers(model.buildFile, model.text, java.util.Collections.<ProjectLibraries.Marker>emptyList());
          model = null;
          STATE.clear();
          almlk.LibraryClassIndex.clear();
        });
        return;
      }
      // W22/4ب٢‑ب: خريطةُ ما أُدرِجَ في settings.gradle تُبنى هُنا — مرةً لكلِّ دورةٍ وعلى الخيطِ
      // العاملِ: لا قرصَ في خيطِ الواجهةِ ولا إعادةَ قراءةٍ مع كلِّ طلبٍ.
      loaded.projectModules = almlk.GradleProjectModules.of(loaded, apkSignerReader());
      // جولةُ ٤١: إصدارُ المشروعِ كما قالَهُ هُوَ — يُنشَرُ معَ دَورةِ المكتباتِ (عندَ الفتحِ وعندَ حفظِ
      // ‏build.gradle‏)، على خيطِ الدَّورةِ لا في الواجهةِ، ومَرَّةً واحدةً لكلِّ دَورةٍ: فَحصُ الإصداراتِ
      // لا يَعمَلُ بغيرِهِ، وبلا تَصريحٍ صَحيحٍ يَبقَى صامِتًا — لا وسمَ وَهميَّ على مشروعٍ لم يُحَدَّ ثَدُّهُ.
      almlk.ProjectPlatform.publish(platformOf(loaded));
      final MavenStore store = AppSettings.mavenStore(activity);
      final String fingerprint = ProjectLibraries.fingerprint(loaded, store);
      final List<MavenResolver.Repo> repos = MavenResolver.repositories(loaded, mavenLocal(), AppSettings.extraRepositories(activity));
      final List<MavenResolver.Request> requests = MavenResolver.requests(loaded);
      boolean automatic = mode == Mode.OPEN || mode == Mode.SAVE;
      if (automatic && STATE.isUpToDate(fingerprint)) {
        if (MavenStore.installedSnapshot().isEmpty()) MavenStore.publishInstalled(store.installedVersions());
        main.post(() -> {
          if (run != generation) return;
          model = loaded;
          publish();
        });
        return;
      }
      if (!automatic) {
        main.post(() -> {
          if (run != generation) return;
          model = loaded;
          download(run, store, repos, requests, fingerprint, mode);
        });
        return;
      }
      // فحص محلي بلا شبكة: الموجود يُحقن بصمت.
      final MavenResolver.Result local =
          new MavenResolver(store, repos, MavenResolver.OFFLINE).resolve(requests, false, null, null);
      STATE.apply(local, true, fingerprint);
      MavenStore.publishInstalled(store.installedVersions());
      final boolean needsDownload = needsNetwork(local);
      main.post(() -> {
        if (run != generation) return;
        model = loaded;
        publish();
        if (needsDownload) download(run, store, repos, requests, fingerprint, mode);
        else host.onLibrariesResolved();
      });
    });
  }

  /** نص ملف الوحدة تغيّر في المحرر: إعادة حساب العلامات من النص الحي بعد توقف قصير. */
  public void onEditorTextChanged(String reference) {
    if (model == null || !almlk.FileReferences.same(reference, model.buildFile.getAbsolutePath())) return;
    main.removeCallbacks(livePublish);
    main.postDelayed(livePublish, LIVE_DELAY_MS);
  }

  private final Runnable livePublish = this::publish;

  /** يحسب العلامات (النص الحي إن كان مفتوحًا، وإلا القرص) وينشرها. */
  private void publish() {
    final GradleBuildModel current = model;
    if (current == null) return;
    final String live = host.liveText(current.buildFile);
    final int run = generation;
    worker.execute(() -> {
      String text = live == null ? current.text : live;
      List<GradleBuildModel.Dependency> dependencies =
          live == null || live.equals(current.text) ? current.dependencies : current.reparse(live);
      final List<ProjectLibraries.Marker> markers = STATE.markers(text, dependencies);
      main.post(() -> {
        if (run == generation && current == model) host.publishDependencyMarkers(current.buildFile, text, markers);
      });
    });
  }

  private void download(final int run, final MavenStore store, List<MavenResolver.Repo> repos,
      List<MavenResolver.Request> requests, final String fingerprint, final Mode mode) {
    MavenResolver resolver =
        new MavenResolver(store, repos, new MavenDownloader()).refreshMetadata(mode == Mode.REFRESH_BUILD);
    final boolean interactive = mode == Mode.REFRESH || mode == Mode.REFRESH_BUILD;
    MavenDownloadDialog.start(activity, resolver, requests, mode == Mode.REFRESH, result -> {
      if (run == generation) {
        if (result.cancelled) STATE.cancelled();
        else STATE.apply(result, false, fingerprint);
        publish();
        MavenDownloadDialog.showOutcome(activity, result, interactive);
        if (!result.cancelled) host.onLibrariesResolved();
        worker.execute(() -> MavenStore.publishInstalled(store.installedVersions()));
      }
      Mode again = rerun;
      rerun = null;
      if (again != null && root != null) start(root, again);
    });
  }

  /** يحتاج الشبكة إن غاب شيء قابل للتنزيل (لا متغير ناقص ولا إصدار غائب فقط). */
  static boolean needsNetwork(MavenResolver.Result local) {
    for (MavenResolver.Failure failure : local.failures) {
      if (failure.type == MavenResolver.Failure.NOT_FOUND) return true;
    }
    return false;
  }

  private static File mavenLocal() {
    return new File(Environment.getExternalStorageDirectory(), ".m2/repository");
  }

  /**
   * ما يَقولُهُ نظامُ الجهازِ عن حزمةٍ على القرصِ: اسمُ الحزمةِ وإصدارُها وموقِّعُها — قراءةٌ
   * ب‏{@code getPackageArchiveInfo} لا تشغيلٌ، وبلا ‏{@code apksigner} ولا ‏{@code jarsigner}.
   * ‏{@code GET_SIGNATURES} لا ‏{@code GET_SIGNING_CERTIFICATES}: لأنَّ الحزمةَ قد تُقرَأُ على جهازٍ
   * أقدمَ من الإصدارِ الثامنِ والعِشرِينَ، والهدفُ سطرٌ في لوحةٍ لا تَحقِيقٌ أمنيٌّ.
   */
  /**
   * ‏build.gradle‏ أولًا (هُناكَ ‏defaultConfig‏ و‏minSdk/compileSdk/targetSdk‏)، ثمَّ
   * ‏AndroidManifest.xml‏ يَملَأُ ما لم يُصَرَّحْ فيهِ — كترتيبِ المرجعِ بينَ ‏`GradleInfo`‏ و
   * ‏`AndroidManifestRead`‏. ولا قِراءةَ قرصَ لملفٍّ غائبٍ أو جَديبٍ: ما قالَهُ الغْرافُ يَكفي،
   * والصَّمتُ أَولى من وَهمٍ على مشروبِ البِناءِ.
   */
  static almlk.ProjectPlatform platformOf(almlk.GradleBuildModel model) {
    almlk.ProjectPlatform p =
        model == null || model.text == null
            ? almlk.ProjectPlatform.unknown()
            : almlk.ProjectPlatform.fromGradle(model.text);
    if (model == null || model.buildFile == null) return p;
    java.io.File dir = model.buildFile.getParentFile();
    if (dir == null) return p;
    java.io.File manifest = new java.io.File(dir, "src/main/AndroidManifest.xml");
    if (!manifest.isFile()) manifest = new java.io.File(dir, "AndroidManifest.xml");
    if (!manifest.isFile() && dir.getParentFile() != null)
      manifest = new java.io.File(dir.getParentFile(), "app/src/main/AndroidManifest.xml");
    if (!manifest.isFile() || manifest.length() <= 0 || manifest.length() > 4 * 1024 * 1024) return p;
    java.io.InputStream in = null;
    try {
      in = new java.io.FileInputStream(manifest);
      byte[] buf = new byte[(int) manifest.length()];
      int got = 0;
      while (got < buf.length) {
        int n = in.read(buf, got, buf.length - got);
        if (n <= 0) break;
        got += n;
      }
      p = p.mergedWith(almlk.ProjectPlatform.fromManifest(new String(buf, 0, got, "UTF-8")));
    } catch (java.io.IOException unreadable) {
      // لا حُكمَ على مانيفستٍ لا يُقرَأُ: ما قالَهُ الغْرافُ وحدَهُ يُنشَرُ.
    } finally {
      if (in != null) {
        try {
          in.close();
        } catch (java.io.IOException ignored) {
        }
      }
    }
    return p;
  }

  private almlk.ApkArtifacts.SignerReader apkSignerReader() {
    final android.content.Context context = activity;
    return new almlk.ApkArtifacts.SignerReader() {
      @Override
      public String describe(java.io.File apk) {
        if (context == null || apk == null || !apk.isFile()) return null;
        try {
          android.content.pm.PackageInfo info = context.getPackageManager().getPackageArchiveInfo(
              apk.getAbsolutePath(), android.content.pm.PackageManager.GET_SIGNATURES);
          if (info == null) return null;
          StringBuilder out = new StringBuilder();
          if (info.packageName != null) out.append(info.packageName);
          if (info.versionName != null) {
            if (out.length() > 0) out.append(' ');
            out.append(info.versionName);
          }
          if (info.signatures == null || info.signatures.length == 0) {
            if (out.length() > 0) out.append(' ');
            return out.append("unsigned").toString();
          }
          byte[] sha = java.security.MessageDigest.getInstance("SHA-1")
              .digest(info.signatures[0].toByteArray());
          if (out.length() > 0) out.append(' ');
          out.append("signed by");
          for (int i = 0; i < 8 && i < sha.length; i++) {
            out.append(' ').append(Integer.toHexString((sha[i] & 0xff) | 0x100).substring(1));
          }
          return out.toString();
        } catch (Exception failure) {
          return null; // حزمةٌ لا تُقرَأُ تَصيرُ علامةَ «لا موقِّعَ»، لا استثناءً في خيطِ الخلفيّةِ
        }
      }
    };
  }
}
