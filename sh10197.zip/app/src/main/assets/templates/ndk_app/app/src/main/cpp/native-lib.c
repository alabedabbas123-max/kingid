#include <jni.h>

JNIEXPORT jstring JNICALL
Java_$package_name_jni$_MainActivity_stringFromJNI(JNIEnv *env, jobject thiz) {
    return (*env)->NewStringUTF(env, "مرحبًا من الكود الأصلي C");
}
