package $package_name$;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;

/**
 * Firebase بلا ملفِّ `google-services.json`: التهيئةُ يدويّةٌ من `firebase-bom`، والإحصاءُ
 * يُرسَلُ إن وُجِدَتْ إعداداتٌ؛ لا يفشَلُ البناءُ بغيابِها (إضافةُ بلوقنِ google-services
 * تختارُها أنتَ حينَ يكونُ الملفُّ عندَكَ).
 */
public class MainActivity extends AppCompatActivity {

    private FirebaseAnalytics analytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
        try {
            FirebaseApp.initializeApp(this);
            analytics = FirebaseAnalytics.getInstance(this);
            analytics.logEvent(FirebaseAnalytics.Event.APP_OPENED, null);
        } catch (Throwable absent) {
            if (message != null) message.setText("Firebase unavailable: " + absent.getMessage());
        }
    }
}
