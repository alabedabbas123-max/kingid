package $package_name$;

import android.content.Context;

/** وحدةُ مكتبةٍ: تُضافُ إلى مشروعٍ آخرَ بـ`project(':library')` أو بملفِّ AAR في `libs/`. */
public final class ShimaLibrary {

    private ShimaLibrary() {}

    public static String describe(Context context) {
        return "$project_name$ library, host " + context.getPackageName();
    }

    public static int versionCode() {
        return 1;
    }
}
