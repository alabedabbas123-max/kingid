package $package_name$;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;

/** Firebase على مكتباتِ الدعمِ القديمةِ (16.x) — تهيئةٌ يدويّةٌ بلا google-services.json. */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
        try {
            FirebaseApp.initializeApp(this);
            FirebaseAnalytics.getInstance(this).logEvent(FirebaseAnalytics.Event.APP_OPENED, null);
        } catch (Throwable absent) {
            if (message != null) message.setText("Firebase unavailable: " + absent.getMessage());
        }
    }
}
