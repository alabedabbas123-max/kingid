package $package_name$;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/** نقطة دخول وحدة Xposed — سجّل خطافاتك هنا. */
public class HookInit implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        XposedBridge.log("$project_name$: تم تحميل الحزمة " + lpparam.packageName);
    }
}
