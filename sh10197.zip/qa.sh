#!/usr/bin/env bash
# مجموعة الانحدار الدائمة — المرحلة التاسعة.
#
# تُشغَّل بأمر واحد:  ./qa.sh
# بلا أي تبعية خارجية (لا JUnit ولا Gradle): جافا صرفة + بدائل android.content وandroid.os
# تحت qa/host-stubs/ (خارجَ جذورِ مصادرِ المشروعِ عمدًا): لتشغيل منطق التفضيلات والملوّن التزايدي خارج android.jar،
# ولا يُفهرَسُ شيئٌ منهُ على الجهازِ — فملفٌّ باسمِ android.content.Context لا يجوزُ أن يكونَ تعريفَ ذلكَ الصنفِ.
#
# حدّ التغطية: أصناف المنطق الصرفة (12 من 19 في almlk + سجل القوائم + أدوات اللغة).
# أصناف الرسم تغطيها qa/acceptance.sh (البناء + فحص الحزمة) لأنها تحتاج جهازًا.

set -uo pipefail
cd "$(dirname "$0")"

# ── حارسُ اللقطةِ: مجلدٌ باسمِ build مُستثنًى من لقطةِ مساحةِ العملِ، فدليلُهُ يَفرَغُ بين الجولاتِ ──
# المنطقُ في qa/attic/restore.sh وحدَهُ (آلةٌ واحدةٌ تُجرى هنا وقبلَ البناءِ عندَ الحاجةِ).
sh qa/attic/restore.sh


# ── إيجاد JDK ────────────────────────────────────────────────────────────
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/javac" ]; then
  JAVAC="$JAVA_HOME/bin/javac"; JAVA="$JAVA_HOME/bin/java"
elif [ -x /home/user/.cache/jdk21/bin/javac ]; then
  JAVAC=/home/user/.cache/jdk21/bin/javac; JAVA=/home/user/.cache/jdk21/bin/java
elif command -v javac >/dev/null 2>&1; then
  JAVAC=$(command -v javac); JAVA=$(command -v java)
else
  echo "✘ لم يُعثر على JDK. شغّل .cache_setup.sh أولًا أو اضبط JAVA_HOME." >&2
  exit 2
fi

SRC=app/src/main/java
OUT=qa/.out
rm -rf "$OUT"; mkdir -p "$OUT"

# ── الترجمة ──────────────────────────────────────────────────────────────
echo "### [1/2] ترجمة المجموعة ..."
"$JAVAC" -encoding UTF-8 -nowarn -proc:none \
  -sourcepath "qa/host-stubs:qa/probes:$SRC" -d "$OUT" \
  qa/host-stubs/android/content/Context.java \
  qa/host-stubs/android/content/SharedPreferences.java \
  qa/host-stubs/android/preference/PreferenceManager.java \
  qa/host-stubs/android/os/Looper.java \
  qa/host-stubs/android/os/Handler.java \
  qa/host-stubs/android/database/sqlite/SQLiteOpenHelper.java \
  "$SRC/almlk/CodeStyle.java" \
  "$SRC/almlk/FileTypeIcons.java" \
  "$SRC/almlk/JavaDiagnosticCodes.java" \
  "$SRC/almlk/DiagnosticBudget.java" \
  "$SRC/almlk/AnalysisPace.java" \
  "$SRC/almlk/ProjectPlatform.java" \
  "$SRC/almlk/UiFormat.java" \
  "$SRC/almlk/EditorDirtyLedger.java" \
  "$SRC/almlk/ProjectScanPace.java" \
  "$SRC/almlk/DeclarationWatch.java" \
  "$SRC/almlk/ProjectSourceRoots.java" \
  "$SRC/almlk/LibraryInstallState.java" \
  "$SRC/almlk/AarExploder.java" \
  "$SRC/almlk/LocalLibraries.java" \
  "$SRC/almlk/RepositoryPolicy.java" \
  "$SRC/almlk/CompletionRules.java" \
  "$SRC/almlk/BuildOutputLocator.java" \
  "$SRC/almlk/ProjectNaming.java" \
  "$SRC/almlk/JavaLangObjectSurface.java" \
  "$SRC/almlk/JavaImportResolver.java" \
  "$SRC/almlk/DiagnosticSpanIndex.java" \
  "$SRC/almlk/IdentifierBounds.java" \
  "$SRC/almlk/LineBuffer.java" \
  "$SRC/almlk/LineDocument.java" \
  "$SRC/almlk/LineStyler.java" \
  "$SRC/almlk/LineOffsetTable.java" \
  "$SRC/almlk/DiagnosticUnderline.java" \
  "$SRC/almlk/EditorKeyInput.java" \
  "$SRC/almlk/QuickKeySequences.java" \
  "$SRC/almlk/QuickKeyToolPolicy.java" \
  "$SRC/almlk/JavaLocalScope.java" \
  "$SRC/almlk/PlatformMemberLookup.java" \
  "$SRC/almlk/JavaCodeAnalyzer.java" \
  "$SRC/almlk/JavaSyntaxChecker.java" \
  "$SRC/almlk/GradleDependencyEditor.java" \
  "$SRC/almlk/GradleLibraryLinks.java" \
  "$SRC/almlk/GradleSigningConfigs.java" \
  "$SRC/almlk/ApkArtifacts.java" \
  "$SRC/almlk/ApkInstallPlan.java" \
  "$SRC/almlk/KeystoreInspector.java" \
  "$SRC/almlk/GradleSourceSets.java" \
  "$SRC/almlk/GradleProjectModules.java" \
  "$SRC/almlk/ConsoleBuffer.java" \
  "$SRC/almlk/MavenStore.java" \
  "$SRC/almlk/GradleBuildModel.java" \
  "$SRC/almlk/MavenVersion.java" \
  "$SRC/almlk/MavenPom.java" \
  "$SRC/almlk/MavenDownloader.java" \
  "$SRC/almlk/MavenResolver.java" \
  "$SRC/almlk/ProjectLibraries.java" \
  "$SRC/almlk/ClassFileReader.java" \
  "$SRC/almlk/LibraryClassIndex.java" \
  "$SRC/almlk/AppSettings.java" \
  "$SRC/almlk/QuickFix.java" \
  "$SRC/almlk/AnalyzerProtocol.java" \
  "$SRC/almlk/IncrementalScope.java" \
  "$SRC/almlk/MarkTable.java" \
  "$SRC/almlk/MarkBinding.java" \
  "$SRC/almlk/IdentifierOccurrences.java" \
  "$SRC/almlk/ImportSoundness.java" \
  "$SRC/almlk/DependencyFetchPlan.java" \
  "$SRC/almlk/UnresolvedSymbolRule.java" \
  "$SRC/almlk/DependencyFetchQueue.java" \
  "$SRC/almlk/ImportFixActions.java" \
  "$SRC/almlk/AnalysisTargets.java" \
  "$SRC/almlk/ErrorBrowserPolicy.java" \
  "$SRC/almlk/AbstractImplementationGap.java" \
  "$SRC/almlk/AnalyzerQueue.java" \
  "$SRC/com/almlkid/analyzer/AnalyzerWire.java" \
  "$SRC/com/almlkid/kay/ui/ProjectSymbolIndex.java" \
  "$SRC/almlk/StyleRunBatcher.java" \
  "$SRC/almlk/UndoRedoStack.java" \
  "$SRC/almlk/XmlColorLiteral.java" \
  "$SRC/almlk/XmlCodeFormatter.java" \
  "$SRC/almlk/XmlCommentEditor.java" \
  "$SRC/almlk/XmlResourceIndex.java" \
  "$SRC/almlk/XmlResourceReference.java" \
  "$SRC/almlk/XmlStructureScanner.java" \
  "$SRC/almlk/XmlCompletionEngine.java" \
  "$SRC/almlk/AndroidApiIndex.java" \
  "$SRC/almlk/AndroidManifestModel.java" \
  "$SRC/almlk/AndroidXMigration.java" \
  "$SRC/almlk/GradleCompletionProvider.java" \
  "$SRC/almlk/CompletionMatcher.java" \
  "$SRC/almlk/JavaSourceOutline.java" \
  "$SRC/almlk/JavaCompletionProvider.java" \
  "$SRC/almlk/GradleCompletionProvider.java" \
  "$SRC/almlk/CompletionPopupPlacement.java" \
  "$SRC/almlk/SelectionExpansion.java" \
  "$SRC/almlk/JsonText.java" \
  "$SRC/almlk/JsonBeanGenerator.java" \
  "$SRC/almlk/CodeEscaper.java" \
  "$SRC/almlk/BatchReplacer.java" \
  "$SRC/almlk/SvgPathParser.java" \
  "$SRC/almlk/MaterialIconCatalog.java" \
  "$SRC/almlk/EditorThemePalette.java" \
  "$SRC/almlk/EditorSyntaxRoles.java" \
  "$SRC/almlk/EditorThemePresets.java" \
  "$SRC/almlk/EditorEmphasisPolicy.java" \
  "$SRC/almlk/AlphaCheckerPattern.java" \
  "$SRC/almlk/TemplateCatalog.java" \
  "$SRC/almlk/ProjectScaffold.java" \
  "$SRC/almlk/MavenMetadata.java" \
  "$SRC/almlk/MavenIndex.java" \
  "$SRC/almlk/MavenVersionSource.java" \
  "$SRC/com/almlkid/kay/ui/KayStyleCompletionEngine.java" \
  "$SRC/com/almlkid/ui/EditorMenuRegistry.java" \
  "$SRC/com/almlkid/kay/ui/CodeLanguageTools.java" \
  "$SRC/net/margaritov/preference/colorpicker/HexColorCodec.java" \
  qa/probes/almlk/ColorLiteralFactory.java \
  qa/RegressionSuite.java
if [ $? -ne 0 ]; then echo "✘ فشلت الترجمة" >&2; exit 2; fi

# ── التشغيل ──────────────────────────────────────────────────────────────
echo "### [2/2] تشغيل البوابات ..."
LANG=C.UTF-8 "$JAVA" -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$OUT" RegressionSuite
CODE=$?

rm -rf "$OUT"
if [ $CODE -eq 0 ]; then echo "### ✔ مجموعة الانحدار نجحت"; else echo "### ✘ مجموعة الانحدار فشلت" >&2; fi
exit $CODE
