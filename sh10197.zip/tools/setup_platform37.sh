#!/usr/bin/env bash
# منصةُ android-37 غيرُ معروضةٍ في القناةِ العامةِ، فتُركَّبُ فوقَ أحدثِ منصةٍ متاحةٍ بنفسِ بنيةِ الدليلِ
# (نفسُ ما كان في بيئةِ الأدوارِ السابقةِ): android-36.1 منسوخةٌ إلى android-37 مع تصحيحِ ApiLevel.
set -uo pipefail
export JAVA_HOME=/home/user/.cache/jdk17 ANDROID_HOME=/home/user/.cache/android-sdk
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses >/dev/null 2>&1
"$SDKM" "platforms;android-36.1" >/dev/null 2>&1 || "$SDKM" "platforms;android-36" >/dev/null 2>&1
src=$(ls -d "$ANDROID_HOME"/platforms/android-36* 2>/dev/null | head -1)
[ -z "$src" ] && { echo "✘ لا منصةَ متاحةٌ"; exit 1; }
dst="$ANDROID_HOME/platforms/android-37"
if [ ! -d "$dst" ]; then cp -r "$src" "$dst"; fi
if [ -f "$dst/source.properties" ]; then
  sed -i 's/^AndroidVersion.ApiLevel=.*/AndroidVersion.ApiLevel=37/' "$dst/source.properties"
  sed -i 's/^AndroidVersion.Preview based on.*/AndroidVersion.Preview based on=37/' "$dst/source.properties" || true
fi
echo "✔ dst=$dst"; grep -E "ApiLevel|Display|Id" "$dst/source.properties"; ls "$dst" | head; du -sh "$dst"
