#!/usr/bin/env python3
"""تجهيزُ التسليماتِ — دورةُ البندِ 1 حرفيًّا.

يُنسخُ `app/build/outputs/apk/debug/app-debug.apk` إلى `deliverables/shima_X_Y_Z.apk` باسمِ
`VERSION`، ويُبنَى `shima_X_Y_Z.zip` من مجموعةٍ مُعلَنةٍ صراحةً: ملفاتُ الجذرِ المُعرَّفةُ والمجلداتُ
المسموحُ بها. الاستبعادُ **بأسماءِ المكوّناتِ لا بجُزءٍ مُطابِقٍ في المسارِ**: درسٌ وقعَ — نمطٌ
فرعيٌّ مثل «build/» يبتلعُ `app/build.gradle` و`.gradle` يبتلعُ `settings.gradle`، فتخرجُ حزمةٌ
مصدريّةٌ ناقصةُ أغلى ما فيها. لذا قائمةُ المجلداتِ الممنوعةِ ومجموعةُ أسماءِ الملفاتِ الممنوعةِ
وقواعدُ السوابقِ، ثمَّ بوابةُ قبولٍ في `qa/acceptance.sh` [7] تُصادقُ على النتيجةِ.
يُجرَى من جذرِ المشروعِ: `python3 tools/package_deliverables.py`.
"""

import io, os, zipfile, hashlib
V = io.open("VERSION", encoding="utf-8").read().strip()
under = V.replace(".", "_")
src = "app/build/outputs/apk/debug/app-debug.apk"
dst = "deliverables/shima_%s.apk" % under
io.open(dst, "wb").write(io.open(src, "rb").read())
print("apk bytes", os.path.getsize(dst), "md5", hashlib.md5(io.open(dst, "rb").read()).hexdigest())

ALLOW_DIRS = ["app", "qa", "reports", "gradle", "signing", "tools"]
ROOT_FILES = [".gitignore", "VERSION", "qa.sh", "build.gradle", "settings.gradle",
              "gradle.properties", "gradlew", "gradlew.bat"]
ROOT_FILES += sorted(f for f in os.listdir(".") if f.endswith(".md") and os.path.isfile(f))
EXC_DIRS = {"build", ".gradle", "__pycache__", "deliverables", ".idea", "outputs", "intermediates",
              "tmp", ".out"}   # ‏1.0.197: ‏qa/.out‏ مُخَرَّجاتُ البَوَّابَةِ — إن تُرِكَ (جَولَةٌ قُطِعَت) حَمَلَتهُ
EXC_FILES = {"local.properties"}
EXC_SUFFIX = (".iml", ".pyc")

# «build» اسمُ حزمةِ شيفرةٍ في المرجعِ (com/almlkid/ui/build) كما اسمُ مجلدِ مخرجاتِ Gradle:
# تُستثنى المخرجاتُ ولا تُستثنى الشيفرةُ — وإلا خرجَتِ الحزمةُ المصدريّةُ ناقصةً بلا خطأٍ.
def pruned(name, rel):
    if name not in EXC_DIRS:
        return False
    return "/src/" not in rel

paths = [f for f in ROOT_FILES if os.path.isfile(f)]
for d in ALLOW_DIRS:
    for root, dirs, files in os.walk(d):
        rel = os.path.relpath(root, ".").replace(os.sep, "/")
        dirs[:] = sorted(x for x in dirs if not pruned(x, rel + "/" + x))
        keep = rel.split("/")
        if any(part in EXC_DIRS and not ("/src/" in rel) for part in keep):
            continue
        for name in files:
            if name in EXC_FILES or name.endswith(EXC_SUFFIX):
                continue
            paths.append(os.path.join(root, name).replace(os.sep, "/"))
paths = sorted(set(paths))
zp = "deliverables/shima_%s.zip" % under
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for rel in paths:
        z.write(rel, rel)
data = io.open(zp, "rb").read()
print("zip entries", len(paths), "bytes", len(data), "md5", hashlib.md5(data).hexdigest())
for probe in ("app/build.gradle", "app/src/main/assets/templates/androidx_app/build.gradle",
              "app/src/main/assets/templates/androidx_app/settings.gradle",
              "app/src/main/assets/templates/gradle_lib/library/build.gradle",
              "tools/make_templates.py"):
    print("  ", probe in paths, probe)
def is_output(p_):
    head = p_.split("/")
    return ("build" in head[:-1] and "/src/" not in p_) or "intermediates" in head or ".gradle" in head
missing = sorted(set(os.path.relpath(os.path.join(r, n), ".").replace(os.sep, "/")
                     for r, d, fs in os.walk("app/src/main/java") for n in fs if n.endswith(".java")) - set(paths))
print("   leaked?", [p_ for p_ in paths if "local.properties" in p_ or is_output(p_) or p_.endswith(".iml")])
print("   java files not packaged?", len(missing), missing[:6])
