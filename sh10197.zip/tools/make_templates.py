#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""مولِّدُ قوالبِ الإنشاءِ ومخطَّطِها (W22/2a).

سبب وجودِهِ: مخطَّطُ `templates.json` ونصوصُ القوالبِ يجبُ ألا يفترقا — فسطورُ
الاعتمادياتِ التي يولّدها «مُنتقى الإصدارِ» تُكتَبُ من نفسِ القائمةِ التي يقرؤُها
المعالجُ. لا يُشغَّلُ في البناءِ؛ يُشغَّلُ عندَ تعديلِ القوالبِ:

    python3 tools/make_templates.py

يكتبُ `app/src/main/assets/templates/templates.json` وكلَّ مجلدِ قالبٍ تحتَ
`app/src/main/assets/templates/<id>/`. الملفاتُ التي لا يلمسُها (مثلَ `cpp/` في
ndk_app و`libs/compile_only/*.jar` و`assets/xposed_init` و`HookInit.java` في
xposed_app) تبقى كما هي — هذا المولِّدُ يُعيدُ كتابةَ ما يعرفُهُ فقطْ.
"""
import io
import json
import os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "assets", "templates")
ROOT = os.path.normpath(ROOT)

MARKER = "// shima:dependencies"

ICON_VECTOR = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <path
        android:fillColor="#3DDC84"
        android:pathData="M24,4C13.5,4 5,12.5 5,23c0,4.3 1.5,8.3 4,11.5l-2.6,4.1 4.9,-1.9C14.8,40 19.2,42 24,42s9.2,-2 12.7,-5.3l4.9,1.9 -2.6,-4.1c2.5,-3.2 4,-7.2 4,-11.5C43,12.5 34.5,4 24,4ZM16,20a2.5,2.5 0,1 1,0 -5,2.5 2.5 0,0 1,0 5ZM32,20a2.5,2.5 0,1 1,0 -5,2.5 2.5 0,0 1,0 5Z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M16,27h16v2H16Z" />
</vector>
"""

PROGUARD = """# قواعدُ حمايةٍ لهذا المشروعِ — تُقرأُ عندَ تفعيلِ minifyEnabled في build.gradle.
# لا تخفِ ما يحتاجُهُ الانعكاسُ: طبقةُ التطبيقِ وحدَها، والأدواتُ تُبقي ما تستدعيهِ.
-dontwarn java.lang.invoke.StringConcatFactory
-keep class $package_name$.** { *; }
"""

KEEP_TXT = """هذا المجلدُ للقواريرِ المحليّةِ (jar/aar).
ألقِ أيَّ مكتبةٍ هنا وستُدخَلُ في البناءِ تلقائيًّا: build.gradle فيه
    implementation fileTree(dir: "libs", include: ["*.jar", "*.aar"])
ملفاتُ `.txt` مثلَ هذا لا تدخلُ الاعتمادياتِ؛ ضعْ هنا أيضًا `libs.versions.toml`
عندَ اعتمادِ منصّةِ التوغلاتِ الحديثِ (catalog).
"""

GITIGNORE = """*.iml
.gradle/
/local.properties
/.idea/
.DS_Store
build/
/captures
.externalNativeBuild
.cxx
local.properties
"""


def version_lines(specs):
    """سطورُ dependencies المولَّدةُ من المُنتقياتِ (لا تُكتَبُ يدويًّا في مكانٍ آخرَ)."""
    out = []
    for spec in specs:
        if not spec.get("mode", "dependency").startswith("depend"):
            continue
        coord = spec["coordinate"].replace("$version$", "$%s_version$" % spec["key"])
        if coord.startswith("platform("):
            out.append("    implementation platform('%s')" % coord[len("platform("):-1])
        else:
            out.append("    implementation '%s'" % coord)
    return out


def root_gradle(t):
    lines = [
        "// مشروع $project_name$ — قالبُ «%s» من Shima." % t["id"],
        "// الإصداراتُ هنا تُملأُ من مُنتقياتِ المعالجِ (أو قيمِها الافتراضيّةِ) عندَ الإنشاءِ.",
        "buildscript {",
        "    ext {",
        "        agp_version = '$agp_version$'",
    ]
    if any(s["key"] == "kotlin" for s in t.get("versions", [])):
        lines.append("        kotlin_version = '$kotlin_version$'")
    lines += [
        "    }",
        "",
        "    repositories {",
        "        google()",
        "        mavenCentral()",
        "    }",
        "",
        "    dependencies {",
        "        classpath \"com.android.tools.build:gradle:$agp_version$\"",
    ]
    if any(s["key"] == "kotlin" for s in t.get("versions", [])):
        lines.append('        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version$"')
    lines += [
        "    }",
        "}",
        "",
        "allprojects {",
        "    repositories {",
        "        google()",
        "        mavenCentral()",
        "        maven { url 'https://jitpack.io' }",
        "    }",
        "}",
        "",
        "tasks.register('clean', Delete) {",
        "    delete rootProject.layout.buildDirectory",
        "}",
        "",
    ]
    return "\n".join(lines)


def settings_gradle(t):
    return (
        "pluginManagement {\n"
        "    repositories {\n"
        "        google()\n"
        "        mavenCentral()\n"
        "        gradlePluginPortal()\n"
        "    }\n"
        "}\n"
        "\n"
        "rootProject.name = \"$project_name$\"\n"
        "include ':%s'\n" % t["main"]
    )


def gradle_properties(t):
    g = t["gradle"]
    lines = ["org.gradle.jvmargs=%s" % g.get("jvmargs", "-Xmx2048m"), "org.gradle.parallel=true"]
    if g.get("androidx"):
        lines += ["android.useAndroidX=true", "android.enableJetifier=false"]
    else:
        lines += ["# مكتباتُ android.support القديمةُ: لا AndroidX ولا تصحيحَ آليًّا."]
    if any(s["key"] == "kotlin" for s in t.get("versions", [])):
        lines.append("kotlin.code.style=official")
    lines.append("# التوقيعُ النهائيُّ في هذا المشروعِ يدويٌّ حتى تُنشِئَ مفتاحًا (قائمةُ المشروعِ ← Sign).")
    return "\n".join(lines) + "\n"


def module_gradle(t):
    main = t["main"]
    lib = t.get("type") == "library"
    kotlin = any(s["key"] == "kotlin" for s in t.get("versions", []))
    native = t.get("flavor") == "native"
    lines = ["// وحدةُ %s — مشروعُ $project_name$" % main]
    lines.append("apply plugin: 'com.android.%s'" % ("library" if lib else "application"))
    if kotlin:
        lines.append("apply plugin: 'kotlin-android'")
    lines.append("apply plugin: 'maven-publish'") if lib else None
    lines += [
        "",
        "android {",
        "    namespace '$package_name$'",
        "    compileSdk $compile_sdk$",
        "",
        "    defaultConfig {",
    ]
    if not lib:
        lines += ["        applicationId \"$package_name$\""]
    lines += [
        "        minSdkVersion $min_sdk$",
        "        targetSdkVersion $target_sdk$",
        "        versionCode 1",
        "        versionName \"1.0\"",
    ]
    if native:
        lines += [
            "",
            "        ndk {",
            "            abiFilters 'armeabi-v7a', 'arm64-v8a', 'x86_64'",
            "        }",
        ]
    lines.append("    }")
    if native:
        lines += [
            "",
            "    externalNativeBuild {",
            "        cmake {",
            "            path \"src/main/cpp/CMakeLists.txt\"",
            "        }",
            "    }",
        ]
    lines += [
        "",
        "    compileOptions {",
        "        sourceCompatibility JavaVersion.VERSION_17",
        "        targetCompatibility JavaVersion.VERSION_17",
        "    }",
        "",
        "    lintOptions {",
        "        abortOnError false",
        "        disable 'MissingTranslation'",
        "    }",
        "",
        "    buildTypes {",
        "        release {",
        "            minifyEnabled false",
        "            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'",
        "        }",
        "    }",
    ]
    if lib:
        lines += [
            "",
            "    publishing {",
            "        singleVariant(\"release\") {",
            "            withSourcesJar()",
            "        }",
            "    }",
        ]
    lines += ["}", "", "dependencies {", "    %s — يختارُ المعالجُ أسطرَ المُنتقياتِ تحتَ هذا السطرِ، ولا يُكرِّرُ موجودًا." % MARKER]
    lines.append('    implementation fileTree(dir: "libs", include: ["*.jar", "*.aar"])')
    if t.get("flavor") == "xposed":
        lines.append("    compileOnly fileTree(dir: 'libs/compile_only', include: ['*.jar'])")
    lines += version_lines(t.get("versions", []))
    lines += ["}", ""]
    return "\n".join(lines)


def manifest(t):
    lib = t.get("type") == "library"
    flavor = t.get("flavor", "plain")
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
    ]
    if flavor in ("admob", "firebase"):
        lines += [
            "",
            '    <uses-permission android:name="android.permission.INTERNET" />',
            '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
        ]
    if lib:
        lines += ["", "    <application android:allowBackup=\"true\" android:label=\"@string/app_name\" />", "", "</manifest>", ""]
        return "\n".join(lines)
    theme = t.get("theme", "@style/AppTheme")
    has_app_class = "App.java" in (t.get("extra") or {})
    application_name = "\n        android:name=\".App\"" if has_app_class else ""
    lines += [
        "",
        "    <application",
        '        android:allowBackup="true"%s' % application_name,
        '        android:icon="@drawable/ic_launcher"',
        '        android:label="@string/app_name"',
        '        android:supportsRtl="true"',
        '        android:theme="%s">' % theme,
    ]
    if flavor == "admob":
        lines += [
            "",
            '        <meta-data',
            '            android:name="com.google.android.gms.ads.APPLICATION_ID"',
            '            android:value="ca-app-pub-3940256099942544~3347513743" />',
        ]
    if flavor == "xposed":
        lines += [
            "",
            '        <meta-data android:name="xposedmodule" android:value="true" />',
            '        <meta-data android:name="xposedminversion" android:value="82" />',
            '        <meta-data android:name="xposeddescription" android:value="$project_name$" />',
        ]
    lines += [
        "",
        '        <activity android:name=".MainActivity"',
        '            android:exported="true"',
        '            android:label="@string/app_name">',
        "            <intent-filter>",
        '                <action android:name="android.intent.action.MAIN" />',
        '                <category android:name="android.intent.category.LAUNCHER" />',
        "            </intent-filter>",
        "        </activity>",
        "    </application>",
        "",
        "</manifest>",
        "",
    ]
    return "\n".join(lines)


STRINGS = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">$project_name$</string>
    <string name="hello_world">مرحبًا بك في $project_name$!</string>
    <string name="action_retry">إعادة المحاولة</string>
</resources>
"""

COLORS = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#3DDC84</color>
    <color name="colorPrimaryDark">#0B3D2E</color>
    <color name="colorAccent">#FF8F00</color>
    <color name="windowBackground">#FFFFFF</color>
    <color name="textPrimary">#1B1B1B</color>
</resources>
"""


def themes(t):
    parent = t.get("theme_parent", "@android:style/Theme.Material.Light.DarkActionBar")
    return (
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
        "<resources>\n"
        "    <style name=\"AppTheme\" parent=\"%s\">\n" % parent
        + "        <item name=\"colorPrimary\">@color/colorPrimary</item>\n"
        + "        <item name=\"colorPrimaryDark\">@color/colorPrimaryDark</item>\n"
        + "        <item name=\"colorAccent\">@color/colorAccent</item>\n"
        + "        <item name=\"android:windowBackground\">@color/windowBackground</item>\n"
        + "    </style>\n</resources>\n"
    )


def layout(t):
    """صفحةٌ واحدةٌ ببنيةٍ لا تحتاجُ ConstraintLayout لتعملَ: LinearLayout + نصٌّ (+ زرٌّ/بانرٌ)."""
    flavor = t.get("flavor", "plain")
    has_ad = flavor == "admob"
    head = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"',
    ]
    if has_ad:
        head.append('    xmlns:ads="http://schemas.android.com/apk/res-auto"')
    head += [
        '    android:layout_width="match_parent"',
        '    android:layout_height="match_parent"',
        '    android:gravity="center"',
        '    android:orientation="vertical"',
        '    android:padding="24dp">',
    ]
    body = [
        '',
        '    <TextView',
        '        android:id="@+id/message"',
        '        android:layout_width="wrap_content"',
        '        android:layout_height="wrap_content"',
        '        android:text="@string/hello_world"',
        '        android:textSize="20sp" />',
    ]
    if flavor in ("androidx", "plain", "basic", "appcompat", "native", "xposed", "firebase"):
        body += [
            '',
            '    <Button',
            '        android:id="@+id/action"',
            '        android:layout_width="wrap_content"',
            '        android:layout_height="wrap_content"',
            '        android:layout_marginTop="16dp"',
            '        android:text="@string/action_retry" />',
        ]
    if has_ad:
        body += [
            '',
            '    <com.google.android.gms.ads.AdView',
            '        android:id="@+id/ad_view"',
            '        android:layout_width="wrap_content"',
            '        android:layout_height="wrap_content"',
            '        android:layout_marginTop="24dp"',
            '        ads:adSize="BANNER"',
            '        ads:adUnitId="ca-app-pub-3940256099942544/6300978111" />',
        ]
    return "\n".join(head + body) + "\n\n</LinearLayout>\n"


JAVA_MAIN = """package $package_name$;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** نقطةُ البدايةِ — قالبُ «$project_name$». */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
    }
}
"""

SUPPORT_MAIN = """package $package_name$;

import android.os.Bundle;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;

/** MainActivity على مكتباتِ android.support القديمةِ (قالبُ AppCompat الكلاسيكيُّ). */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
    }
}
"""

ANDROIDX_MAIN = """package $package_name$;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/** MainActivity على AndroidX (AppCompat 1.x). */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
    }
}
"""

ADMOB_ANDROIDX_MAIN = """package $package_name$;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

/** Banner اختباريٌّ من Google (المعرّفُ في AndroidManifest هو معرّفُ الاختبارِ العامُّ). */
public class MainActivity extends AppCompatActivity {

    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
        adView = findViewById(R.id.ad_view);
        MobileAds.initialize(
                this,
                new OnInitializationCompleteListener() {
                    @Override
                    public void onInitializationComplete(InitializationStatus status) {
                        if (adView != null) adView.loadAd(new AdRequest.Builder().build());
                    }
                });
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        super.onDestroy();
    }
}
"""

ADMOB_LEGACY_MAIN = """package $package_name$;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

/** Banner اختباريٌّ على مكتباتِ الدعمِ القديمةِ (play-services-ads 15.x). */
public class MainActivity extends AppCompatActivity {

    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
        adView = (AdView) findViewById(R.id.ad_view);
        if (adView != null) adView.loadAd(new AdRequest.Builder().build());
    }

    @Override
    protected void onPause() {
        if (adView != null) adView.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        super.onDestroy();
    }
}
"""

FIREBASE_ANDROIDX_MAIN = """package $package_name$;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;

/**
 * Firebase بلا ملفِّ `google-services.json`: التهيئةُ يدويّةٌ من `firebase-bom`، والإحصاءُ
 * يُرسَلُ إن وُجِدَتْ إعداداتٌ؛ لا يفشَلُ البناءُ بغيابِها (إضافةُ بلوقنِ google-services
 * تختارُها أنتَ حينَ يكونُ الملفُّ عندَكَ).
 */
public class MainActivity extends AppCompatActivity {

    private FirebaseAnalytics analytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
        try {
            FirebaseApp.initializeApp(this);
            analytics = FirebaseAnalytics.getInstance(this);
            analytics.logEvent(FirebaseAnalytics.Event.APP_OPENED, null);
        } catch (Throwable absent) {
            if (message != null) message.setText("Firebase unavailable: " + absent.getMessage());
        }
    }
}
"""

FIREBASE_LEGACY_MAIN = """package $package_name$;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;

/** Firebase على مكتباتِ الدعمِ القديمةِ (16.x) — تهيئةٌ يدويّةٌ بلا google-services.json. */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(getString(R.string.hello_world));
        try {
            FirebaseApp.initializeApp(this);
            FirebaseAnalytics.getInstance(this).logEvent(FirebaseAnalytics.Event.APP_OPENED, null);
        } catch (Throwable absent) {
            if (message != null) message.setText("Firebase unavailable: " + absent.getMessage());
        }
    }
}
"""

NATIVE_MAIN = """package $package_name$;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** يستدعي الكودَ الأصليَّ: `native-lib` مبنيٌّ بـCMake من `src/main/cpp`. */
public class MainActivity extends Activity {

    static {
        System.loadLibrary("native-lib");
    }

    public native String stringFromJNI();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) message.setText(stringFromJNI());
    }
}
"""

XPOSED_MAIN = """package $package_name$;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** واجهةٌ بسيطةٌ تُعلنُ أنَّ الحزمةَ مُثبَّتةٌ؛ الخطّافُ في `HookInit.java`. */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView message = (TextView) findViewById(R.id.message);
        if (message != null) {
            message.setText(getString(R.string.hello_world) + "\\nXposed module: " + getPackageName());
        }
    }
}
"""

KOTLIN_MAIN = """package $package_name$

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** نقطةُ البدايةِ بـKotlin — تُبنى بـ`kotlin-android`، ولا يلوّنُها محرِّرُ Javac. */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.message)?.text = getString(R.string.hello_world)
    }
}
"""

LIBRARY_JAVA = """package $package_name$;

import android.content.Context;

/** وحدةُ مكتبةٍ: تُضافُ إلى مشروعٍ آخرَ بـ`project(':library')` أو بملفِّ AAR في `libs/`. */
public final class ShimaLibrary {

    private ShimaLibrary() {}

    public static String describe(Context context) {
        return "$project_name$ library, host " + context.getPackageName();
    }

    public static int versionCode() {
        return 1;
    }
}
"""

APP_CLASS = """package $package_name$;

import android.app.Application;
import android.os.Build;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * تطبيقٌ يرصدُ السقوطَ: كلُّ استثناءٍ غيرِ معالَجٍ يُكتَبُ في `getExternalFilesDir(null)` أو
 * مجلدِ التخزينِ الداخليِّ، ويُرفَقُ بسطرِ الإصدارِ — ليعرفَ المطوِّرُ سببَ السقوطِ بلا adb.
 */
public class App extends Application {

    private static final String TAG = "$package_name$";

    @Override
    public void onCreate() {
        super.onCreate();
        installCrashReporter();
    }

    private void installCrashReporter() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(
                new Thread.UncaughtExceptionHandler() {
                    @Override
                    public void uncaughtException(Thread thread, Throwable error) {
                        try {
                            File dir = getExternalFilesDir(null);
                            if (dir == null) dir = getFilesDir();
                            if (!dir.isDirectory() && !dir.mkdirs()) return;
                            File log = new File(dir, "crash-" + System.currentTimeMillis() + ".txt");
                            PrintWriter out = new PrintWriter(new FileWriter(log));
                            out.println("device: " + Build.MANUFACTURER + " " + Build.MODEL + " api " + Build.VERSION.SDK_INT);
                            out.println("thread: " + thread.getName());
                            error.printStackTrace(out);
                            out.close();
                            Log.e(TAG, "crash written to " + log.getAbsolutePath(), error);
                        } catch (Throwable ignored) {
                        } finally {
                            if (previous != null) previous.uncaughtException(thread, error);
                        }
                    }
                });
    }
}
"""


def main_class_for(t):
    flavor = t.get("flavor", "plain")
    if t.get("type") == "library":
        return None
    kotlin = any(s["key"] == "kotlin" for s in t.get("versions", []))
    if kotlin:
        return KOTLIN_MAIN
    if flavor == "androidx":
        return ANDROIDX_MAIN
    if flavor == "admob":
        return ADMOB_ANDROIDX_MAIN if t["gradle"].get("androidx") else ADMOB_LEGACY_MAIN
    if flavor == "firebase":
        return FIREBASE_ANDROIDX_MAIN if t["gradle"].get("androidx") else FIREBASE_LEGACY_MAIN
    if flavor == "native":
        return NATIVE_MAIN
    if flavor == "xposed":
        return XPOSED_MAIN
    return JAVA_MAIN


# ═══════════════════════ المخطَّطُ ═══════════════════════


def V(key, label, options, default=0, coordinate=None, prop=None, file=None):
    spec = {"key": key, "label": "ui_wizard_version_" + label, "options": options, "default": default}
    if coordinate:
        spec["mode"] = "dependency"
        spec["coordinate"] = coordinate
    else:
        spec["mode"] = "property"
        spec["prop"] = prop or (key + "_version")
        spec["file"] = file or "build.gradle"
    return spec


ANDROID_GRADLE = {"agp": "8.5.2", "wrapper": "8.7", "compileSdk": 34, "minSdk": 21, "targetSdk": 34,
                  "androidx": True, "jvmargs": "-Xmx2048m"}
LEGACY_GRADLE = {"agp": "7.4.2", "wrapper": "7.6.4", "compileSdk": 28, "minSdk": 14, "targetSdk": 28,
                 "androidx": False, "jvmargs": "-Xmx2048m"}

TEMPLATES = [
    {
        "id": "android_app", "title": "ui_template_android_app_title", "description": "ui_template_android_app_description",
        "icon": "ic_project_android", "type": "android", "main": "app", "flavor": "plain",
        "gradle": dict(ANDROID_GRADLE, compileSdk=34, minSdk=26, targetSdk=34, androidx=False),
        "versions": [
            V("appcompat", "appcompat", ["1.6.1", "1.4.2", "1.3.1"], 0, "androidx.appcompat:appcompat:$version$"),
            V("material", "material", ["1.11.0", "1.9.0", "1.6.1"], 0, "com.google.android.material:material:$version$"),
        ],
        "theme_parent": "@android:style/Theme.Material.Light.DarkActionBar",
    },
    {
        "id": "basic_app", "title": "ui_template_basic_app_title", "description": "ui_template_basic_app_description",
        "icon": "ic_tpl_rocket", "type": "android", "main": "app", "flavor": "basic",
        "gradle": dict(ANDROID_GRADLE, compileSdk=34, minSdk=21, targetSdk=34, androidx=False),
        "versions": [
            V("constraintlayout", "constraint", ["2.1.4", "2.0.4"], 0, "androidx.constraintlayout:constraintlayout:$version$"),
        ],
        "theme_parent": "@android:style/Theme.Material.Light.DarkActionBar",
        "extra": {"App.java": APP_CLASS},
    },
    {
        "id": "appcompat_app", "title": "ui_template_appcompat_title", "description": "ui_template_appcompat_description",
        "icon": "ic_project_android", "type": "android", "main": "app", "flavor": "appcompat",
        "gradle": dict(LEGACY_GRADLE),
        "versions": [
            V("support_appcompat", "support_appcompat", ["28.0.0", "27.1.1", "26.1.0"], 0, "com.android.support:appcompat-v7:$version$"),
        ],
        "theme_parent": "@style/Theme.AppCompat.Light.DarkActionBar",
    },
    {
        "id": "androidx_app", "title": "ui_template_androidx_app_title", "description": "ui_template_androidx_app_description",
        "icon": "ic_project_android", "type": "android", "main": "app", "flavor": "androidx",
        "gradle": dict(ANDROID_GRADLE),
        "versions": [
            V("appcompat", "appcompat", ["1.6.1", "1.4.2", "1.3.1"], 0, "androidx.appcompat:appcompat:$version$"),
            V("material", "material", ["1.11.0", "1.9.0", "1.6.1"], 0, "com.google.android.material:material:$version$"),
            V("constraintlayout", "constraint", ["2.1.4", "2.0.4"], 0, "androidx.constraintlayout:constraintlayout:$version$"),
            V("agp", "agp", ["8.5.2", "8.2.2", "7.4.2"], 0, None),
        ],
        "theme_parent": "@style/Theme.MaterialComponents.DayNight.DarkActionBar",
    },
    {
        "id": "admob_appcompat", "title": "ui_template_admob_legacy_title", "description": "ui_template_admob_legacy_description",
        "icon": "ic_tpl_admob", "type": "android", "main": "app", "flavor": "admob", "hide": False,
        "category": "admob",
        "gradle": dict(LEGACY_GRADLE, minSdk=16),
        "versions": [V("play_services_ads", "ads", ["15.0.1", "12.0.1", "11.8.0"], 0, "com.google.android.gms:play-services-ads:$version$"),
                     V("support_appcompat", "support_appcompat", ["28.0.0", "27.1.1"], 0, "com.android.support:appcompat-v7:$version$")],
        "theme_parent": "@style/Theme.AppCompat.Light.DarkActionBar",
    },
    {
        "id": "admob_androidx", "title": "ui_template_admob_androidx_title", "description": "ui_template_admob_androidx_description",
        "icon": "ic_tpl_admob", "type": "android", "main": "app", "flavor": "admob", "category": "admob",
        "gradle": dict(ANDROID_GRADLE, minSdk=19),
        "versions": [V("play_services_ads", "ads", ["23.2.0", "22.6.0", "20.6.0"], 0, "com.google.android.gms:play-services-ads:$version$"),
                     V("appcompat", "appcompat", ["1.6.1", "1.4.2"], 0, "androidx.appcompat:appcompat:$version$")],
        "theme_parent": "@style/Theme.MaterialComponents.DayNight.DarkActionBar",
    },
    {
        "id": "firebase_appcompat", "title": "ui_template_firebase_legacy_title", "description": "ui_template_firebase_legacy_description",
        "icon": "ic_tpl_firebase", "type": "android", "main": "app", "flavor": "firebase", "category": "firebase",
        "gradle": dict(LEGACY_GRADLE, minSdk=16),
        "versions": [V("firebase_legacy", "firebase", ["16.0.9", "16.0.4", "15.0.2"], 0, "com.google.firebase:firebase-core:$version$"),
                     V("support_appcompat", "support_appcompat", ["28.0.0", "27.1.1"], 0, "com.android.support:appcompat-v7:$version$")],
        "theme_parent": "@style/Theme.AppCompat.Light.DarkActionBar",
    },
    {
        "id": "firebase_androidx", "title": "ui_template_firebase_androidx_title", "description": "ui_template_firebase_androidx_description",
        "icon": "ic_tpl_firebase", "type": "android", "main": "app", "flavor": "firebase", "category": "firebase",
        "gradle": dict(ANDROID_GRADLE, minSdk=19),
        "versions": [V("firebase_bom", "firebase_bom", ["33.5.1", "32.7.4", "31.5.0"], 0, "platform(com.google.firebase:firebase-bom:$version$)"),
                     V("firebase_analytics", "firebase_analytics", ["22.1.2", "21.5.1"], 0, "com.google.firebase:firebase-analytics:$version$"),
                     V("appcompat", "appcompat", ["1.6.1", "1.4.2"], 0, "androidx.appcompat:appcompat:$version$")],
        "theme_parent": "@style/Theme.MaterialComponents.DayNight.DarkActionBar",
    },
    {
        "id": "kotlin_app", "title": "ui_template_kotlin_title", "description": "ui_template_kotlin_description",
        "icon": "ic_tpl_kotlin", "type": "android", "main": "app", "flavor": "androidx", "category": "gradle",
        "gradle": dict(ANDROID_GRADLE, minSdk=21),
        "versions": [V("kotlin", "kotlin", ["2.0.0", "1.9.24", "1.8.22"], 0, None),
                     V("core_ktx", "core_ktx", ["1.13.1", "1.10.1"], 0, "androidx.core:core-ktx:$version$"),
                     V("appcompat", "appcompat", ["1.6.1", "1.4.2"], 0, "androidx.appcompat:appcompat:$version$")],
        "theme_parent": "@style/Theme.MaterialComponents.DayNight.DarkActionBar",
        "sources": {"kt": True},
    },
    {
        "id": "ndk_app", "title": "ui_template_ndk_app_title", "description": "ui_template_ndk_app_description",
        "icon": "ic_tpl_gradle", "type": "android", "main": "app", "flavor": "native", "category": "gradle",
        "gradle": dict(ANDROID_GRADLE, androidx=False),
        "versions": [],
        "theme_parent": "@android:style/Theme.Material.Light.DarkActionBar",
    },
    {
        "id": "gradle_lib", "title": "ui_template_library_title", "description": "ui_template_library_description",
        "icon": "ic_tpl_gradle", "type": "library", "main": "library", "flavor": "library", "category": "gradle",
        "gradle": dict(ANDROID_GRADLE),
        "versions": [V("appcompat", "appcompat", ["1.6.1", "1.4.2"], 0, "androidx.appcompat:appcompat:$version$")],
        "theme_parent": "@style/Theme.MaterialComponents.DayNight",
    },
    {
        "id": "xposed_app", "title": "ui_template_xposed_app_title", "description": "ui_template_xposed_app_description",
        "icon": "ic_project_xposed", "type": "android", "main": "app", "flavor": "xposed", "hide": True,
        "category": "hidden",
        "gradle": dict(ANDROID_GRADLE, compileSdk=34, minSdk=26, targetSdk=34, androidx=False),
        "versions": [],
        "theme_parent": "@android:style/Theme.Material.Light.DarkActionBar",
    },
    {
        "id": "java_console", "title": "ui_template_java_console_title", "description": "ui_template_java_console_description",
        "icon": "ic_project_java", "type": "java", "main": "", "flavor": "java", "hide": True, "category": "hidden",
        "gradle": {"agp": "8.5.2", "wrapper": "8.7", "compileSdk": 34, "minSdk": 26, "targetSdk": 34,
                   "androidx": False, "jvmargs": "-Xmx2048m"},
        "versions": [],
        "theme_parent": "@android:style/Theme.Material.Light.DarkActionBar",
    },
]

CATEGORY_ORDER = [
    ("android", "ui_project_category_android", "ic_androidstudio", False),
    ("admob", "ui_project_category_admob", "ic_tpl_admob", False),
    ("firebase", "ui_project_category_firebase", "ic_tpl_firebase", False),
    ("gradle", "ui_project_category_gradle", "ic_tpl_gradle", False),
    ("hidden", "ui_project_category_other", "ic_androidstudio", True),
]


def build_json():
    categories = []
    for key, title, icon, hide in CATEGORY_ORDER:
        members = [t for t in TEMPLATES if t.get("category", "android") == key]
        templates = []
        for t in members:
            entry = {
                "id": t["id"],
                "title": t["title"],
                "description": t["description"],
                "icon": t["icon"],
                "type": t["type"],
                "main": t["main"],
                "open": [],
                "replaces": ["*.xml", "*.java", "*.gradle", "*.kt", "*.c", "*.cpp", "*.properties", "*.md"],
                "gradle": t["gradle"],
                "versions": t["versions"],
            }
            if t.get("hide"):
                entry["hide"] = True
            if t["type"] == "java":
                entry["open"] = ["src/$package_name$/Main.java"]
            elif t["type"] == "library":
                entry["open"] = ["library/src/main/java/$package_name$/ShimaLibrary.java", "library/build.gradle"]
            else:
                main = t.get("sources", {}).get("kt") and "MainActivity.kt" or "MainActivity.java"
                entry["open"] = [
                    "%s/src/main/java/$package_name$/%s" % (t["main"], main),
                    "%s/src/main/res/layout/activity_main.xml" % t["main"],
                    "%s/src/main/AndroidManifest.xml" % t["main"],
                    "%s/build.gradle" % t["main"],
                ]
            templates.append(entry)
        if templates:
            categories.append({"title": title, "icon": icon, "templates": templates, "hide": hide})
    return {"categories": categories}


def write(path, text):
    full = os.path.join(ROOT, path)
    if os.path.isfile(full):
        old = io.open(full, encoding="utf-8").read()
        if old == text:
            return 0
    os.makedirs(os.path.dirname(full), exist_ok=True)
    io.open(full, "w", encoding="utf-8", newline="\n").write(text)
    return 1


STALE_VALUES = ("styles.xml",)


def prune(t):
    """يشطُبُ ما يُبدِّلُهُ المولَّدُ: `styles.xml` (يُكرِّرُ AppTheme مع themes.xml) و`ic_launcher.png`.

    بلا هذا التشذيبِ يفشَلُ aapt بـ«duplicate resources» في القالبِ المُنشَأِ — وهو أسوأُ من
    قالبٍ ناقصٍ، لأنَّ الخطأَ يظهرُ بعدَ الإنشاءِ لا قبلَهُ.
    """
    removed = 0
    base = os.path.join(ROOT, t["id"])
    res = os.path.join(base, t["main"], "src", "main", "res")
    for folder, doomed in (("values", STALE_VALUES), ("drawable", ("ic_launcher.png", "ic_launcher.jpg"))):
        target = os.path.join(res, folder)
        if not os.path.isdir(target):
            continue
        for name in os.listdir(target):
            if name in doomed:
                os.remove(os.path.join(target, name))
                removed += 1
    stale_gitignore = os.path.join(base, t["main"], "dot_gitignore")
    if os.path.isfile(stale_gitignore):
        os.remove(stale_gitignore)
        removed += 1
    return removed


def emit_template(t):
    if t["type"] == "java":
        return 0  # java_console: شجرةٌ بسيطةٌ لا gradle فيها، تُترَكُ كما هي
    written = prune(t)
    main = t["main"]
    src = "%s/src/main" % main
    pkgdir = "%s/java/pkg" % src
    lib = t.get("type") == "library"
    kotlin = t.get("sources", {}).get("kt")
    written += write(os.path.join(t["id"], "build.gradle"), root_gradle(t))
    written += write(os.path.join(t["id"], "settings.gradle"), settings_gradle(t))
    written += write(os.path.join(t["id"], "gradle.properties"), gradle_properties(t))
    written += write(os.path.join(t["id"], "dot_gitignore"), GITIGNORE)
    written += write(os.path.join(t["id"], main, "build.gradle"), module_gradle(t))
    written += write(os.path.join(t["id"], main, "proguard-rules.pro"), PROGUARD)
    written += write(os.path.join(t["id"], main, "libs", "keep.txt"), KEEP_TXT)
    written += write(os.path.join(t["id"], src, "AndroidManifest.xml"), manifest(t))
    body = main_class_for(t)
    if body is not None:
        name = "MainActivity.kt" if kotlin else "MainActivity.java"
        written += write(os.path.join(t["id"], pkgdir, name), body)
    if t.get("extra"):
        for fname, content in t["extra"].items():
            written += write(os.path.join(t["id"], pkgdir, fname), content)
    if lib:
        written += write(os.path.join(t["id"], pkgdir, "ShimaLibrary.java"), LIBRARY_JAVA)
    if not lib:
        written += write(os.path.join(t["id"], src, "res", "layout", "activity_main.xml"), layout(t))
        written += write(os.path.join(t["id"], src, "res", "values", "strings.xml"), STRINGS)
        written += write(os.path.join(t["id"], src, "res", "values", "colors.xml"), COLORS)
        written += write(os.path.join(t["id"], src, "res", "values", "themes.xml"), themes(t))
        written += write(os.path.join(t["id"], src, "res", "drawable", "ic_launcher.xml"), ICON_VECTOR)
    return written


def main():
    os.makedirs(ROOT, exist_ok=True)
    catalog = build_json()
    text = json.dumps(catalog, ensure_ascii=False, indent=2) + "\n"
    changed = write("templates.json", text)
    touched = 0
    for t in TEMPLATES:
        touched += emit_template(t)
    print("templates.json: %s | %d categories, %d templates | ملفاتٌ كُتِبَتْ/حُدِّثَتْ: %d"
          % ("written" if changed else "unchanged", len(catalog["categories"]),
             sum(len(c["templates"]) for c in catalog["categories"]), touched))


if __name__ == "__main__":
    main()
