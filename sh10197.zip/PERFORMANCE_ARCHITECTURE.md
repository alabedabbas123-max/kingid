# بنية الأداء في ShimaExact

## 1. المبدأ العام

الواجهة لا تقرأ القرص ولا تفك ترميز ملف ولا تفهرس المشروع. كل عملية ثقيلة تمر عبر Worker، ثم تعود النتيجة إلى Main Thread عبر `Handler`. قاعدة مهمة:

```text
UI/Main: state + draw + user events فقط
IO pool: File/SAF read/write + UTF-8 decode
Analysis pool: lexer + symbol index + diagnostics
Cache: LRU bounded by bytes
Session: metadata only
```

لا يمكن ضمان «صفر تهنيج» حرفيًا على كل جهاز، لكن هذه الحدود تمنع السبب الأكثر شيوعًا للـ ANR: disk I/O وعمليات التحليل الثقيلة داخل Main Thread.

## 2. Instant Session Restoration

الملف `com/shima/performance/InstantSessionStore.java` يستخدم `SharedPreferences` ويخزن فقط:

```json
{
  "version": 1,
  "selected": "MainActivity.java",
  "tabs": [
    {
      "name": "MainActivity.java",
      "reference": "/storage/emulated/0/AppProjects/Demo/app/src/MainActivity.java",
      "cursor": 320,
      "scrollX": 0,
      "scrollY": 840
    }
  ]
}
```

لا يوجد `content` في الـ JSON. عند بدء التطبيق:

1. يقرأ `AIDEEditorPager` الـ metadata على worker.
2. ينشئ شريط التبويبات فورًا.
3. يعرض التبويب المحدد.
4. لا يفتح `reference` إلا عند اختيار التبويب.
5. يستعيد المؤشر والتمرير بعد اكتمال القراءة.

الاستخدام:

```java
completionWorker.execute(() -> {
    InstantSessionStore.Snapshot snapshot = sessionStore.load();
    post(() -> applyInstantSession(snapshot, listener));
});
```

عند الإيقاف، يتم حفظ metadata فقط باستخدام `apply()`، كما يتم حذف snapshots القديمة التي كانت تخزن النصوص في `session-tabs`.

## 3. File I/O و LRU Cache

`FileSystemRepository` هو بوابة القراءة والكتابة الوحيدة للمحرر:

```java
repository.readTextAsync(
    reference,
    fileName,
    8 * 1024 * 1024,
    (path, text, error) -> {
        if (error != null) {
            showEncodingError(error);
            return;
        }
        editor.setText(text);
    });
```

- يدعم مسار `File` و`content://` من SAF.
- يستخدم pool من خيطين منخفضي الأولوية.
- يعيد النتيجة إلى `Handler(Looper.getMainLooper())`.
- `FileContentCache` هو `LruCache` موزون بحجم UTF-16، بسقف 4 MB.
- الملف الواحد الأكبر من السقف لا يطرد كامل cache.
- `writeTextBlocking` مخصص لـ worker فقط، ويكتب باستبدال الملف وليس append؛ ويمكن إضافة temp+rename عند الحاجة لذرية أعلى.

ممنوع:

```java
// خطأ: لا تستدعِ هذا من onClick/onDraw أو MainActivity مباشرة
repository.readTextBlocking(path, name, limit);
```

## 4. الترميز UTF-8

`EncodingManager` يفرض UTF-8 صريحًا:

```java
String source = EncodingManager.readUtf8(input, maxBytes);
byte[] bytes = EncodingManager.encodeUtf8(source);
```

السلوك:

- يزيل UTF-8 BOM عند القراءة.
- لا يستخدم `new String(bytes)` بالترميز الافتراضي للجهاز.
- يستخدم `CharsetDecoder` مع `REPORT`؛ الملف المعطوب يرفض بدل إنتاج Mojibake.
- الكتابة لا تصدر BOM، ما يجعل الناتج ثابتًا بين الأجهزة.
- الحد الافتراضي 8 MB لحماية الذاكرة؛ يمكن تعديل الحد لملفات المشروع.

## 5. العمال والتزامن

المكونات الحالية موزعة حسب نوع العمل:

| المهمة | المنفذ |
|---|---|
| قراءة/كتابة النص | `FileSystemRepository` — `shima-file-io` |
| فتح المجلدات | `BrowserPager.directoryReader` |
| التحليل اللغوي | `AlmlkEditor.languageWorker` |
| فهرسة الرموز | `BrowserPager.symbolWorker` |
| الاقتراحات والـ quick-fix | `AIDEEditorPager.completionWorker` |

كل عملية تحليل تستخدم generation/request id؛ إذا بدأ المستخدم عملية أحدث، تُهمل نتيجة العملية القديمة ولا تكتب فوق النص الحالي.

## 6. Viewport/Virtualization Editor

أضيفت:

- `LineArrayModel`: يخزن الأسطر ومواقع بدايتها ويقدم تحويل offset ↔ line/column بالبحث الثنائي.
- `ViewportCodeEditorView`: يرسم فقط:

```java
int first = Math.max(0, (getScrollY() - getPaddingTop()) / lineHeight - 1);
int last = Math.min(model.lineCount() - 1,
    (getScrollY() + getHeight()) / lineHeight + 1);
for (int line = first; line <= last; line++) {
    canvas.drawText(model.lineAt(line), x, baseline(line), paint);
}
```

يدعم الأساس الحالي:

- تمرير أفقي وعمودي يدوي bounded.
- تحديد طويل باللمس والسحب.
- `ScaleGestureDetector` للتكبير والتصغير مع حد أدنى وأقصى.
- رسم المؤشر والتحديد دون إنشاء `Span` لكل حرف.

هذا الـ View معزول كطبقة foundation حتى لا تنكسر ميزات `AlmlkEditor` الحالية مثل التحرير، الإكمال، التشخيص، وActionMode. مرحلة الترحيل التالية هي جعل `AlmlkEditor` يستخدم نفس `LineArrayModel` بدل Android `Layout` للملفات الكبيرة فقط، مع إبقاء `EditText` للملفات الصغيرة.

## 7. الربط في التطبيق

```text
BrowserPager
  -> fileReference(name) = File path أو SAF URI
  -> listener(name, content)

MainActivity
  -> editor.openFile(name, content, reference)

AIDEEditorPager
  -> sessionReferences[name] = reference
  -> tab UI فورًا
  -> FileSystemRepository عند selectFile فقط
  -> AlmlkEditor للتحليل على worker

onPause/onStop
  -> saveSession()
  -> InstantSessionStore: references + cursors فقط
```

## 8. التحليل الدلالي والاقتراحات

أضيفت `KayStyleCompletionEngine` فوق `ProjectSymbolIndex`:

- بعد `new` يظهر `CompletionItem.CLASS` فقط.
- بعد `receiver.` يتم حل نوع المتغير من التصريح أو `new` أو cast، ثم إرجاع أعضاء النوع نفسه فقط، بما في ذلك الوراثة.
- عند عدم حل نوع المستقبل، تكون النتيجة فارغة بدل تسريب اقتراحات عامة خاطئة.
- يتم تجاهل النصوص والتعليقات أثناء اكتشاف السياق.
- أسماء `import` تضاف إلى سجل الكلاسات حتى قبل اكتمال فهرسة المصدر.

```java
List<ProjectSymbolIndex.CompletionItem> items =
    KayStyleCompletionEngine.complete(fileName, source, cursorOffset);
```

`UsageSearchEngine` يحتفظ بمواقع الأحرف ويخفي التعليقات والسلاسل النصية دون تغيير offsets، ثم يصنف الاستخدام إلى method call أو reference. يمرر `BrowserPager` مسح المشروع إلى `symbolWorker` بحد أقصى 1000 نتيجة.

الانتقال إلى التعريف يعمل أولًا عبر `ProjectSymbolIndex`، ثم يستخدم مسح declarations كـ fallback إذا لم تكتمل الفهرسة بعد.

## 9. اللوحات المتتالية

أضيف `SequentialPanelHost` باستخدام `ViewPager` بخمس صفحات ثابتة:

1. الأخطاء — تعرض `No errors` عند عدم وجود أخطاء.
2. Search Results — تعرض الاستخدامات مع الملف والسطر والعمود، والنقر يفتح الموضع.
3. Build / Run Output.
4. Debugger.
5. LogCat.

الصفحات تنشأ مرة واحدة وتبقى حالتها محفوظة، بينما يسمح `ViewPager` بالسحب يمينًا ويسارًا. يمكن فتحها من قائمة View أو بالأوامر:

```java
showPanel(SequentialPanelHost.Panel.SEARCH);
showPanel(SequentialPanelHost.Panel.ERRORS);
```

## 10. ترقية Android وحفظ الألوان

تمت ترقية المشروع إلى Android 17 / API 37:

```gradle
android {
    compileSdk = 37
    buildToolsVersion = '37.0.0'

    defaultConfig {
        minSdk 26
        targetSdk = 37
    }
}
```

تم تحديث نظام البناء إلى AGP `9.4.0` وGradle `9.6.0` مع JDK 17. كما تم تحديث AndroidX Core إلى `1.19.1`، والإبقاء على بقية المكتبات عند أحدث إصداراتها المستقرة المتاحة:

- `androidx.drawerlayout:drawerlayout:1.2.0`
- `androidx.documentfile:documentfile:1.1.0`
- `androidx.viewpager:viewpager:1.1.0`
- `androidx.core:core:1.19.1`

في `ThemeConfig` أصبحت الألوان تحفظ بمفتاح مرتبط بالوضع (`dark` أو `light`) باستخدام `commit()` عند تأكيد منتقي اللون. لذلك:

- الحفظ يحدث مباشرة.
- إعادة فتح التطبيق لا تعيد اللون الافتراضي.
- تغيير الوضع لا يمسح الألوان المخصصة.
- توجد قراءة توافقية لمفاتيح الإصدارات القديمة.

## 11. الانتقال إلى التعريف والدرج الجانبي

تمت إضافة مسار مباشر لأمر Go To من قائمة المحرر، وليس فقط من ActionMode:

```text
حدد رمزًا → القائمة الرئيسية → انتقال إلى... → انتقال إلى التعريف
```

يعمل resolver بالترتيب التالي:

1. يحدد الرمز ونطاقه في الملف الحالي.
2. يبحث عن local variable أو field أو method أو class داخل نفس الملف.
3. يحل نوع receiver عند استخدام `object.method()` أو `object.field`.
4. يبحث في فهرس المشروع والكلاسات الموروثة.
5. يفتح virtual source لتعريفات مكتبات Android المعروفة.
6. يستخدم مسح declarations في بقية الملفات كـ fallback إذا لم تكتمل الفهرسة.

تم تحويل `SequentialPanelHost` إلى درج حقيقي داخل `mainFrame` مع scrim وحركة دخول وخروج، بدل نافذة مستقلة. الدرج يحتفظ بحالة الصفحات ويعرض:

- الأخطاء و`No errors`.
- Search Results والاستخدامات.
- Build / Run Output.
- Debugger.
- LogCat.

## 12. خوارزميات البحث السريع داخل المشروع

تمت إضافة `ProjectSearchEngine` ليكون محرك البحث الموحد للمحرر والبحث في المشروع كاملًا. التصميم يركز على السرعة وثبات الذاكرة:

- البحث الحرفي يستخدم `String.indexOf` بدل إنشاء Regex لكل ملف.
- البحث غير الحساس لحالة الأحرف يطبع النص مرة واحدة لكل ملف فقط، ثم يعيد استخدامه لكل التطابقات.
- خيار الكلمة الكاملة يتحقق من حدود `Java identifier` دون تحليل نحوي مكلف.
- Regex يُبنى مرة واحدة لكل ملف، مع التعامل الآمن مع `PatternSyntaxException`.
- حساب السطر والعمود يتم عبر `LineCursor` أحادي الاتجاه؛ لا توجد إعادة قراءة لبداية الملف مع كل نتيجة.
- النتائج محدودة افتراضيًا بـ 2000 نتيجة، والملف بـ 8 MB، مع إيقاف فوري عند إلغاء البحث.
- اجتياز المشروع يتم lazy وعلى worker thread، ويتجاوز `.git` و`.gradle` و`build` و`out` و`target` و`node_modules` والمجلدات الثنائية.
- تتم قراءة الملفات النصية المدعومة فقط، مع `FileContentCache` مرتبط بحجم الملف ووقت تعديله لتجنب النتائج القديمة.
- يدعم البحث ملفات Java/Kotlin/XML/Gradle/Properties/JSON/Markdown/YAML/HTML/CSS/JS/C/C++ وغيرها.
- تظهر النتائج في الدرج الجانبي، ويمكن فتح الملف والانتقال مباشرة إلى offset النتيجة.
- بحث الرموز وFind Usages ما زالا يستخدمان ماسحًا لغويًا منفصلًا يتجاهل التعليقات والسلاسل النصية، مع فهرسة مواضع الأسطر مرة واحدة.

من قائمة **بحث** يمكن اختيار:

1. بحث داخل الملف أو المشروع كاملًا.
2. مطابقة حالة الأحرف.
3. كلمة كاملة فقط.
4. Regex عند الحاجة.

## 13. الإكمال والتكبير الآمن

تم إصلاح مسار الإكمال ليعتمد `KayStyleCompletionEngine` أيضًا عند فتح قائمة الإكمال اليدوية، وليس فقط عند ظهور النافذة تلقائيًا. يدعم ذلك:

- متغيرًا من نوع كلاس: `widget.`.
- اسم كلاس مباشرة: `Widget.`.
- `this.` والحقول المتسلسلة مثل `holder.widget.` عند توفر النوع في الفهرس.
- كلاسات المشروع المفهرسة والكلاسات المعروفة من Android، مع الوراثة.

كما تم إزالة تكبير `Canvas` المؤقت أثناء pinch zoom. تكبير Canvas كان يغيّر clip الخاص بـ `TextView` وقد يجعل النص يختفي بعد التكبير أو التصغير. الحجم الجديد يطبّق بعد انتهاء الإيماءة فقط، مع حفظ موضع التمرير وإعادة التحليل دون حذف النص أو spans.

## 14. الاستفادة من بنية AndroidIDE

تمت مراجعة بنية AndroidIDE المفتوحة المصدر، خصوصًا الفصل بين خدمة اللغة والفهرس، مزود إكمال الأعضاء، إلغاء الطلبات القديمة، cache الإكمال، وخوارزمية Boyer-Moore للبحث. تم تطبيق هذه الأفكار داخل Shima بصياغة Java خفيفة مستقلة، من دون نسخ كود AndroidIDE أو إضافة طبقة Kotlin/LSP كبيرة إلى التطبيق:

- `ProjectSymbolIndex` أصبح يعيد ترتيب النتائج بمستويات exact/prefix/camel-case/subsequence بدل الترتيب الأبجدي فقط.
- `KayStyleCompletionEngine` يفصل سياق العضو عن سياق الاسم والكلاس ويدعم receiver ثابتًا أو متغيرًا وسلاسل الأنواع.
- `AIDEEditorPager` يحتوي cache صغيرًا للسياق المحلي، ويعيد تصفية النتائج عند تمديد الاسم بدل إعادة بناء كل الاقتراحات.
- `ProjectSearchEngine` يستخدم Boyer-Moore/Horspool للبحث الحرفي ويحافظ على UTF-16 offsets المطلوبة لفتح الموضع الصحيح.
- `BrowserPager` يبني catalog للملفات بالبيانات الوصفية فقط، ثم يقرأ المحتوى lazy. لذلك لا تعاد عملية اجتياز شجرة المشروع عند كل بحث، وتُفتح نتائج XML/Kotlin/Gradle وغيرها مباشرة من نفس الفهرس.
- Find Usages يستخدم catalog المشروع الكامل وذاكرة المحتوى، مع استمرار تجاهل التعليقات والسلاسل النصية.

## 15. التحقق

تم اختبار `EncodingManager` و`LineArrayModel` و`KayStyleCompletionEngine` و`UsageSearchEngine` باختبارات Java صغيرة. كما تم بناء APK API 37 بنجاح والتحقق من توقيعه باستخدام v1 وv2. أمر البناء:

```bash
cd /home/user/ShimaProject
./gradlew :app:packageDebug --no-daemon --max-workers=1
```

الإصدار الحالي يستخدم JDK 17 وAndroid Gradle Plugin 9.4.0 وGradle 9.6.0.


## 16. مسار سرعة المحرر والإكمال

تم فصل تحسينات السرعة الجديدة عن واجهة العرض حتى تبقى قابلة للتوسعة داخل Java المملوكة لتطبيق Shima:

- `EditorTextSnapshot` يحدّث نسخة النص حسب النطاق المتغير، ثم ينسخ النص الكامل على worker فقط. لذلك لا تستدعي لوحة الإكمال أو محلل اللغة `EditText.getText().toString()` أثناء ضغطة المفتاح.
- `CompletionLookupCache` يعيد استخدام نتيجة السياق نفسه أثناء تمديد البادئة، مع فحص hash للمصدر لمنع النتائج القديمة.
- إلغاء طلب الإكمال السابق يتم عبر `Future.cancel(true)` قبل جدولة الطلب الأحدث، فلا تتراكم طلبات الكتابة السريعة في طابور worker.
- `EditorEditHistory` يحفظ نطاق التعديل فقط بدل نسخ الملف كاملًا لكل حرف، مع الإبقاء على حد أقصى 30 عملية undo/redo.
- تم تثبيت Regex الخاصة باكتشاف الإنشاءات والتحويلات في `ProjectSymbolIndex`، كما أصبح snapshot أسماء الكلاسات يعاد استخدامه بدل فرزه عند كل طلب.
- تحليل الألوان والتشخيصات ينسخ المصدر على worker، ويعيد استخدام المصدر المفهرس عند تحديث viewport فقط. وتستمر generation checks في منع تطبيق نتيجة قديمة.

جميع هذه الطبقات تدخل DEX الناتج من كود Shima نفسه عبر Gradle؛ لا يتم إدخال DEX أو bytecode من أي مشروع خارجي.

## 17. الفهرس الدائم وTrie للإكمال

تمت إضافة `PersistentSymbolIndexStore` باستخدام SQLite المحلي الخاص بتطبيق Shima. يحفظ فقط fingerprint للملف والرموز المستخرجة، ولا يحفظ مصدر المشروع داخل قاعدة البيانات:

- عند فتح المشروع يعاد بناء catalog المجلدات على worker، ثم تُستعاد كلاسات Java غير المعدلة من SQLite إلى `ProjectSymbolIndex` مباشرة.
- لا تتم قراءة أو تحليل مصدر Java إلا للملفات الجديدة أو التي تغيّر الحجم/وقت التعديل الخاص بها.
- عند حفظ ملف Java يتم تحديث سجل ذلك الملف فقط، ولا يعاد تحليل بقية المشروع.
- `CompletionTrie` يفهرس أسماء الكلاسات وأعضاء الأنواع في الذاكرة. مسار `mkay.` يستخدم نوع المتغير من الفهرس ثم يبحث في Trie الأعضاء بدل مسح قائمة كل الدوال.
- يبقى البحث التقريبي/camel-case كمسار fallback فقط عندما لا توجد نتيجة prefix مباشرة.
- الفهرس الدائم يُنظف من الملفات التي لم تعد موجودة، مع بقاء الفشل في قاعدة البيانات غير قاتل؛ عند حدوثه يستمر الفهرس RAM والعمل من المصدر.
